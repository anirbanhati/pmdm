import re
from typing import List, Optional

class RuleGrammar:
    """Grammar for generating valid rule expressions"""
    
    def __init__(self):
        self.variable_patterns = {
            'assignment': '{var} := IIF[ValidateEmptyAttributes["{attr}"{flags}],""',
            'value_append': 'Concat[" "{separator}, AttributeValue["{attr}"{flags}]]',
            'suppression': '{var} :=IIF[{condition_var}="{condition_val}","",{var}];',
            'concat': 'Concat[{vars}]'
        }
        
        self.known_attributes = {
            "Calc_Brand": {"var": "calc_brand", "suppress_values": []},
            "Material_type": {"var": "material_type", "suppress_values": [" Wooden"]},
            "Use_Foldable": {"var": "use_foldable", "suppress_values": [" Non-foldable"]},
            "Tech_Extendable": {"var": "tech_extendable", 
                               "suppress_values": [" Non extendable", " Fixed", " Non-extendable"]},
            # ... add more
        }
    
    def generate_with_dependencies(self, dependency_graph: dict):
        """
        Generate rules based on a dependency graph
        graph: {var: [list of vars it depends on for suppression]}
        """
        produced_lines = []
        reassignments = {}
        
        for var, deps in dependency_graph.items():
            attr_name = var.replace('_', ' ').title()
            
            # Generate base assignment
            base = self.variable_patterns['assignment'].format(
                var=var, attr=attr_name, flags=""
            )
            value_line = self.variable_patterns['value_append'].format(
                attr=attr_name, flags="", separator=""
            )
            
            lines = [base + ",", value_line]
            
            # Generate suppression rules
            for dep_var in deps:
                if dep_var in self.known_attributes:
                    suppress_vals = self.known_attributes[dep_var]['suppress_values']
                    if suppress_vals:
                        supp_line = self.variable_patterns['suppression'].format(
                            var=var,
                            condition_var=dep_var,
                            condition_val=random.choice(suppress_vals)
                        )
                        lines.append(supp_line)
            
            produced_lines.extend(lines)
            if len(lines) > 2:  # Has reassignments
                reassignments[var] = lines
        
        # Generate concat
        concat_line = self.variable_patterns['concat'].format(
            vars=", ".join(dependency_graph.keys())
        )
        produced_lines.append(concat_line)
        
        # Update reassignments with concat
        for var in reassignments:
            reassignments[var].append(concat_line)
        
        return "\n".join(produced_lines), reassignments
    
    def generate_diverse_set(self, count=500):
        """Generate diverse rule sets by varying dependency graphs"""
        examples = []
        
        for i in range(count):
            # Create dependency graph with varying complexity
            num_vars = random.randint(3, 12)
            vars_pool = list(self.known_attributes.keys())[:num_vars]
            
            graph = {}
            for var_info in vars_pool:
                var_name = var_info.lower().replace(' ', '_') if isinstance(var_info, str) else var_info['var']
                
                # Randomly decide dependencies
                num_deps = random.randint(0, min(3, len(vars_pool)-1))
                deps = random.sample([v for v in vars_pool if v != var_info], num_deps)
                graph[var_name] = [d.lower().replace(' ', '_') if isinstance(d, str) else d['var'] 
                                  for d in deps]
            
            rule_text, json_out = self.generate_with_dependencies(graph)
            examples.append({'input': rule_text, 'output': json_out})
        
        return examples