import random
import json
from typing import List, Tuple, Dict

# Define rule building blocks based on your examples
ATTRIBUTE_TYPES = [
    "Calc_Brand", "Type_Range", "Material_type", "Vdesc_Colour", 
    "Use_Foldable", "Number_of_seats", "Tech_Extendable", 
    "Vdesc_Product_shape", "Core_Product_type", "Key_Feature",
    "Price_Range", "Assembly_Required", "Weight_Capacity",
    "Warranty_Period", "Frame_Material", "Cushion_Type"
]

SUPPRESSION_VALUES = {
    "Material_type": [" Wooden"],
    "Use_Foldable": [" Non-foldable"],
    "Tech_Extendable": [" Non extendable", " Fixed", " Non-extendable"],
    "Assembly_Required": [" Not required"],
    "Cushion_Type": [" None"],
    "Weight_Capacity": [" N/A"],
    "Frame_Material": [" Not applicable"]
}

LANGUAGES = ["", ',"en_GB"', ',"en_US"', ',"fr_FR"', ',"de_DE"']

def generate_rule_block(attr: str, has_validation: bool = True, 
                        has_suppression: bool = False, 
                        suppress_value: str = None) -> Tuple[str, str, List[str]]:
    """
    Generate a variable assignment block
    Returns: (variable_name, rule_lines, dependencies)
    """
    var_name = attr.lower()
    lang = random.choice(LANGUAGES) if random.random() > 0.5 else ""
    
    # Base validation pattern
    if has_validation:
        if lang:
            base_line = f'{var_name} := IIF[ValidateEmptyAttributes["{attr}",IGNORESOURCEFLAG{lang}],""'
        else:
            base_line = f'{var_name} := IIF[ValidateEmptyAttributes["{attr}",IGNORESOURCEFLAG],""'
    else:
        if lang:
            base_line = f'{var_name} := IIF[ValidateEmptyAttributes["{attr}",IGNORESOURCEFLAG{lang}],""'
        else:
            base_line = f'{var_name} := IIF[ValidateEmptyAttributes["{attr}",IGNORESOURCEFLAG],""'
    
    # Value assignment
    if lang:
        value_line = f'Concat[" ", AttributeValue["{attr}"{lang}]]'
    else:
        value_line = f'Concat[" ", AttributeValue["{attr}"]]'
    
    lines = [base_line + ",", f'{value_line}']; 
    deps = [var_name]
    
    # Add suppression rules if applicable
    if has_suppression and suppress_value:
        suppress_line = f'{var_name} :=IIF[another_var="{suppress_value}","",{var_name}];'
        lines.append(suppress_line)
    
    return var_name, lines

def generate_synthetic_rule(num_vars: int, num_reassignments: int) -> Tuple[str, Dict]:
    """
    Generate a complete rule set with specified number of variables and reassignments
    """
    # Select random subset of attributes
    selected_attrs = random.sample(ATTRIBUTE_TYPES, min(num_vars, len(ATTRIBUTE_TYPES)))
    
    rule_lines = []
    variable_definitions = {}
    reassignment_tracker = {}  # Tracks which vars get reassigned
    
    # Generate initial definitions
    for attr in selected_attrs:
        var_name = attr.lower()
        
        # Possibly add suppression
        has_suppression = attr in SUPPRESSION_VALUES and random.random() > 0.6
        suppress_val = random.choice(SUPPRESSION_VALUES[attr]) if has_suppression else None
        
        var_name, block_lines = generate_rule_block(
            attr=attr,
            has_validation=True,
            has_suppression=has_suppression,
            suppress_value=suppress_val
        )
        
        rule_lines.extend(block_lines)
        variable_definitions[var_name] = {
            'lines': block_lines,
            'reassigned': False
        }
        
        # Track if this will be reassigned
        if has_suppression:
            reassignment_tracker[var_name] = []
    
    # Add cross-variable suppressions (reassignments based on other vars)
    if len(selected_attrs) >= 2 and reassignment_tracker:
        # Pick random variables to have suppression rules
        for _ in range(min(num_reassignments, len(reassignment_tracker))):
            target_var = random.choice(list(reassignment_tracker.keys()))
            source_var = random.choice([v for v in variable_definitions.keys() if v != target_var])
            
            suppress_values = SUPPRESSION_VALUES.get(
                target_var.replace('_', ' ').title(), [" Test_value"]
            )
            suppress_val = random.choice(suppress_values)
            
            suppression_line = f'{target_var} :=IIF[{source_var}="{suppress_val}","",{target_var}];'
            rule_lines.append(suppression_line)
            reassignment_tracker[target_var].append(suppression_line)
    
    # Generate CONCAT line
    concat_vars = list(variable_definitions.keys())
    concat_line = f'Concat[{", ".join([v for v in concat_vars if not variable_definitions[v].get("suppressed")])}]'
    rule_lines.append(concat_line)
    
    # Generate JSON output tracking reassignments
    json_output = {}
    for var_name, reassign_lines in reassignment_tracker.items():
        if reassign_lines:  # Only include vars that have reassignments
            var_def = variable_definitions[var_name]
            entry = [
                var_def['lines'][0] + ",",  # First line with comma
                var_def['lines'][1]          # Second line
            ]
            entry.extend(reassign_lines)
            entry.append(concat_line)
            json_output[var_name] = entry
    
    return "\n".join(rule_lines), json_output

# Generate 500 examples
synthetic_examples = []
for i in range(500):
    # Vary complexity
    num_vars = random.randint(3, 12)
    num_reassignments = random.randint(1, 5)
    
    rule_text, json_output = generate_synthetic_rule(num_vars, num_reassignments)
    synthetic_examples.append({
        'input': rule_text,
        'output': json_output
    })
    
# Save to JSONL file
with open('synthetic_rules.jsonl', 'w') as f:
    for example in synthetic_examples:
        f.write(json.dumps(example) + '\n')