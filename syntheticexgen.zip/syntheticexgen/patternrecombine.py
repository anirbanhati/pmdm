def extract_patterns(seed_examples):
    """Extract structural patterns from seed examples"""
    patterns = {
        'validation': r'(\w+) := IIF\[ValidateEmptyAttributes\["([^"]+)"[^\]]*\]',
        'suppression': r'(\w+) :=IIF\[(\w+)="([^"]+)"',
        'concat': r'Concat\[([^\]]+)\]'
    }
    
    extracted = []
    for example in seed_examples:
        validations = re.findall(patterns['validation'], example)
        suppressions = re.findall(patterns['suppression'], example)
        concats = re.findall(patterns['concat'], example)
        
        extracted.append({
            'validations': validations,
            'suppressions': suppressions,
            'concats': concats
        })
    
    return extracted

def recombine_patterns(extracted_patterns, n=500):
    """Create new combinations from extracted patterns"""
    synthetic = []
    
    for _ in range(n):
        # Mix patterns from different seeds
        source1 = random.choice(extracted_patterns)
        source2 = random.choice(extracted_patterns)
        
        # Take validations from one, suppressions from another
        mixed_validations = source1['validations'][:random.randint(1, len(source1['validations']))]
        mixed_suppressions = source2['suppressions'][:random.randint(0, len(source2['suppressions']))]
        
        # Add some from both
        combined_suppressions = list(set(mixed_suppressions + 
                                        source1['suppressions'][:random.randint(0,2)]))
        
        # Generate new rule set
        # ... (build rule text and JSON)
    
    return synthetic