class RuleMutator:
    def __init__(self, seed_examples):
        self.seed_examples = seed_examples
        self.mutations = [
            self.rename_variable,
            self.add_validation_check,
            self.remove_validation_check,
            self.add_suppression_rule,
            self.modify_suppression_value,
            self.add_language_parameter,
            self.reorder_statements,
            self.insert_noop_rule,
            self.add_chained_suppression,
            self.split_concat_expression
        ]
    
    def rename_variable(self, rule_text):
        """Rename variables while preserving logic"""
        old_new_mapping = {
            'calc_brand': random.choice(['brand_calc', 'calc_brand_name', 'brand_name']),
            'vdesc_colour': random.choice(['colour_description', 'desc_colour', 'product_colour'])
        }
        for old, new in old_new_mapping.items():
            rule_text = rule_text.replace(old, new)
        return rule_text
    
    def add_validation_check(self, rule_text):
        """Add an additional validation condition"""
        new_validation = '''new_var := IIF[ValidateEmptyAttributes["New_Attribute",IGNORESOURCEFLAG],"",
Concat[" ", AttributeValue["New_Attribute"]]
];'''
        # Insert before Concat
        concat_pos = rule_text.rfind("Concat[")
        return rule_text[:concat_pos] + new_validation + "\n" + rule_text[concat_pos:]
    
    def add_suppression_rule(self, rule_text):
        """Add a suppression rule between two existing variables"""
        # Parse existing variables and add a suppression
        # Implementation depends on exact parsing needs
        pass
    
    def add_language_parameter(self, rule_text):
        """Add or change language parameters"""
        if random.random() > 0.5:
            # Add language code
            rule_text = rule_text.replace('IGNORESOURCEFLAG]', 'IGNORESOURCEFLAG,"en_GB"]')
        else:
            # Change existing language code
            new_lang = random.choice(['"fr_FR"', '"de_DE"', '"en_US"'])
            rule_text = rule_text.replace('"en_GB"', new_lang)
        return rule_text
    
    def generate_variants(self, num_variants=100):
        """Generate multiple variants through mutation chains"""
        variants = []
        for _ in range(num_variants):
            # Start with random seed
            base = random.choice(self.seed_examples)
            
            # Apply 1-5 random mutations
            num_mutations = random.randint(1, 5)
            for _ in range(num_mutations):
                mutation = random.choice(self.mutations)
                base = mutation(base)
            
            variants.append(base)
        return variants