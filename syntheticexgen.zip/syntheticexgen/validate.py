def validate_generated_rule(rule_text, json_output):
    """Ensure generated rule is valid"""
    # Check syntax
    if not re.match(r'^[\w\s:=,\[\]"\.]+$', rule_text):
        return False
    
    # Verify JSON output matches rule
    vars_in_rule = set(re.findall(r'(\w+) :=', rule_text))
    vars_in_json = set(json_output.keys())
    
    # All JSON keys should have reassignments in rule
    for var in vars_in_json:
        if rule_text.count(f'{var} :=') < 2:
            return False
    
    return True

# Quality filter
valid_examples = [ex for ex in synthetic_examples if validate_generated_rule(ex['input'], ex['output'])]