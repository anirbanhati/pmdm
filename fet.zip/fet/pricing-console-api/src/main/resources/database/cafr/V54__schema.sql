CREATE TABLE IF NOT EXISTS competitorprice.lsp_store_collection
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    store_code text COLLATE pg_catalog."default",
    collection_list_name text COLLATE pg_catalog."default" NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    creation_date timestamp with time zone,
    last_modified timestamp with time zone,
    created_by text COLLATE pg_catalog."default" NOT NULL,
    last_modified_by text COLLATE pg_catalog."default",
    category_type text COLLATE pg_catalog."default" NOT NULL,
    assign_to text COLLATE pg_catalog."default",
    effective_start_date timestamp with time zone,
    effective_end_date timestamp with time zone,
    competitor_store_id bigint,
    status competitorprice.collectionstatus,
    CONSTRAINT lsp_store_collection_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS competitorprice.lsp_assignment
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint,
    collected_ean text COLLATE pg_catalog."default",
    collected_article_code text COLLATE pg_catalog."default",
    collected_pkg text COLLATE pg_catalog."default",
    collected_price numeric,
    collection_id bigint NOT NULL,
    has_promo boolean,
    promo_info text COLLATE pg_catalog."default",
    notes text COLLATE pg_catalog."default",
    is_link boolean DEFAULT false,
    is_master_data_missed boolean DEFAULT false,
    tenant text COLLATE pg_catalog."default",
    product_association_extracted boolean DEFAULT false,
    product_collection_extracted boolean DEFAULT false,
    product_collection_extracted_date timestamp with time zone,
    product_association_extracted_date timestamp with time zone,
    collected_description text COLLATE pg_catalog."default",
    CONSTRAINT lsp_assignment_pk PRIMARY KEY (id),
    CONSTRAINT lsp_assign_fk FOREIGN KEY (product_id)
        REFERENCES competitorprice.lsp_product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT lsp_collection_id FOREIGN KEY (collection_id)
        REFERENCES competitorprice.lsp_store_collection (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS competitorprice.lsp_product_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    final_price numeric,
    last_updated timestamp with time zone NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    user_id bigint NOT NULL,
    store_id bigint NOT NULL,
    end_date timestamp with time zone NOT NULL,
    start_date timestamp with time zone NOT NULL,
    index numeric,
    temp_ref text COLLATE pg_catalog."default",
    verification_req boolean DEFAULT false,
    status text COLLATE pg_catalog."default",
    prd_type competitorprice.product_type,
    extracted_date timestamp with time zone,
    CONSTRAINT lsp_product_price_pkey PRIMARY KEY (id),
    CONSTRAINT lsp_prd_prc_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.lsp_product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT lsp_store_price_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT lsp_user_price_fk FOREIGN KEY (user_id)
        REFERENCES competitorprice."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);