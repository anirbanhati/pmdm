CREATE TABLE IF NOT EXISTS competitorprice.lsp_competitor_store
(
    comp_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    shortname text COLLATE pg_catalog."default" NOT NULL,
    longname text COLLATE pg_catalog."default" NOT NULL,
    code text COLLATE pg_catalog."default",
    reg_date timestamp with time zone,
    concurrent_ratio text COLLATE pg_catalog."default",
    last_updated timestamp with time zone,
    CONSTRAINT com_store_pkey_v2 PRIMARY KEY (comp_id)
);

Alter table competitorprice.competitor_store add column cs_code text;

Alter table competitorprice.lsp_competitor_store add column cs_code text;

Alter table competitorprice.lsp_store_collection add column cl_cs_code text;
