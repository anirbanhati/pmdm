alter table competitorprice.assignment add column collected_pkg_unit text COLLATE pg_catalog."default";
alter table competitorprice.assignment add column collected_pkg_value text COLLATE pg_catalog."default";

alter table competitorprice.lsp_store_collection add column IF NOT EXISTS exp_date timestamp with time zone;
