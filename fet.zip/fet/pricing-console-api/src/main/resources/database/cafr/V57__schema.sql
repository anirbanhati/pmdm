alter table competitorprice.store_product_mapping alter column oor_date type text;
