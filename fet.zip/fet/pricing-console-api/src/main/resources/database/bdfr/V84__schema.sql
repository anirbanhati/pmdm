INSERT INTO competitorprice.lsp_competitor_store
(comp_id, shortname, longname, code, reg_date, concurrent_ratio, last_updated, cs_code)
OVERRIDING SYSTEM VALUE
SELECT cs_id, shortname, longname, code, reg_date, concurrent_ratio, last_updated, cs_code
FROM competitorprice.competitor_store;

alter table competitorprice.map_store_competitorstore_v2 drop constraint map_store_competitorstore_product_id_fkey_v2;
alter table competitorprice.map_store_competitorstore_v2 add constraint map_store_lsp_competitorstore_product_id_fkey_v2 FOREIGN KEY (cs_id) REFERENCES competitorprice.lsp_competitor_store (comp_id);

SELECT setval(pg_get_serial_sequence('competitorprice.lsp_competitor_store', 'comp_id'),
(SELECT MAX(comp_id) FROM competitorprice.lsp_competitor_store));