ALTER TYPE competitorprice.product_type ADD VALUE 'PVMax' after 'WarList';
ALTER TYPE competitorprice.product_type ADD VALUE 'PVLocal' after 'PVMax';