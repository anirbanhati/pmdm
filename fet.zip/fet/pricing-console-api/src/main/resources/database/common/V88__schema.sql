CREATE TABLE IF NOT EXISTS competitorprice.lsp_cluster_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    cluster_price numeric,
	cluster_id text,
	locale text,
	ean text,
    last_updated_date timestamp with time zone NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
	start_date timestamp with time zone NOT NULL,
	end_date timestamp with time zone NOT NULL,
	currency text
);