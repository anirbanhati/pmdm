alter table competitorprice.product_chaining alter column coef_type type text;
