alter table competitorprice.store_collection ALTER COLUMN creation_date TYPE  timestamp with time zone;
alter table competitorprice.store_collection ALTER COLUMN last_modified TYPE  timestamp with time zone;

