CREATE INDEX IF NOT EXISTS idx_lcp_comp_name ON competitorprice.lsp_comp_product (comp_name);

CREATE INDEX IF NOT EXISTS idx_lcp_ean ON competitorprice.lsp_comp_product (ean);


CREATE INDEX IF NOT EXISTS idx_fpr_product_id ON competitorprice.financial_provisions (product_id);

CREATE INDEX IF NOT EXISTS idx_fpr_store_id ON competitorprice.financial_provisions (store_id);


CREATE INDEX IF NOT EXISTS idx_cluster_ean ON competitorprice.lsp_cluster_price (ean);

CREATE INDEX IF NOT EXISTS idx_cluster_cluster_id ON competitorprice.lsp_cluster_price (cluster_id);


