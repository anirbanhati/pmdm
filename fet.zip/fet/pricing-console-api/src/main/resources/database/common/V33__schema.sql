alter table competitorprice.store_product_mapping add column fixed_price text;
alter table competitorprice.store_product_mapping add column max_decrease numeric;
alter table competitorprice.store_product_mapping add column local_pricing text;
alter table competitorprice.store_product_mapping add column oor_date timestamp with time zone;