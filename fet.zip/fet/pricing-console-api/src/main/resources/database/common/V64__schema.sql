alter table competitorprice.user add column store_code text;
