alter table competitorprice.stg_product add column ignore_in_save boolean default false;
alter table competitorprice.product_price add column status text;
alter table competitorprice.product_price add column prd_type competitorprice.product_type;