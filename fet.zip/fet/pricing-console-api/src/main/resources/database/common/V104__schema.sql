CREATE TABLE IF NOT EXISTS competitorprice.lsp_import_errors
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    error_key text NOT NULL,
    error_json JSONB NOT NULL,
    last_updated timestamp with time zone NOT NULL
);