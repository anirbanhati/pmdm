DROP TABLE IF EXISTS competitorprice.lsp_comp_product CASCADE;
CREATE TABLE IF NOT EXISTS competitorprice.lsp_comp_product
(
    cmp_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    code text COLLATE pg_catalog."default",
    ean text COLLATE pg_catalog."default" NOT NULL,
    description text COLLATE pg_catalog."default",
    comp_name text COLLATE pg_catalog."default",
	comp_uom_price numeric,
	comp_sales_unit text COLLATE pg_catalog."default",
	comp_uom text COLLATE pg_catalog."default",
	comp_ean text COLLATE pg_catalog."default",
	coef numeric,
	creation_date timestamp with time zone,
    delete_flag text,
    comp_article_number text,
    last_updated_date timestamp with time zone,
    comp_description text COLLATE pg_catalog."default",
    product_id bigint NOT NULL,
    CONSTRAINT lsp_prod_pk PRIMARY KEY (cmp_id),
    CONSTRAINT lsp_prod_fk_comp FOREIGN KEY (product_id)
        REFERENCES competitorprice.lsp_product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);
