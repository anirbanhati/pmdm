CREATE TABLE IF NOT EXISTS competitorprice.cost_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    sales_org text,
    vendor text,
    cost_price numeric,
    store_id bigint,
    product_id bigint,
    last_updated timestamp with time zone NOT NULL,
    FOREIGN KEY(store_id) REFERENCES competitorprice.store(store_id),
    FOREIGN KEY(product_id) REFERENCES competitorprice.product(product_id)
    );