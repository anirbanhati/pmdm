CREATE TABLE IF NOT EXISTS competitorprice.map_store_competitorstore_v2
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    cs_id bigint NOT NULL,
    store_id bigint NOT NULL,
	active_flag text,
	last_updated timestamp with time zone,
    CONSTRAINT map_store_competitorstore_pKey_v2 PRIMARY KEY (id),
    CONSTRAINT map_store_competitorstore_product_id_fkey_v2 FOREIGN KEY (cs_id)
        REFERENCES competitorprice.competitor_store (cs_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT map_store_competitorstore_fk_v2 FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


