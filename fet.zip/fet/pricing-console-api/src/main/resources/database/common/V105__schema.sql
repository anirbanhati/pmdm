CREATE TABLE IF NOT EXISTS competitorprice.rolling_days
(
    roll_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    ho_user_id text NOT NULL,
    days numeric NOT NULL,
    last_updated timestamp with time zone NOT NULL
);