alter table competitorprice.store_price alter column ref_price type numeric;
alter table competitorprice.store_price alter column store_price type numeric;