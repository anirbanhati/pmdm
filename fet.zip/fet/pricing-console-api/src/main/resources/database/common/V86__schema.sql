alter table competitorprice.store_price drop CONSTRAINT store_price_product_id_fkey;
alter table competitorprice.store_price alter column product_id drop not null;
alter table competitorprice.store_price add column ean text;
alter table competitorprice.sales_history drop CONSTRAINT sales_history_product_id_fkey;
alter table competitorprice.sales_history alter column product_id drop not null;
alter table competitorprice.sales_history add column ean text;