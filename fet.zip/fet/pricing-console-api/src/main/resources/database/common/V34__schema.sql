alter table competitorprice.product DROP COLUMN fixed_price;
alter table competitorprice.product DROP COLUMN max_decrease;
alter table competitorprice.product DROP COLUMN local_pricing;
alter table competitorprice.product DROP COLUMN oor_date;