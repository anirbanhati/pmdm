ALTER TABLE competitorprice.stg_product DROP CONSTRAINT IF EXISTS  stg_product_product_id_fkey;
ALTER TABLE competitorprice.store_product_mapping DROP CONSTRAINT IF EXISTS  store_product_mapping_product_id_fkey;
ALTER TABLE competitorprice.store_stock DROP CONSTRAINT IF EXISTS  store_stock_product_id_fkey;
ALTER TABLE competitorprice.vendor DROP CONSTRAINT IF EXISTS  vendorproduct_id_fkey;
ALTER TABLE competitorprice.store_price DROP CONSTRAINT IF EXISTS  store_price_product_id_fkey;
ALTER TABLE competitorprice.financial_provisions DROP CONSTRAINT IF EXISTS  financial_provisions_product_id_fkey;
ALTER TABLE competitorprice.sales_history DROP CONSTRAINT IF EXISTS  sales_history_product_id_fkey;
ALTER TABLE competitorprice.cost_price DROP CONSTRAINT IF EXISTS  cost_price_product_id_fkey;