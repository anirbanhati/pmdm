CREATE INDEX IF NOT EXISTS idx_store_id ON competitorprice.store_price (store_id);

CREATE INDEX IF NOT EXISTS idx_product_id ON competitorprice.store_price (product_id);