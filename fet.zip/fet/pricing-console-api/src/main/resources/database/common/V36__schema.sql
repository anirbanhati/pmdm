DROP TABLE IF EXISTS competitorprice.role_permission;
DROP TABLE IF EXISTS competitorprice.permissions;
DROP TABLE IF EXISTS competitorprice.user_roles;
DROP TABLE IF EXISTS competitorprice.roles;

ALTER TABLE IF EXISTS competitorprice.lsp_functions
RENAME TO features_permissions;

ALTER TABLE IF EXISTS competitorprice.features_permissions
RENAME COLUMN lsp_functions_id TO features_permissions_id;

ALTER TABLE IF EXISTS competitorprice.features_permissions
RENAME COLUMN lsp_functions_text TO features_permissions_name;

ALTER TABLE IF EXISTS competitorprice.user_code
ADD COLUMN sales_org text COLLATE pg_catalog."default";

update competitorprice.user_code set sales_org='CF01';

ALTER TABLE IF EXISTS competitorprice.lsp_functions_permissions
RENAME TO features_permissions_user_code_map;

ALTER TABLE IF EXISTS competitorprice.features_permissions_user_code_map
DROP COLUMN sales_org;

ALTER TABLE IF EXISTS competitorprice.features_permissions_user_code_map
RENAME COLUMN lsp_functions_code TO features_permissions_name;

ALTER TABLE IF EXISTS competitorprice.features_permissions_user_code_map
DROP COLUMN permission_id;

ALTER TABLE IF EXISTS competitorprice.features_permissions
ADD COLUMN user_code_id bigint;

ALTER TABLE IF EXISTS competitorprice.features_permissions
ADD CONSTRAINT user_code_id_fk FOREIGN KEY (user_code_id)
        REFERENCES competitorprice.user_code (user_code_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION;

TRUNCATE TABLE competitorprice.features_permissions CASCADE;
ALTER TABLE IF EXISTS competitorprice."user" ADD COLUMN workgroup_code_id bigint;

CREATE TABLE IF NOT EXISTS competitorprice.ftr_perm_user_code_map
(
    user_code_id bigint NOT NULL,
    features_permissions_id bigint NOT NULL,
    CONSTRAINT "ftr_perm_user_code_map_pkey" PRIMARY KEY (user_code_id, features_permissions_id),
    CONSTRAINT ftr_user_code_fk FOREIGN KEY (user_code_id)
        REFERENCES competitorprice.user_code (user_code_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ftr_perm_fk FOREIGN KEY (features_permissions_id)
        REFERENCES competitorprice.features_permissions (features_permissions_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
alter table competitorprice.product add column app_type text COLLATE pg_catalog."default";
update competitorprice.product set app_type='CP';

ALTER TABLE IF EXISTS competitorprice."user" DROP COLUMN work_group_code;