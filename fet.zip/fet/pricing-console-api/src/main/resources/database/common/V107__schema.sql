CREATE TABLE IF NOT EXISTS competitorprice.scheduler_status
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 ),
    scheduler_name text NOT NULL,
    scheduler_status text NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    updated_at timestamp with time zone
);