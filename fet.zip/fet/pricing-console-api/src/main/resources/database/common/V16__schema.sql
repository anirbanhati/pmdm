
alter table competitorprice.product add column oor_date timestamp with time zone;
alter table competitorprice.product add column vat_category text COLLATE pg_catalog."default";
alter table competitorprice.store_product_mapping alter column store_id drop not null;