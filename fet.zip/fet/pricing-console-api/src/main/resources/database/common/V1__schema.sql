DROP TYPE IF EXISTS competitorprice.CollectionStatus CASCADE;
DROP TYPE IF EXISTS competitorprice.role CASCADE;
DROP TABLE IF EXISTS competitorprice.warlist_info CASCADE;
DROP TABLE IF EXISTS competitorprice.product CASCADE;
DROP TABLE IF EXISTS competitorprice.warlist_info_product CASCADE;
DROP TABLE IF EXISTS competitorprice.comp_product CASCADE;
DROP TABLE IF EXISTS competitorprice.store CASCADE;
DROP TABLE IF EXISTS competitorprice.competitor_store CASCADE;
DROP TABLE IF EXISTS competitorprice.map_store_competitorstore CASCADE;
DROP TABLE IF EXISTS competitorprice.user CASCADE;
DROP TABLE IF EXISTS competitorprice.product_price CASCADE;
DROP TABLE IF EXISTS competitorprice.store_collection CASCADE;
DROP TABLE IF EXISTS competitorprice.assignment CASCADE;

CREATE SCHEMA IF NOT EXISTS competitorprice;
	

CREATE TYPE competitorprice.CollectionStatus AS ENUM (
  'Created',
  'Completed',
  'Assigned',
  'WIP',
  'Reported'
);

CREATE TYPE competitorprice.role AS ENUM (
  'HeadOffice',
  'Store'
);


CREATE TABLE IF NOT EXISTS competitorprice.warlist_info
(
    warlist_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    last_updated_time timestamp with time zone,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    last_updated_by text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Warlist_Info_pkey" PRIMARY KEY (warlist_id)
);

CREATE TABLE IF NOT EXISTS competitorprice.product
(
    product_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_code text COLLATE pg_catalog."default" NOT NULL,
    ean text COLLATE pg_catalog."default" NOT NULL,
    brick_name text COLLATE pg_catalog."default",
    category text COLLATE pg_catalog."default",
    sub_category text COLLATE pg_catalog."default",
    packaging text COLLATE pg_catalog."default",
    description text COLLATE pg_catalog."default",
    sales_unit text COLLATE pg_catalog."default",
    map numeric,
    standard_price numeric,
    effective_price numeric,
    brick_code text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT prod_pk PRIMARY KEY (product_id)
);

CREATE TABLE IF NOT EXISTS competitorprice.warlist_info_product
(
    warlist_id bigint NOT NULL,
    product_id bigint NOT NULL,
    CONSTRAINT "Warlist_info_prod_pkey" PRIMARY KEY (warlist_id, product_id),
    CONSTRAINT wl_fk FOREIGN KEY (warlist_id)
        REFERENCES competitorprice.warlist_info (warlist_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT wl_prod_fk FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

CREATE TABLE IF NOT EXISTS competitorprice.comp_product
(
    cmp_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    code text COLLATE pg_catalog."default",
    ean text COLLATE pg_catalog."default" NOT NULL,
    description text COLLATE pg_catalog."default",
    comp_name text COLLATE pg_catalog."default",
    product_id bigint NOT NULL,
    CONSTRAINT product_pk PRIMARY KEY (cmp_id),
    CONSTRAINT prod_fk_comp FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);


CREATE TABLE IF NOT EXISTS competitorprice.store
(
    store_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    store_code text COLLATE pg_catalog."default",
    store_name text COLLATE pg_catalog."default",
    store_brand text COLLATE pg_catalog."default",
    CONSTRAINT store_pkey PRIMARY KEY (store_id)
);


CREATE TABLE IF NOT EXISTS competitorprice.competitor_store
(
    cs_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    shortname text COLLATE pg_catalog."default" NOT NULL,
    longname text COLLATE pg_catalog."default" NOT NULL,
    code text COLLATE pg_catalog."default",
    reg_date timestamp with time zone,
    concurrent_ratio text COLLATE pg_catalog."default",
    CONSTRAINT com_store_pkey PRIMARY KEY (cs_id)
);

CREATE TABLE IF NOT EXISTS competitorprice.map_store_competitorstore
(
    store_id bigint NOT NULL,
    cs_id bigint NOT NULL,
    CONSTRAINT "Warlist_Info_prod_pkey" PRIMARY KEY (store_id, cs_id),
    CONSTRAINT wl_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT wl_prod_fk FOREIGN KEY (cs_id)
        REFERENCES competitorprice.competitor_store (cs_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

CREATE TABLE IF NOT EXISTS competitorprice."user"
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    user_id text COLLATE pg_catalog."default",
    first_name text COLLATE pg_catalog."default",
    last_name text COLLATE pg_catalog."default",
    tenant text COLLATE pg_catalog."default" NOT NULL,
    role competitorprice.role NOT NULL,
    store_id bigint NOT NULL,
    CONSTRAINT colleague_pkey PRIMARY KEY (id),
    CONSTRAINT store_id FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS competitorprice.product_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    final_price numeric,
    last_updated timestamp with time zone NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    user_id bigint NOT NULL,
    store_id bigint NOT NULL,
    end_date timestamp with time zone NOT NULL,
    start_date timestamp with time zone NOT NULL,
    index numeric,
    CONSTRAINT product_price_pkey PRIMARY KEY (id),
    CONSTRAINT product_price_war_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT store_price_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT user_price_fk FOREIGN KEY (user_id)
        REFERENCES competitorprice."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

CREATE TABLE IF NOT EXISTS competitorprice.store_collection
(
    id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 100 INCREMENT BY 1),
    store_code text COLLATE pg_catalog."default" NOT NULL,
    collection_list_name text COLLATE pg_catalog."default" NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    creation_date date,
	last_modified date,
    created_by text COLLATE pg_catalog."default" NOT NULL,
	last_modified_by text COLLATE pg_catalog."default",
	category_type text COLLATE pg_catalog."default" NOT NULL,
	assign_to text COLLATE pg_catalog."default",
    effective_start_date timestamp with time zone,
    effective_end_date timestamp with time zone,
    competitor_store_id bigint NOT NULL,
	 status competitorprice.collectionstatus,
    CONSTRAINT store_collection_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS competitorprice.assignment
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    collected_ean text COLLATE pg_catalog."default",
	collected_article_code text COLLATE pg_catalog."default",
	collected_pkg text COLLATE pg_catalog."default",
    collected_price numeric,
    collection_id bigint NOT NULL,
    has_promo boolean,
    promo_info text COLLATE pg_catalog."default",
    notes text COLLATE pg_catalog."default",
    CONSTRAINT store_collection_pk PRIMARY KEY (id),
    CONSTRAINT assign_fk FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT collection_id FOREIGN KEY (collection_id)
        REFERENCES competitorprice.store_collection (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
