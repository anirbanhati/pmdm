alter table competitorprice.lsp_product_price add column cost_price numeric default 0;
