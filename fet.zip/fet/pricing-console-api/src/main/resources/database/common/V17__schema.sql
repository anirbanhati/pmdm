alter table competitorprice.store_collection alter column store_code drop not null;
alter table competitorprice.store_collection alter column competitor_store_id drop not null;
alter table competitorprice.store_price add column tenant text COLLATE pg_catalog."default";
alter table competitorprice.stg_product add column price_stopped boolean default false;
alter table competitorprice.product_price add column verification_req boolean default false;