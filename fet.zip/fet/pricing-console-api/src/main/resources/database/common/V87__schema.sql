CREATE INDEX IF NOT EXISTS idx_ean ON competitorprice.store_price (ean);

CREATE INDEX IF NOT EXISTS idx_sh_ean ON competitorprice.sales_history (ean);

CREATE INDEX IF NOT EXISTS idx_sh_store_id ON competitorprice.sales_history (store_id);