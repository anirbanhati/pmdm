alter table competitorprice.stg_product add column cost_price numeric;
