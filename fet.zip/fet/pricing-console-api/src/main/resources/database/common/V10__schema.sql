alter table competitorprice.product add column sales_price numeric;
