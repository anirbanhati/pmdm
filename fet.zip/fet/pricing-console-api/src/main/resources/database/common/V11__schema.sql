alter table competitorprice.comp_product add column comp_ean text COLLATE pg_catalog."default";
