CREATE TABLE IF NOT EXISTS competitorprice.cl_price_update_map_v2
(
    pu_id bigint NOT NULL,
    cl_id bigint NOT NULL,
    CONSTRAINT "pu_cl_pkey_v2" PRIMARY KEY (pu_id, cl_id),
    CONSTRAINT pu_fk_v2 FOREIGN KEY (pu_id)
        REFERENCES competitorprice.lsp_product_price (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT pu_cl_fk_v2 FOREIGN KEY (cl_id)
        REFERENCES competitorprice.lsp_store_collection (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);