alter table competitorprice.user drop column store_code;
