CREATE INDEX IF NOT EXISTS idx_lpl_store_id ON competitorprice.lsp_product_listing (store_id);

CREATE INDEX IF NOT EXISTS idx_lpl_ean ON competitorprice.lsp_product_listing (ean);