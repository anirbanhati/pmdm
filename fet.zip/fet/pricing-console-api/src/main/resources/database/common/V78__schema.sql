CREATE TABLE IF NOT EXISTS competitorprice.map_price
(
    ean text COLLATE pg_catalog."default" NOT NULL,
    cost_price numeric,
    store_code text NOT NULL,
    CONSTRAINT lsp_map_price_pkey PRIMARY KEY (ean, store_code)
 );