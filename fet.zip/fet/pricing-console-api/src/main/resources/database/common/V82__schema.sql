CREATE INDEX IF NOT EXISTS idx_la_product_id ON competitorprice.lsp_assignment (product_id);

CREATE INDEX IF NOT EXISTS idx_la_collection_id ON competitorprice.lsp_assignment (collection_id);