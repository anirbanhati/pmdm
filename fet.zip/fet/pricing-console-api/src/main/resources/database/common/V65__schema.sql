alter table competitorprice.lsp_product_price add column stopped_price text default 'N';
