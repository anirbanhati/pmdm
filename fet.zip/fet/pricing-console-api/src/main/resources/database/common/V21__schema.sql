alter table competitorprice.assignment add column is_master_data_missed boolean default false;
alter table competitorprice.assignment drop column missed_ean;