CREATE TABLE IF NOT EXISTS competitorprice.lsp_product_listing
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    store_id bigint NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    CONSTRAINT lsp_product_listing_pkey PRIMARY KEY (id),
    CONSTRAINT lsp_product_listing_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.lsp_product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT lsp_product_listing_store_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
alter table competitorprice.lsp_product add column IF NOT EXISTS product_status numeric;