
alter table competitorprice.stg_product add column theroritical_mg_rate numeric;
alter table competitorprice.stg_product add column req_mg_rate numeric;

