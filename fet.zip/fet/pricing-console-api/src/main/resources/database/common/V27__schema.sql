
alter table competitorprice.store_product_mapping alter column prd_type drop not null;