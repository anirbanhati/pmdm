CREATE TABLE IF NOT EXISTS competitorprice.cl_price_update_map
(
    pu_id bigint NOT NULL,
    cl_id bigint NOT NULL,
    CONSTRAINT "pu_cl_pkey" PRIMARY KEY (pu_id, cl_id),
    CONSTRAINT pu_fk FOREIGN KEY (pu_id)
        REFERENCES competitorprice.product_price (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT pu_cl_fk FOREIGN KEY (cl_id)
        REFERENCES competitorprice.store_collection (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);
