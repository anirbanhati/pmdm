CREATE TABLE IF NOT EXISTS competitorprice.lsp_national_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    national_price numeric,
    last_updated timestamp with time zone NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
	start_date timestamp with time zone NOT NULL,
	end_date timestamp with time zone NOT NULL,
	currency text,
    CONSTRAINT national_product_fk FOREIGN KEY (product_id)
        REFERENCES competitorprice."lsp_product" (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);