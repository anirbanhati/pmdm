alter table competitorprice.category_rounding_config
alter column brick_code type bigint using brick_code::bigint;