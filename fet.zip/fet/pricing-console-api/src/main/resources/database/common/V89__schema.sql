CREATE TABLE IF NOT EXISTS competitorprice.cluster_store_mapping
(
    cluster_id text,
	store_code text
);