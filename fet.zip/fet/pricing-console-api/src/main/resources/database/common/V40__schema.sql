CREATE TABLE IF NOT EXISTS competitorprice.lsp_feature
(
    feature_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    feature_name text COLLATE pg_catalog."default" NOT NULL UNIQUE,
    feature_description text COLLATE pg_catalog."default",
    CONSTRAINT feature_pkey PRIMARY KEY (feature_id)
);


CREATE TABLE IF NOT EXISTS competitorprice.lsp_tenant_feature_toggle_config
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
	feature_id bigint NOT NULL,
    tenant text NOT NULL,
	is_enabled BOOLEAN NOT NULL,
    CONSTRAINT "tenant_feature_toggle_config_map_pkey" PRIMARY KEY (id)
);