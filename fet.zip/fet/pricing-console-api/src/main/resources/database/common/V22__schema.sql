CREATE TABLE IF NOT EXISTS competitorprice.roles
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    role_description text COLLATE pg_catalog."default",
    sap_code text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT roles_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS competitorprice.permissions
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    permission_description text COLLATE pg_catalog."default",
    permission_name text COLLATE pg_catalog."default",
    CONSTRAINT permissions_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS competitorprice.role_permission
(
    role_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    CONSTRAINT "Role_permission_pkey" PRIMARY KEY (role_id, permission_id),
    CONSTRAINT rl_fk FOREIGN KEY (role_id)
        REFERENCES competitorprice.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT rl_perm_fk FOREIGN KEY (permission_id)
        REFERENCES competitorprice.permissions (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS competitorprice.user_roles
(
    user_id bigint NOT NULL,
    role_id bigint NOT NULL,
    CONSTRAINT "User_roles_pkey" PRIMARY KEY (user_id, role_id),
    CONSTRAINT usr_fk FOREIGN KEY (user_id)
        REFERENCES competitorprice."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT usr_rl_fk FOREIGN KEY (role_id)
        REFERENCES competitorprice.roles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);