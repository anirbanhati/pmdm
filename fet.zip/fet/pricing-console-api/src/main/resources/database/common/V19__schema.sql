
alter table competitorprice.assignment add column missed_ean text COLLATE pg_catalog."default";
alter table competitorprice.assignment alter column product_id drop not null;
ALTER TABLE IF EXISTS competitorprice.store_price ADD CONSTRAINT store_price_unique UNIQUE (product_id, store_id, tenant);