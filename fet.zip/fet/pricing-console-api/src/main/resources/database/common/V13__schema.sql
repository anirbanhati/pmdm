alter table competitorprice.product add column cost_price numeric;

alter table competitorprice.stg_product add column price_uom numeric;
alter table competitorprice.stg_product add column price_su numeric;
alter table competitorprice.stg_product add column price_index numeric;
alter table competitorprice.stg_product add column price_margin_rate numeric;

