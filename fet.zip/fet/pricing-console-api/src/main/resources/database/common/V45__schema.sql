alter table competitorprice.competitor_store add column last_updated timestamp with time zone;
