CREATE TABLE IF NOT EXISTS competitorprice.product_chaining
(
    product_chain_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    grouping_code text,
    grouping_description text,
    uom text,
	coef_type numeric,
	coef numeric,
	coef_min numeric,
	coef_max numeric,
	creation_date timestamp with time zone NOT NULL,
	delete_flag text,
	last_updated_date timestamp with time zone NOT NULL,
    product_id bigint NOT NULL,
    CONSTRAINT prd_chain PRIMARY KEY (product_chain_id),
    CONSTRAINT prod_fk_chain FOREIGN KEY (product_id)
        REFERENCES competitorprice.lsp_product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);