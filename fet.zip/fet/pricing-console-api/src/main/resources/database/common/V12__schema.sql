-- DROP TYPE IF EXISTS competitorprice.product_type;

CREATE TYPE competitorprice.product_type AS ENUM
    ('OutOfRange', 'SlowMoving', 'WarList');

-- DROP TABLE IF EXISTS competitorprice.stg_product;

CREATE TABLE IF NOT EXISTS competitorprice.stg_product
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    last_updated timestamp with time zone NOT NULL,
    store_id bigint NOT NULL,
    product_id bigint NOT NULL,
    user_id bigint NOT NULL,
    tenant text COLLATE pg_catalog."default" NOT NULL,
    price bigint,
    prd_type competitorprice.product_type NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    CONSTRAINT stg_product_pkey PRIMARY KEY (id),
    CONSTRAINT stg_product_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT stg_product_store_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT stg_product_user_fk FOREIGN KEY (user_id)
        REFERENCES competitorprice."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS competitorprice.store_product_mapping
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    store_id bigint NOT NULL,
    prd_type competitorprice.product_type NOT NULL,
    CONSTRAINT store_product_mapping_pkey PRIMARY KEY (id),
    CONSTRAINT store_product_mapping_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT store_product_mapping_store_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);




-- DROP TABLE IF EXISTS competitorprice.store_stock;

CREATE TABLE IF NOT EXISTS competitorprice.store_stock
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    store_id bigint NOT NULL,
    store_level bigint NOT NULL,
    store_value bigint NOT NULL,
    map bigint NOT NULL,
    fin_provision bigint NOT NULL,
    CONSTRAINT store_stock_pkey PRIMARY KEY (id),
    CONSTRAINT store_stock_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT store_stock_store_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
-- DROP TABLE IF EXISTS competitorprice.vendor;

CREATE TABLE IF NOT EXISTS competitorprice.vendor
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    vendor text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT vendor_pkey PRIMARY KEY (id),
    CONSTRAINT vendorproduct_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


-- DROP TABLE IF EXISTS competitorprice.store_price;

CREATE TABLE IF NOT EXISTS competitorprice.store_price
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_id bigint NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    store_id bigint NOT NULL,
    store_price bigint NOT NULL,
    ref_price bigint NOT NULL,
    CONSTRAINT store_price_pkey PRIMARY KEY (id),
    CONSTRAINT store_price_product_id_fkey FOREIGN KEY (product_id)
        REFERENCES competitorprice.product (product_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT store_price_store_fk FOREIGN KEY (store_id)
        REFERENCES competitorprice.store (store_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);



























