alter table competitorprice.store_product_mapping add column max_increase numeric;
alter table competitorprice.comp_product add column comp_description text COLLATE pg_catalog."default";