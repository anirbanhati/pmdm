CREATE TABLE IF NOT EXISTS competitorprice.category_rounding_config
(
    brick_code bigint NOT NULL,
    cat_lvl_1 bigint,
    cat_lvl_2 bigint,
    cat_lvl_3 bigint,
    cat_lvl_4 bigint,
    cat_lvl_5 bigint,
    perform_rounding boolean,
    rounding_type integer,
    CONSTRAINT category_rounding_config_pkey PRIMARY KEY (brick_code)
);

CREATE TABLE IF NOT EXISTS competitorprice.product_rounding_config
(
    product_code bigint NOT NULL,
    perform_rounding boolean,
    rounding_type integer,
    unit_of_measure character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT product_rounding_config_pkey PRIMARY KEY (product_code)
);
