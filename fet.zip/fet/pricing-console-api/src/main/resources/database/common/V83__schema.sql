CREATE INDEX IF NOT EXISTS idx_lcp_product_id ON competitorprice.lsp_comp_product (product_id);

CREATE INDEX IF NOT EXISTS idx_lcp_ean ON competitorprice.lsp_comp_product (ean);

CREATE INDEX IF NOT EXISTS idx_lcp_comp_name ON competitorprice.lsp_comp_product (comp_name);


CREATE INDEX IF NOT EXISTS idx_pc_product_id ON competitorprice.product_chaining (product_id);

CREATE INDEX IF NOT EXISTS idx_pc_grouping_code ON competitorprice.product_chaining (grouping_code);

CREATE INDEX IF NOT EXISTS idx_pc_delete_flag ON competitorprice.product_chaining (delete_flag);


CREATE INDEX IF NOT EXISTS idx_mp_ean ON competitorprice.map_price (ean);

CREATE INDEX IF NOT EXISTS idx_mp_store_code ON competitorprice.map_price (store_code);