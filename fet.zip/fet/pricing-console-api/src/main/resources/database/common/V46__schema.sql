alter table competitorprice.comp_product add column coef numeric;
alter table competitorprice.comp_product add column creation_date timestamp with time zone;
alter table competitorprice.comp_product add column delete_flag text;
alter table competitorprice.comp_product add column comp_article_number text;
alter table competitorprice.comp_product add column last_updated_date timestamp with time zone;
