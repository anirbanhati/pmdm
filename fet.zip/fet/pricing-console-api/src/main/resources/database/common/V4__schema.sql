alter table competitorprice.user ALTER COLUMN store_id DROP NOT NULL;
