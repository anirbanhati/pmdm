truncate table competitorprice.comp_product;
alter table competitorprice.comp_product add column comp_uom_price numeric;
alter table competitorprice.comp_product add column comp_sales_unit text COLLATE pg_catalog."default";
alter table competitorprice.comp_product add column comp_uom text COLLATE pg_catalog."default"
