alter table competitorprice.assignment add COLUMN is_link boolean default false;
