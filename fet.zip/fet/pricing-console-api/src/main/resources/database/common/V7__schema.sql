alter table competitorprice.product_price add column temp_ref text COLLATE pg_catalog."default";
