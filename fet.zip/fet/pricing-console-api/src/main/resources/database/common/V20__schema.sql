alter table competitorprice.store_price alter column store_id drop not null;
alter table competitorprice.store_price add column locale text;
alter table competitorprice.store_price add column currency text;
alter table competitorprice.store_price add column banner_id text;
alter table competitorprice.product alter column brick_code drop not null;
alter table competitorprice.product add column last_updated timestamp with time zone;
alter table competitorprice.store_stock alter column map drop not null;
alter table competitorprice.store_stock alter column fin_provision drop not null;
alter table competitorprice.vendor add column last_updated timestamp with time zone;
CREATE TABLE IF NOT EXISTS competitorprice.financial_provisions
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    quantity text,
    stock_value numeric,
    prov_stock numeric,
    prov_rate numeric,
    store_id bigint,
    product_id bigint,
    last_updated timestamp with time zone NOT NULL,
    FOREIGN KEY(store_id) REFERENCES competitorprice.store(store_id),
    FOREIGN KEY(product_id) REFERENCES competitorprice.product(product_id)
    );
CREATE TABLE IF NOT EXISTS competitorprice.sales_history
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    avg_price_sales numeric,
    sales_date timestamp with time zone,
    sales_quantity numeric,
    sales_price_type text,
    store_id bigint,
    product_id bigint,
    last_updated timestamp with time zone NOT NULL,
    FOREIGN KEY(store_id) REFERENCES competitorprice.store(store_id),
    FOREIGN KEY(product_id) REFERENCES competitorprice.product(product_id)
   );
CREATE TABLE IF NOT EXISTS competitorprice.product_tax_classifications
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    product_tax_classification_code text,
    tax_jurisdiction_id text,
    tax_code text,
    percent numeric,
    description text,
    last_updated timestamp with time zone NOT NULL
    );