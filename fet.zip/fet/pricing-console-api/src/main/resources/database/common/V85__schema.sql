CREATE INDEX IF NOT EXISTS idx_spm_store_id ON competitorprice.store_product_mapping (store_id);

CREATE INDEX IF NOT EXISTS idx_spm_product_id ON competitorprice.store_product_mapping (product_id);