
alter table competitorprice.lsp_functions add column  lsp_functions_text text;
UPDATE competitorprice.lsp_functions SET lsp_functions_text = 'DISPLAY_PRODUCT' where lsp_functions_id=100;
UPDATE competitorprice.lsp_functions SET lsp_functions_text = 'UPDATE_PRICE' where lsp_functions_id=101;
UPDATE competitorprice.lsp_functions SET lsp_functions_text = 'UPDATE_LOCAL_PRICE' where lsp_functions_id=102;
UPDATE competitorprice.lsp_functions SET lsp_functions_text = 'BULK_UPLOAD' where lsp_functions_id=103;
UPDATE competitorprice.lsp_functions SET lsp_functions_text = 'VALIDATE_PRICE' where lsp_functions_id=104;
alter table competitorprice.lsp_functions ADD CONSTRAINT lsp_functions_text_unique UNIQUE (lsp_functions_text);
alter table competitorprice.lsp_functions_permissions DROP constraint  lsp_function_fk;
alter table competitorprice.lsp_functions_permissions add column  lsp_functions_code text;
alter table competitorprice.lsp_functions_permissions ADD FOREIGN KEY (lsp_functions_code) REFERENCES competitorprice.lsp_functions(lsp_functions_text);
alter table competitorprice.lsp_functions_permissions DROP COLUMN lsp_functions_id;
delete from competitorprice.lsp_functions_permissions;