alter table competitorprice.assignment add column product_association_extracted boolean default false;
alter table competitorprice.assignment add column product_collection_extracted boolean default false;
alter table competitorprice.assignment add column product_collection_extracted_date timestamp with time zone;
alter table competitorprice.assignment add column product_association_extracted_date timestamp with time zone;