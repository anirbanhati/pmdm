alter table competitorprice.product add column fixed_price text;
alter table competitorprice.product add column max_decrease numeric;
alter table competitorprice.product add column local_pricing text;
alter table competitorprice.product_price add column extracted_date timestamp with time zone;