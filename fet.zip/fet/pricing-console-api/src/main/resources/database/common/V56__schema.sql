alter table competitorprice.lsp_assignment add column collected_pkg_unit text COLLATE pg_catalog."default";
alter table competitorprice.lsp_assignment add column collected_pkg_value text COLLATE pg_catalog."default";
