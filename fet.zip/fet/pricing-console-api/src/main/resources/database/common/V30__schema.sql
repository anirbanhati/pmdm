alter table competitorprice.user add column worker_id numeric;
alter table competitorprice.user add column sub_area text;
alter table competitorprice.user add column login_id text;
alter table competitorprice.user add column full_name text;
alter table competitorprice.user add column email_address text;
alter table competitorprice.user add column worker_status_code text;
alter table competitorprice.user add column work_group_code numeric;