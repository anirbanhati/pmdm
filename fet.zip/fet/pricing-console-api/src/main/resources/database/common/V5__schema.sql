alter table competitorprice.product add column price_uom numeric;
alter table competitorprice.product add column uom text COLLATE pg_catalog."default";
