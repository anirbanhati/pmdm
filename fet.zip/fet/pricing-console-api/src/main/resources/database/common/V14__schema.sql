
alter table competitorprice.stg_product add column mg_diff numeric;
alter table competitorprice.stg_product add column price_new_mg_rate numeric;
alter table competitorprice.stg_product add column nrv numeric;
alter table competitorprice.stg_product add column mg_impact numeric;

