  CREATE TABLE IF NOT EXISTS competitorprice.user_role
    (
        id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
        worker_id numeric,
        company_code text,
        sub_area text,
        login_id text,
        first_name text,
        last_name text,
        full_name text,
        email_address text,
        worker_status_code text,
        work_group_code numeric,
        CONSTRAINT user_role_pk PRIMARY KEY (worker_id,company_code,login_id)
    );


    CREATE TABLE IF NOT EXISTS competitorprice.lsp_functions (
    lsp_functions_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    description text,
    CONSTRAINT lsp_functions_pk PRIMARY KEY (lsp_functions_id)
    );

     CREATE TABLE IF NOT EXISTS competitorprice.user_code (
        user_code_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
        workgroup_code numeric,
        workgroup_description text,
        CONSTRAINT user_code_pk PRIMARY KEY (user_code_id),
        CONSTRAINT user_code_uk UNIQUE (workgroup_code)
        );
     CREATE TABLE IF NOT EXISTS competitorprice.lsp_functions_permissions (
            permission_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 100 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
            lsp_functions_id bigint NOT NULL,
            workgroup_code numeric,
            sales_org text,
             CONSTRAINT lsp_function_fk FOREIGN KEY (lsp_functions_id)
                    REFERENCES competitorprice.lsp_functions (lsp_functions_id) MATCH SIMPLE
                    ON UPDATE NO ACTION
                    ON DELETE NO ACTION,
                CONSTRAINT user_code_fk FOREIGN KEY (workgroup_code)
                    REFERENCES competitorprice.user_code (workgroup_code) MATCH SIMPLE
                                        ON UPDATE NO ACTION
                                        ON DELETE NO ACTION

            );