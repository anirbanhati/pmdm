package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.SalesHistory;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dto.SalesHistoryPrice;
import com.kingfisher.compprice.dto.SalesHistoryPrices;
import com.kingfisher.compprice.repository.SalesHistoryRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.SALES_HISTORY_MESSAGE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class SalesHistoryMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final SalesHistoryRepository salesHistoryRepository;
    private final MessageServicesHelper servicesHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return SALES_HISTORY_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Sales History Feed :: {}", message);
        }
        try {
            log.info("Start processing message :: {} {}", this.getClass().getSimpleName(), " :: processMessage()");
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} {}", this.getClass().getSimpleName(), " :: processMessage()");
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata) throws JAXBException {
        SalesHistoryPrices salesHistoryFeed = getSalesHistoryFeed(messageMetadata);
        Optional.ofNullable(salesHistoryFeed).ifPresent(pf -> pf.getPrices().forEach(this::saveSalesHistoryFeedToRepository));
    }

    private SalesHistoryPrices getSalesHistoryFeed(String message) throws JAXBException {
        SalesHistoryPrices salesHistoryFeed = null;
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(SalesHistoryPrices.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            salesHistoryFeed = (SalesHistoryPrices) unmarshaller.unmarshal(sr);
        }
        return salesHistoryFeed;
    }

    @Transactional
    public void saveSalesHistoryFeedToRepository(SalesHistoryPrice historyPrice) {
        final String methodName = "saveSalesHistoryFeedToRepository()";
        log.debug("Entering :: {} {}", this.getClass().getSimpleName(), methodName);
        addSalesHistoryFeedDetailsIntoRepository(historyPrice);
        log.debug("Exiting :: {} {}", this.getClass().getSimpleName(), methodName);
    }

    private void addSalesHistoryFeedDetailsIntoRepository(SalesHistoryPrice historyPrice) {
        Store storeData = servicesHelper.findStoreByStoreCode(historyPrice.getStoreID());
        if (Optional.ofNullable(storeData).isPresent()) {
            addDetailsFromStockFeed(historyPrice, storeData);
        } else {
            log.info("Invalid StoreID in Sales History feed :: {}", historyPrice.getStoreID());
        }
    }

    private void addDetailsFromStockFeed(SalesHistoryPrice historyPrice, Store store) {
        SalesHistory history = new SalesHistory();
        populateStoreStock(historyPrice, history);
        history.setStore(store);
        salesHistoryRepository.save(history);
    }

    private void populateStoreStock(SalesHistoryPrice historyPrice, SalesHistory salesHistory) {
        salesHistory.setSalesDate(servicesHelper.getLocalDateTime(historyPrice.getSalesDate()));
        salesHistory.setAvgPriceFromSales(historyPrice.getAveragePriceFromSales());
        salesHistory.setSalesQuantity(historyPrice.getSalesQuantity());
        salesHistory.setSalesPriceType(historyPrice.getSalesPriceType());
        salesHistory.setLastUpdated(LocalDateTime.now());
        salesHistory.setEan(historyPrice.getEan());
    }

}