package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.enums.CollectionStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
public class StoreCollectionDetails implements Serializable {
	private static final long serialVersionUID = 6945778583767253164L;

	private long id;

	@JsonProperty("storeId")
	private String storeCode;

	private CompetitorResponse competitor;

	private String name;

	@JsonProperty("cBy")
	private String createdBy;

	@JsonProperty("tenant")
	private String tenant;

	@JsonProperty("assignTo")
	private String assignTo;

	@JsonProperty("modBy")
	private String lastModifiedBy;

	@JsonProperty("type")
	private String categoryType;

	@Enumerated(EnumType.STRING)
	private CollectionStatus status;

	@JsonProperty("cTime")
	private LocalDateTime creationTime;

	private LocalDateTime lastModifiedTime;

	private LocalDateTime startDate;

	private int numOfItems;

	private LocalDateTime expDate;

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		StoreCollectionDetails that = (StoreCollectionDetails) o;
		return Objects.equals(competitor.getLongName(), that.competitor.getLongName()) && Objects.equals(name, that.name) && Objects.equals(createdBy, that.createdBy);
	}

	@Override
	public int hashCode() {
		return Objects.hash(competitor.getLongName(), name, createdBy);
	}

}