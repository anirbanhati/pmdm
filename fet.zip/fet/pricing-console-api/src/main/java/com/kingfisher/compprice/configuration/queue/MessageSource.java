package com.kingfisher.compprice.configuration.queue;

public enum MessageSource {

    PRODUCT_FEED("productFeed"),
    PRICE_FEED("priceFeed"),
    VENDOR_FEED("vendorFeed"),
    FINANCIAL_PROVISION_FEED("financialProvisionFeed"),
    SALES_HISTORY_FEED("salesHistoryFeed"),
    TAX_CLASSIFICATION_FEED("taxClassificationFeed"),
    COST_PRICE_SERVICE("costPriceFeed"),
    USER_FEED("userFeed"),
    STORE_ASSOCIATION_FEED("storeAssociationFeed"),
    PRODUCT_ASSOCIATION_FEED("productAssociationFeed"),
    PRODUCT_CHAINING_FEED("productChainingFeed"),
    PRODUCT_LISTING_FEED("productListingFeed"),
    CLUSTER_PRICE_FEED("clusterPriceFeed");




    private final String source;

    MessageSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return this.source;
    }
}
