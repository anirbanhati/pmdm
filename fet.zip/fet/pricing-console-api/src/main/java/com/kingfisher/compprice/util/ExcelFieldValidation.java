package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.util.constants.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class ExcelFieldValidation {

	private static final String COLUMN_NAME_REGEX_CATEGORY_ROUNDING = "Code of level \\d{1}";
	public static final String PRICE_VALIDATION_REGEX = "^\\d{1,3}(?:([., ])?\\d{3})?(?:\\1\\d{3})*(?:(?!\\1)[,.]\\d{1,3})?$";
	public static final String DATE_PATTERN = "^\\d{2}.\\d{2}.\\d{4}$";

	private final RegexValidationUtils regexValidationUtils;


	public Set<ExcelError> validateCellValue(final String columnName, final String cValue, ExcelValidation excelData) {
		final Set<ExcelError> excelErrors = new HashSet<>();
		if (PRICE_LIST_EAN.equals(columnName)) {
			excelData.setEan(cValue);
			eanFieldValidation(cValue, columnName, excelErrors);
		} else if (PRICE_LIST_PRIX.equals(columnName)) {
			priceFieldValidation(cValue, columnName, excelErrors);
		} else if (PRICE_LIST_START_DATE.equals(columnName) || PRICE_LIST_END_DATE.equals(columnName)) {
			dateFieldValidation(cValue, excelErrors, columnName);
		} else if (regexValidationUtils.matchWithValidationRegex(cValue, COLUMN_NAME_REGEX_CATEGORY_ROUNDING)) {
			numericFieldValidation(cValue, excelErrors, columnName);
		} else if (EXCEL_COL_ROUNDING_TYPE.equals(columnName)) {
			roundingTypeFieldValidation(cValue, excelErrors, columnName);
		} else if (Constants.EXCEL_COL_PRODUCT_CODE.equals(columnName)) {
			numericFieldValidation(cValue, excelErrors, columnName);
		}
		return excelErrors;
	}

	private void dateFieldValidation(final String cValue, final Set<ExcelError> excelErrors,
			final String columnName) {
		if (regexValidationUtils.isBlankField(cValue)) {
			final ExcelError eError = setErrorDetail(columnName, BULK_UPLOAD_DATE_NULL_STATUS,
					columnName + BULK_UPLOAD_DATE_NULL, BULK_UPLOAD_DATE_NULL_ID);
			excelErrors.add(eError);
		} else if (!regexValidationUtils.matchWithValidationRegex(cValue, DATE_PATTERN)) {
			final ExcelError eError = setErrorDetail(columnName, BULK_UPLOAD_DATE_INVALID_STATUS,
					columnName + BULK_UPLOAD_DATE_INVALID + COLON_SEPARATOR + cValue, BULK_UPLOAD_DATE_INVALID_ID);
			excelErrors.add(eError);
		}
	}

	public void eanFieldValidation(final String cValue, final String columnName, final Set<ExcelError> excelErrors) {
		if (regexValidationUtils.isBlankField(cValue)) {
			ExcelDataValidation.setErrorDetail(excelErrors,columnName, BULK_UPLOAD_EAN_NULL_STATUS, BULK_UPLOAD_EAN_NULL,
					BULK_UPLOAD_EAN_NULL_ID, cValue);
		} else if (regexValidationUtils.isValidLength(cValue, 13)) {
			ExcelDataValidation.setErrorDetail(excelErrors,columnName, BULK_UPLOAD_EAN_INVALID_STATUS,
					BULK_UPLOAD_EAN_INVALID + COLON_SEPARATOR + cValue, BULK_UPLOAD_EAN_INVALID_ID, cValue);
		}
	}

	private void priceFieldValidation(final String cValue, final String columnName,
			final Set<ExcelError> excelErrors) {
		if (regexValidationUtils.isBlankField(cValue)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_NULL_STATUS, BULK_UPLOAD_PRIX_NULL,
					BULK_UPLOAD_PRIX_NULL_ID));
		} else if (!regexValidationUtils.matchWithValidationRegex(cValue, PRICE_VALIDATION_REGEX)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_INVALID_FORMAT_STATUS,
					BULK_UPLOAD_PRIX_INVALID_FORMAT + COLON_SEPARATOR + cValue, BULK_UPLOAD_PRIX_INVALID_FORMAT_ID));
		}
	}

	private void numericFieldValidation(final String cValue, final Set<ExcelError> excelErrors,
			final String columnName) {
		if (regexValidationUtils.isBlankField(cValue)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_NULL_STATUS, BULK_UPLOAD_PRIX_NULL,
					BULK_UPLOAD_PRIX_NULL_ID));
		} else if (!StringUtils.isNumeric(cValue)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_INVALID_FORMAT_STATUS,
					BULK_UPLOAD_PRIX_INVALID_FORMAT + COLON_SEPARATOR + cValue, BULK_UPLOAD_PRIX_INVALID_FORMAT_ID));
		}
	}

	private void roundingTypeFieldValidation(final String cValue, final Set<ExcelError> excelErrors,
			final String columnName) {
		if (regexValidationUtils.isBlankField(cValue)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_NULL_STATUS, BULK_UPLOAD_PRIX_NULL,
					BULK_UPLOAD_PRIX_NULL_ID));
		} else if (Arrays.asList(RoundingType.values()).contains(cValue)) {
			excelErrors.add(setErrorDetail(columnName, BULK_UPLOAD_PRIX_INVALID_FORMAT_STATUS,
					BULK_UPLOAD_PRIX_INVALID_FORMAT + COLON_SEPARATOR + cValue, BULK_UPLOAD_PRIX_INVALID_FORMAT_ID));
		}
	}

	private ExcelError setErrorDetail(final String columnName, final String eCode, final String eDesc,
			final String eId) {
		final ExcelError eError = new ExcelError();
		eError.setCode(eCode);
		eError.setDesc(eDesc);
		eError.setId(eId);
		eError.setCName(columnName);
		return eError;
	}

}