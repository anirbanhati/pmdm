package com.kingfisher.compprice.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@Entity
@Table(name = "lsp_tenant_feature_toggle_config")
public class TenantFeatureToggleConfigEntity implements Serializable {

    private static final long serialVersionUID = 2773926670817577870L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "feature_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private FeatureEntity feature;

    @Column(name = "tenant")
    private String tenant;

    @Column(name = "is_enabled")
    private boolean isEnabled;

    public TenantFeatureToggleConfigEntity(final FeatureEntity feature, final String tenant, final boolean isEnabled) {
        super();
        this.feature = feature;
        this.tenant = tenant;
        this.isEnabled = isEnabled;
    }

    public TenantFeatureToggleConfigEntity() {
        super();
    }

}