package com.kingfisher.compprice.enums;

public enum Role {
	HeadOffice,
	Store
}
