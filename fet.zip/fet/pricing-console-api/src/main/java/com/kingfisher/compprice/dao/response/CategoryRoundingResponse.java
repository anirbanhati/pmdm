package com.kingfisher.compprice.dao.response;

import com.kingfisher.compprice.dao.RoundingConfigs;
import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import com.kingfisher.compprice.enums.RoundingType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryRoundingResponse {

    private CategoryRoundingConfig categoryConfig;
    private RoundingType rType;
    private List<RoundingConfigs> configs;

}