package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.WarlistInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WarlistInfoRepository extends JpaRepository<WarlistInfo, Long> {

    Optional<WarlistInfo> findTopByOrderByLastUpdatedTimeDesc();

}