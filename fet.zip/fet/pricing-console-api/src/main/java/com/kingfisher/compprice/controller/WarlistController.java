package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.kingfisher.compprice.controller.swagger.WarlistControllerSwagger;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.dao.search.SearchProduct;
import com.kingfisher.compprice.service.WarListService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import static com.kingfisher.compprice.util.constants.Constants.*;

@RestController
@RequestMapping(WARLIST_BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class WarlistController implements WarlistControllerSwagger {

	private final CurrentUser user;
	private final WarListService warListService;

	Gson gson = new Gson();

	@GetMapping(path = GET_PRODUCT_FILTER_OPTIONS)
	public MultiDataResponse<Category> getProductsFilterOption(@PathVariable(ID) final String id) {
		log.info("warList: getProductsFilterOption --> {}", id);
		return JsonApiResponse.multiDataResponse(warListService.findTreeOptions(id));
	}

	@PostMapping(WARLIST_PRODUCTS)
	public SingleDataResponse<SearchProduct> productSearch(@RequestBody final ProductSearchCriteria searchCriteria) {
		log.info("warList: productSearch --> {}", gson.toJson(searchCriteria));
		ProductSearchPaging paging = null != searchCriteria.getPaging() ? searchCriteria.getPaging() : new ProductSearchPaging();
		final SearchProduct searchResponse = warListService.productSearch(paging, searchCriteria, user.getUser());
		return JsonApiResponse.singleDataResponse(searchResponse);
	}

}