package com.kingfisher.compprice.dto;


import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name="PriceList")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClusterPriceInfo {

    @XmlElement(name="clusterID")
    private String clusterID;
    @XmlElement(name="bannerID")
    private String bannerID;
    @XmlElement(name="locale")
    private String locale;
    @XmlElement(name="currency")
    private String currency;
    @XmlElement(name="prices")
    private List<ClusterPrices> prices;

    public String getClusterID() {
        return clusterID;
    }

    public void setClusterID(String clusterID) {
        this.clusterID = clusterID;
    }

    public String getBannerID() {
        return bannerID;
    }

    public void setBannerID(String bannerID) {
        this.bannerID = bannerID;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public List<ClusterPrices> getPrices() {
        return prices;
    }

    public void setPrices(List<ClusterPrices> prices) {
        this.prices = prices;
    }
}
