package com.kingfisher.compprice.exception;

import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_204;
import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_400;
import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_403;
import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_404;
import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_409;
import static com.kingfisher.compprice.util.constants.Constants.RESPONSE_MESSAGE_500;

public class ExceptionConstants {
	private static final String CONSTANT = "Constant Class";

	private ExceptionConstants() {
		throw new IllegalStateException(CONSTANT);
	}

	public static class ProductExceptions {
		private ProductExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String INVALID_EAN_APP_EXP = "PR02";
		public static final String INVALID_EAN_HTTP_STATUS = "404";
		public static final String INVALID_EAN_DETAILS = "Ean not found";
		public static final String INVALID_EAN_ID = "CMP_PRC_PR_DE_02";
		public static final String INVALID_EAN_POINTER = "ean";
		public static final String INVALID_EAN_TITLE = RESPONSE_MESSAGE_404;

		public static final String PRODUCT_NOT_FOUND_APP_EXP = "PR03";
		public static final String PRODUCT_NOT_FOUND_HTTP_STATUS = "404";
		public static final String PRODUCT_NOT_FOUND_DETAILS = "Product not found by type";
		public static final String PRODUCT_NOT_FOUND_ID = "CMP_PRC_PR_DE_03";
		public static final String PRODUCT_NOT_FOUND_POINTER = "ean | prdType";
		public static final String PRODUCT_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;

		public static final String ROUNDING_NOT_FOUND_APP_EXP = "PR04";
		public static final String ROUNDING_NOT_FOUND_HTTP_STATUS = "404";
		public static final String ROUNDING_NOT_FOUND_DETAILS = "Rounding is not available for this product";
		public static final String ROUNDING_NOT_FOUND_ID = "CMP_PRC_PR_DE_04";
		public static final String ROUNDING_NOT_FOUND_POINTER = "ean";
		public static final String ROUNDING_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class ExcelImportExceptions {
		private ExcelImportExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String EXCEL_IMPORT_APP_EXP = "E01";
		public static final String EXCEL_IMPORT_HTTP_STATUS = "500";
		public static final String EXCEL_IMPORT_DETAILS = "Unable to prepare excel";
		public static final String EXCEL_IMPORT_ID = "CMP_PRC_EI_DE_01";
		public static final String EXCEL_IMPORT_POINTER = "priceId";
		public static final String EXCEL_IMPORT_KEY_POINTER = "errorKey";
		public static final String EXCEL_IMPORT_TITLE = RESPONSE_MESSAGE_500;
	}

	public static class StagePriceExceptions {
		private StagePriceExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String STAGE_PRICE_REQ_APP_EXP = "SP01";
		public static final String STAGE_PRICE_REQ_HTTP_STATUS = "400";
		public static final String STAGE_PRICE_REQ_DETAILS = "Price can not be less than minimal price calculated with MAX Decrease % or greater than standard price";
		public static final String STAGE_PRICE_REQ_ID = "CMP_PRC_SP_DE_01";
		public static final String STAGE_PRICE_REQ_POINTER = "ean | maxDecrease";
		public static final String STAGE_PRICE_REQ_TITLE = RESPONSE_MESSAGE_400;

		public static final String STAGE_PRICE_REQ_INV_SD_APP_EXP = "SP02";
		public static final String STAGE_PRICE_REQ_INV_SD_HTTP_STATUS = "400";
		public static final String STAGE_PRICE_REQ_INV_SD_DETAILS = "Invalid start or end date";
		public static final String STAGE_PRICE_REQ_INV_SD_ID = "CMP_PRC_SP_DE_02";
		public static final String STAGE_PRICE_REQ_INV_SD_POINTER = "ean | startDate";
		public static final String STAGE_PRICE_REQ_INV_SD_TITLE = RESPONSE_MESSAGE_400;

		public static final String STAGE_PRICE_REQ_INV_ED_APP_EXP = "SP03";
		public static final String STAGE_PRICE_REQ_INV_ED_HTTP_STATUS = "400";
		public static final String STAGE_PRICE_REQ_INV_ED_DETAILS = "End date should be between start date and start date + 45 if the product_type is WarList";
		public static final String STAGE_PRICE_REQ_INV_ED_ID = "CMP_PRC_SP_DE_03";
		public static final String STAGE_PRICE_REQ_INV_ED_POINTER = "ean | endDate";
		public static final String STAGE_PRICE_REQ_INV_ED_TITLE = RESPONSE_MESSAGE_400;

		public static final String STAGE_MAX_PRICE_REQ_APP_EXP = "SP04";
		public static final String STAGE_MAX_PRICE_REQ_HTTP_STATUS = "400";
		public static final String STAGE_MAX_PRICE_REQ_DETAILS = "Price can not be greater than maximum price calculated with MAX Increase % or standard price";
		public static final String STAGE_MAX_PRICE_REQ_ID = "CMP_PRC_SP_DE_04";
		public static final String STAGE_MAX_PRICE_REQ_POINTER = "ean | maxIncrease";
		public static final String STAGE_MAX_PRICE_REQ_TITLE = RESPONSE_MESSAGE_400;

		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_APP_EXP = "SP05";
		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_HTTP_STATUS = "404";
		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_DETAILS = "No cost price Available";
		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_ID = "CMP_PRC_SP_DE_03";
		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_POINTER = "ean | store";
		public static final String STG_PRODUCT_COST_PRICE_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class UserExceptions {
		private UserExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String USER_ID_EMPTY_APP_EXP = "US01";
		public static final String USER_ID_EMPTY_HTTP_STATUS = "204";
		public static final String USER_ID_EMPTY_DETAILS = "User Id cant be empty";
		public static final String USER_ID_EMPTY_ID = "CMP_PRC_US_DE_01";
		public static final String USER_ID_EMPTY_POINTER = "userId";
		public static final String USER_ID_EMPTY_TITLE = RESPONSE_MESSAGE_204;

		public static final String USER_EXISTS_APP_EXP = "US02";
		public static final String USER_EXISTS_HTTP_STATUS = "409";
		public static final String USER_EXISTS_ID = "CMP_PRC_US_DE_02";
		public static final String USER_EXISTS_POINTER = "userId";
		public static final String USER_EXISTS_TITLE = RESPONSE_MESSAGE_409;

		public static final String USER_NOT_FOUND_APP_EXP = "US03";
		public static final String USER_NOT_FOUND_HTTP_STATUS = "404";
		public static final String USER_NOT_FOUND_DETAILS = "User not found";
		public static final String USER_NOT_FOUND_ID = "CMP_PRC_US_DE_03";
		public static final String USER_NOT_FOUND_POINTER = "userId";
		public static final String USER_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class StoreExceptions {

		private StoreExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String STORE_NOT_FOUND_APP_EXP = "ST01";
		public static final String STORE_NOT_FOUND_HTTP_STATUS = "404";
		public static final String STORE_NOT_FOUND_DETAILS = "No Store Details Available";
		public static final String STORE_NOT_FOUND_ID = "CMP_PRC_ST_DE_01";
		public static final String STORE_CODE_NOT_FOUND_POINTER = "storeCode";
		public static final String STORE_ID_NOT_FOUND_POINTER = "storeId";
		public static final String STORE_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class StorePriceExceptions {

		private StorePriceExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String STORE_PRICE_NOT_FOUND_APP_EXP = "STP01";
		public static final String STORE_PRICE_NOT_FOUND_HTTP_STATUS = "404";
		public static final String STORE_PRICE_NOT_FOUND_DETAILS = "Store Price not Available";
		public static final String STORE_PRICE_NOT_FOUND_ID = "CMP_PRC_STP_DE_01";
		public static final String STORE_PRICE_CODE_NOT_FOUND_POINTER = "ean | storeCode";
		public static final String STORE_PRICE_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class CollectionListExceptions {
		private CollectionListExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String CI_ITEM_EXIST_APP_EXP = "CI01";
		public static final String CI_ITEM_EXIST_HTTP_STATUS = "409";
		public static final String CI_ITEM_EXIST_DETAILS = "Duplicate Item";
		public static final String CI_ITEM_EXIST_ID = "CMP_PRC_CI_DE_01";
		public static final String CI_ITEM_EXIST_POINTER = "clName|id";
		public static final String CI_ITEM_EXIST_TITLE = RESPONSE_MESSAGE_409;

		public static final String CI_ITEM_NOT_FOUND_APP_EXP = "CI02";
		public static final String CI_ITEM_NOT_FOUND_HTTP_STATUS = "404";
		public static final String CI_ITEM_NOT_FOUND_DETAILS = "Collection list not found";
		public static final String CI_ITEM_NOT_FOUND_ID = "CMP_PRC_CI_DE_02";
		public static final String CI_ITEM_NOT_FOUND_POINTER = "id";
		public static final String CI_ITEM_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;

		public static final String CI_ITEM_INTERNAL_ERROR_APP_EXP = "CI03";
		public static final String CI_ITEM_INTERNAL_ERROR_HTTP_STATUS = "409";
		public static final String CI_ITEM_INTERNAL_ERROR_DETAILS = "Unable to copy the data";
		public static final String CI_ITEM_INTERNAL_ERROR_ID = "CMP_PRC_CI_DE_03";
		public static final String CI_ITEM_INTERNAL_ERROR_POINTER = "id";
		public static final String CI_ITEM_INTERNAL_ERROR_TITLE = RESPONSE_MESSAGE_500;

		public static final String CI_ITEM_ID_MISSING_APP_EXP = "CI04";
		public static final String CI_ITEM_ID_MISSING_HTTP_STATUS = "400";
		public static final String CI_ITEM_ID_MISSING_DETAILS = "Id is missing";
		public static final String CI_ITEM_ID_MISSING_ID = "CMP_PRC_CI_DE_04";
		public static final String CI_ITEM_ID_MISSING_POINTER = "id";
		public static final String CI_ITEM_ID_MISSING_TITLE = RESPONSE_MESSAGE_400;

		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_EXP = "CI05";
		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_HTTP_STATUS = "403";
		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_DETAILS = "Action not permitted";
		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_ID = "CMP_PRC_CI_DE_05";
		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_POINTER = "id";
		public static final String CI_ITEM_UPDATE_NOT_PERMITTED_TITLE = RESPONSE_MESSAGE_403;

	}

	public static class WarListExceptions {
		private WarListExceptions() {
			throw new IllegalStateException(CONSTANT);
		}

		public static final String WAR_PRODUCT_NOT_FOUND_APP_EXP = "WP01";
		public static final String WAR_PRODUCT_NOT_FOUND_HTTP_STATUS = "404";
		public static final String WAR_PRODUCT_NOT_FOUND_DETAILS = "No War Product Available";
		public static final String WAR_PRODUCT_NOT_FOUND_ID = "CMP_PRC_WP_DE_01";
		public static final String WAR_PRODUCT_NOT_FOUND_POINTER = "id";
		public static final String WAR_PRODUCT_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;

		public static final String WAR_PRODUCT_INVALID_INPUT_APP_EXP = "WP02";
		public static final String WAR_PRODUCT_INVALID_INPUT_HTTP_STATUS = "500";
		public static final String WAR_PRODUCT_INVALID_INPUT_DETAILS = "Invalid input file";
		public static final String WAR_PRODUCT_INVALID_INPUT_POINTER = "file";
		public static final String WAR_PRODUCT_INVALID_INPUT_TITLE = RESPONSE_MESSAGE_500;

		public static final String WAR_PRODUCT_NO_DATA_FOUND_APP_EXP = "WP03";
		public static final String WAR_PRODUCT_NO_DATA_FOUND_HTTP_STATUS = "404";
		public static final String WAR_PRODUCT_NO_DATA_FOUND_DETAILS = "No War Product Available in excel";
		public static final String WAR_PRODUCT_NO_DATA_FOUND_ID = "CMP_PRC_WP_DE_03";
		public static final String WAR_PRODUCT_NO_DATA_FOUND_POINTER = "file";
		public static final String WAR_PRODUCT_NO_DATA_FOUND_TITLE = RESPONSE_MESSAGE_404;

		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_APP_EXP = "WP04";
		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_HTTP_STATUS = "400";
		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_DETAILS = "Invalid daat";
		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_ID = "CMP_PRC_WP_DE_04";
		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_POINTER = "ean";
		public static final String WAR_PRODUCT_INVALID_DATA_FOUND_TITLE = RESPONSE_MESSAGE_400;

		public static final String WAR_PRODUCT_MISSING_HEADER_APP_EXP = "WP05";
		public static final String WAR_PRODUCT_MISSING_HEADER_HTTP_STATUS = "404";
		public static final String WAR_PRODUCT_MISSING_HEADER_DETAILS = "Message header";
		public static final String WAR_PRODUCT_MISSING_HEADER_ID = "CMP_PRC_WP_DE_05";
		public static final String WAR_PRODUCT_MISSING_HEADER_POINTER = "headers";
		public static final String WAR_PRODUCT_MISSING_HEADER_TITLE = RESPONSE_MESSAGE_404;
	}

	public static class StageProductExceptions {


		public static final String STG_PRODUCT_NOT_FOUND_APP_EXP = "SP01";
		public static final String STG_PRODUCT_NOT_FOUND_HTTP_STATUS = "404";
		public static final String STG_PRODUCT_NOT_FOUND_DETAILS = "No Stage Product Available";
		public static final String STG_PRODUCT_NOT_FOUND_ID = "CMP_PRC_SP_DE_01";
		public static final String STG_PRODUCT_NOT_FOUND_POINTER = "id";
		public static final String STG_PRODUCT_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;

		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_APP_EXP = "SP02";
		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_HTTP_STATUS = "404";
		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_DETAILS = "No Stage Product Available";
		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_ID = "CMP_PRC_SP_DE_02";
		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_POINTER = "userId";
		public static final String STG_PRODUCT_FOR_USER_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;


		private StageProductExceptions() {
			throw new IllegalStateException(CONSTANT);
		}
	}

	public static class FeatureExceptions {

		public static final String FEATURE_NOT_FOUND_EXP = "FT01";
		public static final String FEATURE_NOT_FOUND_HTTP_STATUS = "404";
		public static final String FEATURE_NOT_FOUND_DETAILS = "Feature is not available";
		public static final String FEATURE_NOT_FOUND_ID = "LSP_PRC_FT_DE_01";
		public static final String FEATURE_NAME_NOT_FOUND_POINTER = "featureName";
		public static final String FEATURE_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;

		private FeatureExceptions() {
			throw new IllegalStateException(CONSTANT);
		}
	}

	public static class ClusterExceptions {

		private ClusterExceptions() {
			throw new IllegalStateException(CONSTANT);
		}


			public static final String CLUSTER_NOT_FOUND_APP_EXP = "CL01";
			public static final String CLUSTER_NOT_FOUND_HTTP_STATUS = "404";
			public static final String CLUSTER_NOT_FOUND_DETAILS = "No Cluster Details Available";
			public static final String CLUSTER_NOT_FOUND_ID = "CP_PRC_ST_DE_01";
			public static final String CLUSTER_ID_NOT_FOUND_POINTER = "clusterId";
		    public static final String CLUSTER_STORE_CODE_NOT_FOUND_POINTER = "storeCode";
			public static final String CLUSTER_NOT_FOUND_TITLE = RESPONSE_MESSAGE_404;
		}

}
