package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ProductListing;
import com.kingfisher.compprice.dao.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ProductListingRepository extends JpaRepository<ProductListing, Long> {

    List<ProductListing> findAllByStoreAndEan(final Store store, final String ean);

    List<ProductListing> findByStoreAndEanIn(final Store store, final List<String> listOfEan);

    List<ProductListing> findByEndDateBefore(final LocalDateTime date);

}