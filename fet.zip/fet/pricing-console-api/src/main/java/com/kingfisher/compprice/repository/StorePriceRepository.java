package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StorePrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Repository
public interface StorePriceRepository extends JpaRepository<StorePrice, Long> {

    Set<StorePrice> findByEan(final String ean);

    List<StorePrice> findByEndDateBefore(final LocalDateTime date);

    List<StorePrice> findByStoreAndEanIn(final Store store, final List<String> listOfEan);

    List<StorePrice> findByStore_StoreCodeAndEan(final String storeCode, final String ean);

}