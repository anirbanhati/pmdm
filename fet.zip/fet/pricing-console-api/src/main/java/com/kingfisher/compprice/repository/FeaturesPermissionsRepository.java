package com.kingfisher.compprice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kingfisher.compprice.dao.entity.FeaturesPermissions;

@Repository
public interface FeaturesPermissionsRepository extends JpaRepository<FeaturesPermissions, Long> {

	FeaturesPermissions findByFeaturesPermissionsName(final String name);

}