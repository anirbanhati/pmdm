package com.kingfisher.compprice.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.jsonapi.Resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = TBL_PRODUCT_ROUNDING_CONFIG)
public class ProductRoundingConfig  extends RoundingConfig implements Resource, Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5873058253242747582L;

	@Id
	@Column(name = COL_PRODUCT_CODE)
	private Long articleNumber;

	@Column(name = COL_UNIT_OF_MEASURE)
	private String unitOfMeasure;

	@Column(name = ROUNDING_TYPE)
	private RoundingType type;

	@Column(name = COL_PERFORM_ROUNDING)
	private Boolean performRounding;


	@Override
	public String getJsonApiDataId() {
		return String.valueOf(articleNumber);
	}

	@Override
	public String getJsonApiDataType() {
		return TBL_PRODUCT_ROUNDING_CONFIG;
	}

}