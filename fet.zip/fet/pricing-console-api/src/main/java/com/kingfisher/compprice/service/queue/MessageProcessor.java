package com.kingfisher.compprice.service.queue;

import com.kingfisher.domain.Tenant;
import com.kingfisher.mq.MqErrorHandler;
import com.kingfisher.mq.MqMetricHandler;
import lombok.extern.slf4j.Slf4j;

import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import java.util.List;
import java.util.concurrent.locks.Lock;

@Slf4j
public class MessageProcessor implements MessageListener {

	private final List<MessageService> messageServices;
	private final MqErrorHandler mqErrorHandler;
	private final MqMetricHandler metricHandler;
	private final Lock messageProcessingLock;

	private final Tenant tenant;

	public Tenant getTenant() {
		return tenant;
	}

	public MessageProcessor(
			final List<MessageService> messageServices,
			final MqErrorHandler mqErrorHandler,
			final MqMetricHandler metricHandler,
			final String tenant,
			final Lock messageProcessingLock
			) {
		this.messageServices = messageServices;
		this.mqErrorHandler = mqErrorHandler;
		this.metricHandler = metricHandler;
		this.tenant = Tenant.valueOf(tenant);
		this.messageProcessingLock = messageProcessingLock;
	}

	@Override
	public void onMessage(final Message message) {
		messageProcessingLock.lock();
		try {
			process(((TextMessage) message).getText());
		} catch (final Exception ex) {
			mqErrorHandler.handleError(ex);
		} finally {
			messageProcessingLock.unlock();
		}
	}

	public void process(final String message) {
		messageServices.forEach(service -> service.processMessage(message, metricHandler));
	}

}