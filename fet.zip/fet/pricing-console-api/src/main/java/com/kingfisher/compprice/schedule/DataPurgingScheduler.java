package com.kingfisher.compprice.schedule;

import com.kingfisher.compprice.service.DataPurgeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import static com.kingfisher.compprice.util.constants.SchedulerConstants.*;

@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
public class DataPurgingScheduler {

    private final DataPurgeService dataPurgeService;


    @Scheduled(cron = "${cron.purge.storeProduct}")
    @SchedulerLock(name = PURGE_STORE_PRODUCT)
    public void purgeStoreProductData() {
        dataPurgeService.purgeStoreProductData();
    }

    @Scheduled(cron = "${cron.purge.user}")
    @SchedulerLock(name = PURGE_USER)
    public void purgeUserData() {
        dataPurgeService.purgeUserData();
    }

    @Scheduled(cron = "${cron.purge.salesHistory}")
    @SchedulerLock(name = PURGE_SALES_HISTORY)
    public void purgeSalesHistoryData() {
        dataPurgeService.purgeSalesHistoryData();
    }

    @Scheduled(cron = "${cron.purge.price}")
    @SchedulerLock(name = PURGE_PRICE)
    public void purgePriceData() {
        dataPurgeService.purgePriceData();
    }

    @Scheduled(cron = "${cron.purge.productPrice}")
    @SchedulerLock(name = PURGE_PRODUCT_PRICE)
    public void purgeProductPriceData() {
        dataPurgeService.purgeProductPriceData();
    }

    @Scheduled(cron = "${cron.purge.productListing}")
    @SchedulerLock(name = PURGE_PRODUCT_LISTING)
    public void purgeListingData() {
        dataPurgeService.purgeListingData();
    }

    @Scheduled(cron = "${cron.purge.importErrors}")
    @SchedulerLock(name = PURGE_IMPORT_ERRORS)
    public void purgeImportErrorsData() {
        dataPurgeService.purgeImportErrors();
    }

    @Scheduled(cron = "${cron.purge.rollingDays}")
    @SchedulerLock(name = PURGE_ROLLING_DAYS)
    public void purgeRollingDaysData() {
        dataPurgeService.purgeRollingDays();
    }

    @Scheduled(cron = "${cron.purge.schedulerStatus}")
    @SchedulerLock(name = PURGE_SCHEDULER_STATUS)
    public void purgeSchedulerStatusData() {
        dataPurgeService.purgeSchedulerStatus();
    }

    @Scheduled(cron = "${cron.purge.clusterPrice}")
    @SchedulerLock(name = PURGE_CLUSTER_PRICE)
    public void purgeClusterPriceData() {
        dataPurgeService.purgeClusterPrice();
    }

    @Scheduled(cron = "${cron.purge.hoScObject}")
    @SchedulerLock(name = PURGE_HO_SC_OBJECT)
    public void purgeHoCollectionsObjectsFromBucket() {
        dataPurgeService.deleteS3Items();
    }

    @Scheduled(cron = "${cron.purge.storeCollection}")
    @SchedulerLock(name = PURGE_STORE_COLLECTION)
    public void purgeStoreCollections() {
        dataPurgeService.purgeStoreCollections();
    }

}