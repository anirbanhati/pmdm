package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.CompetitorProduct;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dto.ProductAssociation;
import com.kingfisher.compprice.dto.ProductAssociations;
import com.kingfisher.compprice.repository.CompetitorProductRepository;
import com.kingfisher.compprice.repository.ProductRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.domain.Tenant.BDFR;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductAssociationService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final CompetitorProductRepository competitorProductRepository;
    private final ProductRepository productRepository;
    private final MessageServicesHelper servicesHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return MessageService.ProcessedByType.PRODUCT_ASSOCIATION_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Product Association Feed :: {}", message);
        }
        final String methodName = "processMessage";
        try {
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message:: {} :: {}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message for product association", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String message) throws JAXBException {
        if (StringUtils.isNotEmpty(message)) {
            final List<String> salesUnits = servicesHelper.determineSalesOrgByTenant(BDFR.getTenantId());
            getProductAssociations(message).getProductAssociation().forEach(prdAssoc -> processProductAssociationDetails(prdAssoc, salesUnits));
        } else
            log.info("Product association message is either null or empty");
    }

    private void processProductAssociationDetails(final ProductAssociation productAssociation, final List<String> salesUnits) {
        if (isProductAssociationFeedValid(productAssociation, productAssociation.getCompCode())) {
            processValidProductAssociationDetails(productAssociation, salesUnits);
        } else
            log.info("Product Association feed details are not valid");
    }

    private void processValidProductAssociationDetails(final ProductAssociation productAssociation, final List<String> salesUnits) {
        List<Product> existingProducts = productRepository.findByEanAndSalesUnitIn(productAssociation.getEan(), salesUnits);
        salesUnits.forEach(salesUnit -> {
            var existingProduct = existingProducts.stream()
                    .filter(products -> Objects.equals(salesUnit, products.getSalesUnit())).findFirst();

            if (existingProduct.isPresent()) {
                processAddOrUpdateForFeed(productAssociation, existingProduct.get(), productAssociation.getCompCode(), salesUnit);
            } else {
                Product newProduct = servicesHelper.createProduct(productAssociation.getEan(), productAssociation.getArticleNumber(), salesUnit);
                processAddOrUpdateForFeed(productAssociation, newProduct, productAssociation.getCompCode(), salesUnit);
            }
        });
    }

    private void processAddOrUpdateForFeed(final ProductAssociation productAssociation, final Product product,
                                           final String storeName, final String salesUnit) {
        CompetitorProduct existingCompetitorProduct = competitorProductRepository.findByCompEanAndEanAndCodeAndSalesUnit(
                productAssociation.getCompEAN(), productAssociation.getEan(), productAssociation.getCompCode(), salesUnit).orElse(null);
        if (null != existingCompetitorProduct) {
            populateAndSaveCompetitorProduct(productAssociation, storeName, existingCompetitorProduct, salesUnit);
        } else {
            CompetitorProduct newCompetitorProductDetails = createCompetitorProduct(productAssociation, product);
            populateAndSaveCompetitorProduct(productAssociation, storeName, newCompetitorProductDetails, salesUnit);
        }
    }

    private void populateAndSaveCompetitorProduct(ProductAssociation productAssociation, final String storeName,
                                                  CompetitorProduct competitorProduct, final String salesUnit) {
        populateExistingCompProductAssociation(productAssociation, storeName, competitorProduct, salesUnit);
        competitorProductRepository.save(competitorProduct);
    }

    private CompetitorProduct createCompetitorProduct(ProductAssociation productAssociation, final Product product) {
        log.debug("Creating the new product association for Comp ean ::{}", productAssociation.getCompEAN());
        CompetitorProduct newCompetitorProduct = new CompetitorProduct();
        newCompetitorProduct.setEan(productAssociation.getEan());
        newCompetitorProduct.setComProd(product);
        newCompetitorProduct.setCompEan(productAssociation.getCompEAN());
        return newCompetitorProduct;
    }

    private void populateExistingCompProductAssociation(ProductAssociation productAssociation, final String storeName,
                                                        CompetitorProduct competitorProduct, final String salesUnit) {
        competitorProduct.setCoef(Integer.parseInt(productAssociation.getCoef()));
        competitorProduct.setCompName(storeName);
        competitorProduct.setDeleteFlag(productAssociation.getDeleteFlag());
        competitorProduct.setCreationDate(servicesHelper.getLocalDateTime(productAssociation.getCreationDate()));
        competitorProduct.setUom(productAssociation.getUom());
        competitorProduct.setCompArticleNumber(productAssociation.getCompArticleNumber());
        competitorProduct.setCompDescription(productAssociation.getCompArticleDescription());
        competitorProduct.setCode(productAssociation.getCompCode());
        competitorProduct.setSalesUnit(salesUnit);
        competitorProduct.setLastUpdatedDate(LocalDateTime.now());
    }

    private boolean isProductAssociationFeedValid(final ProductAssociation productAssociation, final String compCode) {
        return StringUtils.isNotEmpty(compCode) && StringUtils.isNotEmpty(productAssociation.getCompEAN()) && StringUtils.isNotEmpty(productAssociation.getEan());
    }

    private ProductAssociations getProductAssociations(final String message) throws JAXBException {
        StringReader sr = new StringReader(message);
        JAXBContext context = JAXBContext.newInstance(ProductAssociations.class);
        Unmarshaller productAssociationUnmarsheller = context.createUnmarshaller();
        return (ProductAssociations) productAssociationUnmarsheller.unmarshal(sr);
    }

}