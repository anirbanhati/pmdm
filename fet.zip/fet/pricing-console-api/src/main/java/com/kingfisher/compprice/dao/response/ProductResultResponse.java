package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductResultResponse implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = -7434852544913078570L;

    @JsonProperty("cat")
    private String category;

    @JsonProperty("brickCode")
    private String brickCode;

    @JsonProperty("subCat")
    private String subCategory;

    private String ean;

    @JsonProperty("bName")
    private String brickName;

    @JsonProperty("desc")
    private String description;

    @JsonProperty("code")
    private String productCode;

    private String prdType;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}