package com.kingfisher.compprice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.entity.CompetitorProduct;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.UOM;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductDTO implements Serializable {
    private static final long serialVersionUID = -7528399064416573455L;

    private Long productId;
    private String ean;
    @JsonProperty("code")
    private String productCode;
    @JsonProperty("cat")
    private String category;
    private String appType;
    @JsonProperty("pkg")
    private String packaging;
    @JsonProperty("brickCode")
    private String brickCode;
    @JsonProperty("subCat")
    private String subCategory;
    @JsonProperty("sUnit")
    private String salesUnit;
    @JsonProperty("bName")
    private String brickName;
    @JsonProperty("desc")
    private String description;
    private String pkg1;
    private String pkg2;
    private String unit;
    private double map;
    private Double priceUom;
    private Double conversion;
    @JsonProperty(UOM)
    private String uom;
    @JsonProperty("stdPrice")
    private Double standardPrice;
    @JsonProperty("sPrice")
    private Double salesPrice;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private double effectivePrice;
    private Double costPrice;
    private String vatCategory;
    private LocalDateTime lastUpdated;
    private Double productStatus;
    private String legalUnit;
    private Set<CompetitorProduct> comProduct;

}