package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.kingfisher.compprice.controller.swagger.ClusterPriceControllerSwagger;
import com.kingfisher.compprice.dao.entity.ClusterStoreMapping;
import com.kingfisher.compprice.service.ClusterPriceService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@RequestMapping(CLUSTER_PRICE_BASE_URL)
@RequiredArgsConstructor
@RestController
@Slf4j
public class ClusterPriceController implements ClusterPriceControllerSwagger {

    private final ClusterPriceService clusterPriceService;

    Gson gson = new Gson();

    @PostMapping(POST_CLUSTER_STORES)
    public MultiDataResponse<ClusterStoreMapping> saveClusterStoresData(@RequestBody final List<ClusterStoreMapping> clusterStoreList) throws JSONException {
        log.info("Cluster: saveClusterStoresData --> {}", gson.toJson(clusterStoreList));
        final List<ClusterStoreMapping> clStoresList = clusterPriceService.saveClusterStoreDetails(clusterStoreList);
        return JsonApiResponse.multiDataResponse(clStoresList);
    }

    @GetMapping(path = GET_CLUSTER_BY_STORE_CODE)
    public SingleDataResponse<ClusterStoreMapping> getClusterByCode(@PathVariable final String code) {
        log.info("Cluster: getClusterByCode --> {}", code);
        return JsonApiResponse.singleDataResponse(clusterPriceService.getClusterByStoreCode(code));
    }

    @GetMapping(path = GET_CLUSTERS_DETAILS)
    public MultiDataResponse<ClusterStoreMapping> getClusterStoreData() {
        log.info("Cluster: getClusterStoreData");
        final List<ClusterStoreMapping> allClusterStoreDetails = clusterPriceService.getAllClusterDetails();
        return JsonApiResponse.multiDataResponse(allClusterStoreDetails);
    }

    @DeleteMapping(path = DELETE_CLUSTER_STORES)
    public ResponseEntity<String> deleteClusterStoreByCode(@PathVariable final String code) {
        log.info("Cluster: deleteClusterStoreByCode --> {}", code);
        clusterPriceService.deleteClusterStores(code);
        return new ResponseEntity<>("All Items have been deleted", HttpStatus.OK);
    }

    @DeleteMapping(path = ALL)
    public ResponseEntity<String> deleteAllClusterStore() {
        log.info("Cluster: deleteAllClusterStore");
        clusterPriceService.deleteAllClusterStores();
        return new ResponseEntity<>("All Items have been deleted", HttpStatus.OK);
    }

}