package com.kingfisher.compprice.config.batch;

import com.kingfisher.compprice.exception.BatchProcessingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

import java.io.IOException;

@RequiredArgsConstructor
@Slf4j
public class BatchStepExecutionListener implements StepExecutionListener {

    private final SynchronizedExcelItemWriter synchronizedExcelItemWriter;


    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.debug(":Batch: BatchStepExecutionListener: beforeStep");
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        try {
            synchronizedExcelItemWriter.close();
        } catch (IOException e) {
            throw new BatchProcessingException("Failed to close SynchronizedExcelItemWriter", e);
        }
        return ExitStatus.COMPLETED;
    }

}