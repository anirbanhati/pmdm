package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductListing;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.repository.ProductListingRepository;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.PRD_LISTING_CACHE;

@Slf4j
@RequiredArgsConstructor
@Service
public class ProductListingService {

    private final ProductListingRepository prdListingRepo;
    private final LogService logService;


    @Cacheable(value = PRD_LISTING_CACHE, key = "{#product.ean, #store.storeCode}")
    public boolean validProductListing(final Product product, final Store store) {
        StopWatch stopWatch = logService.logStopWatchStart("validProductListing");

        boolean isPrdList = true;
        List<ProductListing> prdLists = prdListingRepo.findAllByStoreAndEan(store, product.getEan());
        if (CollectionUtils.isNotEmpty(prdLists)) {
            isPrdList = prdLists.stream()
                    .filter(prdList -> DateUtils.isInBetween(prdList.getStartDate(), prdList.getEndDate().plusDays(1), LocalDateTime.now()))
                    .max(Comparator.comparing(ProductListing::getLastUpdated))
                    .isPresent();
        }
        logService.logStopWatchStop(stopWatch);
        return isPrdList;
    }

    public Map<String, Boolean> validateProductListing(final List<Product> products, List<String> listOfEan, final Store store) {
        StopWatch stopWatch = logService.logStopWatchStart("validateProductListing");
        Map<String, Boolean> eanProductListingMap = new HashMap<>();

        if (CollectionUtils.isEmpty(listOfEan)) {
            listOfEan = products.stream().map(Product::getEan).toList();
        }

        var productListings = findProductListingByListOfEan(store, listOfEan);
        if (CollectionUtils.isEmpty(productListings)) {
            listOfEan.forEach(ean -> eanProductListingMap.put(ean, true));
        } else {
            var productListMap = productListings.stream().collect(Collectors.groupingBy(ProductListing::getEan));
            listOfEan.forEach(ean -> {
                List<ProductListing> prdLists = productListMap.getOrDefault(ean, List.of());
                if (CollectionUtils.isNotEmpty(prdLists)) {
                    var prdListOptional = prdLists.stream()
                            .filter(prdList -> DateUtils.isInBetween(prdList.getStartDate(), prdList.getEndDate().plusDays(1), LocalDateTime.now()))
                            .max(Comparator.comparing(ProductListing::getLastUpdated));
                    eanProductListingMap.put(ean, prdListOptional.isPresent());
                } else {
                    eanProductListingMap.put(ean, true);
                }
            });
        }
        logService.logStopWatchStop(stopWatch);
        return eanProductListingMap;
    }

    private List<ProductListing> findProductListingByListOfEan(final Store store, final List<String> listOfEan) {
        StopWatch stopWatch = logService.logStopWatchStart("findProductListingByListOfEan");
        var productListings = prdListingRepo.findByStoreAndEanIn(store, listOfEan);
        logService.logStopWatchStop(stopWatch);
        return productListings;
    }

}