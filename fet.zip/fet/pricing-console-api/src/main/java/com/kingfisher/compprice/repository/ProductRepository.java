package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Assignment;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.enums.ProductType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    Optional<Product> findProductByEanAndSalesUnit(final String ean, final String salesOrg);

    Optional<Product> findProductByEanAndSalesUnitIn(final String ean, final List<String> salesUnits);

    List<Product> findProductByEanInAndSalesUnitIn(final List<String> listOfEan, final List<String> salesUnits);

    List<Product> findAllByEanInAndSalesUnitInAndLastUpdatedIsNotNull(final List<String> validEans, final List<String> salesOrgIds);

    Optional<Product> findByEanAndSalesUnitInAndStoreProduct_PrdType(final String ean, final List<String> salesUnits, final ProductType type);

    List<Product> findByAssignmentIn(final Set<Assignment> assignments);

    @Query(value = "select  distinct  a.category, a.sub_category, a.brick_name, a.brick_code  from competitorprice.lsp_product a", nativeQuery = true)
    List<Object> findAllDistinctData();

    @Query(value = "select  distinct  a.category, a.sub_category, a.brick_name, a.brick_code  from competitorprice.lsp_product a  where a.product_id in\n" +
            "(select product_id from competitorprice.store_product_mapping d where d.store_id = ?1 and d.prd_type in ('PVMax','PVLocal'))", nativeQuery = true)
    List<Object> findAllDistinctData(Long storeId, List<String> types);

    @Query(value = "select  distinct  a.category, a.sub_category, a.brick_name, a.brick_code  from competitorprice.lsp_product a  where a.product_id in\n" +
            "(select product_id from competitorprice.store_product_mapping d where d.store_id = ?1 and d.prd_type in ('OutOfRange'))", nativeQuery = true)
    List<Object> findAllDistinctDataForOor(Long storeId, List<String> types);

    @Query(value = "select  distinct  a.category, a.sub_category, a.brick_name, a.brick_code  from competitorprice.lsp_product a  where a.product_id in\n" +
            "(select product_id from competitorprice.store_product_mapping d where d.store_id = ?1 and d.prd_type in ('WarList'))", nativeQuery = true)
    List<Object> findAllDistinctDataForWarList(Long storeId, List<String> types);

    @Query(value = "select  distinct  a.category, a.sub_category, a.brick_name, a.brick_code  from competitorprice.lsp_product a  where a.product_id in\n" +
            "(select product_id from competitorprice.store_product_mapping d where d.store_id = ?1 and d.prd_type in ('SlowMoving'))", nativeQuery = true)
    List<Object> findAllDistinctDataForSlowMoving(Long storeId, List<String> types);

    List<Product> findByEanAndSalesUnitIn(final String ean, final List<String> strings);

}