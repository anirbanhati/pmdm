package com.kingfisher.compprice.dto;

import lombok.Getter;
import lombok.Setter;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "PriceList")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class PriceInfo {

    @XmlElement(name = "storeID")
    private String storeID;
    @XmlElement(name = "bannerID")
    private String bannerID;
    @XmlElement(name = "currency")
    private String currency;
    @XmlElement(name = "locale")
    private String locale;
    @XmlElement(name = "prices")
    private List<Prices> prices;
}
