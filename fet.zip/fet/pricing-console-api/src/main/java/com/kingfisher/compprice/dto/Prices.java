package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "prices")
@XmlAccessorType(XmlAccessType.FIELD)
public class Prices {


    @XmlElement(name = "currentReferencePrice")
    private double currentReferencePrice;
    @XmlElement(name = "currentStorePrice")
    private double currentStorePrice;
    @XmlElement(name = "currentNationalPrice")
    private double currentNationalPrice;
    @XmlElement(name = "ean")
    private String ean;
    @XmlElement(name = "uom")
    private String uom;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "startDate")
    private String startDate;
    @XmlElement(name = "endDate")
    private String endDate;

    @XmlElement(name = "priceTypeFlag")
    private String priceTypeFlag;

    public double getCurrentReferencePrice() {
        return currentReferencePrice;
    }

    public void setCurrentReferencePrice(double currentReferencePrice) {
        this.currentReferencePrice = currentReferencePrice;
    }

    public double getCurrentStorePrice() {
        return currentStorePrice;
    }

    public void setCurrentStorePrice(double currentStorePrice) {
        this.currentStorePrice = currentStorePrice;
    }

    public double getCurrentNationalPrice() {
        return currentNationalPrice;
    }

    public void setCurrentNationalPrice(double currentNationalPrice) {
        this.currentNationalPrice = currentNationalPrice;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getPriceTypeFlag() {
        return priceTypeFlag;
    }

    public void setPriceTypeFlag(String priceTypeFlag) {
        this.priceTypeFlag = priceTypeFlag;
    }
}
