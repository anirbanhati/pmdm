package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.Setter;

@XmlRootElement(name = "Product")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class ProductInfo {

    @XmlElement(name = "ean")
    private String ean;

    @XmlElement(name = "articleNumber")
    private String articleNumber;

    @XmlElement(name = "salesOrg")
    private String salesOrg;

    @XmlElement(name = "category")
    private String category;

    @XmlElement(name = "subCategory")
    private String subCategory;

    @XmlElement(name = "uom")
    private String uom;

    @XmlElement(name = "conversion")
    private String conversion;

    @XmlElement(name = "type")
    private String productType;

    @XmlElement(name = "description")
    private String description;

    @XmlElement(name = "brickName")
    private String brickName;

    @XmlElement(name = "brickCode")
    private String brickCode;

    @XmlElement(name = "packaging1")
    private String packaging1;

    @XmlElement(name = "packaging2")
    private String packaging2;

    @XmlElement(name = "storeCode")
    private String storeCode;

    @XmlElement(name = "VATCategory")
    private String vatCategory;

    @XmlElement(name = "OORDate")
    private String oorDate;

    @XmlElement(name = "fixedPrice")
    private String fixedPrice;

    @XmlElement(name = "maxDecrease")
    private String maxDecrease;

    @XmlElement(name = "maxIncrease")
    private String maxIncrease;

    @XmlElement(name = "localPricing")
    private String localPricing;

    @XmlElement(name = "productStatus")
    private String productStatus;

}
