package com.kingfisher.compprice.config;


import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.ArrayList;
import java.util.List;

public class AADKeySet {
	@JsonAlias("keys")
	private List<JsonWebKey> keys = new ArrayList<>();

	public List<JsonWebKey> getKeys() {
		return this.keys;
	}

	public void setKeys(List<JsonWebKey> keys) {
		this.keys = keys;
	}
}
