package com.kingfisher.compprice.schedule;

import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import com.kingfisher.compprice.util.constants.Constants;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.time.LocalDateTime;

@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
@Setter
public class PriceOutboundScheduler {

    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketNamePriceFeed;

    private final S3OutboundLoadService feedLoadService;


    @Scheduled(cron = "${cron.outbound.priceFeed}")
    @SchedulerLock(name = "priceOutboundFeed")
    public void exportPriceOutboundFeed() throws IOException {
        log.info("Export price outbound process started :: {}", LocalDateTime.now());
        feedLoadService.uploadFile(bucketNamePriceFeed, Constants.PRICE_OUTBOUND_TYPE);
    }

}