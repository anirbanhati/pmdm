package com.kingfisher.compprice.enums;

public enum RoundingType {
    UV,
    UL
}
