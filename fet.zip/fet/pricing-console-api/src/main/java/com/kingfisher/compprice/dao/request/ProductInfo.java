package com.kingfisher.compprice.dao.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ProductInfo {

    private String ean;
    private double collectedPrice;
    private String collectedEan;
    private String collectedDescription;
    @JsonProperty("code")
    private String collectedArticleCode;
    @JsonProperty("pkg")
    private String collectedPackage;
    @JsonProperty("pkgUnit")
    private String collectedPackageUnit;
    @JsonProperty("pkgValue")
    private String collectedPackageValue;
    private boolean hasPromo;
    private boolean linkedArticle;
    private String notes;
    private String promoInfo;

}