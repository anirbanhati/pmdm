package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.response.search.Recommandation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProvisionDetails implements Serializable {
    private static final long serialVersionUID = 5627379199577823355L;

    private int cStockQty;
    private Double provRate;
    private Recommandation recommandation;

}