package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.dao.entity.StoreCollection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Repository
public interface StoreCollectionRepository extends JpaRepository<StoreCollection, Long> {

    List<StoreCollection> findByStatusAndAssignToIgnoreCaseOrderByCreationTimeDesc(final CollectionStatus status, final String assignTo);

    Set<StoreCollection> findByIdIn(final List<Long> collectionIds);

    List<StoreCollection> findByNameAndCreationTimeBetween(final String name, final LocalDateTime startTime, final LocalDateTime endTime);

    List<StoreCollection> findByNameInAndCreationTimeBetweenAndCsNameIn(final List<String> name, final LocalDateTime atStartOfDay, final LocalDateTime minusSeconds, final List<String> compStoreNameList);

    Set<StoreCollection> findByCreationTimeBefore(final LocalDateTime currentDateTime);

    List<StoreCollection> findAllByCategoryType(final String categoryType);

}