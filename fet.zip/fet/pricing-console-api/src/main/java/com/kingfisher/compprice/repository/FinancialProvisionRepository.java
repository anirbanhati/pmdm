package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Provisions;
import com.kingfisher.compprice.dao.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FinancialProvisionRepository extends JpaRepository<Provisions, Long> {

	Optional<Provisions> findTopByOrderByLastUpdatedDesc();

    Optional<Provisions> findTopByStoreAndProductOrderByLastUpdatedDesc(final Store store, final Product product);

}