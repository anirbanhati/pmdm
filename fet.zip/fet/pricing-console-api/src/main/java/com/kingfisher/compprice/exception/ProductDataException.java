package com.kingfisher.compprice.exception;

public class ProductDataException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -4679858685404066537L;
    private final String errorCode;

    public ProductDataException(final String errorMessage, final String errorCode) {
        super(errorMessage);
        this.errorCode = errorCode;

    }

    public String getErrorCode() {
        return this.errorCode;
    }

}
