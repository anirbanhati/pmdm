package com.kingfisher.compprice.dao.search;

import org.springframework.data.domain.Sort;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductSearchPaging {

	private int pageNum = 1;
	private int pageSize = 20;
	private Sort.Direction sortDirection = Sort.Direction.ASC;
	private String sortName = "category";

}