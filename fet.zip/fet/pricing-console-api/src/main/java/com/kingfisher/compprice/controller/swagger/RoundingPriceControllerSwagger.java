package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.response.RoundingConfigSpreadsheetData;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Tag(name = TAG_ROUNDING_CONFIG)
public interface RoundingPriceControllerSwagger {

	@Operation(description = "Upload Rounding Config as Excel Spreadsheet(.xlsx)")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
	SingleDataResponse<RoundingConfigSpreadsheetData> uploadConfiguration(
			@Parameter(name = REQUEST_PARAM_FILE, required = true, example = "FET ROUNDING.xlsx") @RequestParam MultipartFile file)
			throws IOException;

}