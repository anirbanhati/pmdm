package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.kingfisher.compprice.controller.swagger.FeatureToggleControllerSwagger;
import com.kingfisher.compprice.dao.OpCoFeatures;
import com.kingfisher.compprice.dao.entity.FeatureEntity;
import com.kingfisher.compprice.dao.request.FeatureToggleRequest;
import com.kingfisher.compprice.service.FeatureToggleService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(FEATURES_URL)
public class FeatureToggleController implements FeatureToggleControllerSwagger {

    private final FeatureToggleService featureToggleService;

    Gson gson = new Gson();

    /**
     * Create Feature with Name & Description
     * Returns all features with id, Name and Description
     *
     * @param features needs to create
     * @return a created feature permissions
     */
    @PostMapping(path = CREATE_FEATURE)
    public MultiDataResponse<FeatureEntity> createFeature(@RequestBody List<FeatureEntity> features) {
        log.info("FeatureToggle: createFeature --> {}", gson.toJson(features));
        return JsonApiResponse.multiDataResponse(featureToggleService.createFeature(features));
    }

    /**
     * Updates Feature with Name & Description
     * Return all features with id, Name and Description
     *
     * @param request feature toggle request
     * @return list of all the toggles
     */
    @PostMapping(UPDATE_FEATURE)
    public MultiDataResponse<FeatureEntity> updateFeature(@PathVariable String featureId, @RequestBody FeatureToggleRequest request) {
        log.info("FeatureToggle: updateFeature --> {}, {}", featureId, gson.toJson(request));
        return JsonApiResponse.multiDataResponse(featureToggleService.updateFeature(featureId, request));
    }

    /**
     * Get All Features
     *
     * @return list of feature permissions
     */
    @GetMapping(path = ALL)
    public MultiDataResponse<FeatureEntity> getAllFeatures() {
        log.info("FeatureToggle: getAllFeatures");
        return JsonApiResponse.multiDataResponse(featureToggleService.getAllFeatures());
    }

    /**
     * Manage Feature with Tenant
     * Returns all features present for that Tenant
     *
     * @param feature the tenant and set of feature permissions
     * @return the tenant and set of feature toggle details
     */
    @PostMapping
    public ResponseEntity<OpCoFeatures> manageFeatureForOpCo(@RequestBody OpCoFeatures feature) {
        log.info("FeatureToggle: manageFeatureForOpCo --> {}", feature);
        return new ResponseEntity<>(featureToggleService.manageFeatureForOpCo(feature), HttpStatus.OK);
    }

    /**
     * Get Feature Toggle Status with Name & Tenant
     *
     * @param tenant      of user
     * @param featureName feature permission name
     * @return the tenant and set of feature toggle details
     */
    @GetMapping(path = COMP_FEATURE_BY_NAME)
    public ResponseEntity<OpCoFeatures> getFeatureDetailsByName(@PathVariable String tenant, @PathVariable String featureName) {
        log.info("FeatureToggle: getFeatureDetailsByName --> {}, {}", tenant, featureName);
        return new ResponseEntity<>(featureToggleService.getFeatureDetailsByNameAndTenant(featureName, tenant), HttpStatus.OK);
    }

    /**
     * Get All Features for Tenant
     *
     * @param tenant of user
     * @return the tenant and set of feature toggle details
     */
    @GetMapping(path = COMP_ALL_FEATURES_BY_TENANT)
    public ResponseEntity<OpCoFeatures> getAllFeaturesByTenant(@PathVariable String tenant) {
        log.info("FeatureToggle: getAllFeaturesByTenant --> {}", tenant);
        return new ResponseEntity<>(featureToggleService.getAllFeaturesByTenant(tenant), HttpStatus.OK);
    }

    /**
     * Get All Enabled Features for Tenant
     *
     * @param tenant of user
     * @return the tenant and set of feature toggle details
     */
    @GetMapping(path = COMP_ALL_ENABLED_FEATURES_BY_TENANT)
    public ResponseEntity<OpCoFeatures> getAllEnabledFeaturesByTenant(@PathVariable String tenant) {
        log.info("FeatureToggle: getAllEnabledFeaturesByTenant --> {}", tenant);
        return new ResponseEntity<>(this.featureToggleService.getAllEnabledFeaturesByTenant(tenant), HttpStatus.OK);
    }

}