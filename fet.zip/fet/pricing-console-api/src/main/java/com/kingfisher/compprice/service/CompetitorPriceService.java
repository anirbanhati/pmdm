package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.dao.request.RoundingRequest;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.RoundingResponse;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.tools.PriceValidation;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DecimalUtils;
import com.kingfisher.compprice.util.RoundOffPrice;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;

@Service
@RequiredArgsConstructor
@Slf4j
public class CompetitorPriceService {

    private final ProductTools productTools;
    private final StorePriceService storePriceService;
    private final StorePriceTools storePriceTools;
    private final StoreProductService storeProductService;
    private final ClusterPriceService clusterPriceService;
    private final PriceValidation priceValidation;
    private final ThirdPartyAPIService thirdPartyAPIService;
    private final ChangeRequestConfiguration crConfig;
    private final HelperService helperService;
    private final LogService logService;


    public RoundingResponse findRoundedPrice(final RoundingRequest request, final User user) {
        RoundingResponse response = new RoundingResponse();
        var product = productTools.findProductByEanAndUser(request.getEan(), user);
        var storePrice = storePriceTools.getActiveStorePrice(product, user.getStore());
        var nPrice = storePriceService.findActiveNationalPriceByProduct(product, user.getTenant());
        var storeProduct = storeProductService.getStoreProductByProductAndStoreFromRepo(product, user);
        var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
        var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);

        final RoundingType roundingTypeFromConfig = helperService.fetchRoundingType(product, new CategoryRoundingResponse());
        response.setEan(request.getEan());
        double finalPrice = PriceTools.applyRounding(roundingTypeFromConfig, RoundingType.valueOf(request.getRType()),
                request.getPrice(), user.getTenant(), !ProductType.OutOfRange.name().equalsIgnoreCase(request.getPrdType()));

        if (RoundingType.UV.toString().equals(request.getRType())) {
            response.setPriceUM(finalPrice / product.getConversion());
            response.setPriceSU(finalPrice);
        } else {
            if (TENANT_BDFR.equalsIgnoreCase(user.getTenant()) && !ProductType.OutOfRange.name().equalsIgnoreCase(request.getPrdType())) {
                response.setPriceSU(Double.parseDouble(DecimalUtils.roundOf(RoundOffPrice.roundOffPrice(finalPrice * product.getConversion(), true), ROUND_OF_2)));
            } else {
                response.setPriceSU(finalPrice * product.getConversion());
            }
            response.setPriceUM(finalPrice);
        }
        final double costPrice = Double.parseDouble(thirdPartyAPIService.getCostPriceDetails(List.of(product), user, true).getOrDefault(product.getEan(), MAP_0));
        priceValidation.isValidPrice(product, storeProduct, stdPrice, costPrice, user, response.getPriceSU());
        return response;
    }

    public double getStdPriceBasedOnRounding(final StorePrice storePrice, final Double nPrice, final Product product,
                                             final CategoryRoundingResponse cRounding, final String tenant, final Double clusterPrice) {
        StopWatch stopWatch = logService.logStopWatchStart("getStdPriceBasedOnRounding");
        Double stdPrice;
        Double newNPrice;
        if (TENANT_BDFR.equals(tenant)) {
            if (RoundingType.UL.toString().equals(cRounding.getRType().toString())) {
                newNPrice = nPrice/product.getConversion();
            } else {
                newNPrice = nPrice;
            }
            stdPrice = Optional.ofNullable(clusterPrice).orElse(newNPrice);
        }
        else {
            double storeRefPrice = null != storePrice ? storePrice.getRefPrice() : 0.0;
            stdPrice = Optional.ofNullable(clusterPrice).orElse(storeRefPrice);
        }
        logService.logStopWatchStop(stopWatch);
        return stdPrice;
    }

    public List<String> getScNamesBySector(final CompItemInfo compItemInfo, final User user) {
        List<String> scNames;
        final String scName = compItemInfo.getName();
        if (crConfig.isSplitHoSc() && StringUtils.isNotEmpty(compItemInfo.getHoClName())) {
            final String storeCode = user.getStore().getStoreCode();
            scNames = Arrays.asList(scName + UNDER_SCORE + storeCode + "_Aménagement",
                    scName + UNDER_SCORE + storeCode + "_Construction",
                    scName + UNDER_SCORE + storeCode + "_Technique");
        } else {
            scNames = List.of(compItemInfo.getName());
        }
        return scNames;
    }

}