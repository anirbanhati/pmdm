package com.kingfisher.compprice.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "change-request")
@Getter
@Setter
public class ChangeRequestConfiguration {

	private boolean stopPrice;
	private boolean prdStatus;
	private boolean splitHoSc;
	private boolean importCsv;
	private boolean massUpload;
	private boolean errorMsg;
	private boolean stopPriceCpt;
	private boolean excludePl;
	private boolean stopPriceEmergency;

}