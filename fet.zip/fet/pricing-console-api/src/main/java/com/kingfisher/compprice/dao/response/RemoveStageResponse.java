package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RemoveStageResponse implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = 1000399145475837403L;

    private long stageCount;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}