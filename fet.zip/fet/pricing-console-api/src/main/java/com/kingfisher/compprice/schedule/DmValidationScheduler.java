package com.kingfisher.compprice.schedule;

import com.kingfisher.compprice.service.PriceUpdateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
@ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
public class DmValidationScheduler {

    private final PriceUpdateService priceUpdateService;

    @Scheduled(cron = "${cron.dmValidation.rejectExpired}")
    @SchedulerLock(name = "rejectExpired")
    public void rejectExpired() {
        priceUpdateService.rejectExpiredItems();
    }

}