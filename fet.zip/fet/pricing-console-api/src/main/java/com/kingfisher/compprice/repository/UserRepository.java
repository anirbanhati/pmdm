package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.enums.Role;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.USER_CACHE;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    List<User> findAllByOrderByUserIdAsc();

    List<User> findByStoreOrderByUserIdAsc(final Store store);

    @Cacheable(value = USER_CACHE, key = "#userId")
    Optional<User> findTopByUserIdIgnoreCaseOrderByIdDesc(final String userId);

    Optional<User> findByUserIdAndTenant(final String userId, final String tenant);

    List<User> findByWorkerStatusCodeAndLastUpdateTimeBefore(final String statusCode, final LocalDateTime date);

    List<User> findAllByRoleOrderByIdAsc(final Role role);

}