package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.PriceUpdate;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface PriceUpdateRepository extends CrudRepository<PriceUpdate, Long> {

    PriceUpdate findByProductAndStore(final Product product, final Store store);

    Optional<PriceUpdate> findByProductAndStoreAndPrdType(final Product product, final Store store, final ProductType prdType);

    PriceUpdate findTopByProductAndStoreOrderByModTimeDesc(final Product product, final Store store);

    Set<PriceUpdate> findByTenantAndPriceGreaterThanOrderByProduct_ProductCodeAsc(final String tenant, final double price);

    Set<PriceUpdate> findByTenantAndStoreAndPriceGreaterThanOrderByProduct_ProductCodeAsc(final String tenant, final Store store, final double price);

    List<PriceUpdate> findByTenantAndRefAndPriceGreaterThan(final String tenant, final String ref, final double price);

    List<PriceUpdate> findByStatusAndPriceGreaterThan(final String status, final double price);

    List<PriceUpdate> findByPriceOrStatusOrExtractedDateBefore(final double price, final String status, final LocalDateTime extractedDate);

    Set<PriceUpdate> findByTenantAndStoreAndStatusIn(final String tenant, final Store store, final List<String> status);

    List<PriceUpdate> findByProductInAndStore(final List<Product> products, final Store store);

    Set<PriceUpdate> findByIdIn(final List<Long> id);

    List<PriceUpdate> findByStatus(final String Status);

}