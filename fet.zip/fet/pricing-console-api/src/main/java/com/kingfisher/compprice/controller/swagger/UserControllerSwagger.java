package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.entity.FeaturesPermissions;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.entity.UserCode;
import com.kingfisher.compprice.dao.request.*;
import com.kingfisher.compprice.dao.response.Roles;
import com.kingfisher.compprice.dao.response.UserWithPermissionsResponse;
import com.kingfisher.compprice.dao.response.user.UserRoleResponse;
import com.kingfisher.compprice.dto.Workers;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


import java.io.IOException;
import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.REQUEST_PARAM_FILE;
import static com.kingfisher.compprice.util.constants.Constants.STORE_CODE;

@Tag(name = Constants.TAG_USER)
public interface UserControllerSwagger {

    @Operation(description = "Delete User", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<User> deleteUserDetails(
            @Parameter(name = Constants.USER_ID, required = true) @NonNull @PathVariable String userId);

    @Operation(description = "Get All User details", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    MultiDataResponse<User> getAllUser();

    @Operation(description = "Get User roles", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<Roles> getUserRoles();

    @Operation(description = "Get User By User Id")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<User> getUserDetailsByUserId(
            @Parameter(name = Constants.USER_ID, required = true) @NonNull @PathVariable String userId);

    @Operation(description = "Find user by store responseCode", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    MultiDataResponse<User> getUsersByStoreCode(
            @Parameter(name = Constants.STORE_CODE, required = true) @NonNull @RequestParam(STORE_CODE)
            final String storeCode);

    @Operation(description = "Create New User", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
    JsonApiResponse saveUserDetails(@Valid @RequestBody UserRequest userRequest);

    @Operation(description = "Update User by user Id", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<User> updateUserByUserId(
            @Parameter(name = Constants.USER_ID, required = true) @NonNull @PathVariable String userId,
            @RequestBody final UserRequest userRequest);

    @Operation(description = "Create Features Permissions", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    List<FeaturesPermissions> postFeaturePermission(
            @RequestBody final List<PermissionRequest> requests);

    @Operation(description = "Tag Permissions with User WorkGroupCode", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    List<UserCode> createAndMapFeaturesPermissions(
            @RequestBody final List<UserCodeRequest> requests);

    @Operation(description = "Update Permission List for a WorkGroupCode", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    String updatePermissionsOfWorkgroupCode(
            @Parameter(name = "workGroupCode", required = true) @NonNull @PathVariable long workGroupCode,
            @RequestBody final UserCodeUpdateRequest updateReq);

    @Operation(description = "Update Permission List for a WorkGroupCode", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<UserWithPermissionsResponse> getUserWithPermissions(
            @Parameter(name = "userId", required = true) @NonNull @PathVariable String userId);

    @Operation(description = "Get User By Role", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    MultiDataResponse<UserRoleResponse> getUserByRole(@RequestParam(value = "role") String role);

    @Operation(description = "Delete Permissions For Users", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    String deleteAllFeaturesPermissions();

    @Operation(description = "Get User Assigned To  Store", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    MultiDataResponse<User> getAssignToUsersByStoreCode(@RequestParam(STORE_CODE) String storeCode);

    @Operation(description = "Import Users", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    ResponseEntity<String> importUsersList(@RequestParam(REQUEST_PARAM_FILE) MultipartFile file) throws IOException;

    @Operation(description = "Upload User XML", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_XML_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> uploadUsersXml(@RequestBody Workers workers);

}