package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Roles implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = 6645601562946181153L;

    private List<String> listOfRole;

    @Override
    public String getJsonApiDataId() {
        return "roles";
    }

    @Override
    public String getJsonApiDataType() {
        return "Roles";
    }

}