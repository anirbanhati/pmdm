package com.kingfisher.compprice.dao;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.descriptor.jdbc.EnumJdbcType;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class PostgreSQLEnumType extends EnumJdbcType {
    private static final long serialVersionUID = -5629703297205937546L;


    public void nullSafeSet(final PreparedStatement st, final Object value, final int index,
                            final SharedSessionContractImplementor session)
            throws HibernateException, SQLException {

        st.setObject(index, value != null ? ((Enum<?>) value).name() : null, Types.OTHER);
    }

}