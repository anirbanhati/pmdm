package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "prices")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClusterPrices {

    @XmlElement(name = "clusterPrice")
    private double clusterPrice;
    @XmlElement(name = "ean")
    private String ean;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "uom")
    private String uom;
    @XmlElement(name = "startDate")
    private String startDate;
    @XmlElement(name = "endDate")
    private String endDate;

    public double getClusterPrice() {
        return clusterPrice;
    }

    public void setClusterPrice(double clusterPrice) {
        this.clusterPrice = clusterPrice;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }


}
