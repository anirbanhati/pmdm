package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "user_code")
@Getter
@Setter
public class UserCode implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5147327675477891663L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_code_id", unique = true, nullable = false)
	private long id;

	@Column(name = "workgroup_code")
	private Long workGroupCode;

	@Column(name="workgroup_description")
	private String workGroupDesc;

	@Column(name="sales_org")
	private String salesOrg;

	@JsonIgnore
	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "ftr_perm_user_code_map", joinColumns = {
			@JoinColumn(name = "user_code_id") }, inverseJoinColumns = {
					@JoinColumn(name = "features_permissions_id") })
	private Set<FeaturesPermissions> featurePermissions = new HashSet<>();


	@JsonIgnore
	@OneToMany(mappedBy = "userCode", cascade = CascadeType.ALL)
	private final Set<User> user = new HashSet<>();

}