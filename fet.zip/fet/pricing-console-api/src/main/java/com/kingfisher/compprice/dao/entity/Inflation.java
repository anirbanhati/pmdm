package com.kingfisher.compprice.dao.entity;


import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "inflation_data")
public class Inflation  implements Serializable {
    private static final long serialVersionUID = 7040746289973021735L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @Column(name = "article_code")
    private String articleNumber;

    @Column(name = "store_acquisition_cost")
    private Double storeAcquisitionCost;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "currency")
    private String currency;

    @Column(name = "last_updated_date")
    private LocalDateTime lastUpdatedDate;

}
