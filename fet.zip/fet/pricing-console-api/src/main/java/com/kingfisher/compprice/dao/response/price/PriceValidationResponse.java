package com.kingfisher.compprice.dao.response.price;

import java.util.List;

import com.kingfisher.compprice.dao.response.search.PendingPriceProductItem;
import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceValidationResponse implements Resource{

	private List<PendingPriceProductItem> product;
	private int totalRecord;

	/**
	 *
	 */
	private static final long serialVersionUID = 1323148995213485649L;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}
