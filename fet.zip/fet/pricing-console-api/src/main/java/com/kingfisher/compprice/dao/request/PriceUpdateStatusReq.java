package com.kingfisher.compprice.dao.request;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PriceUpdateStatusReq {

	private List<Long> id;
	private String status;

}