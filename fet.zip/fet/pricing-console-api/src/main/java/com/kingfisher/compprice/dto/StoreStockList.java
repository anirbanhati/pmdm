package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "StoreStockList")
@XmlAccessorType(XmlAccessType.FIELD)
public class StoreStockList {

    @XmlElement(name = "Stock")
    private List<Stock> stocks;

    public List<Stock> getStock() {
        return stocks;
    }

    public void setStock(List<Stock> stocks) {
        this.stocks = stocks;
    }
}
