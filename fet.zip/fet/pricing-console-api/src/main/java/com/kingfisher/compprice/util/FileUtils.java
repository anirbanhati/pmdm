package com.kingfisher.compprice.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@Slf4j
@UtilityClass
public class FileUtils {

    public static String readFile(final String path) {
        final File file;
        try {
            file = ResourceUtils.getFile("classpath:" + path);
            return new String(Files.readAllBytes(file.toPath()));
        } catch (final IOException e) {
            log.error("Error while parsing file {}", path, e);
        }
        return null;
    }

}