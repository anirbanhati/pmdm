package com.kingfisher.compprice.dao.response;

import com.kingfisher.compprice.dao.response.search.ProductItem;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class SearchItem implements Serializable {

	private static final long serialVersionUID = -7678647767264396085L;

	private ProductItem product;

}