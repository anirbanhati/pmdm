package com.kingfisher.compprice.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import static com.kingfisher.compprice.util.constants.Constants.TENANT_BDFR;

@Component
public class BaseValidationFactory implements ValidationFactory {

	@Override
	public StagePriceValidatorRule validation(final String type) {
		return StringUtils.equalsIgnoreCase(TENANT_BDFR, type)
				? new StagePriceValidationBrico() : new StagePriceValidation();
	}

	@Override
	public ProductTypeValidationRule typeValidation(final String type) {
		return StringUtils.equalsIgnoreCase(TENANT_BDFR, type)
				? new ProductTypeValidationBrico() : new ProductTypeValidation();
	}

}