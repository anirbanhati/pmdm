package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreCollectionSearchResponse implements Resource{

	private static final long serialVersionUID = -1605721759676948477L;
	private List<StoreCollectionDetails> search;
	private long total;

	@Override
	public String getJsonApiDataId() {
		return "cSearch";
	}

	@Override
	public String getJsonApiDataType() {
		return "response";
	}

}
