package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ProductChainings")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductChainings {

    @XmlElement(name = "ProductChaining")
    private List<ProductChaining> productChainingList;

    public List<ProductChaining> getProductChainingList() {
        return productChainingList;
    }

    public void setProductChainingList(List<ProductChaining> productChainingList) {
        this.productChainingList = productChainingList;
    }


}
