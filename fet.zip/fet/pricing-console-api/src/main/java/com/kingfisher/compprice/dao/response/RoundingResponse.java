package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoundingResponse implements Resource {
    private static final long serialVersionUID = 4712138202658819390L;

    private String ean;
    private double priceUM;
    private double priceSU;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}