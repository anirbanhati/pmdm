package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StoreCompetitorStoreMap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface StoreCompetitorStoreRepository extends JpaRepository<StoreCompetitorStoreMap, Long> {

    Optional<StoreCompetitorStoreMap> findByStore_StoreCodeAndCompetitorStore_LongName(String storeCode, String longName);

    Set<StoreCompetitorStoreMap> findByStoreAndActiveFlag(Store store, String activeFlag);

    Optional<StoreCompetitorStoreMap> findByStoreAndCompetitorStore(final Store store, final CompetitorStore competitorStore);

    Set<StoreCompetitorStoreMap> findByCompetitorStore(final CompetitorStore competitorStore);

}