package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.RollingDays;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RollingDaysRepository extends JpaRepository<RollingDays, Long> {

    Optional<RollingDays> findTopByOrderByLastUpdatedDesc();

    List<RollingDays> findAllByOrderByLastUpdatedDesc();

}