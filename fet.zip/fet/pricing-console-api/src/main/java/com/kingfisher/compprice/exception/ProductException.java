package com.kingfisher.compprice.exception;

public class ProductException extends ApplicationException {

	/**
	 *
	 */
	private static final long serialVersionUID = 894265700616888340L;

	public ProductException(final String applicationErrorCode, final String httpStatusCode, final String detail,
			final String id, final String pointer, final String parameter, final String title) {
		super(applicationErrorCode, httpStatusCode, detail, id, pointer, parameter, title);
	}
}
