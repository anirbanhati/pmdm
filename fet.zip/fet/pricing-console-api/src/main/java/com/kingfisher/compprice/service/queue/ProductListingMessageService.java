package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.ProductListing;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dto.ProductListingInfo;
import com.kingfisher.compprice.dto.ProductListings;
import com.kingfisher.compprice.repository.ProductListingRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.PRODUCT_MESSAGE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductListingMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final ProductListingRepository listingRepository;
    private final MessageServicesHelper servicesHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return PRODUCT_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(final String message, final MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Listing Feed :: {}", message);
        }
        final String methodName = "processMessage()";
        try {
            log.info("Start processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
            LocalDateTime time1 = LocalDateTime.now();
            doProcessMessage(message);
            LocalDateTime time2 = LocalDateTime.now();
            log.info("Time taken {}", Duration.between(time1, time2).toSeconds());
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
        } catch (final JAXBException ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }

    }

    private void doProcessMessage(final String messageMetadata)
            throws JAXBException {
        final ProductListings productFeed = getListingFeed(messageMetadata);
        final Map<String, String> invalidStoreCodes = new HashMap<>();
        Optional.ofNullable(productFeed).ifPresent(pf -> pf.getProductListings().forEach(productListingInfo ->
                saveListingFeedToRepository(productListingInfo, invalidStoreCodes)));
        log.info("Invalid Store Codes : {}", invalidStoreCodes);
    }

    private ProductListings getListingFeed(final String message) throws JAXBException {
        ProductListings listingFeed = null;
        final String methodName = "getListingFeed()";
        log.info("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            final StringReader sr = new StringReader(message);
            final JAXBContext jaxbContext = JAXBContext.newInstance(ProductListings.class);
            final Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            listingFeed = (ProductListings) unmarshaller.unmarshal(sr);
        }
        log.info("Exiting :: {} :: {}", this.getClass().getSimpleName(), methodName);
        return listingFeed;
    }

    @Transactional
    public void saveListingFeedToRepository(final ProductListingInfo listing, final Map<String, String> invalidStores) {
        final String methodName = "saveListingFeedToRepository";

        log.info("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        Store storeData = servicesHelper.findStoreByStoreCode(listing.getStoreCode());
        if (servicesHelper.isSalesOrgValid(listing.getSalesOrg()) && StringUtils.isNotEmpty(listing.getStoreCode())
                && null != storeData) {
            addDetailsForNewListing(listing, storeData);
        } else {
            invalidStores.put(listing.getStoreCode(), "Invalid Store in Listing feed ");
            log.info("Invalid stores in Listing Feed :: ean {} , salesOrg {} , Invalid stores {} ", listing.getEan(),
                    listing.getSalesOrg(), listing.getStoreCode());
        }
        log.info("Exiting :: {} :: {}", this.getClass().getSimpleName(), methodName);
    }

    private void addDetailsForNewListing(final ProductListingInfo listingInfo, final Store store) {
        ProductListing listing = new ProductListing();
        populateListingDetails(listingInfo, listing, store);
        listingRepository.save(listing);
    }

    private void populateListingDetails(ProductListingInfo listingInfo, final ProductListing listing, final Store store) {
        listing.setEan(String.valueOf(listingInfo.getEan()));
        listing.setProductCode(String.valueOf(listingInfo.getArticleNumber()));
        listing.setStore(store);
        listing.setStartDate(servicesHelper.getLocalDateTime(listingInfo.getStartDate()));
        listing.setEndDate(servicesHelper.getLocalDateTime(listingInfo.getEndDate()));
        listing.setLastUpdated(LocalDateTime.now());
    }

}