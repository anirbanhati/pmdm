package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.configuration.FunctionalityConfiguration;
import com.kingfisher.compprice.dao.ProductProvision;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Provisions;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.response.ProductResultResponse;
import com.kingfisher.compprice.dao.response.ProductSearchResponse;
import com.kingfisher.compprice.dao.response.SearchPagination;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.dao.search.SearchProduct;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.service.ProductResponseBuilder;
import com.kingfisher.compprice.service.ProductTools;
import com.kingfisher.compprice.service.UserService;
import com.kingfisher.compprice.tools.PerformanceExecution;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Repository
@RequiredArgsConstructor
@Slf4j
public class ProductSearchRepository {

	@PersistenceContext
	private EntityManager entityManager;
	private final UserService userService;
	private final ProductResponseBuilder productResponseBuilder;
	private final FunctionalityConfiguration funConfig;
	private final ProductTools productTools;


	@Transactional
	public SearchProduct getWarListProducts(final ProductSearchPaging page, final ProductSearchCriteria criteria,
											final User user) {
		final List<Product> products;
		boolean isHeadOfficeUser = userService.isHeadOfficeUser(user.getUserId());
		StringBuilder type = productTools.getTypesAsString(criteria.getTypes(), criteria.getPrdType());
		String codes = String.join(HYPHEN_SEPARATOR, criteria.getCodes());

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<Product> criteriaQuery = criteriaBuilder.createQuery(Product.class);
		final Root<Product> prodRoot = criteriaQuery.from(Product.class);
		criteriaQuery.where(productTools.filterRecordsForStoreUsers(criteria, prodRoot, criteriaBuilder, user));
		criteriaQuery.orderBy(criteriaBuilder.asc(prodRoot.get(PRODUCT_CATEGORY)),
				criteriaBuilder.asc(prodRoot.get(PRODUCT_SUB_CATEGORY)),
				criteriaBuilder.asc(prodRoot.get(PRODUCT_BRICK_NAME)),
				criteriaBuilder.asc(prodRoot.get(DESCRIPTION)));
		criteriaQuery.distinct(true);
		final TypedQuery<Product> typedQuery = entityManager.createQuery(criteriaQuery);

		final long count = isHeadOfficeUser ? productTools.getCountOfWarRecordsHo(criteria, entityManager, criteriaBuilder, user, type.toString(), codes) :
				productTools.getCountOfWarRecordsStore(criteria, entityManager, criteriaBuilder, user, type.toString(), codes);

		if (funConfig.isNewListPagination()) {
			productTools.setPageSizeAndNumCpt(page, count);
			int pSize = page.getPageSize();
			int pNum = page.getPageNum();
			typedQuery.setFirstResult((pNum - 1) * pSize);
			typedQuery.setMaxResults(pSize);
		}
		int pSize = page.getPageSize();
		int pNum = page.getPageNum();

		products =	isHeadOfficeUser ? productTools.getCptProductsHo(typedQuery, criteria, user, type.toString(), codes) :
				productTools.getCptProductsStore(typedQuery, criteria, user, type.toString(), codes);

		final List<ProductResultResponse> pResponse = products.stream().map(result -> {
			final ProductResultResponse res = new ProductResultResponse();
			res.setBrickCode(result.getBrickCode());
			res.setCategory(result.getCategory());
			res.setDescription(result.getDescription());
			res.setBrickName(result.getBrickName());
			res.setEan(result.getEan());
			res.setProductCode(result.getProductCode());
			res.setSubCategory(result.getSubCategory());
			res.setPrdType(ProductType.PVMax.toString());
			return res;
		}).toList();
		SearchProduct searchResponse = new SearchProduct();
		searchResponse.setProducts(pResponse);
		searchResponse.setTotal(count);
		if (funConfig.isNewListPagination()) {
			searchResponse.setPagination(preparePageableResponse(pResponse.size(), this.getPageable(page, pSize, pNum), count, pSize));
		}
		return searchResponse;
	}

	private SearchPagination preparePageableResponse(final long noOfElements, final Pageable pageable,
													 final long totalCount, final int pSize) {
		final SearchPagination sPagination = new SearchPagination();
		sPagination.setPageNumber(pageable.getPageNumber() + 1);
		sPagination.setPageSize(pageable.getPageSize());
		sPagination.setTotalElements(totalCount);
		sPagination.setNumberOfElements(noOfElements);
		int total = ((int) totalCount + pSize - 1) / pSize;
		sPagination.setTotalPages(0 == total ? 1 : total);
		return sPagination;
	}

	/**
	 * This method is used to fetch the product based on product types(WarList, InRange: PVMax, PVLocal) with different
	 * filter options
	 */
	@Transactional
	public ProductSearchResponse getProductsByTypes(final ProductSearchPaging page, final ProductSearchCriteria criteria,
													final User user) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		final StringBuilder type = productTools.getTypesAsString(criteria.getTypes(), criteria.getPrdType());
		final String codes = String.join(HYPHEN_SEPARATOR, criteria.getCodes());

		final TypedQuery<Product> typedQuery = buildProductQuery(criteria, user, criteriaBuilder);
		final long count = productTools.getCountOfRecordsStore(criteria, entityManager, criteriaBuilder, user, type.toString(), codes);
		int pSize = page.getPageSize();
		int pNum = page.getPageNum();
		if (page.getPageNum() < 1 || pSize < 1) {
			pSize = (count < 1) ? 1 : (int) count;
			pNum = 1;
		}
		typedQuery.setFirstResult((pNum - 1) * pSize);
		typedQuery.setMaxResults(pSize);

		final List<Product> products = productTools.getProductsStore(typedQuery, criteria, user, type.toString(), codes);

		ProductSearchResponse response = productResponseBuilder.prepareSearchResponse(products, criteria.getPrdType(), user, true, true);
		response.setPagination(preparePageableResponse(products.size(), this.getPageable(page, pSize, pNum), count, pSize));
		return response;
	}

	@PerformanceExecution
	public TypedQuery<Product> buildProductQuery(final ProductSearchCriteria criteria, final User user, CriteriaBuilder criteriaBuilder) {
		final CriteriaQuery<Product> criteriaQuery = criteriaBuilder.createQuery(Product.class);
		final Root<Product> prodRoot = criteriaQuery.from(Product.class);
		final Join<Object, Object> storeProduct = prodRoot.join(STORE_PRODUCT, JoinType.INNER);
		final Join<Object, Object> store = storeProduct.join(STORE, JoinType.INNER);
		final Join<Object, Object> storePrice = store.join(STORE_PRICE, JoinType.INNER);
		return entityManager.createQuery(criteriaQuery
				.where(productTools.filterRecord(criteria, prodRoot, storeProduct, store, storePrice, criteriaBuilder, user))
				.orderBy(criteriaBuilder.asc(prodRoot.get(PRODUCT_CATEGORY)),
						criteriaBuilder.asc(prodRoot.get(PRODUCT_SUB_CATEGORY)),
						criteriaBuilder.asc(prodRoot.get(PRODUCT_BRICK_NAME)),
						criteriaBuilder.asc(prodRoot.get(DESCRIPTION)))
				.distinct(true));
	}

	/**
	 * This method is used to fetch the product based on product type(SlowMoving, OutOfRange) with different
	 * filter options
	 */
	public ProductSearchResponse getProductsByPrdType(final ProductSearchPaging page, final ProductSearchCriteria criteria,
													  final User user) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		final StringBuilder type = productTools.getTypesAsString(criteria.getTypes(), criteria.getPrdType());
		final String codes = String.join(HYPHEN_SEPARATOR, criteria.getCodes());

		final TypedQuery<ProductProvision> typedQuery = buildProductProvisionQuery(criteria, user,criteriaBuilder);
		final long count = productTools.getCountOfRecordsStore(criteria, entityManager, criteriaBuilder, user, type.toString(), codes);

		productTools.setPageSizeAndNumCpt(page, count);
		int pSize = page.getPageSize();
		int pNum = page.getPageNum();
		typedQuery.setFirstResult((pNum - 1) * pSize);
		typedQuery.setMaxResults(pSize);

		final List<ProductProvision> productsWithProv = productTools.getProductProvisionListStore(typedQuery, criteria, user, type.toString(), codes);
		final List<Product> products = productsWithProv.stream().map(ProductProvision::getProduct).toList();

		ProductSearchResponse response = productResponseBuilder.prepareSearchResponse(products, criteria.getPrdType(), user, true, true);
		response.setPagination(preparePageableResponse(products.size(), this.getPageable(page, pSize, pNum), count, pSize));
		return response;
	}

	@PerformanceExecution
	public TypedQuery<ProductProvision> buildProductProvisionQuery(final ProductSearchCriteria criteria, final User user, CriteriaBuilder criteriaBuilder) {
		final CriteriaQuery<ProductProvision> criteriaQuery = criteriaBuilder.createQuery(ProductProvision.class);
		final Root<Product> productRoot = criteriaQuery.from(Product.class);

		final Join<Object, Object> storeProduct = productRoot.join(STORE_PRODUCT, JoinType.INNER);
		final Join<Object, Object> store = storeProduct.join(STORE, JoinType.INNER);
		final Join<Object, Object> storePrice = store.join(STORE_PRICE, JoinType.INNER);
		final Join<Product, Provisions> prdProvision = productRoot.join(PROVISIONS, JoinType.LEFT);
		final Predicate provStore = criteriaBuilder.equal(storeProduct.get(STORE), prdProvision.get(STORE));
		prdProvision.on(provStore);

		criteriaQuery.multiselect(productRoot, productRoot.get(PRODUCT_CATEGORY), productRoot.get(PRODUCT_SUB_CATEGORY),
				productRoot.get(PRODUCT_BRICK_NAME), productRoot.get(DESCRIPTION),
				criteriaBuilder.coalesce(prdProvision.get(PROV_STOCK), criteriaBuilder.literal(Double.MIN_VALUE)));

		return entityManager.createQuery(criteriaQuery
				.where(productTools.filterRecord(criteria, productRoot, storeProduct, store, storePrice, criteriaBuilder, user))
				.orderBy(criteriaBuilder.desc(criteriaBuilder.coalesce(prdProvision.get(PROV_STOCK), criteriaBuilder.literal(Double.MIN_VALUE))),
						criteriaBuilder.asc(productRoot.get(PRODUCT_CATEGORY)),
						criteriaBuilder.asc(productRoot.get(PRODUCT_SUB_CATEGORY)),
						criteriaBuilder.asc(productRoot.get(PRODUCT_BRICK_NAME)),
						criteriaBuilder.asc(productRoot.get(DESCRIPTION)))
				.distinct(true));
	}

	private Pageable getPageable(final ProductSearchPaging page, final int pSize, final int pageNum) {
		final Sort sort = Sort.by(page.getSortDirection(), WAR_LIST_PRODUCT_CAT_NAME, WAR_LIST_PRODUCT_SUB_CAT_NAME,
				WAR_LIST_PRODUCT_BRICK_NAME);
		return PageRequest.of(pageNum - 1, pSize, sort);
	}

}