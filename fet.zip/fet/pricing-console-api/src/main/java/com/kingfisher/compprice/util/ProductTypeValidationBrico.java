package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.enums.ProductType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProductTypeValidationBrico extends ProductTypeValidationRule {

    @Override
    public ProductType getPrdTypeFromStoreProduct(final StoreProduct storeProduct) {
        return null != storeProduct ? storeProduct.getPrdType() : ProductType.PVMax;
    }

}