package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class StageDataResponse implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = -6636760364228564698L;
    private String ean;
    private LocalDateTime sDate;
    private LocalDateTime eDate;
    private LocalDateTime lDate;
    private String priceUOM;
    private String priceSU;
    private String index;
    private String nmRate;
    private String mgDiff;
    private String miOnStock;
    private String nrv;
    private String cmRate;
    private boolean priceStop;
    private long stageCount;

    @Override
    public String getJsonApiDataId() {
        return ean;
    }

    @Override
    public String getJsonApiDataType() {
        return "Stage Price";
    }

}