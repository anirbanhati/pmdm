package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.STORE_NAME;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Getter
@Setter
@Table(name = "store")
public class Store implements Resource, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5725997533022368629L;

    @Id
    @JsonProperty("storeId")
    @Column(name = "store_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long storeId;

    @JsonProperty("storeCode")
    @Column(name = "store_code")
    private String storeCode;

    @Column(name = STORE_NAME)
    @JsonProperty("storeName")
    private String storeName;

    @Column(name = "storeBrand")
    @JsonProperty("storeBrand")
    private String storeBrand;

    @Column(name = "store_type")
    @JsonProperty("storeType")
    private String storeType;

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<PriceUpdate> pUpdate = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<StoreProduct> storeProd = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<ProductListing> productListings = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<StageProduct> stageProd = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<StorePrice> storePrice = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<CostPrice> costPrices = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private final Set<User> user = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private Set<StoreCompetitorStoreMap> storeCompetitorStoreMap = new HashSet<>();

    @JsonIgnore
    @Transient
    private List<CompetitorStore> competitors = new ArrayList<>();

    @Override
    public String getJsonApiDataId() {
        return String.valueOf(storeId);
    }

    @Override
    public String getJsonApiDataType() {
        return "store";
    }

    @PostLoad
    private void initStoreCompStoreMap() {
        Hibernate.initialize(this.storeCompetitorStoreMap);
    }

}