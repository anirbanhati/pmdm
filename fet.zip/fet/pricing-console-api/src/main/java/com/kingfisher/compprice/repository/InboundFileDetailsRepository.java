package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.InboundFileDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public interface InboundFileDetailsRepository extends JpaRepository<InboundFileDetails,Long> {

    Optional<InboundFileDetails> findByFileName(final String fileName);

}