package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dto.Prices;
import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRICE_CACHE;

@Slf4j
@RequiredArgsConstructor
@Service
public class CacheService {

    private final CacheManager cacheManager;


    public void clearCacheByName(final String cacheName) {
        Objects.requireNonNull(cacheManager.getCache(cacheName)).clear();
    }

    public void clearCacheByKeys(final String cacheName, final String key1, final String key2) {
        if (StringUtils.isNotEmpty(key2)) {
            Objects.requireNonNull(cacheManager.getCache(cacheName)).evict(List.of(key1, key2));
        } else {
            Objects.requireNonNull(cacheManager.getCache(cacheName)).evict(key1);
        }
    }

    public void clearCacheList(final List<Prices> prices, final String storeCode) {
        prices.forEach(price -> {
            Objects.requireNonNull(cacheManager.getCache(STORE_PRICE_CACHE)).evict(List.of(price.getEan(), storeCode));
            log.debug("clearCacheList- EAN: {}, Store: {}", price.getEan(), storeCode);
        });
    }

}