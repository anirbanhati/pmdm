package com.kingfisher.compprice.dao.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StoreCollectionPricesRequest {

	private String storeCode;
	private String userId;
	private List<Long> collectionIds;

}