package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceListResponse implements Resource {
	private static final long serialVersionUID = 8995344342833222478L;

	private String errorKey;
	private String successMsg;
	private List<ExcelValidation> pricelistErrors;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}