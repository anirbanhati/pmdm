package com.kingfisher.compprice.util.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CacheConstants {

    public static final String COMPETITOR_PRICE_CACHE = "minCompetitorPriceCache";
    public static final String MAP_CACHE = "mapCache";
    public static final String CLUSTER_PRICE_CACHE = "clusterPriceCache";
    public static final String CLUSTER_STORE_CACHE = "clusterStoreCache";
    public static final String COMP_PRODUCT_CACHE = "compProductCache";
    public static final String HIERARCHY_STORE_CACHE = "HierarchyStoreCache";
    public static final String GET_COUNT_OF_RECORDS_STORE_CACHE = "getCountOfRecordsStore";
    public static final String HIERARCHY_HO_CACHE = "HierarchyHoCache";
    public static final String CPT_COUNT_STORE_CACHE = "cptCountCacheStore";
    public static final String CPT_COUNT_HO_CACHE = "cptCountCacheHo";
    public static final String GET_PRODUCTS_STORE_CACHE = "getProductsStore";
    public static final String GET_PRODUCTS_HO_CACHE = "getProductsHo";
    public static final String GET_CPT_PRODUCTS_STORE_CACHE = "getCptProductsStore";
    public static final String GET_CPT_PRODUCTS_HO_CACHE = "getCptProductsHo";
    public static final String GET_PRD_PROVISION_STORE_CACHE = "getPrdProvisionStore";
    public static final String GET_PRD_PROVISION_HO_CACHE = "getPrdProvisionHo";
    public static final String ROUNDING_CACHE = "roundingCache";
    public static final String STORE_PRICE_CACHE = "storePriceCache";
    public static final String N_PRICE_CACHE = "nationalPriceCache";
    public static final String PRD_LISTING_CACHE = "prdListingCache";
    public static final String CS_STORE_CODE_CACHE = "csStoreCodeCache";
    public static final String STORE_PRODUCT_CACHE = "storeProductCache";
    public static final String STORE_PRODUCT_GET_CACHE = "storeProductObjectCache";
    public static final String CHAIN_ID_CACHE = "getChainIdCache";
    public static final String USER_CACHE = "userCache";
    public static final String STORE_CACHE = "storeCache";
    public static final String USER_PERMISSION_CACHE = "userPermissionCache";
    public static final String STOCK_PROVISIONS_CACHE = "provisionsCache";
    public static final String STORE_COLLECTION_CACHE = "storeCollectionCache";
    public static final String PRODUCT_TAX_CLASSIFICATION_CACHE = "productTaxClassificationCache";
    public static final String PRICE_HISTORY_CACHE = "priceHistoryCache";
    public static final String ROLLING_DAYS_CACHE = "rollingDaysCache";

}