package com.kingfisher.compprice.config.batch;

import com.kingfisher.compprice.dao.StoreCollectionHoSpreadsheetData;
import com.kingfisher.compprice.helper.ExcelFileHelper;
import com.kingfisher.compprice.service.CompetitorProductService;
import com.kingfisher.compprice.service.StorePriceService;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@Component
@StepScope
public class SynchronizedExcelItemWriter implements ItemWriter<StoreCollectionHoSpreadsheetData> {

    @Autowired
    private PriceTools priceTools;
    @Autowired
    private ExcelFileHelper excelFileHelper;
    @Autowired
    private StorePriceService storePriceService;
    @Autowired
    private CompetitorProductService competitorProductService;

    private final String outputFileName;
    private final SXSSFWorkbook workbook;
    private final SXSSFSheet sheet;
    private int rowNo = 4;


    public SynchronizedExcelItemWriter(@Value("#{jobParameters['outputFileName']}") String outputFileName,
                                       @Value("#{jobParameters['scName']}") String scName,
                                       @Value("#{jobParameters['scId']}") Long scId) {
        this.outputFileName = outputFileName;
        this.workbook = new SXSSFWorkbook(105);
        this.sheet = workbook.createSheet(SHEET_NAME);

        log.info(":Batch: SynchronizedExcelItemWriter Headers: fileName: {}", outputFileName);

        if (this.excelFileHelper == null) {
            this.excelFileHelper = new ExcelFileHelper();
        }

        excelFileHelper.prepareFirstTwoRows(workbook, sheet, scName, scId);
        excelFileHelper.prepareThirdRow(workbook, sheet);
        excelFileHelper.prepareFourthRow(workbook, sheet);

        excelFileHelper.setColumnWidthInSheet(sheet);
    }

    @Override
    public void write(Chunk<? extends StoreCollectionHoSpreadsheetData> items) throws Exception {
        log.debug(":Batch: SynchronizedExcelItemWriter write: size--> {}", items.size());
        final CellStyle styleForValues = excelFileHelper.createStyleForValues(workbook);
        for (StoreCollectionHoSpreadsheetData storeCollectionHoSpreadsheetData : items) {
            Row row = sheet.createRow(rowNo++);    // starts with rowNo 4
            row.setHeightInPoints(50);

            var nPrice = storePriceService.findActiveNationalPriceByEan(storeCollectionHoSpreadsheetData.getEan(), storeCollectionHoSpreadsheetData.getSalesUnit());
            var storePrice = storePriceService.findActiveStorePriceByEanFromRepo(storeCollectionHoSpreadsheetData.getEan(), storeCollectionHoSpreadsheetData.getStoreCode());
            var compProduct = competitorProductService.findCompProductByEanAndCode(storeCollectionHoSpreadsheetData.getEan(), storeCollectionHoSpreadsheetData.getCompetitorStoreCode());
            String localPrice = StringUtils.replace(priceTools.calculateSUPrice(nPrice, storeCollectionHoSpreadsheetData), DOT_SEPARATOR, COMMA_SEPARATOR);
            String collectedPriceValue = StringUtils.replace(Double.toString(storeCollectionHoSpreadsheetData.getCollectedPrice()), DOT_SEPARATOR, COMMA_SEPARATOR);

            String[] cellValues = {
                    String.valueOf(storeCollectionHoSpreadsheetData.getCollectionListId()),
                    storeCollectionHoSpreadsheetData.getCollectionListName(),
                    storeCollectionHoSpreadsheetData.getEndDate() != null ? DateUtils.getDateAsString(LocalDateTime.parse(storeCollectionHoSpreadsheetData.getEndDate()), DATE_FORMAT_EXCEL) : null,
                    storeCollectionHoSpreadsheetData.getStoreCode(),
                    storeCollectionHoSpreadsheetData.getStoreName(),
                    storeCollectionHoSpreadsheetData.getStoreCollectionId(),
                    storeCollectionHoSpreadsheetData.getStoreCollectionListName(),
                    storeCollectionHoSpreadsheetData.getCompetitorStoreCode(),
                    storeCollectionHoSpreadsheetData.getCompetitorName(),
                    storeCollectionHoSpreadsheetData.getCategory(),
                    storeCollectionHoSpreadsheetData.getCollectionListCode(),
                    storeCollectionHoSpreadsheetData.getEan(),
                    storeCollectionHoSpreadsheetData.getProductLabel(),
                    UOM_EA.equalsIgnoreCase(storeCollectionHoSpreadsheetData.getUom()) ? UOM_PC : storeCollectionHoSpreadsheetData.getUom(),
                    StringUtils.replace(DecimalUtils.roundOf(Double.parseDouble(storeCollectionHoSpreadsheetData.getPackaging()), DecimalUtils.ROUND_OF_2), DOT_SEPARATOR, COMMA_SEPARATOR),
                    StringUtils.replace(Double.toString(Optional.ofNullable(storePrice.getPrice()).orElse(0.0)), DOT_SEPARATOR, COMMA_SEPARATOR),
                    storeCollectionHoSpreadsheetData.getCompetitorName(),
                    Optional.ofNullable(compProduct.getCompArticleNumber()).orElse(EMPTY_STR),
                    storeCollectionHoSpreadsheetData.getCollectedPkgValue(),
                    ZERO_ZERO.equals(collectedPriceValue) ? EMPTY_STR : collectedPriceValue,
                    ZERO_ZERO.equals(localPrice) ? EMPTY_STR : localPrice,
                    priceTools.getPromoMessage(storeCollectionHoSpreadsheetData.getStatus(), storeCollectionHoSpreadsheetData.isHasPromo()),
                    storeCollectionHoSpreadsheetData.getNotes()
            };
            createCell(row, cellValues, styleForValues);
        }

        if (rowNo % 104 == 0) {
            sheet.flushRows(105);
        }

        excelFileHelper.printSetupForSheet(sheet);
    }

    private void createCell(Row row, final String[] value, final CellStyle styleForValues) {
        for (int cellNo = 0; cellNo < value.length; cellNo++) {
            Cell cell = row.createCell(cellNo);
            cell.setCellValue(value[cellNo]);
            cell.setCellStyle(styleForValues);
        }
    }

    public void close() throws IOException {
        try (FileOutputStream fos = new FileOutputStream(outputFileName)) {
            log.debug(":Batch: close:: Total number of cell styles:: {}", workbook.getNumCellStyles());
            workbook.write(fos);
        }
        workbook.dispose();
    }

}