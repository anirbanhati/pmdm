package com.kingfisher.compprice.controller;

import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.*;

@RestController
@AllArgsConstructor
@RequestMapping(JOB_BASE_URL)
@Slf4j
public class JobController {

    private JobLauncher jobLauncher;
    private Job exportStoreCollectionItems;
    private final S3OutboundLoadService s3OutboundLoadService;


    @GetMapping(EXPORT_FILE)
    public ResponseEntity<String> exportStoreCollection(@RequestParam(name = SC_NAME) final String scName,
                                                   @RequestParam(name = SC_ID) final Long scId) {
        log.info(":Batch: Entered exportStoreCollection ::: scName--> {}, scId--> {}", scName, scId);
        String fileName = scName + HYPHEN_SEPARATOR + LocalDate.now() + EXCEL_FORMAT;
        return runJob(exportStoreCollectionItems, scName, scId, fileName);
    }

    private ResponseEntity<String> runJob(Job job, final String scName, final Long scId, final String fileName) {
        try {
            log.info(":Batch: Entered runJob for file {} :::", fileName);
            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("jobName", job.getName())
                    .addString("date", LocalDateTime.now().toString())
                    .addString(OUTPUT_FILE_NAME, fileName)
                    .addString(SC_NAME, scName)
                    .addLong(SC_ID, scId)
                    .toJobParameters();
            JobExecution jobExecution = jobLauncher.run(job, jobParameters);

            while (jobExecution.isRunning()) {
                Thread.sleep(2000);
            }

            return ResponseEntity.ok("Batch Job " + job.getName()
                    + " ended with JobExecutionId: " + jobExecution.getId());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to start Batch Job: " + e.getMessage());
        }
    }

    @GetMapping(GET_KEYS)
    public ResponseEntity<String[]> getKeysFromS3Bucket(@RequestParam(name = "path") final String path) {
        log.info("JobController: getKeysFromS3Bucket path --> {}", path);
        return new ResponseEntity<>(s3OutboundLoadService.getS3BucketItems(path), HttpStatus.OK);
    }

}