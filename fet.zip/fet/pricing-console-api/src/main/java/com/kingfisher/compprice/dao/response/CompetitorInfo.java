package com.kingfisher.compprice.dao.response;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CompetitorInfo implements Serializable {
	private static final long serialVersionUID = 5368296121924515666L;

	private String cPrice;
	private Date cDate;
	private String compName;

}