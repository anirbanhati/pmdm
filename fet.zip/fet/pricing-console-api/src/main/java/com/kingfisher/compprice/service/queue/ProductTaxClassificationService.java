package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.ProductTaxClassificationInfo;
import com.kingfisher.compprice.dto.ProductTaxClassification;
import com.kingfisher.compprice.dto.ProductTaxClassifications;
import com.kingfisher.compprice.dto.TaxGroupRule;
import com.kingfisher.compprice.repository.ProductTaxClassificationRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.TAX_CLASSIFICATION_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductTaxClassificationService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final ProductTaxClassificationRepository productTaxClassificationRepository;


    @Override
    public ProcessedByType getProcessedBy() {
        return TAX_CLASSIFICATION_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Tax Feed :: {}", message);
        }
        try {
            final String methodName = "processMessage";
            log.info("Start processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} :: {} ", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String messageMetadata) throws JAXBException {
        ProductTaxClassifications productTaxClassifications = getProductTaxClassificationFeed(messageMetadata);
        if (Optional.ofNullable(productTaxClassifications).isPresent()) {
            productTaxClassificationRepository.deleteAllInBatch();
        }
        Optional.ofNullable(productTaxClassifications).ifPresent(pf ->
                pf.getProductTaxClassification().forEach(this::saveProductTaxClassificationFeedToRepository));
    }

    private ProductTaxClassifications getProductTaxClassificationFeed(final String message) throws JAXBException {
        ProductTaxClassifications productTaxClassifications = null;
        final String methodName = "getProductTaxClassificationFeed";
        log.debug("Entering ::{}  :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(ProductTaxClassifications.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            productTaxClassifications = (ProductTaxClassifications) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting ::{} :: {}", this.getClass().getSimpleName(), methodName);
        return productTaxClassifications;
    }

    @Transactional
    public void saveProductTaxClassificationFeedToRepository(ProductTaxClassification productTaxClassification) {
        Optional.ofNullable(productTaxClassification.getTaxGroupRule()).ifPresent(taxGrpRule ->
                taxGrpRule.forEach(taxRule -> processTaxDetailsForTaxRules(productTaxClassification, taxRule)));
    }

    private void processTaxDetailsForTaxRules(final ProductTaxClassification productTaxClassification, final TaxGroupRule taxRule) {
        final String methodName = "processTaxDetailsForTaxRules";
        if (isValidProductTaxFeedToProcess(productTaxClassification, taxRule)) {
            addOrUpdateProductTaxClassificationFeedDetailsIntoRepository(productTaxClassification, taxRule);
        } else {
            log.info("Skipping {}:: {}", this.getClass().getSimpleName(), " :: tax classification code or tax code does not exist");
        }
        log.debug("Exiting {}:: Method:: {}", this.getClass().getSimpleName(), methodName);
    }

    private void addOrUpdateProductTaxClassificationFeedDetailsIntoRepository(final ProductTaxClassification productTaxClassification,
                                                                              final TaxGroupRule taxRule) {
        var productTaxClassificationInfo = productTaxClassificationRepository.findByTaxJurisdictionIdAndTaxCodeAndTaxClassificationCode(taxRule.getTaxJurisdictionId(),
                taxRule.getTaxCode(), productTaxClassification.getProductTaxClassificationCode()).orElse(null);
        if (Optional.ofNullable(productTaxClassificationInfo).isPresent()) {
            refreshProductTaxClassificationRepository(productTaxClassification, productTaxClassificationInfo, taxRule);
        } else {
            createProductTaxClassificationRepository(productTaxClassification, taxRule);
        }
    }

    private boolean isValidProductTaxFeedToProcess(final ProductTaxClassification productTaxClassification, final TaxGroupRule taxRule) {
        return StringUtils.isNotEmpty(productTaxClassification.getProductTaxClassificationCode())
                && StringUtils.isNotEmpty(taxRule.getTaxCode()) && StringUtils.isNotEmpty(taxRule.getTaxJurisdictionId());
    }

    private void refreshProductTaxClassificationRepository(final ProductTaxClassification productTaxClassification,
                                                           final ProductTaxClassificationInfo productTaxClassificationInfo,
                                                           final TaxGroupRule taxGroupRule) {
        if (CollectionUtils.isNotEmpty(taxGroupRule.getTaxRateRule())) {
            refreshProductTaxClassificationWithPercentage(productTaxClassification, productTaxClassificationInfo, taxGroupRule);
        } else {
            refreshProductTaxClassification(taxGroupRule.getDescription(), productTaxClassification.getProductTaxClassificationCode(),
                    productTaxClassificationInfo, 0.0);
        }
    }

    private void refreshProductTaxClassificationWithPercentage(final ProductTaxClassification productTaxClassification,
                                                               final ProductTaxClassificationInfo productTaxClassificationInfo,
                                                               final TaxGroupRule taxGroupRule) {
        taxGroupRule.getTaxRateRule().forEach(taxRateRule ->
                refreshProductTaxClassification(taxGroupRule.getDescription(), productTaxClassification.getProductTaxClassificationCode(),
                        productTaxClassificationInfo, taxRateRule.getPercent()));
    }

    private void refreshProductTaxClassification(final String description, final String productTaxClassificationCode,
                                                 final ProductTaxClassificationInfo productTaxClassificationInfo, final double percentage) {
        productTaxClassificationInfo.setDescription(description);
        productTaxClassificationInfo.setTaxClassificationCode(productTaxClassificationCode);
        productTaxClassificationInfo.setLastUpdated(LocalDateTime.now());
        productTaxClassificationInfo.setPercent(percentage);
        productTaxClassificationRepository.save(productTaxClassificationInfo);
    }

    private void createProductTaxClassificationRepository(final ProductTaxClassification productTaxClassification, final TaxGroupRule taxGrpRule) {
        ProductTaxClassificationInfo newProductTaxClassificationInfo = new ProductTaxClassificationInfo();
        if (CollectionUtils.isNotEmpty(taxGrpRule.getTaxRateRule())) {
            createProductTaxClassificationWithPercentage(productTaxClassification, taxGrpRule, newProductTaxClassificationInfo);
        } else {
            newProductTaxClassificationInfo.setTaxJurisdictionId(taxGrpRule.getTaxJurisdictionId());
            newProductTaxClassificationInfo.setTaxCode(taxGrpRule.getTaxCode());
            refreshProductTaxClassification(taxGrpRule.getDescription(), productTaxClassification.getProductTaxClassificationCode(),
                    newProductTaxClassificationInfo, 0.0);
        }
    }

    private void createProductTaxClassificationWithPercentage(final ProductTaxClassification productTaxClassification,
                                                              final TaxGroupRule taxGrpRule,
                                                              final ProductTaxClassificationInfo newProductTaxClassificationInfo) {
        taxGrpRule.getTaxRateRule().forEach(taxRateRule -> {
            newProductTaxClassificationInfo.setTaxJurisdictionId(taxGrpRule.getTaxJurisdictionId());
            newProductTaxClassificationInfo.setTaxCode(taxGrpRule.getTaxCode());
            refreshProductTaxClassification(taxGrpRule.getDescription(), productTaxClassification.getProductTaxClassificationCode(),
                    newProductTaxClassificationInfo, taxRateRule.getPercent());
        });
    }

}