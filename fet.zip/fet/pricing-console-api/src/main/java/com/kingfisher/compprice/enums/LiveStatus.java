package com.kingfisher.compprice.enums;

public enum LiveStatus {
	ACTIVE,
	INACTIVE
}
