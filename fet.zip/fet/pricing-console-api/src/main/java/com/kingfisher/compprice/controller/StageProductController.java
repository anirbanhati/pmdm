package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.kingfisher.compprice.controller.swagger.StageProductControllerSwagger;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.request.StageChainRequest;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.repository.StageProductSearchRepository;
import com.kingfisher.compprice.service.StageProductService;
import com.kingfisher.compprice.tools.PerformanceExecution;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(STG_PRODUCT_BASE_URL)
public class StageProductController implements StageProductControllerSwagger {

	private final CurrentUser user;
	private final StageProductService stageProductService;
	private final StageProductSearchRepository stageProductSearchRepo;

	Gson gson = new Gson();

	@Override
	@GetMapping(path = GET_PRODUCT_HIERARCHY_BY_TYPE)
	public MultiDataResponse<Category> getProductsFilterOptionByProdType() {
		log.info("StageProduct: getProductsFilterOptionByProdType");
		return JsonApiResponse.multiDataResponse(stageProductService.findHierarchyForStageProduct(user.getUser()));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'MODIFY_ARTICLE_PRICE')")
	@Override
	@PostMapping(STAGE_PRODUCT_SEARCH)
	@PerformanceExecution
	public SingleDataResponse<StageProductSearchResponse> searchStagedProducts(@RequestBody final ProductSearchCriteria searchCriteria) {
		log.info("StageProduct: searchStagedProducts --> {}", gson.toJson(searchCriteria));
		final ProductSearchPaging paging = null != searchCriteria.getPaging() ? searchCriteria.getPaging() :
				new ProductSearchPaging();
		return JsonApiResponse.singleDataResponse(stageProductService.searchStageProducts(paging, searchCriteria, user));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'ARTICLE_BULK_UPLOAD')")
	@PostMapping(path = BULK_PRICE_IMPORT)
	public SingleDataResponse<PriceListResponse> importPriceList(@RequestParam(REQUEST_PARAM_FILE) final MultipartFile file) throws IOException {
		log.info("StageProduct: importPriceList");
		return JsonApiResponse.singleDataResponse(stageProductService.importBulkUploadPriceList(file, user.getUser()));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'MODIFY_ARTICLE_PRICE')")
	@Override
	@PostMapping
	public SingleDataResponse<StageDataResponse> saveStageData(@RequestBody final StageDataRequest request) {
		log.info("StageProduct: saveStageData --> {}", gson.toJson(request));
		return JsonApiResponse.singleDataResponse(stageProductService.saveOrUpdateStageProduct(request, user.getUser(),
				false));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'STOP_LOCAL_PRICE')")
	@Override
	@PostMapping(STOP_STG_DATA)
	public SingleDataResponse<StageDataResponse> stopLocalPriceForLsp(@RequestBody final StageDataRequest request) {
		log.info("StageProduct: stopLocalPriceForLsp --> {}", gson.toJson(request));
		return JsonApiResponse.singleDataResponse(stageProductService.stopLocalPrice(request, user.getUser()));
	}

	@Override
	@PostMapping(RESET_STG_DATA)
	public ResponseEntity<String> resetStageData() {
		log.info("StageProduct: resetStageData");
		stageProductService.resetStageDetails(user.getUser());
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Override
	@PostMapping(RESET_STG_DATA_CHAIN)
	public ResponseEntity<String> resetChainedStageData(@PathVariable final String chainId) {
		log.info("StageProduct: resetChainedStageData --> {}", chainId);
		stageProductService.resetChainStageDetails(user.getUser(), chainId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Override
	@PostMapping(UPDATE_CHAIN_PRODUCT)
	public MultiDataResponse<StageDataResponse> stageChainProducts(@PathVariable final String chainId,
																   @RequestBody final StageChainRequest request) {
		log.info("StageProduct: stageChainProducts --> {}, {}", chainId, gson.toJson(request));
		return JsonApiResponse.multiDataResponse(stageProductSearchRepo.stageChainProducts(user.getUser(), chainId, request));
	}

	@Override
	@DeleteMapping(DELETE_STG_DATA_BY_EAN)
	public SingleDataResponse<RemoveStageResponse> removeStageData(@PathVariable(PRODUCT_EAN) final String ean,
																   @PathVariable(PRD_TYPE) final String prdType) {
		log.info("StageProduct: removeStageData --> {}, {}", ean, prdType);
		return JsonApiResponse.singleDataResponse(stageProductService.deleteStageData(ean, prdType, user.getUser()));
	}

	@Override
	@PostMapping(UPDATE_GLOBAL_DATES)
	public SingleDataResponse<StageDatesResponse> saveGlobalCalendarDate(@RequestBody final ProductSearchCriteria searchCriteria) {
		log.info("StageProduct: saveGlobalCalendarDate --> {}", gson.toJson(searchCriteria));
		return JsonApiResponse.singleDataResponse(stageProductService.updateValidityOfStagedProducts(searchCriteria, user));
	}

}