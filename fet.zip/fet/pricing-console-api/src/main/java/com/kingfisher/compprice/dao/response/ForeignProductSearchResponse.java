package com.kingfisher.compprice.dao.response;

import org.springframework.data.domain.Page;
import com.kingfisher.compprice.dao.ForeignProduct;
import com.kingfisher.jsonapi.Resource;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ForeignProductSearchResponse implements Resource {

  private static final long serialVersionUID = -568034567701430028L;

  private Page<ForeignProduct> searchResponse;

  @Override
  public String getJsonApiDataId() {
    return null;
  }

  @Override
  public String getJsonApiDataType() {
    return null;
  }

}