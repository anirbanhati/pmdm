package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.FeatureToggle;
import com.kingfisher.compprice.dao.OpCoFeatures;
import com.kingfisher.compprice.dao.entity.FeatureEntity;
import com.kingfisher.compprice.dao.entity.TenantFeatureToggleConfigEntity;
import com.kingfisher.compprice.dao.request.FeatureToggleRequest;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.repository.FeatureRepository;
import com.kingfisher.compprice.repository.TenantFeatureToggleConfigRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.ExceptionConstants.FeatureExceptions.*;

@Service
@RequiredArgsConstructor
public class FeatureToggleService {

	private final FeatureRepository featureRepository;
	private final TenantFeatureToggleConfigRepository tenantFeatureRepository;

	/**
	 * Update Feature for Tenant
	 * Return features present for that Tenant
	 * @param opCoFeature opCo feature
	 * @return OpCoFeatures
	 */
	public OpCoFeatures manageFeatureForOpCo(final OpCoFeatures opCoFeature) {

		opCoFeature.getFeatures().stream().map(ft -> {
			final TenantFeatureToggleConfigEntity entity =
					getFeatureToggleConfig(ft.getName(), opCoFeature.getTenant());
			entity.setEnabled(ft.isEnabled());
			return entity;
		}).forEach(tenantFeatureRepository::save);

		return getAllFeaturesByTenant(opCoFeature.getTenant());
	}

	private TenantFeatureToggleConfigEntity getFeatureToggleConfig(final String featureName, final String tenant) {
		final FeatureEntity feature = featureRepository.getItemByName(featureName)
				.orElseThrow(() -> new DetailsNotFoundException(FEATURE_NOT_FOUND_EXP,
						FEATURE_NOT_FOUND_HTTP_STATUS, FEATURE_NOT_FOUND_DETAILS, FEATURE_NOT_FOUND_ID,
						FEATURE_NAME_NOT_FOUND_POINTER, featureName, FEATURE_NOT_FOUND_TITLE));

		return tenantFeatureRepository.findByFeatureAndTenant(feature, tenant)
				.orElse(new TenantFeatureToggleConfigEntity(feature, tenant, false));
	}

	/**
	 * Get Feature details by name and tenant
	 * @param featureName name of feature
	 * @return OpCoFeatures
	 */
	public OpCoFeatures getFeatureDetailsByNameAndTenant(final String featureName, final String tenant) {
		final OpCoFeatures opCoFeatures = new OpCoFeatures();
		opCoFeatures.setTenant(tenant);

		opCoFeatures.setFeatures(Collections.singleton(featureRepository.getItemByName(featureName)
				.map(feature -> Pair.of(feature,
						tenantFeatureRepository.findByFeatureAndTenant(feature, tenant)))
				.map(item -> new FeatureToggle(item.getLeft().getName(), item.getLeft().getDescription(),
						item.getRight().isPresent() && item.getRight().get().isEnabled()))
				.orElseThrow(() -> new DetailsNotFoundException(FEATURE_NOT_FOUND_EXP,
						FEATURE_NOT_FOUND_HTTP_STATUS, FEATURE_NOT_FOUND_DETAILS, FEATURE_NOT_FOUND_ID,
						FEATURE_NAME_NOT_FOUND_POINTER, featureName, FEATURE_NOT_FOUND_TITLE))));

		return opCoFeatures;
	}

	/**
	 * Get all features for a tenant
	 * @param tenant can be any operating company
	 * @return tenant and set of feature toggle details
	 */
	public OpCoFeatures getAllFeaturesByTenant(final String tenant) {
		final OpCoFeatures opCoFeatures = new OpCoFeatures();
		opCoFeatures.setTenant(tenant);

		opCoFeatures
		.setFeatures(featureRepository.findAll().stream()
				.map(feature -> Pair.of(feature,
						tenantFeatureRepository.findByFeatureAndTenant(feature, tenant)))
				.filter(i -> i.getRight().isPresent())
				.map(item -> new FeatureToggle(item.getLeft().getName(),
						item.getLeft().getDescription(), item.getRight().get().isEnabled()))
				.collect(Collectors.toSet()));

		return opCoFeatures;
	}
	/**
	 * Get all enabled features for a tenant
	 * @param tenant can be CAFR or BDFR
	 * @return OpCo features
	 */
	public OpCoFeatures getAllEnabledFeaturesByTenant(final String tenant) {
		final OpCoFeatures opCoFeatures = new OpCoFeatures();
		opCoFeatures.setTenant(tenant);

		opCoFeatures
		.setFeatures(featureRepository.findAll().stream()
				.map(feature -> Pair.of(feature,
						tenantFeatureRepository.findByFeatureAndTenant(feature, tenant)))
				.filter(i -> i.getRight().isPresent())
				.map(item -> new FeatureToggle(item.getLeft().getName(),
						item.getLeft().getDescription(), item.getRight().get().isEnabled()))
				.filter(FeatureToggle::isEnabled)
				.collect(Collectors.toSet()));

		return opCoFeatures;
	}

	/**
	 * Create Feature
	 * @param features features
	 * @return List<FeatureEntity>
	 */
	public List<FeatureEntity> createFeature(final List<FeatureEntity> features) {
		return features.stream().map(featureRepository::save).toList();
	}

	/**
	 * Get All features
	 *
	 * @return List<FeatureEntity>
	 */
	public List<FeatureEntity> getAllFeatures() {
		return featureRepository.findAll();
	}

	/**
	 * Update Feature details
	 * @param featureId Feature Id
	 * @return List<FeatureEntity>
	 */
	public List<FeatureEntity> updateFeature(final String featureId, final FeatureToggleRequest request) {
		final FeatureEntity entity = featureRepository.getReferenceById(Long.parseLong(featureId));
		if (!request.getName().isEmpty()) {
			entity.setName(request.getName());
		}
		if (!request.getDescription().isEmpty()) {
			entity.setDescription(request.getDescription());
		}
		featureRepository.save(entity);
		return getAllFeatures();
	}

}