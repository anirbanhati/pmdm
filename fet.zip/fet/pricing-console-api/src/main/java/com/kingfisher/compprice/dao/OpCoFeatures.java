package com.kingfisher.compprice.dao;

import java.util.Set;
import lombok.Data;

@Data
public class OpCoFeatures {

  private String tenant;
  private Set<FeatureToggle> features;

}