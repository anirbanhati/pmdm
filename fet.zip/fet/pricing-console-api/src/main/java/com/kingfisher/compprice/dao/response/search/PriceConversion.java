package com.kingfisher.compprice.dao.response.search;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PriceConversion implements Serializable {
    private static final long serialVersionUID = -3895017432076658355L;
    private boolean rUV = true;
    private boolean rUL = true;
}
