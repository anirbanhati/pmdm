package com.kingfisher.compprice.dao;

import com.kingfisher.jsonapi.Resource;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
public class ForeignProduct implements Resource, Serializable {

    private static final long serialVersionUID = -1597807951392718006L;

    private String cEan;
    private String cArticleCode;
    private double cPrice;
    private String storeCode;
    private String tenant;
    private String csCode;
    private String csName;
    private long cListId;
    private String cUOM;
    private String cListName;
    private String assignedTo;
    private String createdBy;
    private String cDesc;
    private LocalDateTime creationTime;

    @Override
    public String getJsonApiDataId() {
        return "";
    }

    @Override
    public String getJsonApiDataType() {
        return "ForeignProduct";
    }

}