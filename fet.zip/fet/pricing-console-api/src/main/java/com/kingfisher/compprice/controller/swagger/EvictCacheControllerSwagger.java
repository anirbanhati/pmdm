package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.util.constants.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import static com.kingfisher.compprice.util.constants.Constants.CACHE_NAME;

@Tag(name = Constants.TAG_EVICT_CACHE)
public interface EvictCacheControllerSwagger {

    @Operation(description = "Clear Cache By CacheName")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> clearCache(@PathVariable(CACHE_NAME) String cacheName);

    @Operation(description = "Clear Cache BY CacheName And Keys")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> clearCacheByNameAndKeys(@RequestParam(CACHE_NAME) final String cacheName,
                                                   @RequestParam final String key1,
                                                   @RequestParam(required = false) final String key2);

    @Operation(description = "Clear All Cache")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> clearAllCache();

}