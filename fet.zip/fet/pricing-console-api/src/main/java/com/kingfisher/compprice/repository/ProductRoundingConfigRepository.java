package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ProductRoundingConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface ProductRoundingConfigRepository extends JpaRepository<ProductRoundingConfig, Long> {

    Set<ProductRoundingConfig> findByArticleNumberIn(final List<Long> productCodes);

}