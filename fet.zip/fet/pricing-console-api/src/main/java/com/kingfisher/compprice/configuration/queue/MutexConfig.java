package com.kingfisher.compprice.configuration.queue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Configuration
public class MutexConfig {

    @Bean
    public Lock messageLock() {
        return new ReentrantLock();
    }
}
