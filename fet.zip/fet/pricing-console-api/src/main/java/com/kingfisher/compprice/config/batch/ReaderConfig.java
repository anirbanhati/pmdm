package com.kingfisher.compprice.config.batch;

import com.kingfisher.compprice.dao.StoreCollectionHoSpreadsheetData;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Configuration
@AllArgsConstructor
@Slf4j
public class ReaderConfig {

    private static final String SELECT_CLAUSE = "select distinct " +
            "sc.id," +
            "sc.collection_list_name," +
            "sc.effective_end_date," +
            "sc.sc_store_code," +
            "store.store_name," +
            "sc.exp_date," +
            "sc.cl_cs_code," +
            "compStore.longname," +
            "prd.category," +
            "prd.product_code," +
            "prd.p_ean," +
            "prd.description," +
            "prd.uom," +
            "prd.packaging1," +
            "asg.collected_pkg_value," +
            "asg.collected_price," +
            "sc.status," +
            "asg.has_promo," +
            "asg.notes," +
            "sc.category_type," +
            "prd.conversion," +
            "cc.rounding_type," +
            "sc.ho_cl_name," +
            "sc.ho_cl_id," +
            "sc.ho_cl_name," +
            "prd.sales_unit ";
    private static final String FROM_CLAUSE = "from competitorprice.lsp_store_collection sc " +
            "inner join competitorprice.store store on store.store_code = sc.sc_store_code " +
            "left join competitorprice.lsp_competitor_store compStore on compStore.code = sc.cl_cs_code " +
            "left join competitorprice.map_store_competitorstore_v2 mapComp on compStore.comp_id = mapComp.cs_id " +
            "inner join competitorprice.lsp_assignment asg on asg.collection_id = sc.id " +
            "inner join competitorprice.lsp_product prd on prd.product_id = asg.product_id " +
            "left join competitorprice.CATEGORY_ROUNDING_CONFIG cc on cc.brick_code = cast(prd.brick_code as bigint) ";
    private static final String WHERE_CLAUSE = "where (sc.ho_cl_name = :scName and sc.category_type = 'Store') or " +
            "(sc.collection_list_name = :scName and sc.has_store_clone = false) ";

    private DataSource dataSource;


    @Bean
    @StepScope
    public JdbcPagingItemReader<StoreCollectionHoSpreadsheetData> databaseReader(@Value("#{jobParameters['scName']}") String scName) throws Exception {

        log.debug(":Batch: ReaderConfig: database Reader  :::");
        SqlPagingQueryProviderFactoryBean queryProvider = new SqlPagingQueryProviderFactoryBean();
        queryProvider.setDataSource(dataSource);
        queryProvider.setSelectClause(SELECT_CLAUSE);
        queryProvider.setFromClause(FROM_CLAUSE);
        queryProvider.setWhereClause(WHERE_CLAUSE);
        queryProvider.setSortKeys(sortingKeys());

        return new JdbcPagingItemReaderBuilder<StoreCollectionHoSpreadsheetData>()
                .name("databaseReader")
                .dataSource(dataSource)
                .fetchSize(100)
                .queryProvider(Objects.requireNonNull(queryProvider.getObject()))
                .parameterValues(Collections.singletonMap(SC_NAME, scName))
                .rowMapper(new SpreadsheetDataRowMapper())
                .build();
    }

    @Bean
    public Map<String, Order> sortingKeys() {
        Map<String, Order> sortingKeys = new HashMap<>();
        sortingKeys.put(SC_STORE_CODE, Order.ASCENDING);
        sortingKeys.put(P_EAN, Order.ASCENDING);
        return sortingKeys;
    }

}