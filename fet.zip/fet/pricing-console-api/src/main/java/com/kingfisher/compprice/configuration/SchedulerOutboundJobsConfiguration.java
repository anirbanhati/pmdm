package com.kingfisher.compprice.configuration;

import com.kingfisher.compprice.helper.OutboundHoCollectionHelper;
import com.kingfisher.compprice.schedule.PriceOutboundScheduler;
import com.kingfisher.compprice.schedule.ProductCollectionOutboundScheduler;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import lombok.AllArgsConstructor;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
@AllArgsConstructor
public class SchedulerOutboundJobsConfiguration {

    private final S3OutboundLoadService s3OutboundLoadService;
    private final OutboundHoCollectionHelper outboundHoCollectionHelper;
    private final LogService logService;


    @Bean
    @ConditionalOnProperty(name = "enabled.scheduler")
    public PriceOutboundScheduler getPriceFeedOutboundJob() {
        return new PriceOutboundScheduler(s3OutboundLoadService);
    }

    @Bean
    @ConditionalOnProperty(name = "enabled.scheduler")
    public ProductCollectionOutboundScheduler getProductCollectionFeedOutboundJob() {
        return new ProductCollectionOutboundScheduler(s3OutboundLoadService, outboundHoCollectionHelper, logService);
    }

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(dataSource, "competitorprice.shedlock");
    }

}