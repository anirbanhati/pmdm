package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.ClusterPrice;
import com.kingfisher.compprice.dao.entity.ClusterStoreMapping;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants;
import com.kingfisher.compprice.repository.ClusterPriceRepository;
import com.kingfisher.compprice.repository.ClusterStoreRepository;
import com.kingfisher.compprice.util.DateUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class ClusterPriceService {

    private final ClusterStoreRepository clusterStoreRepository;
    private final ClusterPriceRepository clusterPriceRepository;
    private final ProductTools productTools;
    private final LogService logService;


    public List<ClusterStoreMapping> saveClusterStoreDetails(final List<ClusterStoreMapping> clusterStoresDetail) {
        List<ClusterStoreMapping> updatedCluster = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(clusterStoresDetail)) {
            for (final ClusterStoreMapping clusterStoreData : clusterStoresDetail) {
                Optional<ClusterStoreMapping> clusterStore = clusterStoreRepository.findByStoreCode(clusterStoreData.getStoreCode());
                if (clusterStore.isEmpty()) {
                    updatedCluster.add(clusterStoreData);
                } else {
                    updateNewCluster(clusterStore.get(), clusterStoreData, updatedCluster);
                }
            }
            clusterStoreRepository.saveAll(updatedCluster);
        }
        return updatedCluster;
    }

    private void updateNewCluster(ClusterStoreMapping clusterStore, ClusterStoreMapping clusterStoreData, List<ClusterStoreMapping> updatedCluster) {
        clusterStore.setClusterId(clusterStoreData.getClusterId());
        updatedCluster.add(clusterStore);
    }

    public ClusterStoreMapping getClusterByStoreCode(final String code) {
        return clusterStoreRepository.findByStoreCode(code).orElse(null);
    }

    public List<ClusterStoreMapping> getAllClusterDetails() {
        final List<ClusterStoreMapping> clusterStores = clusterStoreRepository.findAll();
        if (CollectionUtils.isEmpty(clusterStores)) {
            throw new DetailsNotFoundException(ExceptionConstants.ClusterExceptions.CLUSTER_NOT_FOUND_APP_EXP,
                    ExceptionConstants.ClusterExceptions.CLUSTER_NOT_FOUND_HTTP_STATUS, ExceptionConstants.ClusterExceptions.CLUSTER_NOT_FOUND_DETAILS,
                    ExceptionConstants.ClusterExceptions.CLUSTER_NOT_FOUND_ID, ExceptionConstants.ClusterExceptions.CLUSTER_ID_NOT_FOUND_POINTER,
                    "ALL", ExceptionConstants.ClusterExceptions.CLUSTER_NOT_FOUND_TITLE);
        }
        return clusterStores;
    }

    public void deleteClusterStores(final String storeCode) {
        ClusterStoreMapping clusterStoreInfo = getClusterByStoreCode(storeCode);
        clusterStoreRepository.delete(clusterStoreInfo);
    }

    public void deleteAllClusterStores() {
        clusterStoreRepository.deleteAll();
    }

    private List<ClusterPrice> findClusterPricesByListOfEanAndClusterID(final List<String> listOfEan, final ClusterStoreMapping clusterStoreMapping) {
        return clusterPriceRepository.findByEanInAndClusterID(listOfEan, clusterStoreMapping.getClusterId());
    }

    public Double findClusterPriceByClusterId(final Product product, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("findClusterPriceByClusterId");

        Double clusterPrice = null;
        ClusterStoreMapping clusterStoreMapping = getClusterByStoreCode(user.getStore().getStoreCode());
        if (null != clusterStoreMapping) {
            clusterPrice = productTools.findClusterPriceByEanAndClusterId(product, clusterStoreMapping);
        }

        logService.logStopWatchStop(stopWatch);
        return clusterPrice;
    }

    public Map<String, Double> getEanClusterPriceMap(List<String> listOfEan, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getEanClusterPriceMap");
        Map<String, Double> eanClusterPriceMap = new HashMap<>();

        ClusterStoreMapping clusterStoreMapping = getClusterByStoreCode(user.getStore().getStoreCode());
        if (null != clusterStoreMapping) {
            List<ClusterPrice> listOfClusterPrice = findClusterPricesByListOfEanAndClusterID(listOfEan, clusterStoreMapping);
            if (CollectionUtils.isNotEmpty(listOfClusterPrice)) {
                Map<String, List<ClusterPrice>> eanClusterPricesMap = listOfClusterPrice.stream()
                        .collect(Collectors.groupingBy(ClusterPrice::getEan));
                eanClusterPricesMap.forEach((ean, clusterPrices) -> {
                    var clusterPriceOptional = clusterPrices.stream()
                            .filter(cPrice -> DateUtils.isInBetween(cPrice.getStartDate(), cPrice.getEndDate().plusDays(1), LocalDateTime.now()))
                            .max(Comparator.comparing(ClusterPrice::getLastUpdatedDate));
                    clusterPriceOptional.ifPresent(clusterPrice -> eanClusterPriceMap.put(ean, clusterPrice.getPrice()));
                });
            }
        }

        logService.logStopWatchStop(stopWatch);
        return eanClusterPriceMap;
    }

}