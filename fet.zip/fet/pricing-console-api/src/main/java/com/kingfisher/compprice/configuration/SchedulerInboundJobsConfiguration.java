package com.kingfisher.compprice.configuration;

import com.kingfisher.compprice.helper.InboundFeedDownloadHelper;
import com.kingfisher.compprice.schedule.InboundFeedScheduler;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SchedulerInboundJobsConfiguration {

    private InboundFeedDownloadHelper inboundFeedDownloadHelper;

    @Bean
    @ConditionalOnProperty(name = "enabled.bucket")
    public InboundFeedScheduler getInboundConfigs() {
        return new InboundFeedScheduler(inboundFeedDownloadHelper);
    }

}