package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.CompetitorProduct;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.CacheConstants.COMP_PRODUCT_CACHE;

@Repository
public interface CompetitorProductRepository extends JpaRepository<CompetitorProduct, Long> {

    Optional<CompetitorProduct> findByCompEanAndEanAndCodeAndSalesUnit(final String compEan, final String ean,
                                                                       final String compCode, final String salesUnit);

    @Cacheable(value = COMP_PRODUCT_CACHE, key = "#ean")
    List<CompetitorProduct> findByEan(final String ean);

    List<CompetitorProduct> findByEanInAndCompNameIn(final List<String> listOfEan, final Set<String> compNames);

}