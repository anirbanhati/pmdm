package com.kingfisher.compprice.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAPIConfig {

    @Value("${spring.application.name}")
    private String applicationName;

    private static final String GROUP = "v1";
    private static final String PACKAGES_TO_SCAN = "com.kingfisher.compprice.controller";
    private static final String DESCRIPTION = "Competitor Price API";


    @Bean
    public GroupedOpenApi v1() {
        return GroupedOpenApi.builder()
                .group(GROUP)
                .packagesToScan(PACKAGES_TO_SCAN)
                .build();
    }

    @Bean
    public OpenAPI apiDocConfig() {
        return new OpenAPI()
                .info(new Info()
                        .title(applicationName)
                        .description(DESCRIPTION));
    }

}