package com.kingfisher.compprice.util.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SchedulerConstants {

    public static final String PURGE_STORE_PRODUCT = "purgeStoreProduct";
    public static final String PURGE_USER = "purgeUser";
    public static final String PURGE_SALES_HISTORY = "purgeSalesHistory";
    public static final String PURGE_PRICE = "purgePrice";
    public static final String PURGE_PRODUCT_PRICE = "purgeProductPrice";
    public static final String PURGE_PRODUCT_LISTING = "purgeProductListing";
    public static final String PURGE_IMPORT_ERRORS = "purgeImportErrors";
    public static final String PURGE_ROLLING_DAYS = "purgeRollingDays";
    public static final String PURGE_HO_SC_OBJECT = "purgeHoScObject";
    public static final String PURGE_STORE_COLLECTION = "purgeStoreCollection";
    public static final String PURGE_SCHEDULER_STATUS = "purgeSchedulerStatus";
    public static final String PURGE_CLUSTER_PRICE = "purgeClusterPrice";

}