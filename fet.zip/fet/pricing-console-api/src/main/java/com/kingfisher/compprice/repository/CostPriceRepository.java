package com.kingfisher.compprice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kingfisher.compprice.dao.entity.CostPrice;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import org.springframework.stereotype.Repository;

@Repository
public interface CostPriceRepository extends JpaRepository<CostPrice, Long> {

    Optional<CostPrice> findByStoreAndProductAndSalesOrg(final Store store, final Product product, final String salesOrg);

}