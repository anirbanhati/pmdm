package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.entity.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CurrentUser {

	private String currentUserName;
	private String userId;
	private User user;

	public void clear() {
		this.setCurrentUserName("");
	}

}