package com.kingfisher.compprice.dao.response.product;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.dao.response.search.PriceConversion;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ScProductResponse implements Serializable {
    private static final long serialVersionUID = -7694773141903157249L;
    
    private String ean;
    @JsonProperty("code")
    private String productCode;
    @JsonProperty("sUnit")
    private String salesUnit;
    private String pkg1;
    private String pkg2;
    @JsonProperty("desc")
    private String description;
    @JsonProperty("stdPrice")
    private Double standardPrice;
    @JsonProperty("pkg")
    private String packaging;
    private String unit;
    private String prdType;
    private Double costPrice;
    private Double costPriceVat;
    private Double conversion;
    private boolean showDatePicker;
    private boolean isFixedPrice;
    private String catType;
    private boolean validPrd;
    @JsonProperty("pConversion")
    private PriceConversion pConversion;
    @JsonProperty("sProduct")
    private StoreProduct sProduct;
    @JsonProperty("sPrice")
    private StorePrice sPrice;
    @JsonProperty("nPrice")
    private Double nPrice;

}