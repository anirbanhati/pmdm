package com.kingfisher.compprice.dao.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="store_stock")
public class StoreStock  implements Serializable {

	private static final long serialVersionUID = 5359820566839987274L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name="vendor")
	private String vInfo;
	
	@Column(name="last_updated")
	private LocalDateTime lastUpdateTime;
	
	@Column(name="store_level")
	private Double currStoreLevel;
	
	@Column(name="store_value")
	private Double currStoreValue;
	
	@Column(name="map")
	private Double map;
	
	@Column(name="fin_provision")
	private Double finProvision;
	

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;
	
}