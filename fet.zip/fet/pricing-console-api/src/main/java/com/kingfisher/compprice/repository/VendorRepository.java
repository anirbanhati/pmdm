package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {

    List<Vendor> findByProduct(Product product);

}