package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.CollectionProduct;
import com.kingfisher.compprice.dao.DesiredPrice;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.ProvisionDetails;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.entity.PriceUpdate;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.response.search.*;
import com.kingfisher.compprice.dto.ProductDTO;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.service.*;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.tools.PriceValidation;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;
import static com.kingfisher.compprice.util.DecimalUtils.roundOf;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductInfoHelper {

	private final VendorService vendorService;
	private final StockProvisionsService stockProvService;
	private final StoreProductService storeProductService;
	private final StorePriceService storePriceService;
	private final HelperService helperService;
	private final StorePriceTools storePriceTools;
	private final ProductTools productTools;
	private final PriceTools priceTools;
	private final PriceValidation priceValidation;
	private final ThirdPartyAPIService thirdPartyAPIService;
	private final PriceHistoryService priceHistoryService;
	private final AssignmentItemService assignmentItemService;
	private final ClusterPriceService clusterPriceService;
	private final ProductListingService productListingService;
	private final ChangeRequestConfiguration crConfig;


	@Transactional
	public ProductItemDetails setProductDetails(final Product product, final String type, final User user,
												ProductDetailsResponse response) {
		final ProductItemDetails pItem = new ProductItemDetails();
		var storePrice = storePriceTools.getActiveStorePrice(product, user.getStore());
		var nPrice = storePriceService.findActiveNationalPriceByProduct(product, user.getTenant());
		var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
		var storeProduct = storeProductService.getStoreProductByProductAndStoreFromRepo(product, user);
		var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);
		var price = storePriceService.getStorePriceWithCluster(nPrice,storePrice, user, clusterPrice);

		pItem.setStorePrice(storePriceService.setStorePrice(storePrice, price));
		pItem.setHistoryPrices(priceHistoryService.setHistoryPriceNew(product, user));
		pItem.setVendor(vendorService.getVendorByProduct(product));
		pItem.setType(type);
		pItem.setEan(product.getEan());
		pItem.setCat(product.getCategory());
		pItem.setSCat(product.getSubCategory());
		pItem.setBName(product.getBrickName());
		pItem.setDesc(product.getDescription());
		pItem.setPCode(product.getProductCode());
		pItem.setUom(product.getUom());
		pItem.setShowDatePicker(storeProductService.isShowDatePicker(type, user));
		pItem.setPrdList(productTools.filterNonEligibleProductByStatus(product) && productListingService.validProductListing(product, user.getStore()));
		pItem.setEnableStopPrice(!crConfig.isStopPrice() || priceTools.isStoppedLocalPrice(storePrice, nPrice));
		if (null != storeProduct) {
			pItem.setFixedPriceFlag(storeProduct.getFixedPrice());
			pItem.setOorDate(storeProduct.getOorDate());
			pItem.setEditable(storeProduct.isEditable());
		}
		final Map<String, String> costPriceDetailsMap = thirdPartyAPIService.getCostPriceDetails(List.of(product), user, true);
		String costPriceValue = StringUtils.isNotEmpty(costPriceDetailsMap.get(product.getEan())) ?
				costPriceDetailsMap.get(product.getEan()) : MAP_0;
		final double costPrice = Double.parseDouble(costPriceValue);
		var costPriceVat = priceValidation.calculateCostPriceInclusiveOfVat(costPrice, product, user);
		pItem.setCostPrice(DecimalUtils.roundOf(costPrice, ROUND_OF_2));
		pItem.setCostPriceVat(String.valueOf(costPriceVat));

		pItem.setStgPrice(helperService.getStagePriceInfo(product, type, user, costPrice, null,
				new ProvisionDetails(0, 0.0, null),	Double.parseDouble(pItem.getStorePrice().getPrice())));
		pItem.setStdPrice(DecimalUtils.roundOf(stdPrice, ROUND_OF_2));
		pItem.setCompInfos(setCompItemInfo(product, user));
		final Map<String, Integer> currentStockMap = thirdPartyAPIService.getCurrentStockDetails(Collections.singletonList(product), user.getStore());
		if (currentStockMap.containsKey("Error")) {
			response.setStockApiError(true);
		}
		pItem.setStockInfo(stockProvService.getStockInfo(user, product, currentStockMap.getOrDefault(product.getEan(), 0),
				costPrice));
		pItem.setRecom(stockProvService.getRecommendation(pItem.getStockInfo(),
				StringUtils.isNotEmpty(pItem.getStdPrice()) ? Double.parseDouble(pItem.getStdPrice()) : 0));
		return pItem;
	}

	public PendingPriceProductItem setPendingPriceProductItem(final PriceUpdate pUpdate, final MasterData masterData, final User user) {
		final PendingPriceProductItem item = new PendingPriceProductItem();

		final Product product = pUpdate.getProduct();
		var storePrice = masterData.getEanStorePriceMap().get(product.getEan());
		var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
		var clusterPrice = masterData.getEanClusterPriceMap().get(product.getEan());

		item.setCostPrice(String.valueOf(pUpdate.getCPrice()));
		item.setBName(product.getBrickName());
		item.setCat(product.getCategory());
		item.setDesc(product.getDescription());
		item.setDPrice(DecimalUtils.roundOf(pUpdate.getPrice(), ROUND_OF_2));
		item.setEan(product.getEan());
		item.setEDate(DateUtils.getDateAsString(pUpdate.getEndDate(), DateUtils.DATE_FORMAT));
		item.setPCode(product.getProductCode());
		item.setPkg2(product.getPkg2());
		item.setSCat(product.getSubCategory());
		item.setSDate(DateUtils.getDateAsString(pUpdate.getStartDate(), DateUtils.DATE_FORMAT));
		item.setType(pUpdate.getPrdType().toString());
		item.setReqId(pUpdate.getId());
		item.setStatus(pUpdate.getStatus());

		if (null != storePrice) {
			item.setStdPrice(DecimalUtils.roundOf(storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice), ROUND_OF_2));
			item.setStoreAppPrice(DecimalUtils.roundOf(storePriceService.getStorePriceWithCluster(nPrice, storePrice, user, clusterPrice), ROUND_OF_2));
		}
		return item;
	}

	public ProductItem setProductItem(final Product product, final String type, final User user, final int currentStock,
									  final List<StageProduct> stgProducts, final boolean isCurrentStockValidated, final String costPrice) {
		ProductItem pItem;
		var storePrice = storePriceTools.getActiveStorePrice(product, user.getStore());
		var nPrice = storePriceService.findActiveNationalPriceByProduct(product, user.getTenant());
		var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
		var storeProduct = storeProductService.getStoreProductByProductAndStoreFromRepo(product, user);
		var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);
		var price = storePriceService.getStorePriceWithCluster(nPrice, storePrice, user, clusterPrice);
		var costPriceVat = priceValidation.calculateCostPriceInclusiveOfVat(Double.parseDouble(costPrice), product, user);

		pItem = getProductItem(product, type, user, currentStock, isCurrentStockValidated, price, costPrice, stdPrice, stgProducts);
		pItem.setType(type);
		pItem.setShowDatePicker(storeProductService.isShowDatePicker(type, user));
		pItem.setEan(product.getEan());
		pItem.setPCode(product.getProductCode());
		pItem.setCat(product.getCategory());
		pItem.setPkg2(product.getPkg2());
		pItem.setSCat(product.getSubCategory());
		pItem.setBName(product.getBrickName());
		pItem.setDesc(product.getDescription());
		pItem.setUom(UOM_EA.equalsIgnoreCase(product.getUom()) ? UOM_PC : product.getUom());
		pItem.setFixedPriceFlag(null != storeProduct ? storeProduct.getFixedPrice() : PRICE_FLAG_NO);
		pItem.setEditable(null != storeProduct && storeProduct.isEditable());
		pItem.setEnableStopPrice(!crConfig.isStopPrice() || priceTools.isStoppedLocalPrice(storePrice, nPrice));
		pItem.setChainId(productTools.getChainIdFromProduct(product));
		pItem.setStoreAppPrice(DecimalUtils.roundOf(price, ROUND_OF_2));
		pItem.setCostPrice(costPrice);
		pItem.setCostPriceVat(String.valueOf(costPriceVat));
		pItem.setStdPrice(DecimalUtils.roundOf(stdPrice, ROUND_OF_2));
		pItem.setPrdList(productTools.filterNonEligibleProductByStatus(product) && productListingService.validProductListing(product, user.getStore()));
		return pItem;
	}

	public WarListProductItem setPVMaxOrPVLocalOrWarListItem(final Product prd, final String type, final User user, final Double storePrice,
															  final String costPrice, List<StageProduct> stgProducts) {
		final WarListProductItem wlItem = new WarListProductItem();
		double cpUom = assignmentItemService.setCompetitorPrice(prd, user);
		wlItem.setCpUom(DecimalUtils.roundOf(cpUom, ROUND_OF_2));
		if (!storePrice.equals(0.0)) {
			wlItem.setSpUom(
					DecimalUtils.roundOf(storePrice / (Optional.ofNullable(prd.getConversion()).orElse(1D)),
							DecimalUtils.ROUND_OF_3));
		}
		wlItem.setStgPrice(helperService.getStagePriceInfo(prd, type, user, Double.parseDouble(costPrice), stgProducts,
				new ProvisionDetails(0, 0.0, null), storePrice));
		return wlItem;
	}

	private NonWarListProductItem setOorOrSmProductInfo(final Product prd, final String type, final User user, final Double storePrice,
														final Double stdPrice, List<StageProduct> stgProducts) {
		return setOorOrSmProductInfo(prd, type, user, 0, storePrice, 0, stgProducts, false, stdPrice);
	}

	private NonWarListProductItem setOorOrSmProductInfo(final Product product, final String type, final User user, final int currentStockQty,
														final Double storePrice, final double costPrice, List<StageProduct> stgProducts,
														final boolean isCurrentStockValidated, final Double stdPrice) {
		final NonWarListProductItem oorItem = new NonWarListProductItem();
		ProvisionDetails provDetails;
		final StockInfo stockInfo = stockProvService.getStockInfo(user, product, currentStockQty, costPrice);
		final Recommandation recommandation = stockProvService.getRecommendation(stockInfo, stdPrice);
		if (isCurrentStockValidated) {
			provDetails = new ProvisionDetails(currentStockQty, stockInfo.getWeeklyStock().getPRate(), recommandation);
		} else {
			provDetails = new ProvisionDetails(0, 0.0, null);
		}
		oorItem.setStockInfo(stockInfo);
		oorItem.setRecommadation(recommandation);
		oorItem.setStgPrice(helperService.getStagePriceInfo(product, type, user, costPrice, stgProducts, provDetails,
				storePrice));
		return oorItem;
	}

	private List<CompetitorInfo> setCompItemInfo(final Product product, final User user) {
		final Set<Assignment> assignments = assignmentItemService.findAssignmentByStatusSCAndProd(user.getStore().getStoreCode(),
				product);
		List<CompetitorInfo> cpInfos = null;
		if (CollectionUtils.isNotEmpty(assignments)) {
			cpInfos = new ArrayList<>();
			for (final Assignment assignment : assignments) {
				final CompetitorInfo compInfo = new CompetitorInfo();
				compInfo.setCPrice(DecimalUtils.roundOf(assignment.getCollectedPrice(), ROUND_OF_2));
				compInfo.setCompName(assignment.getStoreCollection().getCsName());
				compInfo.setCDate(Date.from(assignment.getStoreCollection().getCreationTime().atZone(ZoneId.systemDefault())
								.toInstant()) );
				cpInfos.add(compInfo);
			}
		}
		return cpInfos;
	}

	private ProductItem getProductItem(final Product product, final String type, final User user, final int currentStockQty,
									   final boolean isCurrentStockValidated, final Double storePrice, final String costPrice,
									   final Double stdPrice, final List<StageProduct> stgProducts) {
		ProductItem pItem;
		if (ProductType.OutOfRange.toString().equals(type) || ProductType.SlowMoving.toString().equals(type)) {
			final NonWarListProductItem oorItem;
			if (isCurrentStockValidated) {
				oorItem = setOorOrSmProductInfo(product, type, user, currentStockQty, storePrice, Double.parseDouble(costPrice),
						stgProducts, true, stdPrice);
			} else {
				oorItem = setOorOrSmProductInfo(product, type, user, storePrice, stdPrice, stgProducts);
			}
			pItem = oorItem;
		} else {
			pItem = setPVMaxOrPVLocalOrWarListItem(product, type, user, storePrice, costPrice, stgProducts);
		}
		return pItem;
	}

	public ProductChainItem getProductChainItem(final boolean isSPrice, final Product product, final StorePrice storePrice) {
		final ProductChainItem item = new ProductChainItem();
		item.setPrd(product);
		item.setEan(product.getEan());
		item.setCat(product.getCategory());
		item.setSCat(product.getSubCategory());
		item.setBName(product.getBrickName());
		item.setDesc(product.getDescription());
		item.setPCode(product.getProductCode());
		if (isSPrice && null != storePrice && null != storePrice.getId()) {
			item.setStoreAppPrice(roundOf(null != storePrice.getPrice() ? storePrice.getPrice() : 0, ROUND_OF_2));
			item.setEDate(DateUtils.getDateAsString(storePrice.getEndDate(), DateUtils.DATE_FORMAT));
			item.setSDate(DateUtils.getDateAsString(storePrice.getStartDate(), DateUtils.DATE_FORMAT));
			item.setStdPrice(roundOf(null != storePrice.getRefPrice() ? storePrice.getRefPrice() : 0, ROUND_OF_2));
		}
		return item;
	}

	public void setDesiredPriceResponse(CollectionProduct cPrd, final Product product, final MasterData masterData) {
		DesiredPrice desiredPrice = null;
		final PriceUpdate priceUpdate = masterData.getProductPriceUpdateMap().get(product);

		if (null != priceUpdate) {
			desiredPrice = new DesiredPrice();
			desiredPrice.setModifiedBy(priceUpdate.getPUser().getUserId());
			desiredPrice.setModifiedTime(priceUpdate.getModTime());
			desiredPrice.setPrice(priceUpdate.getPrice());
			desiredPrice.setEan(priceUpdate.getProduct().getEan());
			desiredPrice.setStartDate(priceUpdate.getStartDate());
			desiredPrice.setEndDate(priceUpdate.getEndDate());
		}
		cPrd.setPrice(desiredPrice);
	}

	public void updateProductDetailsLatest(final CategoryRoundingResponse cRounding, final User user, final Product product,
											final ProductDTO productDTO) {
		StorePrice sPrice = storePriceTools.getActiveStorePrice(product, user.getStore());
		Double nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
		Double clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);

		if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
			productDTO.setLegalUnit(RoundingType.UV.toString().equals(cRounding.getRType().toString()) ? product.getUom() : product.getPkg2());
		}
		productDTO.setStandardPrice(storePriceService.deriveStandardPrice(nPrice, sPrice, user, clusterPrice));
		productDTO.setUom(UOM_EA.equalsIgnoreCase(product.getUom()) ? UOM_PC : product.getUom());
	}

}