package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.entity.PriceUpdate;
import com.kingfisher.compprice.dao.response.search.LatestPriceHistory;
import com.kingfisher.compprice.dao.response.search.PriceHistory;
import com.kingfisher.compprice.repository.PriceUpdateRepository;
import com.kingfisher.compprice.repository.SalesHistoryRepository;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.PRICE_HISTORY_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;

@Component
@RequiredArgsConstructor
@Slf4j
public class PriceHistoryService {

    private final SalesHistoryRepository salesHistoryRepo;
    private final PriceUpdateRepository priceUpdateRepo;
    private final StorePriceTools storePriceTools;
    private final StorePriceService storePriceService;


    public LatestPriceHistory setLatestPriceHistory(final Product prd, final Store store) {
        LatestPriceHistory pHistory = null;
        final PriceUpdate priceUpdate = priceUpdateRepo.findTopByProductAndStoreOrderByModTimeDesc(prd, store);
        if (null != priceUpdate) {
            pHistory = new LatestPriceHistory();
            pHistory.setLastUpdateBy(priceUpdate.getPUser().getUserId());
            pHistory.setLastUpdateTime(priceUpdate.getModTime());
            pHistory.setPrice(DecimalUtils.roundOf(priceUpdate.getPrice(), ROUND_OF_2));
            pHistory.setStatus(priceUpdate.getStatus());
            pHistory.setId(priceUpdate.getId());
        }
        return pHistory;
    }

    @Cacheable(value = PRICE_HISTORY_CACHE, key = "{#prd.ean, #user.userId}")
    public List<PriceHistory> setHistoryPriceNew(final Product prd, final User user) {
        List<PriceHistory> priceHistoryList = new ArrayList<>();
        // Get store prices list
        final List<StorePrice> storePrices = storePriceTools.getStorePricesList(prd, user);
        // Get sales history data
        final List<SalesHistory> salesHistoryList = salesHistoryRepo.findByStoreAndEan(user.getStore(), prd.getEan());

        if (CollectionUtils.isNotEmpty(storePrices)) {
            LocalDateTime tempSDate = null;
            for (int i = 0; i < storePrices.size(); i++) {
                // Price history start & end date logic
                StorePrice storePrice = storePrices.get(i);
                if (i != storePrices.size() - 1) {
                    if (storePrices.get(i + 1).getStartDate().minusDays(1).toLocalDate().isBefore(storePrice.getStartDate().toLocalDate())) {
                        if (storePrice.getEndDate().toLocalDate().isBefore(LocalDateTime.now().toLocalDate())) {
                            storePrice.setEndDate(storePrice.getEndDate());
                            storePrice.setStartDate(null != tempSDate && storePrice.getStartDate().isAfter(tempSDate) ? tempSDate.plusDays(1) : storePrice.getStartDate());
                        } else {
                            LocalDate lastUpdated = storePrice.getLastUpdateTime().toLocalDate();
                            if (i != 0 && null != tempSDate && lastUpdated.atStartOfDay().isAfter(tempSDate.minusDays(1))) {
                                storePrice.setStartDate(lastUpdated.atStartOfDay());
                                storePrice.setEndDate(lastUpdated.atStartOfDay());
                            } else {
                                storePrice.setStartDate(null != tempSDate && storePrice.getStartDate().isAfter(tempSDate) ? tempSDate : storePrice.getStartDate());
                                storePrice.setEndDate(null != tempSDate && storePrice.getStartDate().isAfter(tempSDate) ? tempSDate : storePrice.getStartDate());
                            }
                        }
                    } else {
                        // Newer storePrice's startDate is After Previous storePrice's startDate
                        storePrice.setStartDate(startDateIsAfterPreviousStartDate(i, storePrice, storePrices));
                        storePrice.setEndDate(deriveStorePriceEndDate(i, storePrice, storePrices));
                    }
                    tempSDate = storePrice.getEndDate();
                    // Process sales history data & set Response
                    processSalesHistoryAndSetResponse(priceHistoryList, salesHistoryList, storePrice);
                }
            }
            Collections.reverse(priceHistoryList);
        }
        return priceHistoryList;
    }

    private LocalDateTime startDateIsAfterPreviousStartDate(final int i, final StorePrice storePrice, final List<StorePrice> storePrices) {
        return i != 0 && storePrice.getStartDate().isBefore(storePrices.get(i - 1).getEndDate()) ?
                storePrices.get(i - 1).getEndDate().plusDays(1) : storePrice.getStartDate();
    }

    private LocalDateTime deriveStorePriceEndDate(final int i, final StorePrice storePrice, final List<StorePrice> storePrices) {
        LocalDateTime storePriceEndDate;
        if (storePrice.getEndDate().isBefore(storePrices.get(i + 1).getStartDate())) {
            storePriceEndDate = storePrice.getEndDate();
        } else if (storePrices.get(i + 1).getStartDate().minusDays(1).isAfter(storePrice.getStartDate())) {
            storePriceEndDate = storePrices.get(i + 1).getStartDate().minusDays(1);
        } else if (storePrice.getEndDate().isAfter(LocalDateTime.now().toLocalDate().atStartOfDay())) {
            storePriceEndDate = storePrice.getStartDate();
        } else {
            storePriceEndDate = storePrice.getEndDate();
        }
        return storePriceEndDate;
    }

    private void processSalesHistoryAndSetResponse(List<PriceHistory> priceHistoryList, List<SalesHistory> salesHistoryList, StorePrice storePrice) {
        LocalDateTime saleDate;
        double avgPrice = 0.0;
        int sQty = 0;
        int count = 0;
        if (CollectionUtils.isNotEmpty(salesHistoryList)) {
            for (final SalesHistory salesHistory : salesHistoryList) {
                saleDate = salesHistory.getSalesDate() == null ? storePrice.getLastUpdateTime() : salesHistory.getSalesDate();
                if (storePrice.getEndDate() != null && storePrice.getStartDate() != null && DateUtils.isInBetween(storePrice.getStartDate().minusDays(1), storePrice.getEndDate().plusDays(1), saleDate)) {
                    sQty = sQty + salesHistory.getSalesQuantity().intValue();
                    avgPrice = avgPrice + salesHistory.getAvgPriceFromSales();
                    count = count + 1;
                }
            }
        }
        PriceHistory priceHistory = new PriceHistory();
        setPriceHistoryResponse(priceHistory, storePrice, avgPrice, sQty, count);
        priceHistoryList.add(priceHistory);
    }

    public void setPriceHistoryResponse(PriceHistory pHistory, StorePrice sPrice, double avgPrice, int sQty, int count) {
        String sType = Optional.ofNullable(sPrice.getPriceTypeFlag()).orElse(EMPTY_STR);
        pHistory.setSDate(sPrice.getStartDate());
        pHistory.setEDate(sPrice.getEndDate());
        pHistory.setAppPrice(DecimalUtils.roundOf(sPrice.getPrice(), ROUND_OF_2));
        pHistory.setRefPrice(DecimalUtils.roundOf(sPrice.getRefPrice(), ROUND_OF_2));
        pHistory.setAvgPrice(count!=0 ? DecimalUtils.roundOf(avgPrice/count, ROUND_OF_2) : String.valueOf(avgPrice));
        pHistory.setSqty(sQty);
        pHistory.setSpType(StringUtils.isBlank(sType) ? null: storePriceService.getPriceType(sType));
    }

}