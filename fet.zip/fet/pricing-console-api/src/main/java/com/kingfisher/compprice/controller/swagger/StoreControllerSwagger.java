package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.entity.RollingDays;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.request.RollingDaysRequest;
import com.kingfisher.compprice.dao.request.UpdateStoreRequest;
import com.kingfisher.compprice.dao.response.StoreResponse;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Tag(name = Constants.TAG_STORE)
public interface StoreControllerSwagger {

    @Operation(description = "Create Store", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    MultiDataResponse<Store> createStores(@RequestBody final List<Store> stores) throws JSONException;

    @Operation(description = "Configure PVMax Rolling Days", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    ResponseEntity<String> configurePVMaxRollingDays(@RequestBody final RollingDaysRequest rollingDaysRequest);

    @Operation(description = "Get PVMax Rolling Days info", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    SingleDataResponse<RollingDays> getPVMaxRollingDaysInfo();

    @Operation(description = "Get list of Stores by store Code")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    SingleDataResponse<Store> getStoreByStoreCode(@Parameter(name = "code", required = true) @NonNull @PathVariable String code);

    @Operation(description = "Get list of all Stores")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    MultiDataResponse<Store> getAllStores();

    @Operation(description = "Update Store by store Id", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    ResponseEntity<String> bulkUpdateStores(final @RequestBody Set<UpdateStoreRequest> storeRequests);

    @Operation(description = "Get list of responseCode and Name for All stores", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    MultiDataResponse<StoreResponse> getStoresList();

    @Operation(description = "Update Store By StoreCode", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    SingleDataResponse<Store> updateStore(
            @RequestBody final UpdateStoreRequest storeReq,
            @Parameter(name = ID, required = true) @NonNull @PathVariable String id);

    @Operation(description = "Delete stores by StoreIds")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    ResponseEntity<String> deleteStoresByIds(@RequestBody final List<String> ids);

    @Operation(description = "Delete all Stores")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
    ResponseEntity<String> deleteAllStore();

}