package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kingfisher.compprice.dao.PostgreSQLEnumType;
import com.kingfisher.compprice.enums.ProductType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.dialect.PostgreSQLEnumJdbcType;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "lsp_product_price")
@Convert(attributeName = "pgsql_enum", converter = PostgreSQLEnumType.class)
public class PriceUpdate implements Serializable {

    private static final long serialVersionUID = -5917593043985400829L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User pUser;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @Column(name = "last_updated")
    private LocalDateTime modTime;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(name = "final_price")
    private double price;

    @Column(name = "cost_price")
    private double cPrice;

    @Column(name = "tenant")
    private String tenant;

    @Column(name = "start_date", nullable = false)
    private LocalDateTime startDate;

    @Column(name = "end_date", nullable = false)
    private LocalDateTime endDate;

    @Column(name = "index", nullable = false)
    private double index;

    @Column(name = "verification_req", nullable = false)
    private boolean verificationReq;

    private String status;

    @Column(name = "prd_type")
    @Enumerated(EnumType.STRING)
    @JdbcType(PostgreSQLEnumJdbcType.class)
    private ProductType prdType;

    @Column(name = "temp_ref", nullable = false)
    private String ref;

    @Column(name = "extracted_date")
    private LocalDateTime extractedDate;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "cl_price_update_map_v2", joinColumns = {@JoinColumn(name = "pu_id")}, inverseJoinColumns = {@JoinColumn(name = "cl_id")})
    private Set<StoreCollection> storeCollection = new HashSet<>();

    @Column(name = "stopped_price")
    private String stoppedPrice;

    public PriceUpdate(PriceUpdate priceUpdate) {
        this.id = priceUpdate.getId();
        this.pUser = priceUpdate.getPUser();
        this.store = priceUpdate.getStore();
        this.modTime = priceUpdate.getModTime();
        this.product = priceUpdate.getProduct();
        this.price = priceUpdate.getPrice();
        this.cPrice = priceUpdate.getCPrice();
        this.tenant = priceUpdate.getTenant();
        this.startDate = priceUpdate.getStartDate();
        this.endDate = priceUpdate.getEndDate();
        this.index = priceUpdate.getIndex();
        this.verificationReq = priceUpdate.isVerificationReq();
        this.status = priceUpdate.getStatus();
        this.prdType = priceUpdate.getPrdType();
        this.ref = priceUpdate.getRef();
        this.extractedDate = priceUpdate.getExtractedDate();
        this.stoppedPrice = priceUpdate.getStoppedPrice();
        this.storeCollection = priceUpdate.getStoreCollection();
    }

    public PriceUpdate() {
    }

}