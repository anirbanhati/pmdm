package com.kingfisher.compprice.dao.response.user;


import com.kingfisher.jsonapi.Resource;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserRoleResponse implements Resource {
    private static final long serialVersionUID = -5100503108168757207L;
    private long id;
    private String userId;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }
}
