package com.kingfisher.compprice.dao.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoundingRequest {

    private String ean;
    private String rType;
    private double price;
    private String prdType;

}