package com.kingfisher.compprice.dao.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "lsp_cluster_price")
public class ClusterPrice implements Serializable {


    private static final long serialVersionUID = 6331517379489459265L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cluster_id")
    private String clusterID;

    @Column(name = "locale")
    private String locale;

    @Column(name = "cluster_price")
    private Double price;

    @Column(name = "tenant")
    private String tenant;

    @Column(name = "currency")
    private String currency;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "last_updated_date")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "ean")
    private String ean;

}