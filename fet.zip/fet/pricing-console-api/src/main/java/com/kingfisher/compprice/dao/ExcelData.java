package com.kingfisher.compprice.dao;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExcelData {

	private String productCode;
	private String productDesc;
	private String storeCode;
	private String clName;
	private String compName;
	private LocalDateTime creationTime;
	private String cEan;
	private String cArticleCode;
	private String notes;
	private String hasPromo;
	private String pkg;
	private String cPkg;
	private String stdPrice;
	private String unit;
	private String cPrice;
	private String dPrice;
	private String dStartDate;

}