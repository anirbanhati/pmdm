package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import static com.kingfisher.compprice.enums.ProductType.PVLocal;
import static com.kingfisher.compprice.enums.ProductType.PVMax;
import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Component
@Slf4j
public class StagePriceValidationBrico extends StagePriceValidatorRule {

    @Override
    public void isValidPriceToStage(final Product product, final Double price, final double minimalPrice,
                                    final double maxPrice) {
        isValidStagePrice(price, minimalPrice, maxPrice, product);
    }

    @Override
    public void isValidDatesToStage(final String ean, final LocalDateTime startDate, final LocalDateTime endDate,
                                    final String prdType, final boolean isStoppedPrice) {

        if (PVLocal.toString().equals(prdType)) {
            isValidStartDate(ean, startDate, isStoppedPrice);
        } else {
            isValidStartDate(ean, startDate, isStoppedPrice);
            isValidEndDate(ean, startDate, endDate, prdType, isStoppedPrice);
        }
    }

    private static void isValidEndDate(final String ean, final LocalDateTime startDate, final LocalDateTime endDate,
                                       final String prdType, boolean isStoppedPrice) {
        String endDateTime = endDate != null ? endDate.toString() : EMPTY_STR;
        String startDateTime = startDate != null ? startDate.toString() : EMPTY_STR;
        log.info("Entered isValidEndDate() with EAN:{}, startDate:{}, endDate:{}, prdType:{}, isStoppedPrice:{}", ean, startDateTime, endDateTime,
                prdType, isStoppedPrice);

        if (null != startDate && null != endDate) {
            boolean isValidEndDate = true;
            if (isStoppedPrice) {
                isValidEndDate = DateUtils.isEqual(endDate, LocalDateTime.now());
            } else if (PVMax.toString().equals(prdType)) {
                isValidEndDate = DateUtils.isBefore(endDate, startDate.plusDays(45));
            }
            if (!isValidEndDate) {
                throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP,
                        STAGE_PRICE_REQ_INV_SD_HTTP_STATUS, STAGE_PRICE_REQ_INV_SD_DETAILS,
                        STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER, ean + PIPE_SEPARATOR + endDate,
                        STAGE_PRICE_REQ_INV_SD_TITLE);
            }
        } else {
            throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP,
                    STAGE_PRICE_REQ_INV_SD_HTTP_STATUS, STAGE_PRICE_REQ_INV_SD_DETAILS,
                    STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER, ean + PIPE_SEPARATOR + endDate,
                    STAGE_PRICE_REQ_INV_SD_TITLE);
        }
    }

    private static void isValidStartDate(final String ean, final LocalDateTime startDate, boolean isStoppedPrice) {
        if (!isStoppedPrice) {
            String startTime = startDate != null ? startDate.toString() : EMPTY_STR;
            log.debug("Entered isValidStartDate() with EAN:{}, startDate:{}", ean, startTime);

            if (null != startDate) {
                final LocalDateTime today = LocalDate.now().atTime(0, 0);
                final boolean isValidStartDate = !DateUtils.isBefore(startDate, today);
                if (!isValidStartDate) {
                    throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                            STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                            ean + PIPE_SEPARATOR + startDate, STAGE_PRICE_REQ_INV_SD_TITLE);
                }
            } else {
                throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                        STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                        ean + PIPE_SEPARATOR + startDate, STAGE_PRICE_REQ_INV_SD_TITLE);
            }
        }
    }

    private static void isValidStagePrice(final Double price, final double minimalPrice, final double maxPrice, Product product) {
        if (isInValidMinPrice(price, minimalPrice)) {
            throw new DetailsNotFoundException(STAGE_PRICE_REQ_APP_EXP, STAGE_PRICE_REQ_HTTP_STATUS,
                    STAGE_PRICE_REQ_DETAILS, STAGE_PRICE_REQ_ID, STAGE_PRICE_REQ_POINTER,
                    product.getEan() + PIPE_SEPARATOR + DecimalUtils.roundOf(minimalPrice, DecimalUtils.ROUND_OF_3), STAGE_PRICE_REQ_TITLE);
        }
        if (isInValidMaxPrice(price, maxPrice)) {
            throw new DetailsNotFoundException(STAGE_MAX_PRICE_REQ_APP_EXP, STAGE_MAX_PRICE_REQ_HTTP_STATUS,
                    STAGE_MAX_PRICE_REQ_DETAILS, STAGE_MAX_PRICE_REQ_ID, STAGE_MAX_PRICE_REQ_POINTER,
                    product.getEan() + PIPE_SEPARATOR + DecimalUtils.roundOf(maxPrice, DecimalUtils.ROUND_OF_3), STAGE_MAX_PRICE_REQ_TITLE);
        }
    }

    private static boolean isInValidMinPrice(final Double price, final double minPrice) {
        return null != price && price < minPrice;
    }

    private static boolean isInValidMaxPrice(final Double price, final double maxPrice) {
        return null != price && price > maxPrice;
    }

    @Override
    public boolean isValidStartDateToStageImport(final LocalDateTime startDate, final boolean isStopPrice) {
        return validStartDate(startDate, isStopPrice);
    }

    @Override
    public boolean isValidEndDateToStageImport(final LocalDateTime endDate, final LocalDateTime startDate,
                                               final String prdType, final boolean isStopPrice) {
        return validEndDate(startDate, endDate, prdType, isStopPrice);
    }

    @Override
    public void validatePriceToStageForImport(final Set<ExcelError> excelErrors, final Product product, final Double price,
                                              final double minimalPrice, final double maxPrice) {
        if (price > maxPrice) {
            ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_STATUS,
                    BULK_UPLOAD_PRODUCT_INCORRECT_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_ID,
                    DecimalUtils.roundOf(maxPrice, DecimalUtils.ROUND_OF_3));
        }
        if (price < minimalPrice) {
            ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_STATUS,
                    BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE, BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_ID,
                    DecimalUtils.roundOf(minimalPrice, DecimalUtils.ROUND_OF_3));
        }
    }

    @Override
    public void validateEndDateToStageImport(final Set<ExcelError> excelErrors, final LocalDateTime endDate,
                                             final LocalDateTime startDate, final String prdType, final boolean isStopPrice) {
        if (!isValidEndDateToStageImport(endDate, startDate, prdType, false)) {
            if (ProductType.OutOfRange.toString().equals(prdType)) {
                ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_END_DATE, BULK_UPLOAD_INCORRECT_END_DATE_STATUS,
                        BULK_UPLOAD_INCORRECT_END_DATE, BULK_UPLOAD_INCORRECT_END_DATE_ID, endDate.toString());
            } else {
                ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_END_DATE, BULK_UPLOAD_BDFR_INCORRECT_END_DATE_STATUS,
                        BULK_UPLOAD_BDFR_INCORRECT_END_DATE, BULK_UPLOAD_BDFR_INCORRECT_END_DATE_ID, endDate.toString());
            }
        }
    }

    private static boolean validStartDate(final LocalDateTime startDate, final boolean isStopPrice) {
        final LocalDateTime today = LocalDate.now().atTime(0, 0);
        return isStopPrice ? Boolean.TRUE : !DateUtils.isBefore(startDate, today);
    }

    private static boolean validEndDate(final LocalDateTime startDate, final LocalDateTime endDate,
                                        final String prdType, final boolean isStopPrice) {
        boolean isValidEndDate;
        if (isStopPrice) {
            isValidEndDate = DateUtils.isEqual(endDate, LocalDateTime.now().plusDays(1));
        } else if (ProductType.OutOfRange.toString().equals(prdType)) {
            isValidEndDate = DateUtils.isAfter(endDate, startDate) || DateUtils.isEqual(endDate, startDate);
        } else {
            if (ProductType.PVLocal.toString().equals(prdType)) {
                isValidEndDate = (DateUtils.isAfter(endDate, startDate) || DateUtils.isEqual(endDate, startDate));
            } else {
                isValidEndDate = (DateUtils.isAfter(endDate, startDate) || DateUtils.isEqual(endDate, startDate))
                        && DateUtils.isBefore(endDate, startDate.plusDays(60));
            }
        }
        return isValidEndDate;
    }

}