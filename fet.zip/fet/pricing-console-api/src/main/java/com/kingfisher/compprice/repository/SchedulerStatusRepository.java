package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.SchedulerStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SchedulerStatusRepository extends JpaRepository<SchedulerStatus, Long> {

      List<SchedulerStatus> findAllByUpdatedAtBefore(final LocalDateTime updatedAt);

}
