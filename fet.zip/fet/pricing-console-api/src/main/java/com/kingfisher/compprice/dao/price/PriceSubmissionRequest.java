package com.kingfisher.compprice.dao.price;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PriceSubmissionRequest implements Serializable {

    private static final long serialVersionUID = -7145175529247758688L;

    private List<Long> scIds;
    private String userId;
    private Set<PriceSubmissionDetails> prdPrice;
    private String storeCode;

}