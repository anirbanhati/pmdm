package com.kingfisher.compprice.dao.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermissionRequest {

	private String functionDescription;
	private String featuresPermissionsName;

}