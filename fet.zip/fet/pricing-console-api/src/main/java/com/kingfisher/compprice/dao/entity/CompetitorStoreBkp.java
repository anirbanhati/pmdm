package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.LONG_NAME;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
@Table(name = "competitor_store")
@Getter
@Setter
public class CompetitorStoreBkp implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = -3724138509497301150L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cs_id")
    @JsonIgnore
    private Long id;

    @Column(name = "shortname")
    private String name;

    @Column(name = LONG_NAME)
    @JsonProperty("longname")
    private String longName;

    @Column(name = "code")
    private String code;

    @Column(name = "concurrent_ratio")
    @JsonIgnore
    private String ratio;

    @Column(name = "reg_date")
    @JsonIgnore
    private LocalDateTime registrationDate;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Column(name = "cs_code")
    private String csCode;

}