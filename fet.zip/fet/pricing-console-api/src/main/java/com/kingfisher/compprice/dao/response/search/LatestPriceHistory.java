package com.kingfisher.compprice.dao.response.search;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LatestPriceHistory implements Serializable {

	private static final long serialVersionUID = 5254413399927790795L;
	private String lastUpdateBy;
	private LocalDateTime lastUpdateTime;
	private String price;
	private String status;
	private long id;
}
