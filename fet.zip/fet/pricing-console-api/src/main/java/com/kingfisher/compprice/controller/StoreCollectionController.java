package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.StoreCollectionControllerSwagger;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.price.PriceUpdateRequest;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.dao.request.StoreCollectionPricesRequest;
import com.kingfisher.compprice.dao.request.StoreCollectionUpdatesInfo;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.search.CompItemCriteria;
import com.kingfisher.compprice.dao.search.SearchPaging;
import com.kingfisher.compprice.dao.search.StoreCollectionItemSearchCriteria;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.service.StoreCollectionService;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.math3.exception.NoDataException;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(COLL_LIST_BASE_URL)
public class StoreCollectionController implements StoreCollectionControllerSwagger {

    private final StoreCollectionService storeCollectionService;
    private final CurrentUser user;

    Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

    @PostMapping(POST_STORE_COLL_SEARCH)
    @Override
    public SingleDataResponse<StoreCollectionSearchResponse> searchStoreCollectionItems(@RequestBody final StoreCollectionItemSearchCriteria criteria) {
        log.info("StoreCollection: searchStoreCollectionItems --> {}", gson.toJson(criteria));
        SearchPaging searchPaging = null != criteria.getPaging() ? criteria.getPaging() : new SearchPaging();
        return JsonApiResponse.singleDataResponse(storeCollectionService.findStoreCollectionBySearchCriteria(searchPaging, criteria));
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'CREATE_COLLECTION')")
    @PostMapping(POST_CREATE_STORE_COLLECTION)
    @Override
    public ResponseEntity<String> createStoreCollection(@RequestBody final CompItemInfo collListInfo) {
        log.info("StoreCollection: createStoreCollection --> {}", gson.toJson(collListInfo));
        return new ResponseEntity<>(storeCollectionService.saveStoreCollectionItems(collListInfo, user.getUser()), HttpStatus.CREATED);
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'CREATE_COLLECTION')")
    @PostMapping(Constants.POST_CREATE_BULK_STORE_COLLECTION)
    @Override
    public SingleDataResponse<EanListResponse> createBulkStoreCollection(@RequestParam(REQUEST_PARAM_FILE) final MultipartFile file,
                                                                         @RequestHeader(COMP_STORE_LONG_NAMES) String compStoreLongNames,
                                                                         @RequestHeader(STORES) String stores,
                                                                         @RequestHeader(NAME) String name,
                                                                         @RequestHeader(EXP_DATE) String expDate) throws IOException {
        log.info("StoreCollection: createBulkStoreCollection --> CompStoreLongNames={}, Stores={}, Name={}, Expiry date={}, User={}", compStoreLongNames, stores, name, expDate, user.getUser().getId());
        return JsonApiResponse.singleDataResponse(this.storeCollectionService.importBulkUploadEanList
                (file.getInputStream(), storeCollectionService.prepareStoreCollectionInfo(compStoreLongNames, stores, name, expDate, user.getUser()),
                        user.getUser()));
    }

    @GetMapping(STORE_COLLECTION_BY_USER_STATUS)
    @Override
    public MultiDataResponse<StoreCollectionItemResponse> getCollectionsByStatusAndUserForTC72(@PathVariable(STATUS) final CollectionStatus status,
                                                                                               @PathVariable(USER) final String user) {
        log.info("StoreCollection: getCollectionsByStatusAndUserForTC72(request) --> {}, {}", status, user);
        List<StoreCollectionItemResponse> response = storeCollectionService.findScItemsByStatusAndUser(status, user);
        log.info("StoreCollection: getCollectionsByStatusAndUserForTC72(response) --> {}", gson.toJson(response));
        return JsonApiResponse.multiDataResponse(response);
    }

    @GetMapping(POST_STORE_COLL_SEARCH)
    @Override
    public SingleDataResponse<StoreCollectionSearchResponse> getAllStoreCollection(final SearchPaging page,
                                                                                   final CompItemCriteria criteria) {
        log.info("StoreCollection: getAllStoreCollection --> {}, {}", gson.toJson(page), gson.toJson(criteria));
        return JsonApiResponse.singleDataResponse(storeCollectionService.findStoreCollectionBySearchCriteria(page, criteria));
    }

    @GetMapping(COLL_LIST_BY_ID)
    @Override
    public SingleDataResponse<StoreCollectionItemResponse> getStoreCollectionByID(@PathVariable(ID) final Long id) {
        log.info("StoreCollection: getStoreCollectionByID --> {}", id);
        return JsonApiResponse.singleDataResponse(storeCollectionService.findStoreCollectionById(id));
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'VALIDATE_COLLECTION')")
    @PostMapping(URI_PRICES)
    @Override
    public SingleDataResponse<StoreCollectionPricesResponse> prepareStoreCollectionPrices(
            @RequestBody final StoreCollectionPricesRequest collectionListModel) {
        log.info("StoreCollection: prepareStoreCollectionPrices --> {}", gson.toJson(collectionListModel));
        return JsonApiResponse.singleDataResponse(storeCollectionService.getStoreCollectionPriceDetails(collectionListModel, user.getUser()));
    }

    @GetMapping(COLL_LIST_STATUS)
    @Override
    public SingleDataResponse<Status> getCollectionListStatus() {
        log.info("StoreCollection: getCollectionListStatus");
        return JsonApiResponse.singleDataResponse(storeCollectionService.getStoreCollectionStatus());
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'CREATE_COLLECTION,ASSIGN_COLLECTION')")
    @PatchMapping(COLL_LIST_BY_ID)
    @Override
    public ResponseEntity<String> updateStoreCollectionList(@RequestBody final StoreCollectionUpdatesInfo clUpdateInfo,
                                                            @PathVariable(ID) final Long id) {
        log.info("StoreCollection: updateStoreCollectionList --> {}, {}", id, gson.toJson(clUpdateInfo));
       storeCollectionService.updateStoreCollectionById(clUpdateInfo, id, false,user.getUser(), true);
       return new ResponseEntity<>("Updated the collection list", HttpStatus.OK);
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'CREATE_COLLECTION')")
    @PatchMapping(COLL_LIST_UPDATE_BULK)
    @Override
    public ResponseEntity<String> collectPricesFromTC72(@RequestBody final Set<StoreCollectionUpdatesInfo> scUpdateInfoItems) {
        log.info("StoreCollection: collectPricesFromTC72 --> {}", gson.toJson(scUpdateInfoItems));
        storeCollectionService.updateStoreCollections(scUpdateInfoItems, user.getUser(), false);
        return new ResponseEntity<>("All Items has been updated", HttpStatus.OK);
    }

    @GetMapping(COLLECTION_LIST_DOWNLOAD)
    @Override
    public ResponseEntity<InputStreamResource> downloadStoreCollectionById(@RequestParam(ID) final String id) throws NoDataException, IOException {
        log.info("StoreCollection: downloadStoreCollectionById --> {}", id);
        final InputStreamResource file = new InputStreamResource(
                storeCollectionService.prepareFileForStoreCollections(id, user.getUser()));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + storeCollectionService.getStoreCollectionFileName(id))
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
    }

    /**
     * Search Foreign Products with filters
     *
     * @param filters as request body
     * @return search response
     */
    @PostMapping(path = SEARCH_FOREIGN_PRODUCTS)
    @Override
    public SingleDataResponse<ForeignProductSearchResponse> searchForeignProducts(@RequestBody final StoreCollectionItemSearchCriteria filters) {
        log.info("StoreCollection: searchForeignProducts --> {}", gson.toJson(filters));
        return JsonApiResponse.singleDataResponse(storeCollectionService.searchForeignProducts(filters));
    }

    @PostMapping(COLL_LIST_LOWEST_PRICES)
    @Override
    public SingleDataResponse<StoreCollectionPricesResponse> compareFinalPrice(@RequestBody final PriceUpdateRequest pUpdateInfo) {
        log.info("StoreCollection: compareFinalPrice --> {}", gson.toJson(pUpdateInfo));
        return JsonApiResponse.singleDataResponse(storeCollectionService.getChainedProdsWithLowestPrice(pUpdateInfo, user.getUser()));
    }

}