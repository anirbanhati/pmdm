package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.entity.Product;

import java.time.LocalDateTime;
import java.util.Set;

public abstract class StagePriceValidatorRule {

    public abstract void isValidPriceToStage(final Product product, final Double price, final double minimalPrice,
                                             final double standardPrice);

    public abstract void isValidDatesToStage(final String ean, final LocalDateTime startDate,
                                             final LocalDateTime endDate,
                                             final String prdType, boolean isPriceStop);

    public abstract boolean isValidStartDateToStageImport(LocalDateTime startDate, boolean isStopPrice);

    public abstract boolean isValidEndDateToStageImport(LocalDateTime endDate, LocalDateTime startDate, String prdType,
                                                        boolean isStopPrice);

    public abstract void validatePriceToStageForImport(final Set<ExcelError> excelErrors, final Product product, final Double price,
                                                       final double minimalPrice, final double standardPrice);

    public abstract void validateEndDateToStageImport(final Set<ExcelError> excelErrors, final LocalDateTime endDate, final LocalDateTime startDate,
                                                      final String prdType, final boolean isStopPrice);

}