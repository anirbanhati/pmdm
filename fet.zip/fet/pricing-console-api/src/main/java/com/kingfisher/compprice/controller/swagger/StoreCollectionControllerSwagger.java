package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.price.PriceUpdateRequest;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.dao.request.StoreCollectionPricesRequest;
import com.kingfisher.compprice.dao.request.StoreCollectionUpdatesInfo;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.search.CompItemCriteria;
import com.kingfisher.compprice.dao.search.SearchPaging;
import com.kingfisher.compprice.dao.search.StoreCollectionItemSearchCriteria;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Tag(name = TAG_STORE_COLLECTION)
public interface StoreCollectionControllerSwagger {

    @Operation(description = "Search Store Collection Based on Criteria")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<StoreCollectionSearchResponse> searchStoreCollectionItems(@RequestBody final StoreCollectionItemSearchCriteria criteria);

    @Operation(description = "Create Store Collection Based on the Item Information", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    ResponseEntity<String> createStoreCollection(@RequestBody final CompItemInfo collListInfo);

    @Operation(description = "Create Bulk Competitor List")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<EanListResponse> createBulkStoreCollection(
            @RequestParam(REQUEST_PARAM_FILE) final MultipartFile file,
            @RequestHeader("compStoreLongNames") String compStoreLongNames,
            @RequestHeader("stores") String stores, @RequestHeader("name") String name,
            @RequestHeader("expDate") String expDate) throws IOException;

    @Operation(description = "Fetch Store Collection by UserId and Collection Status")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    MultiDataResponse<StoreCollectionItemResponse> getCollectionsByStatusAndUserForTC72(@PathVariable(STATUS) final CollectionStatus status,
                                                                                        @PathVariable(USER) final String user);

    @Operation(description = "Fetch Store Collection Based on Item Search Criteria")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<StoreCollectionSearchResponse> getAllStoreCollection(final SearchPaging page,
                                                                            final CompItemCriteria criteria);

    @Operation(description = "Fetch Store Collection Based on ID")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<StoreCollectionItemResponse> getStoreCollectionByID(@PathVariable(ID) final Long id);

    @Operation(description = "Fetch Store Collection Based on Collection Price Request", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<StoreCollectionPricesResponse> prepareStoreCollectionPrices(@RequestBody final StoreCollectionPricesRequest collectionListModel);

    @Operation(description = "Fetch Store Collection Status")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<Status> getCollectionListStatus();

    @Operation(description = "Update Single Collections Lists Based on Item Info", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    ResponseEntity<String> updateStoreCollectionList(@RequestBody final StoreCollectionUpdatesInfo clUpdateInfo, @PathVariable(ID) final Long id);

    @Operation(description = "collect Prices From TC72", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    ResponseEntity<String> collectPricesFromTC72(@RequestBody final Set<StoreCollectionUpdatesInfo> clUpdateInfoItems);

    @Operation(description = "Download Store Collection by Id")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    ResponseEntity<InputStreamResource> downloadStoreCollectionById(@RequestParam final String id) throws IOException;

    @Operation(description = "Fetch Foreign Product Based on Item Search Criteria", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<ForeignProductSearchResponse> searchForeignProducts(@RequestBody final StoreCollectionItemSearchCriteria filters);

    @Operation(description = "Compare and Fetch Lowest Final Price", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description = RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description = RESPONSE_MESSAGE_409),
            @ApiResponse(responseCode = "500", description = RESPONSE_MESSAGE_500)})
    SingleDataResponse<StoreCollectionPricesResponse> compareFinalPrice(@RequestBody final PriceUpdateRequest pUpdateInfo);

}