package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.ProductTaxClassificationInfo;
import com.kingfisher.compprice.repository.ProductTaxClassificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.PRODUCT_TAX_CLASSIFICATION_CACHE;

@Service
@RequiredArgsConstructor
@Slf4j
public class TaxClassificationService {

    private final ProductTaxClassificationRepository productTaxRepo;
    private final LogService logService;


    @Cacheable(value = PRODUCT_TAX_CLASSIFICATION_CACHE, key = "{#taxJurisdictionIds, #taxClassificationCode}")
    public Optional<ProductTaxClassificationInfo> findByTaxIdAndTaxClassificationCode(final List<String> taxJurisdictionIds,
                                                                                      final String taxClassificationCode) {
        StopWatch stopWatch = logService.logStopWatchStart("findByTaxIdAndTaxClassificationCode");
        var taxInfo = productTaxRepo.findByTaxJurisdictionIdInAndTaxClassificationCode(taxJurisdictionIds, taxClassificationCode);
        logService.logStopWatchStop(stopWatch);
        return taxInfo;
    }

}