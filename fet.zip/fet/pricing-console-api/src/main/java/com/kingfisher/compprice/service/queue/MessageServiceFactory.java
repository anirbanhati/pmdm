package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.configuration.queue.MessageSource;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MessageServiceFactory {

    private final ProductMessageService productMessageService;
    private final PriceMessageService priceMessageService;
    private final VendorMessageService vendorMessageService;
    private final FinancialProvisionMessageService financialProvisionMessageService;
    private final SalesHistoryMessageService salesHistoryMessageService;
    private final ProductTaxClassificationService productTaxClassificationService;
    private final CostPriceMessageService costPriceMessageService;
    private final LocalStorePricingUserService userService;
    private final StoreAssociationMessageService storeAssociationMessageService;
    private final ProductChainingMessageService productChainingMessageService;
    private final ProductAssociationService productAssociationService;
    private final ProductListingMessageService productListingMessageService;
    private final ClusterPriceMessageService clusterPriceMessageService;


    public MessageService getMessageService(String group) {
        if (group.equalsIgnoreCase(MessageSource.PRODUCT_FEED.getSource())) {
            return productMessageService;
        } else if (group.equalsIgnoreCase(MessageSource.PRICE_FEED.getSource())) {
            return priceMessageService;
        } else if (group.equalsIgnoreCase(MessageSource.VENDOR_FEED.getSource())) {
            return vendorMessageService;
        } else if (group.equalsIgnoreCase(MessageSource.FINANCIAL_PROVISION_FEED.getSource())) {
            return financialProvisionMessageService;
        } else if (group.equalsIgnoreCase(MessageSource.SALES_HISTORY_FEED.getSource())) {
            return salesHistoryMessageService;
        } else if (group.equalsIgnoreCase(MessageSource.TAX_CLASSIFICATION_FEED.getSource())) {
            return productTaxClassificationService;
        } else if (group.equalsIgnoreCase(MessageSource.COST_PRICE_SERVICE.getSource())) {
            return costPriceMessageService;
        } else if (MessageSource.USER_FEED.getSource().equalsIgnoreCase(group)) {
            return userService;
        } else if (MessageSource.STORE_ASSOCIATION_FEED.getSource().equalsIgnoreCase(group)) {
            return storeAssociationMessageService;
        } else if (MessageSource.PRODUCT_ASSOCIATION_FEED.getSource().equals(group)) {
            return productAssociationService;
        } else if (MessageSource.PRODUCT_CHAINING_FEED.getSource().equals(group)) {
            return productChainingMessageService;
        } else if (MessageSource.PRODUCT_LISTING_FEED.getSource().equals(group)) {
            return productListingMessageService;
        } else if (MessageSource.CLUSTER_PRICE_FEED.getSource().equals(group)) {
            return clusterPriceMessageService;
        } else
            return null;
    }

}