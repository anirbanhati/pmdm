package com.kingfisher.compprice.dao.response.search;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StorePriceResponse implements Serializable {

	private static final long serialVersionUID = 4008734958229527005L;
	private String price;
	private String refPrice;
	private LocalDateTime sDate;
	private LocalDateTime eDate;
}
