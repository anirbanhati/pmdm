package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.FeatureEntity;
import com.kingfisher.compprice.dao.entity.TenantFeatureToggleConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TenantFeatureToggleConfigRepository extends JpaRepository<TenantFeatureToggleConfigEntity, Long> {

  Optional<TenantFeatureToggleConfigEntity> findByFeatureAndTenant(FeatureEntity feature, String tenant);

}