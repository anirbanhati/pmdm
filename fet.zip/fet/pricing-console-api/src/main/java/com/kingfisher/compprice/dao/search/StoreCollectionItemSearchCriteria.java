package com.kingfisher.compprice.dao.search;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StoreCollectionItemSearchCriteria extends CompItemCriteria {

	private SearchPaging paging;

}