package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "prices")
@XmlAccessorType(XmlAccessType.FIELD)
public class SalesHistoryPrice {

    @XmlElement(name = "storeID")
    private String storeID;

    @XmlElement(name = "salesorg")
    private String salesOrg;

    @XmlElement(name = "ean")
    private String ean;

    @XmlElement(name = "articleNumber")
    private String articleNumber;

    @XmlElement(name = "salesPriceType")
    private String salesPriceType;

    @XmlElement(name = "salesQuantity")
    private double salesQuantity;

    @XmlElement(name = "averagePriceFromSales")
    private double averagePriceFromSales;

    @XmlElement(name = "salesDate")
    private String salesDate;

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getSalesPriceType() {
        return salesPriceType;
    }

    public void setSalesPriceType(String salesPriceType) {
        this.salesPriceType = salesPriceType;
    }

    public double getSalesQuantity() {
        return salesQuantity;
    }

    public void setSalesQuantity(double salesQuantity) {
        this.salesQuantity = salesQuantity;
    }

    public double getAveragePriceFromSales() {
        return averagePriceFromSales;
    }

    public void setAveragePriceFromSales(double averagePriceFromSales) {
        this.averagePriceFromSales = averagePriceFromSales;
    }

    public String getSalesDate() {
        return salesDate;
    }

    public void setSalesDate(String salesDate) {
        this.salesDate = salesDate;
    }

    public String getSalesOrg() {
        return salesOrg;
    }

    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
}
