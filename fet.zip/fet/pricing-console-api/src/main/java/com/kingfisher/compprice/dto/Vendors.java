package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "VendorList")
@XmlAccessorType(XmlAccessType.FIELD)
public class Vendors {

    @XmlElement(name = "Vendor")
    private List<VendorInfo> vendorInfoList;

    public List<VendorInfo> getVendorInfoList() {
        return vendorInfoList;
    }

    public void setVendorInfoList(List<VendorInfo> vendorInfoList) {
        this.vendorInfoList = vendorInfoList;
    }



}
