package com.kingfisher.compprice.dao.entity;

import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "rolling_days")
public class RollingDays implements Resource, Serializable {

    private static final long serialVersionUID = -1020506893150197105L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "roll_id")
    private Long rollId;

    @Column(name = "ho_user_id")
    private String hoUserId;

    @Column(name = "days")
    private int days;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}