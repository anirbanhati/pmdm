package com.kingfisher.compprice.dao.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class WeeklyStock implements Serializable {

	private static final long serialVersionUID = 8573643655859467739L;
	private String qty;
	private String value;
	private String finProv;
	private double pRate;

}