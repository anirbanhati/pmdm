package com.kingfisher.compprice.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@UtilityClass
public class DecimalUtils {

	public static final String ROUND_OF_2 = "0.00";
	public static final String ROUND_OF_3 = "0.000";
	public static final String ROUND_OF_0 = "0";
	private static final DecimalFormat df = new DecimalFormat("0.00");
	
	
	public static String roundOf(final double input, final String pattern) {
		final DecimalFormat df = new DecimalFormat(pattern);
		return df.format(input);
	}

	public static double roundOfDouble(final double input, final String pattern) {
		final DecimalFormat df = new DecimalFormat(pattern);
		return Double.parseDouble(df.format(input));
	}

	public static double convertToDouble(final String inputObj) {
		double parseValue = 0.00;
		if(StringUtils.isNotBlank(inputObj)) {
			final String inputStr = inputObj.replace(" ", EMPTY_STR).replace(COMMA_SEPARATOR, DOT_SEPARATOR);
			parseValue = Double.parseDouble(inputStr);
		}
		return parseValue;
	}

	public static BigDecimal parse(final String amount, final Locale locale) {
		final NumberFormat format = NumberFormat.getNumberInstance(locale);
		if (format instanceof DecimalFormat decimalFormat) {
			decimalFormat.setParseBigDecimal(true);
		}
		try {
			return (BigDecimal) format.parse(amount.replaceAll("[^\\d.,]", EMPTY_STR));
		} catch (final ParseException e) {
			log.error("ParseException -->", e);
		}
		return null;
	}

	public static double convertNegativeZero(double val) {
		return Double.compare(-0.0, val) == 0 ? 0 : val;
	}

	public static String getRounded(double price) {
		df.setRoundingMode(RoundingMode.DOWN);
		return df.format(price);
	}

}