package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.dao.search.SearchProduct;
import com.kingfisher.compprice.helper.WarlistParser;
import com.kingfisher.compprice.repository.ProductSearchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class WarListService {

    private final ProductSearchRepository productSearchRepository;
    private final WarlistParser warlistParser;

    @Transactional
    public List<Category> findTreeOptions(final String id) {
        final List<Category> categories = new ArrayList<>(warlistParser.getFilters(id).values());
        categories.sort(Comparator.comparing(Category::getName, String.CASE_INSENSITIVE_ORDER));
        return categories;
    }

    public SearchProduct productSearch(final ProductSearchPaging paging, final ProductSearchCriteria searchCriteria,
                                       final User user) {
        return productSearchRepository.getWarListProducts(paging, searchCriteria, user);
    }

}