package com.kingfisher.compprice.dao.entity;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.io.Serializable;

@Getter
@Setter
@Entity
@NoArgsConstructor(force = true)
@AllArgsConstructor
@Table(name = "map_price")
public class MapPrice implements Serializable {

    private static final long serialVersionUID = -2603463226005963190L;

    @Id
    @Column(name = "ean", nullable = false)
    private String ean;

    @NonNull
    @Column(name = "store_code")
    private String storeCode;

    @Column(name = "cost_price")
    private double costPrice;

}