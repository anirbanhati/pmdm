package com.kingfisher.compprice.dao.entity;


import lombok.*;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.STATUS;
import static com.kingfisher.compprice.util.constants.FeedConstants.*;
import static jakarta.persistence.GenerationType.IDENTITY;

@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = FILE_DETAILS_TABLE_NAME)
public class InboundFileDetails implements Serializable {

    private static final long serialVersionUID = 916614634099719977L;

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;

    @Column(name = FEED_DETAILS_COLUMN_NAME, unique = true)
    private String fileName;

    @Column(name = FEED_NAME, unique = true)
    private String feedName;

    @Column(name = PROCESSED_DATE, unique = true)
    private LocalDateTime processedDate;

    @Column(name = STATUS, unique = true)
    private String status;

}