package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EanListResponse implements Resource {

    private static final long serialVersionUID = -5429419445865538098L;
    private String successMsg;
    private List<ExcelValidation> eanListErrors;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}