package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ProductListings")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductListings {

    @XmlElement(name = "ProductListing")
    private List<ProductListingInfo> productListingInfos;

    public List<ProductListingInfo> getProductListings() {
        return productListingInfos;
    }

    public void setProductListings(List<ProductListingInfo> productListingInfos) {
        this.productListingInfos = productListingInfos;
    }
}
