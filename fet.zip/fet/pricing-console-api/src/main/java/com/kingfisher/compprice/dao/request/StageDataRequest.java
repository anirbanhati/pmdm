package com.kingfisher.compprice.dao.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StageDataRequest  implements Serializable {

	private static final long serialVersionUID = -1244013004775049445L;
	private String ean;
	private String price;
	private String priceType;
	private String sDate;
	private String eDate;
	private String prdType;
	private String cPrice;
	private String rqSell;
	private double costPrice;
	private double storePrice;
	private double stdPrice;
	@JsonProperty("isReview")
	private boolean isReview;
	private String chainId;

}