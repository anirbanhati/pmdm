package com.kingfisher.compprice.util;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.service.ProductListingService;
import com.kingfisher.compprice.service.StorePriceService;
import com.kingfisher.compprice.service.StoreProductService;
import com.kingfisher.compprice.tools.PriceValidation;
import com.nimbusds.oauth2.sdk.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.util.*;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Component
public class ExcelDataValidation {

	public static final String ERROR = "err";

	private final BaseValidationFactory stageValidation;
	private final StoreProductService storeProductService;
	private final StorePriceService storePriceService;
	private final PriceValidation priceValidation;
	private final ProductListingService productListingService;
	private final ChangeRequestConfiguration crConfig;
	private final LogService logService;


	public Product isValidEanCpt(String cValue, List<Product> productList, final Set<ExcelError> excelErrors) {
		Product product = productList.stream().filter(prd -> cValue.equals(prd.getEan())).findFirst().orElse(null);
		if (null == product || null == product.getCategory()) {
			addErrorDetails(cValue, excelErrors);
		}
		return product;
	}

	private static void addErrorDetails(final String cValue, final Set<ExcelError> excelErrors) {
		setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_PRODUCT_NOT_FOUND_STATUS,
				BULK_UPLOAD_PRODUCT_NOT_FOUND_DETAILS, BULK_UPLOAD_PRODUCT_NOT_FOUND_ID, cValue);
	}

	public Product validateDataForStaging(final String columnName, final Object columnValue, final User user, final ExcelValidation excelData,
										  Product product, StoreProduct storeProduct, final MasterData masterData) {
		StopWatch stopWatch = logService.logStopWatchStart("validateDataForStaging");

		final Set<ExcelError> excelErrors = CollectionUtils.isNotEmpty(excelData.getErrors()) ? excelData.getErrors()
				: new HashSet<>();
		StoreProduct sProd;
		if (isValidationRequiredForEan(columnName, columnValue, product)) {
			product = isValidEanCpt(columnValue.toString(), masterData.getProducts(), excelErrors);
			if (null != product) {
				sProd = masterData.getProductStoreProductMap().getOrDefault(product, new StoreProduct());
				setStoreProductDetails(storeProduct, sProd);
				if (null != storeProduct.getId()) {
					excelData.setPrdType(getPrdType(storeProduct));
					excelData.setMaxDecrease(storeProduct.getMaxDecrease());
					excelData.setMaxIncrease(storeProduct.getMaxIncrease());
					validatedAndPrepareErrors(user, excelData, product, storeProduct, masterData, excelErrors);
				} else {
					setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_STATUS,
							BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_DETAILS, BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_ID, product.getEan());
				}
			}
			excelData.setEan(columnValue.toString());
		}
		if (null != columnValue && !ERROR.equals(columnValue) && null != product && null!= storeProduct.getId()) {
			validatePrice(columnName, columnValue, user, excelData, product, masterData, excelErrors);
			validateStartDate(columnName, columnValue, user, excelData, excelErrors);
			validateEndDate(columnName, columnValue, user, excelData, excelErrors);
		}
		excelData.setErrors(excelErrors);
		if (CollectionUtils.isNotEmpty(excelData.getErrors())) {
			excelData.setErrorCount(excelData.getErrors().size());
		}
		logService.logStopWatchStop(stopWatch);
		return product;
	}

	public void isValidPrdStatus(final Product product, Set<ExcelError> excelErrors) {
		if (crConfig.isPrdStatus() && null != product.getProductStatus() && List.of(40.0, 99.0).contains(product.getProductStatus())) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_PRODUCT_STATUS_CODE, BULK_UPLOAD_INVALID_PRODUCT_STATUS_DETAILS,
					BULK_UPLOAD_INVALID_PRODUCT_STATUS_STATUS_ID, product.getEan());
		}
	}

	public void isValidOor(Product product, StoreProduct storeProduct, Set<ExcelError> excelErrors) {
		if (!storeProduct.isEditable()) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_OOR_STATUS_CODE, BULK_UPLOAD_INVALID_OOR,
					BULK_UPLOAD_INVALID_OOR_STATUS_ID, product.getEan());
		}
	}

	public void isValidPrdListing(Product product, Set<ExcelError> excelErrors, User user) {
		boolean isValidPrdListing = productListingService.validProductListing(product, user.getStore());
		if (crConfig.isPrdStatus() && null != product.getProductStatus() && List.of(10.0, 11.0).contains(product.getProductStatus())
				|| !isValidPrdListing) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_CODE, BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_DETAILS,
					BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_ID, product.getEan());
		}
	}

	private void isValidPrdListingBulkStage(final MasterData masterData, final Product product, Set<ExcelError> excelErrors) {
		if ((crConfig.isPrdStatus() && null != product.getProductStatus() && List.of(10.0, 11.0).contains(product.getProductStatus()))
				|| Boolean.TRUE.equals(!masterData.getValidPrdListingMap().getOrDefault(product.getEan(),true))) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_CODE, BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_DETAILS,
					BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_ID, product.getEan());
		}
	}

	private void setStoreProductDetails(StoreProduct storeProduct, StoreProduct sProd) {
		storeProduct.setId(sProd.getId());
		storeProduct.setProduct(sProd.getProduct());
		storeProduct.setModTime(sProd.getModTime());
		storeProduct.setStore(sProd.getStore());
		storeProduct.setPrdType(sProd.getPrdType());
		storeProduct.setMaxDecrease(sProd.getMaxDecrease());
		storeProduct.setMaxIncrease(sProd.getMaxIncrease());
		storeProduct.setFixedPrice(sProd.getFixedPrice());
		storeProduct.setLocalPricing(sProd.getLocalPricing());
		storeProduct.setOorDate(sProd.getOorDate());
		storeProduct.setEditable(sProd.isEditable());
	}

	public static void setErrorDetail(final Set<ExcelError> excelErrors, final String columnName, final String eCode,
									  final String eDesc, final String eId, final String cValue) {
		final ExcelError eError = new ExcelError();
		eError.setCode(eCode);
		eError.setDesc(eDesc);
		eError.setId(eId);
		eError.setCName(columnName);
		eError.setCValue(cValue);
		excelErrors.add(eError);
	}

	public void isLocalPriceStopped(final Product product, final User user, final StoreProduct storeProduct, ExcelValidation excelData,
									 final MasterData masterData, final Set<ExcelError> excelErrors) {
		if (priceValidation.isLocalStorePriceStopped(product, masterData, excelData) ||
				storeProductService.isLocalPricingStopped(storeProduct, user)) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE_STATUS,
					BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE, BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE_ID, product.getEan());
		}
	}

	private void isFixedPrice(final Product product, final StoreProduct storeProduct, final Set<ExcelError> excelErrors) {
		if (StringUtils.isNotBlank(storeProduct.getFixedPrice()) && storeProduct.getFixedPrice().equalsIgnoreCase(PRICE_FLAG_YES)) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS_CODE,
					BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS, BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS_ID,product.getEan());
		}
	}
	public void isValidStoreProduct(Product product, Set<ExcelError> excelErrors, User user) {
		final Set<StoreProduct> sProds = storeProductService.isStoreProductAvailableByProductAndStoreAndTenantAndTypes(product, excelErrors, user);

		if (CollectionUtils.isEmpty(sProds)) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_STATUS,
					BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_DETAILS, BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_ID, product.getEan());
		} else {
			Optional<StoreProduct> sProd = sProds.stream().findFirst();
			if (sProd.isPresent() && PRICE_FLAG_YES.equals(sProd.get().getFixedPrice())) {
				setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_FIXED_PRICE_STATUS,
						BULK_UPLOAD_FIXED_PRICE_DETAILS, BULK_UPLOAD_FIXED_PRICE_ID, product.getEan());
			}
		}
	}

	public void isValidPrice(final User user, final Product product, Set<ExcelError> excelErrors) {
		Double nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
		if (nPrice == 0.0) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_PRICE_NOT_FOUND_STATUS_CODE,
					BULK_UPLOAD_PRICE_NOT_FOUND_DETAILS, BULK_UPLOAD_PRICE_NOT_FOUND_STATUS_ID, product.getEan());
		}
	}

	public void isValidCostPrice(final Product product, final MasterData masterData, Set<ExcelError> excelErrors) {
		StopWatch stopWatch = logService.logStopWatchStart("isValidCostPrice");

		final String costPrice = masterData.getEanCostPriceMap().getOrDefault(product.getEan(), MAP_0_0);
		log.info("Bulk --> ean {} :: costPrice {}", product.getEan(), costPrice);
		if (MAP_0.equals(costPrice) || MAP_0_0.equals(costPrice) || MAP_0_00.equals(costPrice)) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_COST_PRICE_MISSING_STATUS,
					BULK_UPLOAD_COST_PRICE_MISSING_MESSAGE, BULK_UPLOAD_COST_PRICE_MISSING_ID, product.getEan());
		}
		logService.logStopWatchStop(stopWatch);
	}

	private void validatedAndPrepareErrors(final User user, ExcelValidation excelData, final Product product,
										   final StoreProduct storeProduct, final MasterData masterData, Set<ExcelError> excelErrors) {
		StopWatch stopWatch = logService.logStopWatchStart("validatedAndPrepareErrors");

		if (StringUtils.isBlank(excelData.getPrdType())) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS_CODE,
					BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS, BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS_ID, product.getEan());
		} else if (ProductType.PVMax.toString().equalsIgnoreCase(storeProduct.getPrdType().toString())) {
			setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_PRODUCT_TYPE_STATUS,
					BULK_UPLOAD_INVALID_PRODUCT_TYPE, BULK_UPLOAD_INVALID_PRODUCT_TYPE_ID, product.getEan());
		} else {
			isLocalPriceStopped(product, user, storeProduct, excelData, masterData, excelErrors);
			isFixedPrice(product, storeProduct, excelErrors);
			isValidOor(product, storeProduct, excelErrors);
			isValidPrdStatus(product, excelErrors);
			isValidPrdListingBulkStage(masterData, product, excelErrors);
		}
		logService.logStopWatchStop(stopWatch);
	}

	private void validatePrice(String columnName, Object columnValue, final User user, ExcelValidation excelData,
							   final Product product, final MasterData masterData, Set<ExcelError> excelErrors) {
		StopWatch stopWatch = logService.logStopWatchStart("validatePrice");

		if (PRICE_LIST_PRIX.equals(columnName)) {
			final double price = Objects.requireNonNull(DecimalUtils.parse(columnValue.toString(), Locale.FRANCE)).doubleValue();
			var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
			var storePrice = masterData.getEanStorePriceMap().get(product.getEan());
			var clusterPrice = masterData.getEanClusterPriceMap().get(product.getEan());
			var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);
			excelData.setStdPrice(stdPrice);
			excelData.setStorePrice(null!=storePrice ? storePrice.getPrice() : 0.0);
			isValidCostPrice(product, masterData, excelErrors);
			stageValidation.validation(user.getTenant())
					.validatePriceToStageForImport(excelErrors, product, price,
							priceValidation.calculateMinimalPrice(stdPrice, excelData.getMaxDecrease()),
							priceValidation.calculateMaxPrice(stdPrice, excelData.getMaxIncrease(), user.getTenant()));
		}
		logService.logStopWatchStop(stopWatch);
	}

	private void validateStartDate(final String columnName, Object columnValue, final User user, ExcelValidation excelData,
								   Set<ExcelError> excelErrors) {
		StopWatch stopWatch = logService.logStopWatchStart("validateStartDate");

		if (PRICE_LIST_START_DATE.equals(columnName)) {
			excelData.setSDate(columnValue.toString());
			if (!stageValidation.validation(user.getTenant())
					.isValidStartDateToStageImport(DateUtils.getFormattedDateWithFormatter(
							columnValue.toString().replace(DOT_SEPARATOR, HYPHEN_SEPARATOR), DATE_FORMAT_DD_MM_YYYY_HH_MM),
							false)) {
				setErrorDetail(excelErrors, PRICE_LIST_START_DATE, BULK_UPLOAD_DATE_FUTURE_DATE_STATUS,
						PRICE_LIST_START_DATE + BULK_UPLOAD_DATE_FUTURE_DATE, BULK_UPLOAD_DATE_FUTURE_DATE_ID,
						columnValue.toString());
			}
		}
		logService.logStopWatchStop(stopWatch);
	}

	private void validateEndDate(final String columnName, Object columnValue, final User user, ExcelValidation excelData,
								 Set<ExcelError> excelErrors) {
		StopWatch stopWatch = logService.logStopWatchStart("validateEndDate");

		if (PRICE_LIST_END_DATE.equals(columnName)) {
			String endDate = columnValue.toString().trim().substring(0, 10);
			stageValidation.validation(user.getTenant()).validateEndDateToStageImport(excelErrors,
					DateUtils.getFormattedDateWithFormatter(endDate.replace(DOT_SEPARATOR, HYPHEN_SEPARATOR),
							DATE_FORMAT_DD_MM_YYYY_HH_MM),
					DateUtils.getFormattedDateWithFormatter(
							excelData.getSDate().replace(DOT_SEPARATOR, HYPHEN_SEPARATOR), DATE_FORMAT_DD_MM_YYYY_HH_MM),
					excelData.getPrdType(), false);
		}
		logService.logStopWatchStop(stopWatch);
	}

	private boolean isValidationRequiredForEan(final String columnName, final Object columnValue, final Product product) {
		return !ERROR.equals(columnValue) && PRICE_LIST_EAN.equals(columnName) && null == product;
	}

	private String getPrdType(final StoreProduct storeProduct) {
		return null != storeProduct.getPrdType() ? storeProduct.getPrdType().toString() : null;
	}

}