package com.kingfisher.compprice.dao.search;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ProductSearchCriteria extends WarListSearchCriteria{
	
	private ProductSearchPaging paging;
	private String prdType;
	private List<String> types;
	@JsonProperty("sDate")
	private String sDate;
	@JsonProperty("eDate")
	private String eDate;

}