package com.kingfisher.compprice.dao.response.map;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ExternalMapAPIResponse {

	private MapMeta meta;
	private List<ExternalMapResponseDetails> data;

}