package com.kingfisher.compprice.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.COMMA_SEPARATOR;

/**
 * This class is used to set custom rules for the hasPermission() method
 * of annotation @PreAuthorize. This class is responsible for the method and criteria by which
 * a user will be authorized.
 */
@Slf4j
public class CustomPermissionEvaluator implements PermissionEvaluator {

    @Override
    public boolean hasPermission(Authentication auth, Object targetDomainObject, Object permission) {
        showLog("Invoked hasPermission() method with parameter: " + targetDomainObject + ", " + permission);
        if ((auth == null) || (targetDomainObject == null) || !(permission instanceof String)){
            return false;
        }
        String targetType = targetDomainObject.getClass().getSimpleName().toUpperCase();
        return hasPermissions(auth, targetType, permission.toString().toUpperCase());
    }

    @Override
    public boolean hasPermission(Authentication auth, Serializable targetId, String targetType, Object permission) {
    	showLog("Invoked hasPermission() method with parameter: " + targetType + ", " + permission);
        if ((auth == null) || (targetType == null) || !(permission instanceof String)) {
            return false;
        }
        if (hasPermissions(auth, targetType.toUpperCase(), permission.toString().toUpperCase())) {
        	showLog("Role matched, user is authorized");
        	return true;
        }
        else {
        	showLog("Role did not match, user is not Authorized");
        	return false;
        }
    }

    private boolean hasPermissions(Authentication auth, String targetType, String permission) {
    	showLog("Entered hasPermissions() method with parameter: " + targetType + ", " + permission);
        if (permission.contains(COMMA_SEPARATOR)) {
        	List<String> userPermissions = Arrays.asList(permission.split(COMMA_SEPARATOR));
        	return auth.getAuthorities().stream().anyMatch(grantedAuth -> userPermissions.contains(grantedAuth.getAuthority()));
        } else {
        	return auth.getAuthorities().stream().anyMatch(grantedAuth -> grantedAuth.getAuthority().equalsIgnoreCase(permission));
        }
    }
    
    private void showLog(String msg) {
    	if (log.isDebugEnabled()) {
    		log.debug(msg);
    	}
    }

}