package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.request.RollingDaysRequest;
import com.kingfisher.compprice.dao.request.UpdateStoreRequest;
import com.kingfisher.compprice.dao.response.StoreResponse;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants.StoreExceptions;
import com.kingfisher.compprice.repository.CompetitorStoreRepository;
import com.kingfisher.compprice.repository.RollingDaysRepository;
import com.kingfisher.compprice.repository.StoreCompetitorStoreRepository;
import com.kingfisher.compprice.repository.StoreRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.*;
import static com.kingfisher.compprice.util.constants.Constants.PIPE_SEPARATOR;
import static com.kingfisher.compprice.util.constants.Constants.PRICE_FLAG_YES;
import static org.springframework.util.CollectionUtils.isEmpty;

@Service
@Slf4j
@AllArgsConstructor
public class StoreService {

    private StoreRepository storeRepository;
    private StoreCompetitorStoreRepository storeCompetitorStoreRepository;
    private CompetitorStoreRepository compStoreRepo;
    private RollingDaysRepository rollingDaysRepository;
    private CacheService cacheService;
    private LogService logService;


    @Cacheable(value = CS_STORE_CODE_CACHE, key = "{#name, #code}")
    public CompetitorStore getCsByStoreCodeAndLongName(final String name, final String code) {
        final Optional<StoreCompetitorStoreMap> storeCompetitorStore =
            storeCompetitorStoreRepository.findByStore_StoreCodeAndCompetitorStore_LongName(
                code, name);
        return storeCompetitorStore.map(StoreCompetitorStoreMap::getCompetitorStore).orElseThrow(
            () -> new DetailsNotFoundException(StoreExceptions.STORE_NOT_FOUND_APP_EXP,
                StoreExceptions.STORE_NOT_FOUND_HTTP_STATUS, StoreExceptions.STORE_NOT_FOUND_DETAILS,
                StoreExceptions.STORE_NOT_FOUND_ID, StoreExceptions.STORE_CODE_NOT_FOUND_POINTER,
                name + PIPE_SEPARATOR + code, StoreExceptions.STORE_NOT_FOUND_TITLE));
    }

    @Transactional
    public void saveCompStoreDetails(final List<CompetitorStore> stores) {
        if (!isEmpty(stores)) {
            for (final CompetitorStore storeItem : stores) {
                compStoreRepo.save(storeItem);
            }
        }
    }

    public List<CompetitorStore> getCompStoreDetails() {
        return compStoreRepo.findAll()
                   .stream()
                   .sorted(Comparator.comparing(CompetitorStore::getLongName, String.CASE_INSENSITIVE_ORDER))
                   .toList();
    }

    @Cacheable(value = STORE_CACHE, key = "#storeId")
    public Store getStoreById(final Long storeId) {
        return storeRepository.findById(storeId).orElseThrow(
            () -> new DetailsNotFoundException(StoreExceptions.STORE_NOT_FOUND_APP_EXP,
                StoreExceptions.STORE_NOT_FOUND_HTTP_STATUS, StoreExceptions.STORE_NOT_FOUND_DETAILS,
                StoreExceptions.STORE_NOT_FOUND_ID, StoreExceptions.STORE_ID_NOT_FOUND_POINTER,
                storeId.toString(), StoreExceptions.STORE_NOT_FOUND_TITLE));
    }

    @Cacheable(value = STORE_CACHE, key = "#code")
    public Store getStoreByCode(final String code) {
        StopWatch stopWatch = logService.logStopWatchStart("getStoreByCode");
        Store store = storeRepository.findByStoreCode(code).orElseThrow(
            () -> new DetailsNotFoundException(StoreExceptions.STORE_NOT_FOUND_APP_EXP,
                StoreExceptions.STORE_NOT_FOUND_HTTP_STATUS, StoreExceptions.STORE_NOT_FOUND_DETAILS,
                StoreExceptions.STORE_NOT_FOUND_ID, StoreExceptions.STORE_CODE_NOT_FOUND_POINTER,
                code, StoreExceptions.STORE_NOT_FOUND_TITLE));
        logService.logStopWatchStop(stopWatch);
        return store;
    }

    public List<Store> getAllStoreDetails() {
        final List<Store> stores = storeRepository.findAll();
        if (CollectionUtils.isEmpty(stores)) {
            throw new DetailsNotFoundException(StoreExceptions.STORE_NOT_FOUND_APP_EXP,
                StoreExceptions.STORE_NOT_FOUND_HTTP_STATUS, StoreExceptions.STORE_NOT_FOUND_DETAILS,
                StoreExceptions.STORE_NOT_FOUND_ID, StoreExceptions.STORE_CODE_NOT_FOUND_POINTER,
                "ALL", StoreExceptions.STORE_NOT_FOUND_TITLE);
        }
        return stores;
    }

    public List<StoreResponse> getAllStoreList() {
        final List<Store> stores = getAllStoreDetails();
        return stores.stream()
                .sorted(Comparator.comparing(Store::getStoreName))
                .map(store -> {
                    final StoreResponse res = new StoreResponse();
                    res.setCode(store.getStoreCode());
                    res.setName(store.getStoreName());
                    res.setStoreType(store.getStoreType());
                    return res;
                }).toList();
    }

    @Transactional
    public List<Store> saveStoreDetails(final List<Store> stores) {
        if (CollectionUtils.isNotEmpty(stores)) {
            for (final Store storeItem : stores) {
                final Optional<Store> store = storeRepository.findByStoreCode(storeItem.getStoreCode());
                if (store.isEmpty()) {
                    storeRepository.save(storeItem);
                    saveCompStoreMapping(storeItem, null);
                } else {
                    saveCompStoreMapping(storeItem, store.get());
                }
            }
        }
        return stores;
    }

    private void saveCompStoreMapping(final Store reqStore, final Store store) {
        reqStore.getCompetitors().forEach(competitorStore -> {
            compStoreRepo.save(competitorStore);
            StoreCompetitorStoreMap storeCompetitorStoreMap = createStoreCompetitorStoreMap(Objects.requireNonNullElse(store, reqStore),
                competitorStore);
            storeCompetitorStoreRepository.save(storeCompetitorStoreMap);
        });
    }

    public Store updateStore(final UpdateStoreRequest storeReq, final String storeCode) {
        final Store store = getStoreByCode(storeCode);
        store.setStoreCode(storeReq.getStoreCode());
        store.setStoreName(storeReq.getName());
        store.setStoreType(storeReq.getStoreType());
        if (null != storeReq.getCompetitors()) {
            store.setStoreCompetitorStoreMap(populateStoreCompStoreMapping(storeReq.getCompetitors(), storeReq.getStoreCode()));
        }
        return storeRepository.save(store);
    }

    @Transactional
    public List<CompetitorStore> getCompStoreByStoreCode(final String storeCode) {
        var storeCompetitorStoreMaps = storeCompetitorStoreRepository.findByStoreAndActiveFlag(getStoreByCode(storeCode), PRICE_FLAG_YES);
        return storeCompetitorStoreMaps.stream()
                .map(StoreCompetitorStoreMap::getCompetitorStore)
                .sorted(Comparator.comparing(CompetitorStore::getLongName, String.CASE_INSENSITIVE_ORDER)).toList();
    }

    @Transactional
    public CompetitorStore getCompetitorStoreData(final StoreCollection storeCollection) {
        StopWatch stopWatch = logService.logStopWatchStart("getCompetitorStoreData");
        CompetitorStore compStore = compStoreRepo.findByCodeAndLongName(storeCollection.getClCsCode(), storeCollection.getCsName()).orElse(null);
        logService.logStopWatchStop(stopWatch);
        return compStore;
    }

    public void updateStores(final Set<UpdateStoreRequest> storeRequests) {
        storeRequests.forEach(store -> updateStore(store, store.getStoreCode()));
    }

    public void deleteStores(final List<String> ids) {
        ids.forEach(s -> storeRepository.deleteById(Long.parseLong(s)));
    }

    public void deleteStores() {
        storeRepository.deleteAll();
    }

    private Set<StoreCompetitorStoreMap> populateStoreCompStoreMapping(final List<CompetitorStore> competitorStores,
        final String storeCode) {
        final Optional<Store> storeOpt = storeRepository.findByStoreCode(storeCode);
        return storeOpt.map(store -> competitorStores.stream()
                                         .map(competitorStore -> createStoreCompetitorStoreMap(store, competitorStore))
                                         .collect(Collectors.toSet())
        ).orElse(Collections.emptySet());
    }

    private static StoreCompetitorStoreMap createStoreCompetitorStoreMap(Store store, CompetitorStore competitorStore) {
        final StoreCompetitorStoreMap storeCompetitorStoreMap = new StoreCompetitorStoreMap();
        storeCompetitorStoreMap.setStore(store);
        storeCompetitorStoreMap.setCompetitorStore(competitorStore);
        storeCompetitorStoreMap.setModTime(LocalDateTime.now());
        return storeCompetitorStoreMap;
    }

    @Transactional
    public void configurePVMaxRollingDays(final RollingDaysRequest rollingDaysRequest) {
        RollingDays rollingDays = new RollingDays();
        rollingDays.setHoUserId(rollingDaysRequest.getUserId());
        rollingDays.setDays(rollingDaysRequest.getRollingDays());
        rollingDays.setLastUpdated(LocalDateTime.now());
        rollingDaysRepository.save(rollingDays);
        cacheService.clearCacheByName(ROLLING_DAYS_CACHE);
    }

    public RollingDays getPVMaxRollingDays() {
        return rollingDaysRepository.findTopByOrderByLastUpdatedDesc().orElse(new RollingDays());
    }

}