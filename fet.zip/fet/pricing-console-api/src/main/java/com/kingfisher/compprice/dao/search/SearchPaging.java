package com.kingfisher.compprice.dao.search;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Sort;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SearchPaging {
	
	private int pageNum = 1;
	private int pageSize = 10;
	private Sort.Direction sortDirection = Sort.Direction.DESC;
	private String sortBy = "creationTime";

}