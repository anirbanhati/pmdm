package com.kingfisher.compprice.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;

@Slf4j
@Service
@Scope("singleton")
public class HttpClientProvider {

	@Value("${application.ssl.certfile.path}")
	private String certfilePath;
	@Value("${application.ssl.certfile.truststore.password}")
	private String storePassword;
	@Value("${application.ssl.certfile.alias.keypassword}")
	private String keyPassword;
	@Value("${application.ssl.certfile.alias.name}")
	private String aliasName;

	public CloseableHttpClient buildHttpClient(final int connectionTimeOut, final int socketTimeOut,
												final int connectionRequestTimeOut, final int maxConnections) throws GeneralSecurityException, IOException {

		final RequestConfig requestConfig = buildRequestConfig(connectionTimeOut, socketTimeOut,
				connectionRequestTimeOut);

		final HttpClientBuilder httpClientBuilder = HttpClients.custom().setDefaultRequestConfig(requestConfig)
				.setMaxConnPerRoute(maxConnections).setMaxConnTotal(maxConnections);

		SSLContext sslContext=buildSslContext();
		SSLConnectionSocketFactory f = new SSLConnectionSocketFactory(sslContext,
				//https://stackoverflow.com/questions/54119613/sslhandshakeexception-received-fatal-alert-record-overflow
				//If you're on Java 11 or 12, then the reason is probably a TLSv1.3 bug in the JDK.
				//The workaround is to disable TLSv1.3:
				//-Djdk.tls.client.protocols="TLSv1,TLSv1.1,TLSv1.2"
				new String[]{"TLSv1", "TLSv1.1", "TLSv1.2"},
				null,
				new NoopHostnameVerifier());
		httpClientBuilder.setSSLSocketFactory(f);
		return httpClientBuilder.build();
	}

	private static RequestConfig buildRequestConfig(final int connectionTimeOut, final int socketTimeOut,
													final int connectionRequestTimeOut) {
		return RequestConfig.custom().setConnectTimeout(connectionTimeOut).setSocketTimeout(socketTimeOut)
				.setConnectionRequestTimeout(connectionRequestTimeOut).build();
	}

	private SSLContext buildSslContext() throws IOException, GeneralSecurityException {
		log.debug("certfilepath in buildSslContext() :: {}", certfilePath);
		File file = ResourceUtils.getFile(certfilePath);
		final KeyStore keyStore = createKeyStore(storePassword.toCharArray(), keyPassword.toCharArray(), aliasName, file);
		return SSLContexts.custom().loadKeyMaterial(keyStore, keyPassword.toCharArray(), (aliases, socket) -> aliasName).build();
	}

	private static KeyStore createKeyStore(final char[] storePassword, final char[] keyPassword, final String keyAlias,
										   final File keyStoreFile) throws IOException, GeneralSecurityException {

		final KeyStore oldKeyStore = loadTrustKeyStore(storePassword, keyStoreFile);

		final Key key = oldKeyStore.getKey(keyAlias, keyPassword);

		if(null == key) {
			throw new GeneralSecurityException("KEY_DID_NOT_FIND_IN_KEY_STORE");
		}

		final KeyStore newKeyStore = KeyStore.getInstance("JKS");
		newKeyStore.load(null);
		newKeyStore.setKeyEntry(keyAlias, key, keyPassword, oldKeyStore.getCertificateChain(keyAlias));

		return newKeyStore;
	}

	private static KeyStore loadTrustKeyStore(final char[] storePassword, final File keyStoreFile)
			throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {
		final KeyStore keyStore = KeyStore.getInstance("JKS"/*KeyStore.getDefaultType()*/);

		try (InputStream inputStream = new FileInputStream(keyStoreFile)) {
			keyStore.load(inputStream, storePassword);
		}
		return keyStore;
	}

}