package com.kingfisher.compprice.util;

import lombok.RequiredArgsConstructor;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@RequiredArgsConstructor
public class CacheUtils {

    private final CacheManager cacheManager;

    public void evictCacheByKey(final String cacheName, final Object key) {
        Objects.requireNonNull(cacheManager.getCache(cacheName)).evict(key);
    }

}