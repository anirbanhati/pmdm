package com.kingfisher.compprice.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.kingfisher.compprice.dao.entity.FeatureEntity;

@Repository
public interface FeatureRepository extends JpaRepository<FeatureEntity, Long> {
  
  Optional<FeatureEntity> getItemByName(final String featureName);

}