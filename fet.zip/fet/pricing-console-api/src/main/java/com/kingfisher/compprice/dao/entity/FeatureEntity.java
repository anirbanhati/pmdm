package com.kingfisher.compprice.dao.entity;

import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = "lsp_feature")
public class FeatureEntity implements Resource, Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 9040922921854923780L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "feature_id")
    private Long id;

    @Column(name = "feature_name")
    private String name;

    @Column(name = "feature_description")
    private String description;

    @Override
    public String getJsonApiDataId() {
        return String.valueOf(id);
    }

    @Override
    public String getJsonApiDataType() {
        return "feature";
    }

}