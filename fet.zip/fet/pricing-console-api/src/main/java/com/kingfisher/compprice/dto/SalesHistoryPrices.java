package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "AllSalesHistoryPrices")
@XmlAccessorType(XmlAccessType.FIELD)
public class SalesHistoryPrices {

    @XmlElement(name = "prices")
    private List<SalesHistoryPrice> prices;

    public List<SalesHistoryPrice> getPrices() {
        return prices;
    }

    public void setPrices(List<SalesHistoryPrice> prices) {
        this.prices = prices;
    }
}
