package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompetitorResponse implements Serializable {
    private static final long serialVersionUID = 5870936482202822259L;

    @JsonProperty("longname")
    private String longName;
    
}