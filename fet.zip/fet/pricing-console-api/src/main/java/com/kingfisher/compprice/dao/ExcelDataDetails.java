package com.kingfisher.compprice.dao;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class ExcelDataDetails {

	private List<ExcelValidation> excelData;
	private boolean hasHeaderError;
	private boolean hasError;
	private long count;

}