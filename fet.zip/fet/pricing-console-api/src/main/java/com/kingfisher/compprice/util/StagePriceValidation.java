package com.kingfisher.compprice.util;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_APP_EXP;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_HTTP_STATUS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_DETAILS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_ID;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_POINTER;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_MAX_PRICE_REQ_TITLE;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_APP_EXP;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_DETAILS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_HTTP_STATUS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_ID;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_APP_EXP;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_DETAILS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_HTTP_STATUS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_ID;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_POINTER;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_TITLE;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_APP_EXP;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_DETAILS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_HTTP_STATUS;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_ID;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_SD_POINTER;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_INV_ED_TITLE;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_POINTER;
import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.STAGE_PRICE_REQ_TITLE;
import static com.kingfisher.compprice.util.constants.Constants.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import com.kingfisher.compprice.dao.ExcelError;
import org.springframework.stereotype.Component;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;

@Component
public class StagePriceValidation extends StagePriceValidatorRule {


    @Override
    public void isValidPriceToStage(final Product product, final Double price, final double minimalPrice,
                                    final double standardPrice) {
        isValidStagePrice(price, minimalPrice, standardPrice, product);
    }

    @Override
    public boolean isValidEndDateToStageImport(final LocalDateTime endDate, final LocalDateTime startDate,
                                               final String prdType, final boolean isStopPrice) {
        return validEndDate(startDate, endDate, prdType, isStopPrice);
    }

    @Override
    public void isValidDatesToStage(final String ean, final LocalDateTime startDate, final LocalDateTime endDate,
                                    final String prdType, final boolean isStopPrice) {
        isValidStartDate(ean, startDate, isStopPrice);
        isValidEndDate(ean, startDate, endDate, prdType, isStopPrice);
    }

    @Override
    public boolean isValidStartDateToStageImport(final LocalDateTime startDate, final boolean isStopPrice) {
        return validStartDate(startDate, isStopPrice);
    }

    private static void isValidEndDate(final String ean, final LocalDateTime startDate, final LocalDateTime endDate,
                                       final String prdType, final boolean isStopPrice) {

        if (null != startDate && null != endDate) {
            final boolean isValidEndDate = validEndDate(startDate, endDate, prdType, isStopPrice);
            if (!isValidEndDate) {
                if (ProductType.OutOfRange.toString().equals(prdType)) {
                    throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                            STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                            ean + PIPE_SEPARATOR + endDate, STAGE_PRICE_REQ_INV_SD_TITLE);
                } else {
                    throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_ED_APP_EXP, STAGE_PRICE_REQ_INV_ED_HTTP_STATUS,
                            STAGE_PRICE_REQ_INV_ED_DETAILS, STAGE_PRICE_REQ_INV_ED_ID, STAGE_PRICE_REQ_INV_ED_POINTER,
                            ean + PIPE_SEPARATOR + endDate, STAGE_PRICE_REQ_INV_ED_TITLE);
                }
            }
        } else {
            throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                    STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                    ean + PIPE_SEPARATOR + endDate, STAGE_PRICE_REQ_INV_SD_TITLE);
        }
    }

    private static boolean validEndDate(final LocalDateTime startDate, final LocalDateTime endDate,
                                        final String prdType, final boolean isStopPrice) {
        boolean isValidEndDate;
        if (isStopPrice) {
            isValidEndDate = DateUtils.isEqual(endDate, LocalDateTime.now().plusDays(1));
        } else if (ProductType.OutOfRange.toString().equals(prdType) || ProductType.SlowMoving.toString().equals(prdType)) {
            isValidEndDate = DateUtils.isAfter(endDate, startDate) || DateUtils.isEqual(endDate, startDate);
        } else {
            isValidEndDate = (DateUtils.isAfter(endDate, startDate) || DateUtils.isEqual(endDate, startDate))
                    && DateUtils.isBefore(endDate, startDate.plusDays(45));
        }
        return isValidEndDate;
    }

    private static void isValidStartDate(final String ean, final LocalDateTime startDate, final boolean isStopPrice) {
        if (null != startDate || isStopPrice) {
            final boolean isValidStartDate = validStartDate(startDate, isStopPrice);
            if (!isValidStartDate) {
                throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                        STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                        ean + PIPE_SEPARATOR + startDate, STAGE_PRICE_REQ_INV_SD_TITLE);
            }
        } else {
            throw new DetailsNotFoundException(STAGE_PRICE_REQ_INV_SD_APP_EXP, STAGE_PRICE_REQ_INV_SD_HTTP_STATUS,
                    STAGE_PRICE_REQ_INV_SD_DETAILS, STAGE_PRICE_REQ_INV_SD_ID, STAGE_PRICE_REQ_INV_SD_POINTER,
                    ean + PIPE_SEPARATOR + null, STAGE_PRICE_REQ_INV_SD_TITLE);
        }
    }

    private static boolean validStartDate(final LocalDateTime startDate, final boolean isStopPrice) {
        final LocalDateTime today = LocalDate.now().atTime(0, 0);
        return isStopPrice ? Boolean.TRUE : DateUtils.isAfter(startDate, today);
    }

    private static void isValidStagePrice(final Double price, final double minimalPrice, final double maxPrice,
                                          final Product product) {

        if (isInValidMinPrice(price, minimalPrice)) {
            throw new DetailsNotFoundException(STAGE_PRICE_REQ_APP_EXP, STAGE_PRICE_REQ_HTTP_STATUS,
                    STAGE_PRICE_REQ_DETAILS, STAGE_PRICE_REQ_ID, STAGE_PRICE_REQ_POINTER,
                    product.getEan() + PIPE_SEPARATOR + DecimalUtils.roundOf(minimalPrice, DecimalUtils.ROUND_OF_3), STAGE_PRICE_REQ_TITLE);
        }
        if (isInValidMaxPrice(price, maxPrice)) {
            throw new DetailsNotFoundException(STAGE_MAX_PRICE_REQ_APP_EXP, STAGE_MAX_PRICE_REQ_HTTP_STATUS,
                    STAGE_MAX_PRICE_REQ_DETAILS, STAGE_MAX_PRICE_REQ_ID, STAGE_MAX_PRICE_REQ_POINTER,
                    product.getEan() + PIPE_SEPARATOR + DecimalUtils.roundOf(maxPrice, DecimalUtils.ROUND_OF_3), STAGE_MAX_PRICE_REQ_TITLE);
        }
    }

    private static boolean isInValidMinPrice(final Double price, final double maxPrice) {
        return null != price && price < maxPrice;
    }

    private static boolean isInValidMaxPrice(final Double price, final double maxPrice) {
        return null != price && price > maxPrice;
    }

    @Override
    public void validatePriceToStageForImport(final Set<ExcelError> excelErrors, final Product product, final Double price,
                                              final double minimalPrice, final double standardPrice) {
        if (price > standardPrice) {
            ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_STATUS,
                    BULK_UPLOAD_PRODUCT_INCORRECT_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_ID,
                    DecimalUtils.roundOf(standardPrice, DecimalUtils.ROUND_OF_3));
        }
        if (price < minimalPrice) {
            ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_PRIX, BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_STATUS,
                    BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE, BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_ID,
                    DecimalUtils.roundOf(minimalPrice, DecimalUtils.ROUND_OF_3));
        }
    }

    @Override
    public void validateEndDateToStageImport(final Set<ExcelError> excelErrors, final LocalDateTime endDate, final LocalDateTime startDate,
                                             final String prdType, final boolean isStopPrice) {
        if (!isValidEndDateToStageImport(endDate, startDate, prdType, false)) {
            if (ProductType.OutOfRange.toString().equals(prdType)) {
                ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_END_DATE, BULK_UPLOAD_INCORRECT_END_DATE_STATUS,
                        BULK_UPLOAD_INCORRECT_END_DATE, BULK_UPLOAD_INCORRECT_END_DATE_ID, endDate.toString());
            } else {
                ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_END_DATE, BULK_UPLOAD_DATE_INCORRECT_END_DATE_STATUS,
                        BULK_UPLOAD_DATE_INCORRECT_END_DATE, BULK_UPLOAD_DATE_INCORRECT_END_DATE_ID, endDate.toString());
            }
        }
    }

}