package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name="sales_history")
public class SalesHistory implements Serializable {

	private static final long serialVersionUID = 6443112025650118673L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name="sales_date")
	private LocalDateTime salesDate;

	@Column(name="sales_quantity")
	private Double salesQuantity;
	
	@Column(name="avg_price_sales")
	private Double avgPriceFromSales;

	@Column(name="sales_price_type")
	private String salesPriceType;

	@Column(name="last_updated")
	private LocalDateTime lastUpdated;

	@Column(name="ean")
	private String ean;

	@Column(name = "product_id")
	private Long productId;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

}