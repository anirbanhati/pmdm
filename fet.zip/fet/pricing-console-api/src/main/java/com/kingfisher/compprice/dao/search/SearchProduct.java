package com.kingfisher.compprice.dao.search;

import com.kingfisher.compprice.dao.response.ProductResultResponse;
import com.kingfisher.compprice.dao.response.SearchPagination;
import com.kingfisher.compprice.dao.entity.WarlistInfo;
import com.kingfisher.jsonapi.Resource;
import lombok.Data;

import java.util.List;

@Data
public class SearchProduct  implements Resource {

	/**
	 *
	 */
	private static final long serialVersionUID = -3128339949536153299L;

	private WarlistInfo warInfo;

	private List<ProductResultResponse> products;

	private long total;
	
	private SearchPagination pagination;

	@Override
	public String getJsonApiDataId() {
		return String.valueOf(1);
	}

	@Override
	public String getJsonApiDataType() {
		return "product";
	}


}