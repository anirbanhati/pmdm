package com.kingfisher.compprice.dao.product;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Category implements Resource {

	/**
	 *
	 */
	private static final long serialVersionUID = -4830318151277215640L;
	private String name;
	private List<SubCategory> subCategory;

	public List<SubCategory> getSubCategory() {
		subCategory.sort(Comparator.comparing(SubCategory::getName));
		return subCategory;
	}

	public void addSubCategory(SubCategory subCategory){
		if(this.subCategory==null){
			this.subCategory=new ArrayList<>();
		}
		this.subCategory.add(subCategory);
	}

	public Boolean subCategoryIsPresent(String subCategoryName){
		if(this.subCategory!=null){
			return 	this.subCategory.stream().anyMatch(e-> e.getName().equalsIgnoreCase(subCategoryName));
		}else{
			return false;
		}
	}

	public SubCategory getSubCategoryByName(String subCategoryName){
		Optional<SubCategory> optionalSubCategory = this.subCategory.stream().filter(sc -> sc.getName().equalsIgnoreCase(subCategoryName)).findFirst();
		return optionalSubCategory.orElse(null);
	}

	@Override
	public String getJsonApiDataId() {
		return "hierarchy";
	}

	@Override
	public String getJsonApiDataType() {
		return "filterOption";
	}

}
