package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.CompetitorStore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CompetitorStoreRepository extends JpaRepository<CompetitorStore, Long>{

    Optional<CompetitorStore> findByCode(final String code);

    Optional<CompetitorStore> findByCodeAndLongName(final String clCsCode, final String csName);

}