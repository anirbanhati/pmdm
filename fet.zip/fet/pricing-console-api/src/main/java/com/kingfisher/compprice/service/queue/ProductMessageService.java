package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dto.Products;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.PRODUCT_MESSAGE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final MessageServicesHelper servicesHelper;
    

    @Override
    public ProcessedByType getProcessedBy() {
        return PRODUCT_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(final String message, final MqMetricHandler metricHandler) {
        processMessageFromQueue(message, metricHandler);
    }

    private void processMessageFromQueue(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Article Feed :: {}", message);
        }
        final String methodName = "processMessage()";
        try {
            log.info("Start processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
            LocalDateTime time1 = LocalDateTime.now();
            doProcessMessage(message);
            LocalDateTime time2 = LocalDateTime.now();
            log.debug("Time taken {}", Duration.between(time1, time2).toSeconds());
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
        } catch (final Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String messageMetadata) throws JAXBException {
        final Products productFeed = getProductFeed(messageMetadata);
        final Map<String, String> invalidStoreCodes = new HashMap<>();
        processProduct(productFeed, invalidStoreCodes);
        log.info("Invalid Store Codes : {}", invalidStoreCodes);
    }

    public void processProduct(Products productFeed, Map<String, String> invalidStoreCodes) {
        Optional.ofNullable(productFeed).ifPresent(pf ->
            pf.getProductList().forEach(productInfo ->
                    servicesHelper.saveProductFeedToRepository(productInfo, invalidStoreCodes)
            )
        );
    }

    private Products getProductFeed(final String message) throws JAXBException {
        Products productFeed = null;
        final String methodName = "getProductFeed()";
        log.debug("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            final StringReader sr = new StringReader(message);
            final JAXBContext jaxbContext = JAXBContext.newInstance(Products.class);
            final Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            productFeed = (Products) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting :: {} :: {}", this.getClass().getSimpleName(), methodName);
        return productFeed;
    }

}