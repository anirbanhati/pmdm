package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.StageProduct;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.ProductSearchResponse;
import com.kingfisher.compprice.dao.response.SearchItem;
import com.kingfisher.compprice.dao.response.search.ProductItem;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.helper.ProductInfoHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.ERROR_KEY;
import static com.kingfisher.compprice.util.constants.Constants.MAP_0;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductResponseBuilder {

    private static final List<String> ALLOWED_PRD_TYPE_FOR_STOCK = List.of(ProductType.OutOfRange.toString(), ProductType.SlowMoving.toString());

    private final HelperService helperService;
    private final ProductInfoHelper productInfoHelper;
    private final StoreProductService storeProductService;
    private final StageProductService stageProductService;
    private final RoundingPriceService roundingPriceService;
    private final ThirdPartyAPIService thirdPartyAPIService;
    private final LogService logService;


    public ProductSearchResponse prepareSearchResponse(final List<Product> products, final String prdType, final User user,
                                                       final boolean hasCostPrice, final boolean hasStockDetail) {
        StopWatch stopWatch = logService.logStopWatchStart("prepareSearchResponse");
        final ProductSearchResponse response = new ProductSearchResponse();
        List<SearchItem> items = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(products)) {
            Map<String, String> costPriceDetailsMap = thirdPartyAPIService.getCostPriceDetails(products, user, hasCostPrice);
            Map<String, Integer> productCurrentStock = getProductStockDetails(products, user, prdType, response, hasStockDetail);
            response.setStageCount(setProductItemInResponseAndGetStageCount(products, prdType, user, items, productCurrentStock,
                    response.isCurrentStockValidated(), costPriceDetailsMap));
        }
        response.setItems(items);

        logService.logStopWatchStop(stopWatch);
        return response;
    }

    private Map<String, Integer> getProductStockDetails(final List<Product> products, final User user, final String prdType,
                                                        ProductSearchResponse response, final boolean hasStockDetail) {
        Map<String, Integer> productCurrentStock = new HashMap<>();

        if (hasStockDetail && (null != prdType && ALLOWED_PRD_TYPE_FOR_STOCK.contains(prdType))) {
            productCurrentStock = thirdPartyAPIService.getCurrentStockDetails(products, user.getStore());
            isStockHasValidResponse(response, productCurrentStock);
        }
        return productCurrentStock;
    }

    private void isStockHasValidResponse(final ProductSearchResponse response, final Map<String, Integer> productCurrentStock) {
        response.setCurrentStockValidated(MapUtils.isNotEmpty(productCurrentStock) || !productCurrentStock.containsKey(ERROR_KEY));
        if (productCurrentStock.containsKey(ERROR_KEY)) {
            response.setStockApiError(true);
        }
    }

    private long setProductItemInResponseAndGetStageCount(final List<Product> products, final String prdType, final User user,
                                                          final List<SearchItem> items, final Map<String, Integer> productCurrentStock,
                                                          final boolean isCurrentStockValidated, final Map<String, String> costPriceDetailsMap) {
        List<StageProduct> stageProducts = stageProductService.getStageProductsByUserAndStoreAndTenant(user);
        CategoryRoundingResponse cRounding = roundingPriceService.getRoundingConfigs(products);
        products.forEach(product -> {
            final SearchItem item = new SearchItem();
            ProductItem productItem = productInfoHelper.setProductItem(product,
                    Objects.requireNonNullElse(prdType, storeProductService.getProductTypeFromProduct(product, user)),
                    user, productCurrentStock.getOrDefault(product.getEan(), 0), stageProducts,
                    isCurrentStockValidated, costPriceDetailsMap.getOrDefault(product.getEan(), MAP_0));
            productItem.setPConversion(helperService.getConversionDetails(product, cRounding));
            productItem.setCatType(null != cRounding.getRType() ? cRounding.getRType().toString() : null);
            item.setProduct(productItem);
            items.add(item);
        });

        return stageProducts.size();
    }

}