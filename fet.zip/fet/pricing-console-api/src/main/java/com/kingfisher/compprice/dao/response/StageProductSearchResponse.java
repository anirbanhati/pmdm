package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StageProductSearchResponse implements Resource {

	/**
	 *
	 */
	private static final long serialVersionUID = -4493162963634879916L;
	private List<SearchItem> items;
	private long stageCount;
	private long totalRecords;
	private SearchPagination pagination;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}