package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Entity
@Getter
@Setter
@Table(name = "lsp_assignment")
public class Assignment implements Serializable{
	private static final long serialVersionUID = -2489212266153786682L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;

	@JsonProperty("cPrice")
	@Column(name = COLLECTED_PRICE)
	private double collectedPrice;

	@JsonProperty("cPkg")
	@Column(name = "collected_pkg")
	private String collectedPackage;

	@JsonProperty("cPkgUnit")
	@Column(name = "collected_pkg_unit")
	private String collectedPkgUnit;

	@JsonProperty("cPkgValue")
	@Column(name = COLLECTED_PKG_VALUE)
	private String collectedPkgValue;

	@JsonProperty("tenant")
	@Column(name = "tenant")
	private String tenant;

	@Column(name = "is_master_data_missed")
	private boolean masterDataMissing;

	@JsonProperty("cCode")
	@Column(name = "collected_article_code")
	private String collectedArticleCode;

	@JsonProperty("cEan")
	@Column(name = "collected_ean")
	private String collectedEan;

	@JsonProperty("hasPromo")
	@Column(name = HAS_PROMO)
	private boolean hasPromo = false;

	@JsonProperty("isLinked")
	@Column(name = "is_link")
	private boolean linkArticle = false;

	@JsonProperty("productCollectionExtracted")
	@Column(name = "product_collection_extracted")
	private boolean productCollectionExtracted;

	@JsonProperty("productAssociationExtracted")
	@Column(name = "product_association_extracted")
	private boolean productAssociationExtracted;

	@JsonProperty("productAssociationExtractedDate")
	@Column(name = "product_association_extracted_date")
	private LocalDateTime productAssociationExtractedDate;

	@JsonProperty("productCollectionExtractedDate")
	@Column(name = "product_collection_extracted_date")
	private LocalDateTime productCollectionExtractedDate;

	@Column(name = NOTES)
	private String notes;

	@JsonProperty("promoInfo")
	@Column(name = "promo_info")
	private String promoInfo;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "collection_id")
	private StoreCollection storeCollection;

	@JsonProperty("cDesc")
	@Column(name = "collected_description")
	private String collectedDescription;

}