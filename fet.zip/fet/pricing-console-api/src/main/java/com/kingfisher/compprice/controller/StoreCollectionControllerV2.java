package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.StoreCollectionControllerV2Swagger;
import com.kingfisher.compprice.service.CsvDownloadService;
import com.kingfisher.compprice.util.constants.Constants;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequestMapping(Constants.COLL_LIST_2_BASE_URL)
@RequiredArgsConstructor
public class StoreCollectionControllerV2 implements StoreCollectionControllerV2Swagger {

    private final CsvDownloadService csvDownloadService;

    Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

    @Override
    @GetMapping(COLLECTION_LIST_CSV_DOWNLOAD)
    public ResponseEntity<Resource> downloadCsvFile(final HttpServletResponse response) throws IOException {
        log.info("StoreCollectionV2: downloadCsvFile --> {}", gson.toJson(response));
        final String filename = "Associations produit suggérées_" + LocalDate.now() + CSV_FORMAT;
        final File file = csvDownloadService.getCsvFile();
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-csv")).body(resource);
    }

}