package com.kingfisher.compprice.helper;

import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.kingfisher.compprice.configuration.InboundFeedFileTypeConfiguration;
import com.kingfisher.compprice.dao.entity.InboundFileDetails;
import com.kingfisher.compprice.repository.InboundFileDetailsRepository;
import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import com.kingfisher.compprice.service.queue.InflationMessageService;
import com.kingfisher.compprice.util.constants.FeedConstants;
import jakarta.xml.bind.JAXBException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;
import static com.kingfisher.compprice.util.constants.FeedConstants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class InboundFeedDownloadHelper {

    private final S3OutboundLoadService loadService;
    private final InboundFileDetailsRepository inboundRepository;
    private final InflationMessageService inflationMessageService;
    private final InboundFeedFileTypeConfiguration inboundFeedFileTypeConfiguration;

    private static final Logger logger = LoggerFactory.getLogger(InboundFeedDownloadHelper.class);


    public void processInboundFeedFromBucket(final String bucketName, final String feedType) {
        List<String> fileDetailsList;
        fileDetailsList = loadService.getFileDetailsList(bucketName, feedType, inboundFeedFileTypeConfiguration.getFileTypeMap().get(feedType));
        fileDetailsList.forEach(fileDetail -> {
            try {
                processFeedFile(fileDetail, bucketName, feedType);
            } catch (JAXBException e) {
                loadService.moveFileFromSourceAndDelete(bucketName, fileDetail, getFileName(fileDetail), FAILED_FOLDER, feedType);
            } catch (DataIntegrityViolationException exception) {
                String exMsg = exception.getMessage();
                if (StringUtils.isNotEmpty(exMsg) && exMsg.contains(FeedConstants.FILE_DETAILS_TABLE_NAME)) {
                    logger.info("The file details already exist in database ::{} :: {}", exception.getClass().getSimpleName(), fileDetail);
                } else {
                    loadService.moveFileFromSourceAndDelete(bucketName, fileDetail, getFileName(fileDetail), FAILED_FOLDER, feedType);
                }
            } catch (Exception exception) {
                logger.info("The exception occurred while processing ::{} :: {}", exception.getClass().getSimpleName(), fileDetail);
                loadService.moveFileFromSourceAndDelete(bucketName, fileDetail, getFileName(fileDetail), FAILED_FOLDER, feedType);
            }
        });
    }

    private void processFeedFile(String fileNameWithPath, final String bucketName, final String feedType) throws JAXBException, IOException {
        final String fileName = getFileName(fileNameWithPath);
        log.info("Feed consumption will start for the file {}", fileName);
        if (StringUtils.isNotEmpty(fileName)) {
            final InboundFileDetails fileDetails = inboundRepository.findByFileName(fileName).orElse(null);
            if (null == fileDetails) {
                consumeInflationFeedAndMoveFileToArchive(fileNameWithPath, bucketName, fileName, feedType);

            } else
                log.info("File detail is already present in db so processing will be skipped for file  :: {}", fileName);
        } else {
            log.info("FileName is empty");
        }
    }

    private String getFileName(final String fileNameWithPath) {
        String[] fileNameArray = fileNameWithPath.split(FORWARD_SLASH);
        return fileNameArray[fileNameArray.length - 1];
    }

    private void consumeInflationFeedAndMoveFileToArchive(String fileNameWithPath, String bucketName, String fileName, String feedType) throws IOException {
        S3ObjectInputStream inboundInputStream = loadService.getFileContent(bucketName, fileNameWithPath);
        if (INFLATION_FEED_NAME.equalsIgnoreCase(feedType)) {
            inflationMessageService.createInflationData(getInboundCSVData(inboundInputStream));
            loadService.moveFileFromSourceAndDelete(bucketName, fileNameWithPath, fileName, ARCHIVE_FOLDER, feedType);
        }
    }

    private static List<String[]> getInboundCSVData(S3ObjectInputStream inputStream) throws IOException {
        BufferedReader csvReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.US_ASCII));
        List<String[]> inboundCSVData;
        String header = csvReader.readLine(); //NOSONAR
        String line = csvReader.readLine();
        inboundCSVData = getProcessedContent(csvReader, line);
        return inboundCSVData;
    }

    private static List<String[]> getProcessedContent(BufferedReader csvReader, String line) throws IOException {
        List<String[]> inflationData = new ArrayList<>();
        while (line != null) {
            String modifiedLine = line.replace("\"", EMPTY_STR);
            String[] inflationRaw = modifiedLine.split(",");
            inflationData.add(inflationRaw);
            line = csvReader.readLine();
        }
        return inflationData;
    }

}