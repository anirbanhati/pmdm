package com.kingfisher.compprice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@XmlRootElement(name = "ProductAssociations")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductAssociations {

    @XmlElement(name = "ProductAssociation")
    private List<ProductAssociation> productAssociation;

    public List<ProductAssociation> getProductAssociation() {
        return productAssociation;
    }

    public void setProductAssociation(List<ProductAssociation> productAssociation) {
        this.productAssociation = productAssociation;
    }
}
