package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.ExcelDataDetails;
import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.service.*;
import com.kingfisher.compprice.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class ExcelDataRead {

	private final List<String> lspImportHeaders = new ArrayList<>(Arrays.asList(PRICE_LIST_EAN, PRICE_LIST_PRIX,
			PRICE_LIST_START_DATE, PRICE_LIST_END_DATE));

	private final UserService userService;
	private final ExcelDataValidatorRules validatorRules;
	private final StoreProductService storeProductService;
	private final StorePriceService storePriceService;
	private final ProductListingService productListingService;
	private final ClusterPriceService clusterPriceService;
	private final AssignmentItemService assignmentItemService;
	private final ThirdPartyAPIService thirdPartyAPIService;
	private final ProductTools productTools;
	private final ChangeRequestConfiguration crConfig;
	private final LogService logService;


	public static Set<Map<String, Object>> readDataFromExcelIList(final XSSFWorkbook workBook, final XSSFSheet sheet,
																  final List<String> headerColumnList) {
		final Set<Map<String, Object>> listOfData = new HashSet<>();
		final Row headerRow = sheet.getRow(0);
		final FormulaEvaluator formulaEvaluator=workBook.getCreationHelper().createFormulaEvaluator();
		for (int row = 1; row < sheet.getPhysicalNumberOfRows(); row++) {
			final Row currentRow = sheet.getRow(row);
			final HashMap<String, Object> currentHash = new HashMap<>();
			for (int column = 0; column < headerRow.getPhysicalNumberOfCells(); column++) {
				if (headerColumnList.contains(getHeaderColumnValue(headerRow, column))) {
					final Cell currentCell = currentRow.getCell(column);
					prepareDataMap(formulaEvaluator, headerRow, currentHash, column, currentCell);
					listOfData.add(currentHash);
				}
			}
		}
		return listOfData;
	}

	public ExcelDataDetails readSingleColumnByHeader(final XSSFWorkbook workBook, final XSSFSheet sheet, final String header,
													 CompItemInfo collListInfo, final User user) {
		final ExcelDataDetails dataDetails = new ExcelDataDetails();
		List<String> columnData = new ArrayList<>();
		List<Product> validPrdList = new ArrayList<>();
		ExcelValidation excelValidation = new ExcelValidation();
		final List<ExcelValidation> list = new ArrayList<>();
		boolean hasError = false;
		final Set<ExcelError> excelErrors = new HashSet<>();
		final Row headerRow = sheet.getRow(0);
		final FormulaEvaluator formulaEvaluator = workBook.getCreationHelper().createFormulaEvaluator();

		prepareListOfInvalidHeadersForErrReport(header, excelErrors, headerRow);
		if (CollectionUtils.isNotEmpty(excelErrors)) {
			hasError = true;
			final ExcelValidation invalidHeaderError = new ExcelValidation();
			invalidHeaderError.setErrorCount(excelErrors.size());
			invalidHeaderError.setErrors(excelErrors);
			list.add(invalidHeaderError);
		} else {
			List<Product> productList = getProductsFromEans(sheet, formulaEvaluator, user);
			for (int row = 1; row < sheet.getPhysicalNumberOfRows(); row++) {
				final Row currentRow = sheet.getRow(row);
				if (null != currentRow && null != currentRow.getCell(0) &&
						StringUtils.isNotEmpty(validatorRules.deriveCellType(currentRow.getCell(0)))) {
					final Cell currentCell = currentRow.getCell(0);
					excelValidation = getExcelDataValidation(user, columnData, validPrdList, excelValidation, formulaEvaluator, productList, currentCell);
					if (excelValidation.getErrorCount() > 0) {
						hasError = true;
						excelValidation.setRowNum(row);
					}
					list.add(excelValidation);
				}
			}
		}
		collListInfo.setProductList(validPrdList);
		dataDetails.setCount(columnData.size());
		dataDetails.setExcelData(list);
		dataDetails.setHasError(hasError);

		return dataDetails;
	}

	public List<Product> getProductsFromEans(final XSSFSheet sheet, FormulaEvaluator formulaEvaluator, User user) {
		List<String> eans = new ArrayList<>();
		for (int row = 1; row < sheet.getPhysicalNumberOfRows(); row++) {
			final Row currentRow = sheet.getRow(row);
			if (null != currentRow && null != currentRow.getCell(0) &&
					StringUtils.isNotEmpty(validatorRules.deriveCellType(currentRow.getCell(0)))) {
				final Cell currentCell = currentRow.getCell(0);
				String cellValue;
				switch (formulaEvaluator.evaluateInCell(currentCell).getCellType()) {
					case NUMERIC:
						cellValue = NumberToTextConverter.toText(currentCell.getNumericCellValue());
						eans.add(cellValue);
						break;
					case STRING:
						cellValue = currentCell.getStringCellValue();
						eans.add(cellValue);
						break;
					default:
						break;
				}
			}
		}
		return productTools.findProductByListOfEanAndType(eans, user);
	}

	public static Map<String, Map<String, Object>> readDataFromExcel(final XSSFWorkbook workBook, final XSSFSheet sheet, final List<String> headerColumnList) {
		final Map<String, Map<String, Object>> excelDataMap = new HashMap<>();

		final Row headerRow = sheet.getRow(0);
		final FormulaEvaluator formulaEvaluator = workBook.getCreationHelper().createFormulaEvaluator();
		for (int row = 1; row < sheet.getPhysicalNumberOfRows(); row++) {
			final Row currentRow = sheet.getRow(row);
			final HashMap<String, Object> currentHash = new HashMap<>();
			for (int column = 0; column < headerRow.getPhysicalNumberOfCells(); column++) {
				if (headerColumnList.contains(getHeaderColumnValue(headerRow, column))) {
					final Cell currentCell = currentRow.getCell(column);
					prepareDataMap(formulaEvaluator, headerRow, currentHash, column, currentCell);
				}
			}

			if (null != currentHash.get(headerColumnList.get(0))) {
				excelDataMap.put(currentHash.get(headerColumnList.get(0)).toString(), currentHash);
			}

		}
		return excelDataMap;
	}

	private static void prepareDataMap(final FormulaEvaluator formulaEvaluator, final Row headerRow,
																		 final HashMap<String, Object> currentHash, final int j, final Cell currentCell) {
		if (null != currentCell) {
			switch (formulaEvaluator.evaluateInCell(currentCell).getCellType()) {
				case STRING:
					currentHash.put(getHeaderColumnValue(headerRow, j), currentCell.getStringCellValue());
					break;
				case NUMERIC:
					currentHash.put(getHeaderColumnValue(headerRow, j), currentCell.getNumericCellValue());
					break;
				case BOOLEAN:
					currentHash.put(getHeaderColumnValue(headerRow, j), currentCell.getBooleanCellValue());
					break;
				default:
			}
		} else {
			currentHash.put(getHeaderColumnValue(headerRow, j), EMPTY_STR);
		}
	}

	private static String getHeaderColumnValue(final Row headerRow, final int j) {
		return headerRow.getCell(j).getStringCellValue();
	}

	public ExcelDataDetails readBulkPriceDataFromExcel(final MultipartFile file, List<Product> prodList, final User user)
			throws IOException {
		StopWatch stopWatch = logService.logStopWatchStart("readBulkPriceDataFromExcel");
		ExcelDataDetails dataDetails = new ExcelDataDetails();

		if (isValidHeadersForLspBulkImport(file, dataDetails)) {
            if (crConfig.isImportCsv()) {
                validateCsvData(file, prodList, user, dataDetails);
            } else {
                validateExcelData(file, prodList, user, dataDetails);
            }
        }

		logService.logStopWatchStop(stopWatch);
		return dataDetails;
	}

	private void validateExcelData(final MultipartFile file, List<Product> prodList, final User user,
								   ExcelDataDetails dataDetails) throws IOException {
		final XSSFSheet sheet = SpreadsheetUtils.getInputStreamAsWorkBook(file.getInputStream()).getSheetAt(0);
		MasterData masterData = getMasterDataExcel(sheet, user);
		prodList.addAll(masterData.getProducts());

		final List<ExcelValidation> list = new ArrayList<>();
		boolean hasError = false;
		for (int row = 2; row < sheet.getPhysicalNumberOfRows(); row++) {
			log.debug("Call started for readBulkPriceDataFromExcel Row{}", row);
			final Row currentRow = sheet.getRow(row);
			if (null != currentRow.getCell(0) && StringUtils.isNotEmpty(validatorRules.deriveCellType(currentRow.getCell(0)))) {
				final ExcelValidation validateRow = validatorRules.validateRowExcel(currentRow, sheet.getRow(1),
						user, masterData);
				if (validateRow.getErrorCount() > 0) {
					hasError = true;
				}
				list.add(validateRow);
			}
		}
		dataDetails.setExcelData(list);
		dataDetails.setHasError(hasError);
	}

	private void validateCsvData(final MultipartFile file, List<Product> prodList, final User user,
								 ExcelDataDetails dataDetails) throws IOException {
		String[] rows = new String(file.getBytes(), StandardCharsets.ISO_8859_1).split(NEW_LINE_SEPARATOR);
		String headerRow = rows[1];
		MasterData masterData = getMasterDataCsv(rows, user);
		prodList.addAll(masterData.getProducts());

		final List<ExcelValidation> list = new ArrayList<>();
		boolean hasError = false;
		for (int row = 2; row < rows.length; row++) {
			log.debug("Call started for validateCsvData Row{}", row);
			final String currentRow = rows[row];
			String[] currentRowValues = currentRow.split(SEMI_COLON_SEPARATOR);

			if (StringUtils.isNotEmpty(currentRow)) {
				final ExcelValidation validateRow = validatorRules.validateRowCsv(currentRowValues, headerRow, user,
						masterData, row - 1);
				if (validateRow.getErrorCount() > 0) {
					hasError = true;
				}
				list.add(validateRow);
			}
		}
		dataDetails.setExcelData(list);
		dataDetails.setHasError(hasError);
	}

    private boolean isValidHeadersForLspBulkImport(final MultipartFile file, ExcelDataDetails dataDetails)
			throws IOException {
        Set<ExcelError> excelHeaderErrors = new HashSet<>();
        final List<ExcelValidation> list = new ArrayList<>();
        boolean hasHeaderError = false;

        if (crConfig.isImportCsv()) {
			String[] rows = new String(file.getBytes(), StandardCharsets.ISO_8859_1).split(NEW_LINE_SEPARATOR);
			csvHeaderValidation(excelHeaderErrors, rows[1]);
		} else {
			final XSSFSheet sheet = SpreadsheetUtils.getInputStreamAsWorkBook(file.getInputStream()).getSheetAt(0);
			final Row headerRowExcel = sheet.getRow(1);
			for (int column = 0; column < lspImportHeaders.size(); column++) {
				if (!lspImportHeaders.contains(headerRowExcel.getCell(column).getStringCellValue())) {
					ExcelDataValidation.setErrorDetail(excelHeaderErrors, lspImportHeaders.get(column), BULK_UPLOAD_HEADER_INVALID_STATUS,
							BULK_UPLOAD_HEADER_INVALID + lspImportHeaders.get(column), BULK_UPLOAD_HEADER_INVALID_ID,
							headerRowExcel.getCell(column).getStringCellValue());
				}
			}
        }
        if (CollectionUtils.isNotEmpty(excelHeaderErrors)) {
			hasHeaderError = true;
            final ExcelValidation invalidHeaderError = new ExcelValidation();
            invalidHeaderError.setErrorCount(excelHeaderErrors.size());
            invalidHeaderError.setErrors(excelHeaderErrors);
            list.add(invalidHeaderError);
        }
        dataDetails.setExcelData(list);
        dataDetails.setHasError(hasHeaderError);
		dataDetails.setHasHeaderError(hasHeaderError);
        return !hasHeaderError;
    }

	private void csvHeaderValidation(Set<ExcelError> excelHeaderErrors, final String headerRowCsv) {
		final String[] headerRowValues = headerRowCsv.split(SEMI_COLON_SEPARATOR);
		if (headerRowValues.length < lspImportHeaders.size()) {
			ExcelDataValidation.setErrorDetail(excelHeaderErrors, EMPTY_STR, BULK_UPLOAD_HEADER_INVALID_STATUS,
					BULK_UPLOAD_HEADER_INVALID, BULK_UPLOAD_HEADER_INVALID_ID, headerRowCsv);
		} else {
			for (int column = 0; column < lspImportHeaders.size(); column++) {
				if (!lspImportHeaders.contains(headerRowValues[column].replaceAll("(\\r\\n|\\n|\\r)", EMPTY_STR))) {
					ExcelDataValidation.setErrorDetail(excelHeaderErrors, lspImportHeaders.get(column), BULK_UPLOAD_HEADER_INVALID_STATUS,
							BULK_UPLOAD_HEADER_INVALID + lspImportHeaders.get(column), BULK_UPLOAD_HEADER_INVALID_ID,
							headerRowValues[column]);
				}
			}
		}
	}

	private MasterData getMasterDataExcel(XSSFSheet sheet, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getMasterData");

		List<String> listOfEan = new ArrayList<>();
		for (int row = 2; row < sheet.getPhysicalNumberOfRows(); row++) {
			final Row currentRow = sheet.getRow(row);
			if (null != currentRow.getCell(0)) {
				String ean = validatorRules.deriveCellType(currentRow.getCell(0));
				if (StringUtils.isNotEmpty(ean)) {
					listOfEan.add(ean);
				}
			}
		}
		MasterData masterData = prepareMasterData(user, listOfEan);

		logService.logStopWatchStop(stopWatch);
		return masterData;
	}

	private MasterData prepareMasterData(final User user, final List<String> listOfEan) {
		StopWatch stopWatch = logService.logStopWatchStart("prepareMasterData");
		var products = productTools.getProductsFromEans(listOfEan, user);
		var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, listOfEan, user.getStore());
		var productStoreProductMap = storeProductService.getProductStoreProductMap(products, listOfEan, user);
		var validPrdListMap = productListingService.validateProductListing(products, listOfEan, user.getStore());
		var productMinCPriceMap = assignmentItemService.getProductMinCPriceMap(products, user);
		var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
		var productStageProductMap = productTools.getProductStageProductMap(products, user);
		var eanCostPriceMap = thirdPartyAPIService.getCostPriceDetails(products, user, true);
		MasterData masterData = MasterData.builder().eanStorePriceMap(eanStorePriceMap).productStoreProductMap(productStoreProductMap).
				validPrdListingMap(validPrdListMap).productMinCPriceMap(productMinCPriceMap).eanClusterPriceMap(eanClusterPriceMap).
				productStageProductMap(productStageProductMap).eanCostPriceMap(eanCostPriceMap).products(products).build();
		logService.logStopWatchStop(stopWatch);
		return masterData;
	}

	public MasterData getMasterDataCsv(String[] rows, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getMasterDataCsv");

		List<String> listOfEan = new ArrayList<>();
		for (int row = 2; row < rows.length; row++) {
			final String currentRow = rows[row];
			String[] values = currentRow.split(SEMI_COLON_SEPARATOR);
			if (null != values[0]) {
				String ean = values[0].replaceAll("(\\r\\n|\\n|\\r)", EMPTY_STR);
				if (StringUtils.isNotEmpty(ean)) {
					listOfEan.add(ean);
				}
			}
		}
		MasterData masterData = prepareMasterData(user, listOfEan);
		logService.logStopWatchStop(stopWatch);
		return masterData;
	}

	private void prepareListOfInvalidHeadersForErrReport(String header, Set<ExcelError> excelErrors, Row headerRow) {
		if (!header.equalsIgnoreCase(headerRow.getCell(0).getStringCellValue())) {
			ExcelDataValidation.setErrorDetail(excelErrors, header, BULK_UPLOAD_HEADER_INVALID_STATUS,
					BULK_UPLOAD_HEADER_INVALID + header, BULK_UPLOAD_HEADER_INVALID_ID,
					headerRow.getCell(0).getStringCellValue());
		}
	}

	private ExcelValidation getExcelDataValidation(User user, List<String> columnData, List<Product> validPrdList,
												   ExcelValidation excelValidation, FormulaEvaluator formulaEvaluator,
												   List<Product> productList, Cell currentCell) {
		String cellValue;
		boolean isHeadOfficeUser = userService.isHeadOfficeUser(user.getUserId());
		switch (formulaEvaluator.evaluateInCell(currentCell).getCellType()) {
			case NUMERIC:
				cellValue = NumberToTextConverter.toText(currentCell.getNumericCellValue());
				columnData.add(cellValue);
				excelValidation = validatorRules.validateEans(cellValue, validPrdList, productList, isHeadOfficeUser, user);
				break;
			case STRING:
				cellValue = currentCell.getStringCellValue();
				columnData.add(cellValue);
				excelValidation = validatorRules.validateEans(cellValue, validPrdList, productList, isHeadOfficeUser, user);
				break;
			default:
		}
		return excelValidation;
	}

}