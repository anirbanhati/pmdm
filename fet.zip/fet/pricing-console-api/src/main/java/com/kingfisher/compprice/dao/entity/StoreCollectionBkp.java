package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Getter
@Setter
@Entity
@Table(name = "lsp_store_collection_bkp")
public class StoreCollectionBkp implements Serializable, Resource {
    private static final long serialVersionUID = 6582631126458471633L;

    @Id
    @Column(name = "id")
    private long id;

    @Column(name = "store_code")
    @JsonProperty("storeId")
    private String storeCode;

    @JsonIgnore
    @Column(name = "competitor_store_id")
    private Long compId;

    @Column(name = COLLECTION_LIST_NAME)
    private String name;

    @Column(name = "created_by")
    @JsonProperty("cBy")
    private String createdBy;

    @Column(name = "tenant")
    @JsonProperty("tenant")
    private String tenant;

    @JsonProperty("assignTo")
    @Column(name = "assign_to")
    private String assignTo;

    @Column(name = "last_modified_by")
    @JsonProperty("modBy")
    private String lastModifiedBy;

    @Column(name = CATEGORY_TYPE)
    @JsonProperty("type")
    private String categoryType;

    @Column(name = STATUS)
    private String status;

    @JsonProperty("cTime")
    @Column(name = "creation_date")
    private LocalDateTime creationTime;

    @JsonProperty("modTime")
    @Column(name = "last_modified")
    private LocalDateTime lastModifiedTime;

    @JsonIgnore
    @Column(name = "effective_start_date")
    private LocalDateTime startDate;

    @JsonIgnore
    @Column(name = EFFECTIVE_END_DATE)
    private LocalDateTime endDate;

    @Column(name = "exp_date")
    private String expDate;

    @JsonIgnore
    @JsonProperty("items")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "storeCollectionBkp")
    private List<AssignmentBkp> assignmentBkp = new ArrayList<>();

    @Column(name = "cl_cs_code")
    private String clCsCode;

    @Column(name = "cs_name")
    private String csName;

    @Column(name = HO_CL_NAME)
    private String hoClName;


    public void setAssignmentBkp(final List<AssignmentBkp> listOfAssignmentBkp) {
        this.assignmentBkp = listOfAssignmentBkp;
        for (final AssignmentBkp assign : listOfAssignmentBkp) {
            assign.setStoreCollectionBkp(this);
        }
    }

    @Override
    public String getJsonApiDataId() {
        return String.valueOf(this.id);
    }

    @Override
    public String getJsonApiDataType() {
        return "clItem";
    }

}