package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WorkgroupAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class WorkGroupAssignment {

    @XmlElement(name = "WorkgroupCode")
    private Long workGroupCode;

    public Long getWorkGroupCode() {
        return workGroupCode;
    }

    public void setWorkGroupCode(Long workGroupCode) {
        this.workGroupCode = workGroupCode;
    }


}
