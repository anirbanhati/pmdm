package com.kingfisher.compprice.config;

import com.kingfisher.compprice.config.batch.*;
import com.kingfisher.compprice.dao.StoreCollectionHoSpreadsheetData;
import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import lombok.AllArgsConstructor;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
@AllArgsConstructor
public class BatchConfiguration {

    private ReaderConfig readerConfig;
    private S3OutboundLoadService s3OutboundLoadService;
    private PlatformTransactionManager transactionManager;
    private SynchronizedExcelItemWriter synchronizedExcelItemWriter;


    @Bean
    public Job exportStoreCollectionItems(JobRepository jobRepository) throws Exception {
        return new JobBuilder("exportStoreCollectionItems", jobRepository)
                .incrementer(new RunIdIncrementer())
                .listener(jobCompletionListener())
                .flow(writeFile(transactionManager, jobRepository))
                .end().build();
    }

    @Bean
    public Step writeFile(PlatformTransactionManager transactionManager, JobRepository jobRepository) throws Exception {
        return new StepBuilder("exportStoreCollectionItems", jobRepository)
                .<StoreCollectionHoSpreadsheetData, StoreCollectionHoSpreadsheetData>chunk(100, transactionManager)
                .reader(readerConfig.databaseReader(""))
                .writer(synchronizedExcelItemWriter)
                .listener(myStepExecutionListener())
                .build();
    }

    @Bean
    public StepExecutionListener myStepExecutionListener() {
        return new BatchStepExecutionListener(synchronizedExcelItemWriter);
    }

    @Bean
    public JobCompletionListener jobCompletionListener() {
        return new JobCompletionListener(s3OutboundLoadService);
    }

}