package com.kingfisher.compprice.dao;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StoreCollectionHoSpreadsheetData {

    private Long collectionListId;
    private String collectionListName;
    private String endDate;
    private String storeCode;
    private String storeName;
    private String storeCollectionId;
    private String collectionListCode;
    private String storeCollectionListName;
    private String competitorStoreCode;
    private String competitorName;
    private String category;
    private String ean;
    private String productLabel;
    private String uom;
    private String packaging;
    private String collectedPkgValue;
    private double collectedPrice;
    private boolean hasPromo;
    private String notes;
    private String salesUnit;

    private String status;
    private Double conversion;
    private Integer catRoundingType;

}