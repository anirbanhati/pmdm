package com.kingfisher.compprice.dao.search;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WarListSearchCriteria {
	
	private String brickCodes;
	private String eanOrDesc;
	private Set<String> codes;

}