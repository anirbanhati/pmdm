package com.kingfisher.compprice.enums;

public enum CollectionType {
	STORE("Store"), CENTER("Center");

	private final String type;

	CollectionType(final String type) {
		this.type = type;
	}

	public String type() {
		return type;
	}
}
