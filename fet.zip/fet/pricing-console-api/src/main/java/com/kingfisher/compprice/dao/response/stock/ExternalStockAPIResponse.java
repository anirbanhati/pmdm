package com.kingfisher.compprice.dao.response.stock;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Getter
@Setter
public class ExternalStockAPIResponse {

    Meta meta;
    List<ExternalStockResponseDetails> data;

}