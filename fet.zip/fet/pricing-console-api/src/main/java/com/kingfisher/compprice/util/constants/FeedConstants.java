package com.kingfisher.compprice.util.constants;

import lombok.experimental.UtilityClass;

import java.util.Map;

@UtilityClass
public class FeedConstants {

    public static final String INBOUND_FOLDER = "/inbound";
    public static final String FAILED_FOLDER = "failed";
    public static final String FILE_DETAILS_TABLE_NAME = "lsp_inbound_file_details";
    public static final String FORWARD_SLASH = "/";
    public static final String ARCHIVE_FOLDER = "archive";
    public static final String FEED_DETAILS_COLUMN_NAME = "inbound_file_name";
    public static final String FEED_NAME = "feed_name";
    public static final String PROCESSED_DATE = "processed_date";
    public static final String INFLATION_FEED_NAME = "inflationFeed";
    public static final Map<String, String> feedTypeToBucketFolderMap = Map.of("productFeed", "Product", INFLATION_FEED_NAME, "inflation");

}