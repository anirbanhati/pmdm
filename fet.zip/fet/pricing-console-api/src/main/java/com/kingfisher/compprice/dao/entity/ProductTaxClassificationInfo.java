package com.kingfisher.compprice.dao.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.DESCRIPTION;

@Getter
@Setter
@Entity
@Table(name = "product_tax_classifications")
public class ProductTaxClassificationInfo implements Serializable {
    private static final long serialVersionUID = -4885622736122964826L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "product_tax_classification_code")
    private String taxClassificationCode;

    @Column(name = "tax_jurisdiction_id")
    private String taxJurisdictionId;

    @Column(name = "tax_code")
    private String taxCode;

    @Column(name = "percent")
    private double percent;

    @Column(name = DESCRIPTION)
    private String description;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

}