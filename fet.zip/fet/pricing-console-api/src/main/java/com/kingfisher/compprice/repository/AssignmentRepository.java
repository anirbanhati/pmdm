package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.dao.entity.Assignment;
import com.kingfisher.compprice.dao.entity.StoreCollection;
import com.kingfisher.compprice.dao.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, Long> {

	Optional<Assignment> findByStoreCollectionAndProduct(final StoreCollection list, final Product product);

	Set<Assignment> findByStoreCollection(final StoreCollection storeCollection);

	List<Assignment> findByProductAndStoreCollectionInAndCollectedPriceGreaterThan(final Product product, final Set<StoreCollection> collList, final double price);

	List<Assignment> findByProductAndStoreCollectionIn(final Product product, final Set<StoreCollection> collList);

	List<Assignment> findByMasterDataMissingAndProductCollectionExtracted(final boolean isMasterDataMissing, final boolean productCollectionExtracted);

	Set<Assignment> findByStoreCollection_IdInAndProductIsNotNull(final List<Long> collectionIds);

	Set<Assignment> findByStoreCollection_IdInAndCollectedPriceGreaterThanAndProductIsNotNull(final List<Long> collectionIds,final double cPrice);

	Set<Assignment> findByProductAndStoreCollection_StatusInAndStoreCollection_StoreCodeAndCollectedPriceGreaterThan(final Product product, final List<CollectionStatus> status, final String storeCode, final double price);

	List<Assignment> findByProductInAndStoreCollection_StatusInAndStoreCollection_StoreCodeAndCollectedPriceGreaterThan(final List<Product> product, final List<CollectionStatus> status, final String storeCode, final double price);

	List<Assignment> findByCollectedEanNotNullOrCollectedArticleCodeNotNull();

}