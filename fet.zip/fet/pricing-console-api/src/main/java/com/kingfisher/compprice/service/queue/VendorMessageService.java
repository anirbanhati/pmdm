package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Vendor;
import com.kingfisher.compprice.dto.VendorInfo;
import com.kingfisher.compprice.dto.Vendors;
import com.kingfisher.compprice.repository.VendorRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.VENDOR_MESSAGE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class VendorMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final VendorRepository vendorRepository;
    private final MessageServicesHelper serviceHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return VENDOR_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Vendor Feed :: {}", message);
        }
        final String methodName = "processMessage";
        try {
            log.info("Start processing message {}::{}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message {}::{}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata) throws JAXBException {
        Vendors vendorFeed = getVendorFeed(messageMetadata);
        Optional.ofNullable(vendorFeed).ifPresent(vf ->
            vf.getVendorInfoList().forEach(this::saveVendorFeedToRepository));
    }

    private Vendors getVendorFeed(String message) throws JAXBException {
        Vendors vendorFeed = null;
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(Vendors.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            vendorFeed = (Vendors) unmarshaller.unmarshal(sr);
        }
        return vendorFeed;
    }

    @Transactional
    public void saveVendorFeedToRepository(VendorInfo vendorInfo) {
        addOrUpdateVendorFeedDetailsIntoRepository(vendorInfo);
    }

    private void addOrUpdateVendorFeedDetailsIntoRepository(VendorInfo vendorInfo) {
        Product product = serviceHelper.getProductByEanAndSalesUnit(vendorInfo.getEan(), vendorInfo.getSalesOrg());
        refreshVendorDetails(product, vendorInfo);
    }

    private void refreshVendorDetails(Product product, VendorInfo vendorInfo) {
        if (Optional.ofNullable(product).isPresent()) {
            addVendorDetailsInRepository(vendorInfo, product);
        } else {
            Product existingProduct = serviceHelper.createProduct(vendorInfo.getEan(), vendorInfo.getArticleNumber(), vendorInfo.getSalesOrg());
            addVendorDetailsInRepository(vendorInfo, existingProduct);
        }
    }

    private void addVendorDetailsInRepository(VendorInfo vendorInfo, Product existingProduct) {
        Vendor existingVendor = getExistingVendor(existingProduct);
        if (Optional.ofNullable(existingVendor).isEmpty()) {
            refreshVendorRepository(vendorInfo, existingProduct, null);
        } else {
            refreshVendorRepository(vendorInfo, existingProduct, existingVendor);
        }
    }

    private Vendor getExistingVendor(Product product) {
        List<Vendor> vendor = vendorRepository.findByProduct(product);
        return CollectionUtils.isNotEmpty(vendor) ? vendor.get(0) : null;
    }

    private void refreshVendorRepository(final VendorInfo vendorInfo, final Product product, final Vendor vendor) {

        Vendor vendorDetails = Optional.ofNullable(vendor).isPresent() ? vendor : new Vendor();
        if (null == vendor) {
            vendorDetails.setProduct(product);
        }
        vendorDetails.setLastUpdated(LocalDateTime.now());
        vendorDetails.setVInfo(vendorInfo.getVendor());
        vendorRepository.save(vendorDetails);
    }

}