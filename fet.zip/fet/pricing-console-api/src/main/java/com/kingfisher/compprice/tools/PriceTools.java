package com.kingfisher.compprice.tools;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.*;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.price.ProductPrice;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.PriceListResponse;
import com.kingfisher.compprice.dao.response.StockInfo;
import com.kingfisher.compprice.dao.response.search.ProductItem;
import com.kingfisher.compprice.dao.response.search.Recommandation;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.enums.PriceValidationStatus;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.repository.ImportErrorsRepository;
import com.kingfisher.compprice.repository.PriceUpdateRepository;
import com.kingfisher.compprice.repository.StageProductRepository;
import com.kingfisher.compprice.service.*;
import com.kingfisher.compprice.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.*;
import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;

@Service
@RequiredArgsConstructor
@Slf4j
public class PriceTools {

    @Value("${bulkUpload.batchSize}")
    private int batchSize;

    private final BaseValidationFactory stageValidation;
    private final StageProductRepository stageProdRepo;
    private final PriceUpdateRepository priceUpdateRepository;
    private final ImportErrorsRepository importErrorsRepository;
    private final StorePriceTools storePriceTools;
    private final ProductTools productTools;
    private final StorePriceService storePriceService;
    private final StoreProductService storeProductService;
    private final ClusterPriceService clusterPriceService;
    private final PriceHistoryService priceHistoryService;
    private final AssignmentItemService assignmentItemService;
    private final RoundingPriceService roundingPriceService;
    private final StockProvisionsService stockProvisionsService;
    private final ChangeRequestConfiguration crConfig;
    private final PriceValidation priceValidation;
    private final HelperService helperService;
    private final LogService logService;


    @Transactional
    public StageProduct saveStageInRepository(final StageDataRequest req, final Product product, final User user,
                                              final StageProduct stageProduct, final boolean isStoppedPrice,
                                              final int currentStockQty) {
        log.debug("Saving stage price for {}", product.getEan());
        ExcelValidation excelValidation = new ExcelValidation();
        excelValidation.setRequest(req);
        excelValidation.setProduct(product);
        final StageProduct sProd = prepareStageDataToSave(excelValidation, user, stageProduct, isStoppedPrice,
                currentStockQty, new CategoryRoundingResponse());
        stageProdRepo.save(sProd);
        return sProd;
    }

    @Transactional
    public long saveBulkUploadProducts(final List<ExcelValidation> excelData, final List<Product> products, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("saveBulkUploadProducts");

        long totalCount = 0;
        List<StageProduct> listOfStageProducts = new ArrayList<>();
        final List<List<ExcelValidation>> excelDataGroups = new ArrayList<>(
                excelData.parallelStream().filter(ex -> null != ex.getRequest())
                        .collect(Collectors.groupingBy(s -> excelData.indexOf(s) / batchSize)).values());
        if (CollectionUtils.isNotEmpty(excelDataGroups)) {
            log.info("BulkUpload data size {}, number of batches {}, number of data per batch {}", excelData.size(), excelDataGroups.size(), batchSize);

            var cRounding = roundingPriceService.getRoundingConfigs(products);
            for (final List<ExcelValidation> excelValidationList : excelDataGroups) {
                excelValidationList.forEach(ex -> listOfStageProducts.add(prepareStageDataToSave(ex, user, ex.getStgPrd(),
                        false, 0, cRounding)));
                totalCount = totalCount + excelValidationList.size();
            }
            synchronized(listOfStageProducts) {
                stageProdRepo.saveAll(listOfStageProducts);
            }
        }
        logService.logStopWatchStop(stopWatch);
        return totalCount;
    }

    public StageProduct prepareStageDataToSave(final ExcelValidation excelData, final User user, StageProduct stageProd,
                                               final boolean isStoppedPrice, int currentStockQty, final CategoryRoundingResponse cRounding) {
        StopWatch stopWatch = logService.logStopWatchStart("prepareStageDataToSave");

        var req = excelData.getRequest();
        var product = excelData.getProduct();
        StageProduct stageProduct = stageProd;
        if (stageProd == null) {
            stageProduct = new StageProduct();
            updateStageToExcludeInSave(req, product, user, stageProduct);
        }
        stageProduct.setTenant(user.getTenant());
        stageProduct.setSDate(StringUtils.isNoneEmpty(req.getSDate()) ? DateUtils.formattedDate(req.getSDate()) : null);
        stageProduct.setEDate(StringUtils.isNoneEmpty(req.getEDate()) ? DateUtils.formattedDate(req.getEDate()) : null);
        stageProduct.setUser(user);
        if (req.getCostPrice() > 0) {
            calculateProductPrice(req, product, isStoppedPrice, stageProduct, user, currentStockQty, cRounding);
            stageProduct.setPriceSU(Double.parseDouble(DecimalUtils.roundOf(stageProduct.getPriceSU(), DecimalUtils.ROUND_OF_2)));
            stageProduct.setStore(user.getStore());
            stageProduct.setProduct(product);
            stageProduct.setPrdType(ProductType.valueOf(req.getPrdType()));
            stageProduct.setPriceStopped(isStoppedPrice);
            stageProduct.setGroupingCode(req.getChainId());
            stageProduct.setCostPrice(req.getCostPrice());
        } else {
            throw new DetailsNotFoundException(STG_PRODUCT_COST_PRICE_NOT_FOUND_APP_EXP,
                    STG_PRODUCT_COST_PRICE_NOT_FOUND_HTTP_STATUS, STG_PRODUCT_COST_PRICE_NOT_FOUND_DETAILS,
                    STG_PRODUCT_COST_PRICE_NOT_FOUND_ID, STG_PRODUCT_COST_PRICE_NOT_FOUND_POINTER,
                    req.getEan() + PIPE_SEPARATOR + user.getStore().getStoreCode(),
                    STG_PRODUCT_COST_PRICE_NOT_FOUND_TITLE);
        }
        logService.logStopWatchStop(stopWatch);
        return stageProduct;
    }

    private void updateStageToExcludeInSave(final StageDataRequest req, final Product product, final User user,
                                            final StageProduct sProd) {
        StopWatch stopWatch = logService.logStopWatchStart("updateStageToExcludeInSave");

        if (ProductType.WarList.toString().equals(req.getPrdType())) {
            final Set<StageProduct> storeProducts = stageProdRepo.findByProductAndUserAndStoreAndTenantAndPrdTypeIn(
                    product, user, user.getStore(), user.getTenant(),
                    Arrays.asList(ProductType.SlowMoving, ProductType.OutOfRange));
            if (CollectionUtils.isNotEmpty(storeProducts)) {
                for (final StageProduct sp : storeProducts) {
                    sp.setIgnoreSaving(true);
                    stageProdRepo.save(sp);
                }
            }
        } else if (ProductType.OutOfRange.toString().equals(req.getPrdType())
                || ProductType.SlowMoving.toString().equals(req.getPrdType())) {
            final Set<StageProduct> storeProducts = stageProdRepo.findByProductAndUserAndStoreAndTenantAndPrdTypeIn(
                    product, user, user.getStore(), user.getTenant(), List.of(ProductType.WarList));
            if (CollectionUtils.isNotEmpty(storeProducts)) {
                sProd.setIgnoreSaving(true);
            }
        }
        logService.logStopWatchStop(stopWatch);
    }

    @Transactional
    public void saveFinalPriceDetails(final Set<PriceUpdate> priceDetails, final List<StageProduct> stageProducts) {
        if (CollectionUtils.isNotEmpty(priceDetails)) {
            priceUpdateRepository.saveAll(priceDetails);
        }
        if (CollectionUtils.isNotEmpty(stageProducts)) {
            stageProdRepo.deleteAll(stageProducts);
        }
    }

    public void savePriceUpdate(final Set<PriceUpdate> priceDetails, final User user, final StageProduct sProd,
                                final String ref) {
        var storePrice = storePriceTools.getActiveStorePrice(sProd.getProduct(), user.getStore());
        var nPrice = storePriceService.findActiveNationalPriceFromProduct(sProd.getProduct(), user.getTenant());
        var clusterPrice = clusterPriceService.findClusterPriceByClusterId(sProd.getProduct(), user);
        var storeProduct = storeProductService.getStoreProductByProductAndStore(sProd.getProduct(), user.getStore());
        var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);

        stageValidation.validation(user.getTenant()).isValidDatesToStage(sProd.getProduct().getEan(), sProd.getSDate(),
                sProd.getEDate(), sProd.getPrdType().toString(), sProd.isPriceStopped());
        if (!sProd.isPriceStopped()) {
            stageValidation.validation(user.getTenant()).isValidPriceToStage(sProd.getProduct(),
                    sProd.getPriceSU(),
                    priceValidation.calculateMinimalPrice(stdPrice, storeProduct.getMaxDecrease()),
                    priceValidation.calculateMaxPrice(stdPrice, storeProduct.getMaxIncrease(), user.getTenant()));
        }

        if (isUsefulPrice(sProd.getProduct().getEan(), sProd.getPriceSU(), stdPrice)) {
            PriceUpdate exPriceUpdate = priceUpdateRepository.findByProductAndStore(sProd.getProduct(), user.getStore());
            final PriceUpdate pUpdate = Optional.ofNullable(exPriceUpdate).orElse(new PriceUpdate());
            pUpdate.setStore(user.getStore());
            pUpdate.setProduct(sProd.getProduct());
            pUpdate.setPUser(user);
            pUpdate.setRef(ref);
            pUpdate.setTenant(user.getTenant());
            pUpdate.setStartDate(sProd.getSDate());
            pUpdate.setEndDate(Optional.ofNullable(sProd.getEDate()).orElse(DateUtils.formattedDate("9999-12-31")));
            pUpdate.setPrdType(sProd.getPrdType());
            pUpdate.setCPrice(sProd.getCostPrice());
            pUpdate.setModTime(LocalDateTime.now());
            pUpdate.setPrice(sProd.getPriceSU());
            pUpdate.setStoppedPrice(sProd.isPriceStopped() ? PRICE_FLAG_YES : PRICE_FLAG_NO);
            var costPriceVat = priceValidation.calculateCostPriceInclusiveOfVat(Optional.ofNullable(sProd.getCostPrice()).orElse(0.0), sProd.getProduct(), user);
            pUpdate.setStatus(!sProd.isPriceStopped() && costPriceVat > sProd.getPriceSU() ? PriceValidationStatus.PENDING.getStatus()
                    : PriceValidationStatus.APPROVED.getStatus());
            if (ProductType.WarList.toString().equals(sProd.getPrdType().toString())) {
                pUpdate.setIndex(sProd.getIndex());
            }
            if (sProd.isPriceStopped()) {
                PriceUpdate pUpdateDup = new PriceUpdate(pUpdate);
                pUpdateDup.setStartDate(LocalDate.now().atStartOfDay());
                pUpdateDup.setEndDate(DateUtils.formattedDate("9999-12-31"));
                priceDetails.add(pUpdateDup);
            } else {
                priceDetails.add(pUpdate);
            }
        }
    }

    public boolean isUsefulPrice(final String ean, final Double priceSu, final Double stdPrice) {
        log.debug("Ean {}: price {}, stdPrice {}", ean, priceSu, stdPrice);
        return !Objects.equals(priceSu, stdPrice);
    }

    public void calculateProductPrice(final StageDataRequest req, final Product product, final boolean isStoppedPrice,
                                       final StageProduct stageProduct, final User user, final int currentStockQty,
                                       final CategoryRoundingResponse cRounding) {
        StopWatch stopWatch = logService.logStopWatchStart("calculateProductPrice");

        final double remQtyToSell = StringUtils.isNotEmpty(req.getRqSell()) ? Double.parseDouble(req.getRqSell()) : 0;
        final double stgPrice = StringUtils.isNotEmpty(req.getPrice()) ? Double.parseDouble(req.getPrice()) : 0.0;
        final double vat = productTools.getVATByJurisdictionIdAndClassificationCode(product.getVatCategory(), user);
        final RoundingType roundingTypeFromConfig = helperService.fetchRoundingType(product, cRounding);
        final boolean isAllowedRounding = !ProductType.OutOfRange.name().equalsIgnoreCase(req.getPrdType());

        if (STAGING_PRD_TYPES.contains(req.getPrdType())) {
            final double comPrice = StringUtils.isNotEmpty(req.getCPrice()) ? Double.parseDouble(req.getCPrice()) :
                    assignmentItemService.setCompetitorPrice(product, user);
            //SU=UV, UM=UL
            if (isStoppedPrice) {
                // don't apply rounding if stopped price
                stageProduct.setPriceUM(stgPrice / product.getConversion());
                stageProduct.setPriceSU(stgPrice);
            } else if (req.isReview()) {
                // input price will come as SU
                double finalPrice = applyRounding(roundingTypeFromConfig, RoundingType.UV, stgPrice, user.getTenant(), isAllowedRounding);
                stageProduct.setPriceUM(finalPrice / product.getConversion());
                stageProduct.setPriceSU(finalPrice);
            } else {
                setUOMAndSuPrices(req, product, stageProduct, user, stgPrice, roundingTypeFromConfig, isAllowedRounding);
            }
            stageProduct.setIndex(0 != comPrice ? stageProduct.getPriceUM() / comPrice * 100 : stageProduct.getPriceUM() * 100);

        } else {
            if (isStoppedPrice) {
                // don't apply rounding if stopped price
                stageProduct.setPriceUM(stgPrice / product.getConversion());
                stageProduct.setPriceSU(stgPrice);
            } else {
                setUOMAndSuPrices(req, product, stageProduct, user, stgPrice, roundingTypeFromConfig, isAllowedRounding);
            }

            final StockInfo stockInfo = stockProvisionsService.getStockInfo(user, product, 0, req.getCostPrice());
            final Recommandation recommandation = stockProvisionsService.getRecommendation(stockInfo, req.getStdPrice());
            recommandation.setRemQtyToSell(DecimalUtils.roundOf(remQtyToSell, DecimalUtils.ROUND_OF_0));

            ProvisionDetails provDetails = new ProvisionDetails(currentStockQty, stockInfo.getWeeklyStock().getPRate(), recommandation);
            productTools.updateNrvAndMargin(req.getPrdType(), stageProduct, stgPrice, req.getStorePrice(), provDetails, vat);
        }

        calculateMarginRates(product, stageProduct, user, req.getCostPrice(), req.getStorePrice(), vat);
        stageProduct.setLastUpdatedTime(LocalDateTime.now());
        stageProduct.setProduct(product);
        stageProduct.setPrdType(ProductType.valueOf(req.getPrdType()));
        logService.logStopWatchStop(stopWatch);
    }

    private void setUOMAndSuPrices(StageDataRequest req, final Product product, StageProduct stageProduct, final User user,
                                   double stgPrice, final RoundingType roundingTypeFromConfig, final boolean isAllowedRounding) {
        if (PRODUCT_PRICE_SU.equalsIgnoreCase(req.getPriceType())) {
            double finalPrice = applyRounding(roundingTypeFromConfig, RoundingType.UV, stgPrice, user.getTenant(), isAllowedRounding);
            stageProduct.setPriceUM(finalPrice / product.getConversion());
            stageProduct.setPriceSU(finalPrice);
        } else {
            // input price will come as UM
            double finalPrice = applyRounding(roundingTypeFromConfig, RoundingType.UL, stgPrice, user.getTenant(), isAllowedRounding);
            stageProduct.setPriceUM(finalPrice);
            stageProduct.setPriceSU(finalPrice * product.getConversion());
        }
    }

    private void calculateMarginRates(final Product product, StageProduct sProd, final User user, double costPrice,
                                      double storePrice, double vat) {
        double mRate = (((storePrice / vat) - costPrice) / costPrice) * 100;
        if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
            sProd.setMarginRate(mRate);
            sProd.setNewMarginRate(null != sProd.getPriceSU()
                                           ? (((sProd.getPriceSU() / vat) - costPrice) / costPrice) * 100 : 0);
        } else if (TENANT_CAFR.equalsIgnoreCase(user.getTenant())) {
            sProd.setMarginRate(mRate);
            sProd.setNewMarginRate(null != sProd.getPriceUM() ?
                    (((sProd.getPriceUM() * product.getConversion() / vat) - costPrice) / costPrice) * 100
                                           : 0);
        }
        log.debug("New Margin Rate: {}, cost Price: {}", sProd.getNewMarginRate(), costPrice);
        sProd.setMarginDiff(sProd.getMarginRate() - sProd.getNewMarginRate());
        sProd.setTheoriticalMarginRate(sProd.getMarginRate());
        sProd.setReqMarginRate(sProd.getNewMarginRate());
    }

    public static double applyRounding(final RoundingType incomingRoundingType, final RoundingType expectedRoundingType,
                                       final double priceToRound, final String tenant, final boolean isRoundingAllowed) {
        return RoundOffPrice.roundOffPrice(priceToRound,
                isRoundingAllowed && TENANT_BDFR.equalsIgnoreCase(tenant) && expectedRoundingType.equals(incomingRoundingType));
    }

    public void suGreaterThanStdPrice(final Product product, final CollectionProduct cPrd, final boolean roundOff,
                                      final double stdPrice) {
        if (cPrd.getPriceSU() > stdPrice) {
            cPrd.setPriceSU(RoundOffPrice.roundOffPrice(stdPrice, roundOff));
            cPrd.setPriceUOM(RoundOffPrice.roundOffPrice(cPrd.getPriceSU() / product.getConversion(), roundOff));
        }
    }

    public void applyRounding(final double priceToRound, final Product product, final CollectionProduct cPrd,
                              final Double stdPrice, final String catType, final String tenant, final boolean roundingAllowed) {
        if (TENANT_BDFR.equals(tenant)) {
            setCalculatedPrice(priceToRound, product, cPrd, roundingAllowed, stdPrice, catType);
        } else {
            cPrd.setPriceSU(priceToRound);
            cPrd.setPriceUOM(cPrd.getPriceSU() / product.getConversion());
        }
    }

    public void setCalculatedPrice(final double priceToRound, final Product product, final CollectionProduct cPrd,
                                   final boolean isRoundingAllowed, final double stdPrice, final String catType) {
        if (RoundingType.UL.toString().equals(catType)) {
            cPrd.setPriceUOM(RoundOffPrice.roundOffPrice(priceToRound, isRoundingAllowed));
            cPrd.setPriceSU(Double.parseDouble(DecimalUtils.roundOf(
                    RoundOffPrice.roundOffPrice(cPrd.getPriceUOM() * product.getConversion(), isRoundingAllowed), DecimalUtils.ROUND_OF_2)));
            suGreaterThanStdPrice(product, cPrd, isRoundingAllowed, stdPrice);
        } else {
            cPrd.setPriceSU(RoundOffPrice.roundOffPrice(priceToRound, isRoundingAllowed));
            cPrd.setPriceUOM(RoundOffPrice.roundOffPrice(cPrd.getPriceSU() / product.getConversion(), isRoundingAllowed));
            suGreaterThanStdPrice(product, cPrd, isRoundingAllowed, stdPrice);
        }
    }

    public String calculateSUPrice(double stdNPrice, StoreCollectionHoSpreadsheetData data) {
        String price = "0.0";
        if (CollectionStatus.Completed.equals(CollectionStatus.valueOf(data.getStatus()))) {
            RoundingType type = null != data.getCatRoundingType() ? RoundingType.values()[data.getCatRoundingType()] : RoundingType.UV;
            double clPrice = Math.min(data.getCollectedPrice(), stdNPrice);
            price = String.valueOf(priceAfterConversion(clPrice, data.getConversion(), stdNPrice, type));
        }
        return price;
    }

    public double priceAfterConversion(final double priceToRound, final Double conversion, double stdNPrice,
                                       RoundingType type) {
        CollectionProduct clProduct = new CollectionProduct();
        if (RoundingType.UL.equals(type)) {
            clProduct.setPriceUOM(priceToRound);
            clProduct.setPriceSU(priceToRound * conversion);
        } else {
            clProduct.setPriceUOM(priceToRound / conversion);
            clProduct.setPriceSU(priceToRound);
        }
        return Math.min(clProduct.getPriceSU(), stdNPrice);
    }

    public String getPromoMessage(final String status, final boolean isHasPromo) {
        return isHasPromo && (CollectionStatus.Completed.equals(CollectionStatus.valueOf(status)) ||
                CollectionStatus.Reported.equals(CollectionStatus.valueOf(status))) ?
                PROMO_ON : PRICE_FLAG_NO;
    }

    public double getStageSUPrice(final double stgPrice, final boolean isStoppedPrice, final boolean isReview,
                                  final Product product, final String priceType) {
        double suPrice;
        if (isStoppedPrice || isReview || PRODUCT_PRICE_SU.equalsIgnoreCase(priceType)) {
            suPrice = stgPrice;
        } else {
            suPrice = stgPrice * product.getConversion();
        }
        return suPrice;
    }

    public void getSuPriceFromCollectedPrice(Set<ProductPrice> prdPrices, final Map<String, Double> eanClusterPriceMap,
                                             Map<String, Product> eanProductMapWithoutChained, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getSuPriceFromCollectedPrice");

        final double[] stdNPrice = new double[1];
        prdPrices.forEach(prdPrice -> {
            double price = prdPrice.getConvertedPrice();
            stdNPrice[0] = getStdPriceBasedOnCatType(prdPrice, eanProductMapWithoutChained, eanClusterPriceMap, user);

            if ((TENANT_BDFR.equalsIgnoreCase(user.getTenant()))) {
                double su;
                if (stdNPrice[0] < price) {
                    su = stdNPrice[0];
                    price = su;
                }
            } else {
                price = Math.min(stdNPrice[0], price * prdPrice.getConversion());
            }
            prdPrice.setPrice(price);
        });
        logService.logStopWatchStop(stopWatch);
    }

    private double getStdPriceBasedOnCatType(ProductPrice prdPrice, final Map<String, Product> eanProductMapWithoutChained,
                                             final Map<String, Double> eanClusterPriceMap, final User user) {
        var clusterPrice = eanClusterPriceMap.get(prdPrice.getEan());
        double stdPrice = storePriceService.deriveStandardPrice(prdPrice.getNPrice(), prdPrice.getSPrice(), user, clusterPrice);
        if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
            Product product = eanProductMapWithoutChained.getOrDefault(prdPrice.getEan(), new Product());
            stdPrice = RoundingType.UL.toString().equals(prdPrice.getCatType()) ? stdPrice / product.getConversion() : stdPrice;
        }
        return stdPrice;
    }

    @Transactional
    public void savePriceDetails(final Set<PriceUpdate> priceUpdates, final Set<StoreCollection> listOfSc) {
        priceUpdateRepository.saveAll(priceUpdates);
        productTools.updateScStatusAndSave(listOfSc);
    }

    public ProductItem setStagedProductItem(final Product product, final String type, final User user, final MasterData masterData) {
        final ProductItem pItem = new ProductItem();
        var storePrice = masterData.getEanStorePriceMap().getOrDefault(product.getEan(), new StorePrice());
        var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
        var clusterPrice = masterData.getEanClusterPriceMap().get(product.getEan());
        var sProd = masterData.getProductStoreProductMap().get(product);
        var price = storePriceService.getStorePriceWithCluster(nPrice, storePrice, user, clusterPrice);
        var costPrice = masterData.getEanCostPriceMap().getOrDefault(product.getEan(), MAP_0);
        var costPriceVat = priceValidation.calculateCostPriceInclusiveOfVat(Double.parseDouble(costPrice), product, user);

        pItem.setHisPrice(priceHistoryService.setLatestPriceHistory(product, user.getStore()));
        pItem.setPConversion(helperService.getConversionDetails(product, new CategoryRoundingResponse()));
        pItem.setEan(product.getEan());
        pItem.setCat(product.getCategory());
        pItem.setPCode(product.getProductCode());
        pItem.setSCat(product.getSubCategory());
        pItem.setBName(product.getBrickName());
        pItem.setDesc(product.getDescription());
        pItem.setUom(product.getUom());
        pItem.setStoreAppPrice(DecimalUtils.roundOf(price, ROUND_OF_2));
        pItem.setStdPrice(DecimalUtils.roundOf(storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice), ROUND_OF_2));
        pItem.setCostPrice(DecimalUtils.roundOf(Double.parseDouble(costPrice), ROUND_OF_2));
        pItem.setCostPriceVat(DecimalUtils.roundOf(Double.parseDouble(String.valueOf(costPriceVat)), ROUND_OF_2));
        pItem.setType(type);
        pItem.setShowDatePicker(storeProductService.isShowDatePicker(type, user));
        pItem.setStgPrice(helperService.getStagePriceInfo(product, type, user, Double.parseDouble(pItem.getCostPrice()), null,
                new ProvisionDetails(0, 0.0, null), price));
        pItem.setEditable(null!=sProd && sProd.isEditable());
        pItem.setEnableStopPrice(!crConfig.isStopPrice() || isStoppedLocalPrice(storePrice, nPrice));
        pItem.setPrdList(productTools.filterNonEligibleProductByStatus(product) && masterData.getValidPrdListingMap().getOrDefault(product.getEan(), true));

        return pItem;
    }

    public boolean isStoppedLocalPrice(final StorePrice storePrice, final Double nPrice) {
        String priceType = Optional.ofNullable(storePrice).map(StorePrice::getPriceTypeFlag).orElse(EMPTY_STR);
        return (VKP0.equalsIgnoreCase(priceType)) && (null != storePrice && !nPrice.equals(storePrice.getPrice()));
    }

    @Transactional
    public void saveErrorMessagesResponse(final PriceListResponse response) {
        if (crConfig.isMassUpload() && CollectionUtils.isNotEmpty(response.getPricelistErrors())) {
            String errorKey = UUID.randomUUID().toString();
            response.setErrorKey(errorKey);

            ImportErrors importErrors = new ImportErrors();
            importErrors.setErrorKey(errorKey);
            importErrors.setErrorJson(response);
            importErrors.setLastUpdated(LocalDateTime.now());

            importErrorsRepository.save(importErrors);
            log.info("error_key --> {}", errorKey);
        }
    }

}