package com.kingfisher.compprice.enums;

import lombok.Getter;

@Getter
public enum PriceValidationStatus {
	APPROVED("Approved"),
	REJECT("Reject"),
	PENDING("Pending"),
	EXTRACTED("Extracted");

	private final String status;

	PriceValidationStatus(String status) {
		this.status = status;
	}

}