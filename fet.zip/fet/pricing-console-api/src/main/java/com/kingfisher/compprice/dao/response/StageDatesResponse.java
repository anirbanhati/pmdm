package com.kingfisher.compprice.dao.response;

import com.kingfisher.compprice.dao.EanDates;
import com.kingfisher.jsonapi.Resource;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StageDatesResponse implements Resource {

    private static final long serialVersionUID = -1896367278880220168L;

    private List<EanDates> products;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}