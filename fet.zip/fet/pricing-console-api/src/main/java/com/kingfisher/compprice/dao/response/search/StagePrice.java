package com.kingfisher.compprice.dao.response.search;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StagePrice implements Serializable {

	private static final long serialVersionUID = -49543877676664005L;
	private String price;
	private LocalDateTime sDate;
	private LocalDateTime eDate;
	private LocalDateTime lDate;
	private String newPriceUM;
	private String priceUOM;
	private String priceSU;
	private String index;
	private String cmRate;
	private String tRate;
	private String reqRate;
	@JsonProperty("nmRate")
	private String newMargingRate;
	private String mgDiff;
	private String miOnStock;
	private String nrv;
	private boolean priceStop;
}
