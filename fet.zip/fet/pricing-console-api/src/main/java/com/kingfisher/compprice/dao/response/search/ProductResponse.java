package com.kingfisher.compprice.dao.response.search;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProductResponse implements Serializable {

	private static final long serialVersionUID = -4550512188514504984L;
	private String ean;
	private String desc;
	private String cat;
	private String sCat;
	private String bName;
	private String pCode;
	private String pkg2;
	private String uom;
	private String costPrice;
	private String costPriceVat;
	private String stdPrice;
	private boolean showDatePicker;
	private StorePriceResponse storePrice;
	private String type;
	private String fixedPriceFlag;
	private StagePrice stgPrice;
	private String chainId;
	private boolean editable;
	private String catType;
	private boolean enableStopPrice;
	private boolean isPrdList;

}