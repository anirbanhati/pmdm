package com.kingfisher.compprice.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.enums.PriceValidationStatus.REJECT;
import static com.kingfisher.compprice.util.constants.Constants.STATUS_FAILURE;
import static com.kingfisher.compprice.util.constants.Constants.STATUS_SUCCESS;
import static com.kingfisher.compprice.util.constants.SchedulerConstants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataPurgeService {

    @Value("${cron.days.user}")
    private long userPurgeDays;
    @Value("${cron.days.price}")
    private long pricePurgeDays;
    @Value("${cron.days.productPrice}")
    private long productPricePurgeDays;
    @Value("${cron.days.salesHistory}")
    private long salesHistoryPurgeDays;
    @Value("${cron.days.hoScObject}")
    private long hoScObjectPurgeDays;
    @Value("${cron.days.importErrors}")
    private long importErrorsPurgeDays;
    @Value("${cron.days.rollingDays}")
    private long rollingDaysPurgeDays;
    @Value("${user.statusCodeForPurging}")
    private String statusCodeForPurging;
    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketName;
    @Value("${cron.days.storeCollection}")
    private int storeCollectionPurgeDays;
    @Value("${aws.s3.path}")
    private String path;
    @Value("${cron.days.schedulerStatus}")
    private long schedulerPurgeDays;

    private final AmazonS3 client;
    private final HelperService helperService;
    private final StoreProductRepository storeProductRepository;
    private final SalesHistoryRepository salesHistoryRepository;
    private final StorePriceRepository storePriceRepository;
    private final PriceUpdateRepository priceUpdateRepository;
    private final UserRepository userRepository;
    private final ProductListingRepository productListingRepository;
    private final ImportErrorsRepository importErrorsRepository;
    private final RollingDaysRepository rollingDaysRepository;
    private final StoreCollectionRepository storeCollectionRepository;
    private final SchedulerStatusRepository schedulerStatusRepository;
    private final ClusterPriceRepository clusterPriceRepository;


    @Transactional
    public void purgeStoreProductData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<StoreProduct> storeProducts = new ArrayList<>();
        try {
            storeProducts = storeProductRepository.findByPrdTypeIsNull();
            if (CollectionUtils.isNotEmpty(storeProducts)) {
                storeProductRepository.deleteAllInBatch(storeProducts);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeStoreProductData  :: {} ", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_STORE_PRODUCT, startTime, status);
        schedulerLogger(PURGE_STORE_PRODUCT, storeProducts.size(), status);
    }

    @Transactional
    public void purgeUserData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<User> users = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgeUserData = getEffectivePurgeDate(userPurgeDays);
            log.info("Effective date to purge user data :: {} :: user status code :: {}", effectiveDateToPurgeUserData, statusCodeForPurging);
            users = userRepository.findByWorkerStatusCodeAndLastUpdateTimeBefore(statusCodeForPurging, effectiveDateToPurgeUserData);
            if (CollectionUtils.isNotEmpty(users)) {
                userRepository.deleteAllInBatch(users);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeUserData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_USER, startTime, status);
        schedulerLogger(PURGE_USER, users.size(), status);
    }

    @Transactional
    public void purgeSalesHistoryData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<SalesHistory> salesHistoryListForPurging = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgeSalesData = getEffectivePurgeDate(salesHistoryPurgeDays);
            log.info("Effective date to purge sales data :: {}", effectiveDateToPurgeSalesData);
            salesHistoryListForPurging = salesHistoryRepository.findBySalesDateBefore(effectiveDateToPurgeSalesData);
            if (CollectionUtils.isNotEmpty(salesHistoryListForPurging)) {
                salesHistoryRepository.deleteAllInBatch(salesHistoryListForPurging);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeSalesHistoryData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_SALES_HISTORY, startTime, status);
        schedulerLogger(PURGE_SALES_HISTORY, salesHistoryListForPurging.size(), status);
    }

    @Transactional
    public void purgePriceData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<StorePrice> storePricePurgingData = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgePriceData = getEffectivePurgeDate(pricePurgeDays);
            log.info("Effective date to purge price data :: {}", effectiveDateToPurgePriceData);
            storePricePurgingData = storePriceRepository.findByEndDateBefore(effectiveDateToPurgePriceData);
            if (CollectionUtils.isNotEmpty(storePricePurgingData)) {
                storePriceRepository.deleteAll(storePricePurgingData);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgePriceData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_PRICE, startTime, status);
        schedulerLogger(PURGE_PRICE, storePricePurgingData.size(), status);
    }

    @Transactional
    public void purgeProductPriceData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<PriceUpdate> productPricePurgingData = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgeProductPriceData = getEffectivePurgeDate(productPricePurgeDays);
            log.info("Effective date to purge product price data :: {}", effectiveDateToPurgeProductPriceData);
            productPricePurgingData = priceUpdateRepository.findByPriceOrStatusOrExtractedDateBefore(0, REJECT.getStatus(), effectiveDateToPurgeProductPriceData);
            if (CollectionUtils.isNotEmpty(productPricePurgingData)) {
                priceUpdateRepository.deleteAll(productPricePurgingData);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeProductPriceData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_PRODUCT_PRICE, startTime, status);
        schedulerLogger(PURGE_PRODUCT_PRICE, productPricePurgingData.size(), status);
    }

    @Transactional
    public void purgeListingData() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<ProductListing> expiredListings = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgePurgeListingData = LocalDateTime.now().toLocalDate().atStartOfDay();
            log.info("Effective date to purge product listing data :: {}", effectiveDateToPurgePurgeListingData);
            expiredListings = productListingRepository.findByEndDateBefore(effectiveDateToPurgePurgeListingData);
            if (CollectionUtils.isNotEmpty(expiredListings)) {
                productListingRepository.deleteAll(expiredListings);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeListingData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_PRODUCT_LISTING, startTime, status);
        schedulerLogger(PURGE_PRODUCT_LISTING, expiredListings.size(), status);
    }

    @Transactional
    public void purgeImportErrors() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<ImportErrors> dataToPurge = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgeImportErrorsData = getEffectivePurgeDate(importErrorsPurgeDays);
            log.info("Effective date to purge import errors data :: {}", effectiveDateToPurgeImportErrorsData);
            dataToPurge = importErrorsRepository.findAllByLastUpdatedBefore(effectiveDateToPurgeImportErrorsData);
            if (CollectionUtils.isNotEmpty(dataToPurge)) {
                importErrorsRepository.deleteAllInBatch(dataToPurge);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeImportErrors  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_IMPORT_ERRORS, startTime, status);
        schedulerLogger(PURGE_IMPORT_ERRORS, dataToPurge.size(), status);
    }

    @Transactional
    public void purgeRollingDays() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<RollingDays> rollingDaysData = new ArrayList<>();
        try {
            LocalDateTime effectiveDateToPurgeRollingDaysData = getEffectivePurgeDate(rollingDaysPurgeDays);
            rollingDaysData = rollingDaysRepository.findAllByOrderByLastUpdatedDesc();
            log.info("Rolling Days: Effective date :: {}, Total Rolling Days records before purge :: {}", effectiveDateToPurgeRollingDaysData, rollingDaysData.size());
            if (CollectionUtils.isNotEmpty(rollingDaysData)) {
                rollingDaysData.remove(0);
                rollingDaysData.removeIf(rollingDays -> rollingDays.getLastUpdated().isAfter(effectiveDateToPurgeRollingDaysData));
                rollingDaysRepository.deleteAllInBatch(rollingDaysData);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeRollingDays  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_ROLLING_DAYS, startTime, status);
        schedulerLogger(PURGE_ROLLING_DAYS, rollingDaysData.size(), status);
    }

    @Transactional
    public void purgeStoreCollections() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        Set<StoreCollection> storeCollections = new HashSet<>();
        try {
            LocalDateTime effectiveDate = LocalDate.now().atStartOfDay().minusDays(this.storeCollectionPurgeDays);
            log.info("Effective date to purge store collection :: {}", effectiveDate);
            storeCollections = storeCollectionRepository.findByCreationTimeBefore(effectiveDate);
            if (CollectionUtils.isNotEmpty(storeCollections)) {
                storeCollectionRepository.deleteAll(storeCollections);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeStoreCollections  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_STORE_COLLECTION, startTime, status);
        schedulerLogger(PURGE_STORE_COLLECTION, storeCollections.size(), status);
    }

    @Transactional
    public void purgeSchedulerStatus() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<SchedulerStatus> schedulerStatuses = new ArrayList<>();
        try {
            LocalDateTime effectiveDate = getEffectivePurgeDate(schedulerPurgeDays);
            log.info("Effective date to purge scheduler status data :: {}", effectiveDate);
            schedulerStatuses = schedulerStatusRepository.findAllByUpdatedAtBefore(effectiveDate);
            if (CollectionUtils.isNotEmpty(schedulerStatuses)) {
                schedulerStatusRepository.deleteAll(schedulerStatuses);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeSchedulerStatusData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_SCHEDULER_STATUS, startTime, status);
        schedulerLogger(PURGE_SCHEDULER_STATUS, schedulerStatuses.size(), status);
    }

    @Transactional
    public void purgeClusterPrice() {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        List<ClusterPrice> clusterPrices = new ArrayList<>();
        try {
            LocalDateTime effectiveDate = LocalDateTime.now().toLocalDate().atStartOfDay();
            log.info("Effective date to purge cluster price data :: {}", effectiveDate);
            clusterPrices = clusterPriceRepository.findByEndDateBefore(effectiveDate);
            if (CollectionUtils.isNotEmpty(clusterPrices)) {
                clusterPriceRepository.deleteAll(clusterPrices);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in purgeClusterPriceData  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_CLUSTER_PRICE, startTime, status);
        schedulerLogger(PURGE_CLUSTER_PRICE, clusterPrices.size(), status);
    }

    public void deleteS3Items() {
        LocalDateTime effectiveDate = LocalDate.now().atStartOfDay().minusDays(hoScObjectPurgeDays);
        log.info("PathKey --> {}, effectiveDate--> {}", path, effectiveDate);

        ListObjectsV2Request request = new ListObjectsV2Request();
        request.setBucketName(bucketName);
        request.setStartAfter(path);

        removeObjectsFromBucket(getValidKeysForPurging(effectiveDate, request));
    }

    @NotNull
    private String[] getValidKeysForPurging(final LocalDateTime effectiveDate, final ListObjectsV2Request request) {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        String[] keys = new String[0];
        try {
        keys = client.listObjectsV2(request).getObjectSummaries().stream()
                .filter(object -> {
                    LocalDateTime lastModified = object.getLastModified().toInstant()
                            .atZone(ZoneId.systemDefault())
                            .toLocalDateTime();
                    log.info("Key | ModTime --> {} | {}", object.getKey(), lastModified);
                    return effectiveDate.isAfter(lastModified);
                })
                .map(S3ObjectSummary::getKey)
                .toArray(String[]::new);
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in deleteS3Items(getValidKeysForPurging)  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_HO_SC_OBJECT, startTime, status);
        schedulerLogger(PURGE_HO_SC_OBJECT, keys.length, status);
        return keys;
    }

    private void removeObjectsFromBucket(final String[] keys) {
        final LocalDateTime startTime = LocalDateTime.now();
        String status = STATUS_SUCCESS;
        try {
            if (ArrayUtils.isNotEmpty(keys)) {
                var deleteObjects = new DeleteObjectsRequest(bucketName).withKeys(keys);
                client.deleteObjects(deleteObjects);
            }
        } catch (final Exception e) {
            status = STATUS_FAILURE;
            log.error("exception occurred in deleteS3Items(removeObjectsFromBucket)  :: {}", e.getMessage());
        }
        helperService.saveSchedulerStatusInfo(PURGE_HO_SC_OBJECT, startTime, status);
        schedulerLogger(PURGE_HO_SC_OBJECT, keys.length, status);
    }

    private LocalDateTime getEffectivePurgeDate(long purgeDuration) {
        return LocalDate.now().atStartOfDay().minusDays(purgeDuration);
    }

    private void schedulerLogger(final String schedulerName, final long totalRecords, final String status) {
        log.info("{} {} {}",
                StructuredArguments.keyValue("SchedulerName", schedulerName),
                StructuredArguments.keyValue("TotalRecords", totalRecords),
                StructuredArguments.keyValue("Status", status));
    }

}