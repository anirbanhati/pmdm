package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.request.RoundingRequest;
import com.kingfisher.compprice.dao.response.ProductDetailsResponse;
import com.kingfisher.compprice.dao.response.ProductSearchResponse;
import com.kingfisher.compprice.dao.response.RoundingResponse;
import com.kingfisher.compprice.dao.response.search.ProductChainItem;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Tag(name = Constants.TAG_PRODUCT)
public interface ProductControllerSwagger {

	@Operation(description = "Get hierarchy by product type", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	MultiDataResponse<Category> getHierarchyByProductType(
			@Parameter(name = Constants.PRD_TYPE, required = true) @NonNull @RequestParam(Constants.PRD_TYPE) final List<String> prdType);

	@Operation(description = "Search products by search criteria with pagination")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) }) SingleDataResponse<ProductSearchResponse> searchProductsByCriteria(
			@RequestBody ProductSearchCriteria searchCriteria);

	@Operation(description = "Get product details by ean and product type", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	SingleDataResponse<ProductDetailsResponse> getProductDetailsByEanAndType(
			@Parameter(name = PRODUCT_EAN, required = true) @NonNull @RequestParam(PRODUCT_EAN) final String ean,
			@Parameter(name = Constants.PRD_TYPE, required = true) @NonNull @RequestParam(Constants.PRD_TYPE) final String prdType);

	@Operation(description = "Get chained products by chainId", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	MultiDataResponse<ProductChainItem> getChainedProductsByChainId(String chainId);

	@Operation(description = "Get Rounded price", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	SingleDataResponse<RoundingResponse> roundedProduct(@RequestBody RoundingRequest request);

}