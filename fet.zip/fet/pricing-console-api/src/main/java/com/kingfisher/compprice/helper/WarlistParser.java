package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.product.Brick;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.product.SubCategory;
import com.kingfisher.compprice.dao.entity.WarlistInfo;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants.WarListExceptions;
import com.kingfisher.compprice.repository.WarlistInfoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class WarlistParser {

    private final WarlistInfoRepository warlistInfoRepository;


    @Transactional
    public Map<String, Category> getFilters(final String id) {
        final Optional<WarlistInfo> warListInfo = this.getWarLIstInfoById(id);
        Map<String, Category> categoryTree;
        if (warListInfo.isPresent()) {
            final Set<Product> productList = warListInfo.get().getProducts();
            final Map<String, Category> mapOfFilter = new HashMap<>();
            categoryTree = getCategoryTree(productList, mapOfFilter);
        } else {
            throw new DetailsNotFoundException(WarListExceptions.WAR_PRODUCT_NOT_FOUND_APP_EXP,
                    WarListExceptions.WAR_PRODUCT_NOT_FOUND_HTTP_STATUS, WarListExceptions.WAR_PRODUCT_NOT_FOUND_DETAILS,
                    WarListExceptions.WAR_PRODUCT_NOT_FOUND_ID, WarListExceptions.WAR_PRODUCT_NOT_FOUND_POINTER,
                    id, WarListExceptions.WAR_PRODUCT_NOT_FOUND_TITLE);
        }
        return categoryTree;
    }

    private Optional<WarlistInfo> getWarLIstInfoById(final String id) {
        Optional<WarlistInfo> warListInfo;
        if (WAR_LIST_ID_LATEST.equals(id)) {
            warListInfo = warlistInfoRepository.findTopByOrderByLastUpdatedTimeDesc();
        } else {
            warListInfo = warlistInfoRepository.findById(Long.parseLong(id));
        }
        return warListInfo;
    }

    public Map<String, Category> getCategoryTree(final Set<Product> productList, final Map<String, Category> mapOfFilter) {
        log.debug("Size of products:: {}", productList.size());
        for (final Product product : productList) {
            if (hasMandatoryProductData(product)) {
                if (null != mapOfFilter.get(product.getCategory())) {
                    log.debug("mapOfFilter:: {}", mapOfFilter);
                    final Category category = mapOfFilter.get(product.getCategory());
                    prepareSubCategoryData(mapOfFilter, product, category);
                } else {
                    final Category category = this.setCategoryInTree(product);
                    mapOfFilter.put(product.getCategory(), category);
                }
            }
        }
        return mapOfFilter;
    }

    public boolean hasMandatoryProductData(final Product product) {
        return StringUtils.isNotEmpty(product.getCategory()) && StringUtils.isNotEmpty(product.getSubCategory()) &&
                StringUtils.isNotEmpty(product.getBrickCode()) && StringUtils.isNotEmpty(product.getBrickName());
    }

    private Category setCategoryInTree(final Product product) {
        final Category category = new Category();
        final List<SubCategory> subCategories = new ArrayList<>();
        final SubCategory subCategory = new SubCategory();
        final List<Brick> bricks = new ArrayList<>();
        final Brick brick = new Brick();
        brick.setName(product.getBrickName());
        brick.setCode(product.getBrickCode());
        bricks.add(brick);
        subCategory.setName(product.getSubCategory());
        subCategory.setBricks(bricks);
        subCategories.add(subCategory);
        category.setName(product.getCategory());
        category.setSubCategory(subCategories);
        return category;
    }

    public void prepareSubCategoryData(Map<String, Category> mapOfFilter, Product product, Category category) {
        if (CollectionUtils.isNotEmpty(category.getSubCategory())) {
            final Set<SubCategory> sCategories = new HashSet<>();
            final List<SubCategory> exSubCategories = category.getSubCategory();
            final Set<String> subCatNames = exSubCategories.stream().map(SubCategory::getName)
                    .collect(Collectors.toSet());
            for (final SubCategory subCategory : category.getSubCategory()) {
                setSubCategoryData(mapOfFilter, product, category, sCategories, subCatNames,
                        subCategory);
            }
        }
    }

    public void setSubCategoryData(final Map<String, Category> mapOfFilter, final Product product, final Category category,
                                   final Set<SubCategory> sCategories, final Set<String> subCatNames, final SubCategory subCategory) {
        SubCategory subCat;
        if (subCatNames.contains(product.getSubCategory())) {
            if (product.getSubCategory().equals(subCategory.getName())) {
                final List<Brick> bricks = subCategory.getBricks();
                final Set<String> brickCodes = bricks.stream().map(Brick::getCode)
                        .collect(Collectors.toSet());
                if (!brickCodes.contains(product.getBrickCode())) {
                    final Brick brick = new Brick();
                    brick.setName(product.getBrickName());
                    brick.setCode(product.getBrickCode());
                    bricks.add(brick);
                }
                subCategory.setBricks(bricks);
            }
        } else {
            subCat = setSubCategoryInTree(product);
            sCategories.add(subCat);
        }
        sCategories.add(subCategory);
        category.setSubCategory(new ArrayList<>(sCategories));
        mapOfFilter.put(product.getCategory(), category);
    }

    private SubCategory setSubCategoryInTree(final Product product) {
        final SubCategory subCat = new SubCategory();
        final List<Brick> bricks = new ArrayList<>();
        final Brick brick = new Brick();
        brick.setName(product.getBrickName());
        brick.setCode(product.getBrickCode());
        bricks.add(brick);
        subCat.setName(product.getSubCategory());
        subCat.setBricks(bricks);
        return subCat;
    }

}