package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.StoreCollectionSpreadsheetData;
import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StoreCollection;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants.ExcelImportExceptions;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static org.apache.commons.lang3.StringUtils.EMPTY;

@Component
@NoArgsConstructor
@Slf4j
public class ExcelFileHelper {

    public static final String DEPOT = "Dépot : ";
    public static final String ID = "N relevé : ";

    private StoreService storeService;

    @Autowired
    public ExcelFileHelper(StoreService storeService)
    {
        this.storeService = storeService;
    }


    public ByteArrayInputStream prepareFileDataForCollectionListForBdfr(final List<StoreCollectionSpreadsheetData> excelData,
                                                                        final StoreCollection storeCollection) {

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            final Sheet sheet = workbook.createSheet(SHEET_NAME);
            addDataIntoFirstRow(workbook, sheet, storeCollection);
            addDataIntoSecondRow(workbook, sheet);

            CellStyle style1 = createStyleWithBorders(workbook);
            style1.setWrapText(true);

            CellStyle style2 = createStyleWithBorders(workbook);
            style2.setWrapText(true);
            style2.setAlignment(HorizontalAlignment.CENTER);

            CellStyle style3 = createStyle(workbook);

            setHeaderValues(sheet, style3);
            setCellValues(excelData, sheet, style1, style2);

            PrintSetup printSetup = sheet.getPrintSetup();
            //Scaling : Fit all columns in one page
            sheet.setFitToPage(true);
            printSetup.setFitWidth((short) 1);
            printSetup.setFitHeight((short) 0);
            //Orientation : Landscape
            printSetup.setLandscape(true);
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());

        } catch (final IOException e) {
            throw new DetailsNotFoundException(ExcelImportExceptions.EXCEL_IMPORT_APP_EXP,
                    ExcelImportExceptions.EXCEL_IMPORT_HTTP_STATUS, ExcelImportExceptions.EXCEL_IMPORT_DETAILS,
                    BULK_EXPORT, ExcelImportExceptions.EXCEL_IMPORT_POINTER, EXPORT,
                    ExcelImportExceptions.EXCEL_IMPORT_TITLE);
        }
    }

    private static void setHeaderValues(Sheet sheet, CellStyle style3) {

        final Row headerRow = sheet.createRow(3);
        for (int col = 0; col < COLLECTION_LIST_HEADERS_BDFR.length; col++) {
            final Cell cell = headerRow.createCell(col);
            cell.setCellValue(COLLECTION_LIST_HEADERS_BDFR[col]);
            cell.getRow().setHeightInPoints(50);
            cell.setCellStyle(style3);
        }
        sheet.setColumnWidth(0, 7000);
        sheet.setColumnWidth(1, 4500);
        sheet.setColumnWidth(2, 7000);

        sheet.setColumnWidth(3, 3000);
        sheet.setColumnWidth(4, 3000);
        sheet.setColumnWidth(5, 3000);

        sheet.setColumnWidth(6, 4500);
        sheet.setColumnWidth(7, 4000);
        sheet.setColumnWidth(8, 3000);
        sheet.setColumnWidth(9, 5000);
        sheet.setColumnWidth(10, 3000);
        sheet.setColumnWidth(11, 7000);
    }

    private static void setCellValues(List<StoreCollectionSpreadsheetData> excelData, Sheet sheet, CellStyle style1, CellStyle style2) {
        final int[] rowIdx = {4};
        excelData.forEach(data -> {
            final Row row = sheet.createRow(rowIdx[0]);
            row.setHeightInPoints(30);
            final Cell cell0 = row.createCell(0);
            cell0.setCellValue(data.getCategory());
            cell0.setCellStyle(style1);
            final Cell cell1 = row.createCell(1);
            cell1.setCellValue(data.getEan());
            cell1.setCellStyle(style2);
            final Cell cell2 = row.createCell(2);
            cell2.setCellValue(data.getDescription());
            cell2.setCellStyle(style1);
            final Cell cell3 = row.createCell(3);
            cell3.setCellValue(UOM_EA.equalsIgnoreCase(data.getUom()) ? UOM_PC : data.getUom());
            cell3.setCellStyle(style2);
            final Cell cell4 = row.createCell(4);
            cell4.setCellValue(StringUtils.replace(DecimalUtils.roundOf(Double.parseDouble(data.getPackaging()), DecimalUtils.ROUND_OF_2), DOT_SEPARATOR, COMMA));
            cell4.setCellStyle(style2);
            final Cell cell5 = row.createCell(5);
            cell5.setCellValue(StringUtils.replace(Double.toString(data.getNationalPrice()), DOT_SEPARATOR, COMMA));
            cell5.setCellStyle(style2);
            final Cell cell6 = row.createCell(6);
            cell6.setCellValue(data.getCompetitorName());
            cell6.setCellStyle(style2);
            final Cell cell7 = row.createCell(7);
            cell7.setCellValue(data.getCompetitorStoreCode());
            cell7.setCellStyle(style2);
            final Cell cell8 = row.createCell(8);
            cell8.setCellValue(data.getCollectedPkgValue());
            cell8.setCellStyle(style2);
            final Cell cell9 = row.createCell(9);
            String value = StringUtils.replace(Double.toString(data.getCompetitorPrice()), DOT_SEPARATOR, COMMA);
            cell9.setCellValue(ZERO_ZERO.equals(value) ? EMPTY : value);
            cell9.setCellStyle(style2);
            final Cell cell10 = row.createCell(10);
            cell10.setCellValue(data.getPromoInfo());
            cell10.setCellStyle(style2);
            final Cell cell11 = row.createCell(11);
            cell11.setCellValue(data.getNotes());
            cell11.setCellStyle(style2);
            rowIdx[0]++;
        });
    }

    private void addDataIntoFirstRow(Workbook workbook, Sheet sheet, StoreCollection storeCollection) {
        Store store = storeService.getStoreByCode(storeCollection.getStoreCode());
        final Row headerRowRef1 = sheet.createRow(0);
        Cell cell1 = headerRowRef1.createCell(0);
        Cell cell2 = headerRowRef1.createCell(1);
        Cell cell3 = headerRowRef1.createCell(2);
        Cell cell4 = headerRowRef1.createCell(3);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));
        headerRowRef1.createCell(0).setCellValue(DEPOT + store.getStoreCode() + " - " + store.getStoreName());
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 2, 3));
        headerRowRef1.createCell(2).setCellValue(ID + storeCollection.getId());

        final Row headerRowRef2 = sheet.createRow(1);
        Cell cell5 = headerRowRef2.createCell(0);
        Cell cell6 = headerRowRef2.createCell(1);
        Cell cell7 = headerRowRef2.createCell(2);
        Cell cell8 = headerRowRef2.createCell(3);
        CompetitorStore comStore = storeService.getCompetitorStoreData(storeCollection);
        sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 1));
        headerRowRef2.createCell(0).setCellValue("Concurrent : " + (null != comStore ? comStore.getCode() : null) + " - " + (null != comStore ? comStore.getName() : null));
        sheet.addMergedRegion(new CellRangeAddress(1, 1, 2, 3));
        headerRowRef2.createCell(2).setCellValue("Lib.relevé : " + storeCollection.getName());

        setStyleForMainHeaders(workbook, List.of(cell1, cell2, cell3, cell4, cell5, cell6, cell7, cell8));
    }

    private void setStyleForMainHeaders(final Workbook workbook, final List<Cell> cells) {
        final CellStyle style = createStyleWithBorders(workbook);
        cells.forEach(cell -> cell.setCellStyle(style));
    }

    private void addDataIntoSecondRow(Workbook workbook, Sheet sheet) {
        final Row headerColMerge = sheet.createRow(2);
        Cell hcell10 = headerColMerge.createCell(0);
        Cell h1Cell11 = headerColMerge.createCell(1);
        Cell h2Cell12 = headerColMerge.createCell(2);
        Cell hcell = headerColMerge.createCell(3);
        Cell h1Cell = headerColMerge.createCell(4);
        Cell h2Cell = headerColMerge.createCell(5);
        Cell ccell = headerColMerge.createCell(6);
        Cell c1Cell = headerColMerge.createCell(7);
        Cell c2Cell = headerColMerge.createCell(8);
        Cell c3Cell = headerColMerge.createCell(9);
        Cell c4Cell = headerColMerge.createCell(10);
        Cell c5Cell = headerColMerge.createCell(11);

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 3, 5));
        headerColMerge.createCell(3).setCellValue("Dépot");
        setStyleDepot(workbook, hcell, h1Cell, h2Cell);

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 6, 11));
        headerColMerge.createCell(6).setCellValue("Concurrent");
        setStyleConcurrent(workbook, List.of(ccell, c1Cell, c2Cell, c3Cell, c4Cell, c5Cell));

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 0, 2));
        CellStyle style5 = createStyleWithBorders(workbook);
        hcell10.setCellStyle(style5);
        h1Cell11.setCellStyle(style5);
        h2Cell12.setCellStyle(style5);
    }

    private void setStyleDepot(Workbook workbook, Cell hcell, Cell h1Cell, Cell h2Cell) {
        final CellStyle style = createStyleWithBorders(workbook);
        style.setAlignment(HorizontalAlignment.CENTER);
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        hcell.setCellStyle(style);
        h1Cell.setCellStyle(style);
        h2Cell.setCellStyle(style);
    }

    public ByteArrayInputStream prepareFileDataForCollectionListForCafr(final List<StoreCollectionSpreadsheetData> excelData) {

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            final Sheet sheet = workbook.createSheet(SHEET_NAME);
            final Row headerRow = sheet.createRow(0);
            for (int col = 0; col < COLLECTION_LIST_HEADERS_CAFR.length; col++) {
                final Cell cell = headerRow.createCell(col);
                cell.setCellValue(COLLECTION_LIST_HEADERS_CAFR[col]);
            }
            int rowIdx = 1;
            for (final StoreCollectionSpreadsheetData data : excelData) {
                final Row row = sheet.createRow(rowIdx);
                row.createCell(0).setCellValue(data.getCategory());
                row.createCell(1).setCellValue(data.getSubCategory());
                row.createCell(2).setCellValue(data.getBrickName());
                row.createCell(3).setCellValue(data.getArticleNumber());
                row.createCell(4).setCellValue(data.getEan());
                row.createCell(5).setCellValue(data.getDescription());
                row.createCell(6).setCellValue(data.getUom());
                row.createCell(7).setCellValue(data.getPackaging());
                row.createCell(8).setCellValue(data.getNationalPrice());
                row.createCell(9).setCellValue(data.getCompetitorName());
                row.createCell(10).setCellValue(data.getCompetitorProductDescription());
                row.createCell(11).setCellValue(data.getCompetitorStoreCode());
                row.createCell(12).setCellValue(data.getCompetitorProductCollectedEAN());
                row.createCell(13).setCellValue(data.getCompetitorProductCollectedArticleCode());
                row.createCell(14).setCellValue(data.getCompetitorConversionUnit());
                row.createCell(15).setCellValue(data.getCompetitorQuantity());
                row.createCell(16).setCellValue(data.getCompetitorPrice());
                row.createCell(17).setCellValue(data.getPromoInfo());
                row.createCell(18).setCellValue(data.getNotes());
                rowIdx++;
            }
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (final IOException e) {
            throw new DetailsNotFoundException(ExcelImportExceptions.EXCEL_IMPORT_APP_EXP,
                    ExcelImportExceptions.EXCEL_IMPORT_HTTP_STATUS, ExcelImportExceptions.EXCEL_IMPORT_DETAILS,
                    BULK_EXPORT, ExcelImportExceptions.EXCEL_IMPORT_POINTER, EXPORT,
                    ExcelImportExceptions.EXCEL_IMPORT_TITLE);
        }
    }

    private void setStyleConcurrent(Workbook workbook, List<Cell> cells) {
        CellStyle style = createStyleWithBorders(workbook);
        style.setAlignment(HorizontalAlignment.CENTER);
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        cells.forEach(cell -> cell.setCellStyle(style));
    }


    public void prepareFirstTwoRows(Workbook workbook, Sheet sheet, final String scName, final Long scId) {
        final Row headerRow0 = sheet.createRow(0);   // 1st Row
        headerRow0.setHeightInPoints(20);
        Cell row0Cell3 = headerRow0.createCell(2);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 2));
        headerRow0.createCell(0).setCellValue("N° Relevé siège : " + Objects.requireNonNullElse(scId, EMPTY_STR));

        final Row headerRow1 = sheet.createRow(1);  // 2nd Row
        headerRow1.setHeightInPoints(20);
        Cell row1Cell1 = headerRow1.createCell(0);
        Cell row1Cell2 = headerRow1.createCell(1);
        Cell row1Cell3 = headerRow1.createCell(2);
        sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 2));
        headerRow1.createCell(0).setCellValue("Libellé Relevé siège : " + Objects.requireNonNullElse(scName, EMPTY_STR));

        setStyleForFirstTwoRows(workbook, row0Cell3, row1Cell1, row1Cell2, row1Cell3);
    }

    public void prepareThirdRow(Workbook workbook, Sheet sheet) {
        final Row headerRow2 = sheet.createRow(2);   // 3rd Row
        headerRow2.setHeightInPoints(30);
        Cell hCell1 = headerRow2.createCell(0);
        Cell hCell2 = headerRow2.createCell(1);
        Cell hCell3 = headerRow2.createCell(2);
        Cell headerCell4 = headerRow2.createCell(3);
        Cell headerCell5 = headerRow2.createCell(4);
        Cell headerCell6 = headerRow2.createCell(5);
        Cell headerCell7 = headerRow2.createCell(6);
        Cell headerCell8 = headerRow2.createCell(7);
        Cell headerCell9 = headerRow2.createCell(8);
        Cell headerCell10 = headerRow2.createCell(9);
        Cell headerCell11 = headerRow2.createCell(10);
        Cell hCell12 = headerRow2.createCell(11);
        Cell hCell13 = headerRow2.createCell(12);
        Cell hCell14 = headerRow2.createCell(13);
        Cell hCell15 = headerRow2.createCell(14);
        Cell hCell16 = headerRow2.createCell(15);
        Cell hCell17 = headerRow2.createCell(16);
        Cell hCell18 = headerRow2.createCell(17);
        Cell hCell19 = headerRow2.createCell(18);
        Cell hCell20 = headerRow2.createCell(19);
        Cell hCell21 = headerRow2.createCell(20);
        Cell hCell22 = headerRow2.createCell(21);
        Cell hCell23 = headerRow2.createCell(22);


        sheet.addMergedRegion(new CellRangeAddress(2, 2, 0, 2));
        hCell1.setCellValue("Relevé siège");
        setStyleDepotForHo(workbook, hCell1, hCell2, hCell3);

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 3, 11));
        headerCell4.setCellValue("Relevé Dépot");
        setStyleReleveDepot(workbook, List.of(headerCell4, headerCell5, headerCell6, headerCell7, headerCell8,
                headerCell9, headerCell10, headerCell11, headerCell11, hCell12));

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 12, 14));
        hCell13.setCellValue("Prix Dépot");
        setStylePrixDepot(workbook, hCell13, hCell14, hCell15);

        sheet.addMergedRegion(new CellRangeAddress(2, 2, 15, 21));
        hCell16.setCellValue("Prix Concurrent");
        setStyleConcurrentForHO(workbook, List.of(hCell16, hCell17, hCell18, hCell19, hCell20, hCell21, hCell22, hCell23));
    }

    public void prepareFourthRow(Workbook workbook, Sheet sheet) {
        CellStyle style = createStyle(workbook);
        style.setWrapText(true);

        final Row headerRow = sheet.createRow(3);  // 4th Row
        headerRow.setHeightInPoints(80);
        for (int columnNo = 0; columnNo < COLLECTION_LIST_HEADERS_FOR_HO.length; columnNo++) {
            final Cell cell = headerRow.createCell(columnNo);
            cell.setCellValue(COLLECTION_LIST_HEADERS_FOR_HO[columnNo]);
            cell.setCellStyle(style);
        }
    }

    public void setColumnWidthInSheet(Sheet sheet) {
        int[] columnWidths = {
                3000, 5000, 3000, 2000, 6000, 3000,
                10000, 3500, 5000, 6000, 3800, 4000,
                7000, 2000, 2500, 3000, 3500, 3200,
                2000, 3900, 2000, 2000, 5000
        };
        setColumnWidth(sheet, columnWidths);
    }

    public CellStyle createStyleForValues(Workbook workbook) {
        CellStyle style2 = createStyleWithBorders(workbook);
        style2.setWrapText(true);
        style2.setAlignment(HorizontalAlignment.CENTER);
        style2.setVerticalAlignment(VerticalAlignment.BOTTOM);
        return style2;
    }

    public void printSetupForSheet(SXSSFSheet sheet) {
        PrintSetup printSetup = sheet.getPrintSetup();
        //Scaling : Fit all columns in one page
        sheet.setFitToPage(true);
        printSetup.setFitWidth((short) 1);
        printSetup.setFitHeight((short) 0);
        //Orientation : Landscape
        printSetup.setLandscape(true);
    }

    private void setStyleForFirstTwoRows(Workbook workbook, Cell row0Cell3, Cell row1Cell1, Cell row1Cell2, Cell row1Cell3) {
        final CellStyle style = createStyleWithBorders(workbook);

        row0Cell3.setCellStyle(style);
        row1Cell1.setCellStyle(style);
        row1Cell2.setCellStyle(style);
        row1Cell3.setCellStyle(style);
    }

    private void setStyleDepotForHo(Workbook workbook, Cell hCell1, Cell hCell2, Cell hCell3) {
        CellStyle style = createStyle(workbook);

        hCell1.setCellStyle(style);
        hCell2.setCellStyle(style);
        hCell3.setCellStyle(style);
    }

    private void setStyleConcurrentForHO(final Workbook workbook, final List<Cell> cells) {
        final CellStyle style = createStyle(workbook);
        cells.forEach(cell -> cell.setCellStyle(style));
    }

    private void setStylePrixDepot(Workbook workbook, Cell hCell12, Cell hCell13, Cell hCell14) {
        CellStyle style = createStyle(workbook);

        hCell12.setCellStyle(style);
        hCell13.setCellStyle(style);
        hCell14.setCellStyle(style);
    }

    private void setStyleReleveDepot(Workbook workbook, final List<Cell> headerCell) {
        final CellStyle style = createStyle(workbook);
        headerCell.forEach(hCell -> hCell.setCellStyle(style));
    }

    private void setColumnWidth(Sheet sheet, final int[] values) {
        for (int columnNo = 0; columnNo < values.length; columnNo++) {
            sheet.setColumnWidth(columnNo, values[columnNo]);
        }
    }

    private CellStyle createStyleWithBorders(final Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        return style;
    }

    private CellStyle createStyle(final Workbook workbook) {
        final CellStyle style = createStyleWithBorders(workbook);
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

}