package com.kingfisher.compprice.dto;

import lombok.Getter;
import lombok.Setter;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FinancialProvision")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class FinancialProvision {

    @XmlElement(name = "ean")
    private String  ean;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "salesOrg")
    private String salesOrg;
    @XmlElement(name = "storeCode")
    private String storeCode;
    @XmlElement(name = "quantityValue")
    private double quantityValue;
    @XmlElement(name = "stockValue")
    private double stockValue;
    @XmlElement(name = "provStock")
    private double provStock;
    @XmlElement(name = "provRate")
    private double provRate;

    @Override
    public boolean equals(Object o){
        if (o == this) {
            return true;
        }
        if(o == null || o.getClass()!= this.getClass()) {
            return false;
        }
        FinancialProvision f = (FinancialProvision) o;
        return f.ean.equalsIgnoreCase(this.ean) && f.storeCode.equalsIgnoreCase(this.storeCode);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((null != ean) ? ean.hashCode() : 0);
        result = prime * result + ((null != storeCode) ? storeCode.hashCode() : 0);
        return result;
    }
}
