package com.kingfisher.compprice.exception;

import com.kingfisher.jsonapi.error.Error;
import com.kingfisher.jsonapi.error.ErrorSource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ApplicationException extends RuntimeException{

	/**
	 *
	 */
	private static final long serialVersionUID = 8616623133572854689L;
	final String applicationErrorCode;
	final String httpStatusCode;
	final String detail;
	final String id;
	final String pointer;
	final String parameter;
	final String title;

	public Error build(){
		return Error.builder().applicationErrorCode(getApplicationErrorCode())
				.httpStatusCode(getHttpStatusCode())
				.detail(getDetail())
				.id(getId())
				.source(new ErrorSource(getPointer(), getParameter()))
				.title(getTitle()).build();
	}
}
