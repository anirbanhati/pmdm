package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProductChaining")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductChaining {


    @XmlElement(name = "groupingCode")
    private String groupingCode;
    @XmlElement(name = "groupingDescription")
    private String groupingDescription;
    @XmlElement(name = "ean")
    private String ean;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "uom")
    private String uom;
    @XmlElement(name = "coefType")
    private String coefType;
    @XmlElement(name = "coef")
    private int coef;
    @XmlElement(name = "coefMin")
    private int coefMin;
    @XmlElement(name = "coefMax")
    private int coefMax;
    @XmlElement(name = "creationDate")
    private String creationDate;
    @XmlElement(name = "deleteFlag")
    private String deleteFlag;


    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getCoefType() {
        return coefType;
    }

    public void setCoefType(String coefType) {
        this.coefType = coefType;
    }

    public int getCoef() {
        return coef;
    }

    public void setCoef(int coef) {
        this.coef = coef;
    }

    public int getCoefMin() {
        return coefMin;
    }

    public void setCoefMin(int coefMin) {
        this.coefMin = coefMin;
    }

    public int getCoefMax() {
        return coefMax;
    }

    public void setCoefMax(int coefMax) {
        this.coefMax = coefMax;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getGroupingCode() {
        return groupingCode;
    }

    public void setGroupingCode(String groupingCode) {
        this.groupingCode = groupingCode;
    }

    public String getGroupingDescription() {
        return groupingDescription;
    }

    public void setGroupingDescription(String groupingDescription) {
        this.groupingDescription = groupingDescription;
    }


}
