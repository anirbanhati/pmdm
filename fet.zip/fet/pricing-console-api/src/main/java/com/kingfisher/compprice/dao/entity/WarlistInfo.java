package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "warlist_info")
@Data
public class WarlistInfo implements Serializable {
	private static final long serialVersionUID = 1359954693829301466L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name= "warlist_id")
	@JsonProperty("id")
	private Long warlistId;
	
	private String tenant =  "CAFR";
	
	@Column(name = "last_updated_time")
	@JsonProperty("modTime")
	private LocalDateTime lastUpdatedTime;
	
	@Column(name = "last_updated_by")
	@JsonProperty("modBy")
	private String lastUpdateBy;
	
	@JsonIgnore
	@ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinTable(name="warlist_info_product", joinColumns = { @JoinColumn (name= "warlist_id")}, inverseJoinColumns = {@JoinColumn(name="product_id")})
	private Set<Product> products=  new HashSet<>();

	public WarlistInfo(LocalDateTime lastUpdatedTime, String lastUpdateBy) {
		super();
		this.lastUpdatedTime = lastUpdatedTime;
		this.lastUpdateBy = lastUpdateBy;
	}

}