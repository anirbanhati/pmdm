package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ProductTaxClassificationInfo;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.PRODUCT_TAX_CLASSIFICATION_CACHE;

@Repository
public interface ProductTaxClassificationRepository extends JpaRepository<ProductTaxClassificationInfo, Long> {

    @Cacheable(value = PRODUCT_TAX_CLASSIFICATION_CACHE, key = "{#taxJurisdictionId, #taxCode, #taxClassificationCode}")
    Optional<ProductTaxClassificationInfo> findByTaxJurisdictionIdAndTaxCodeAndTaxClassificationCode(String taxJurisdictionId,
                                                                                                     String taxCode, String taxClassificationCode);

    Optional<ProductTaxClassificationInfo> findByTaxJurisdictionIdInAndTaxClassificationCode(final List<String> taxJurisdictionIds,
                                                                                             final String taxClassificationCode);

}