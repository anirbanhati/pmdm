package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.*;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants;
import com.kingfisher.compprice.helper.PricelistParser;
import com.kingfisher.compprice.helper.WarlistParser;
import com.kingfisher.compprice.repository.StageProductRepository;
import com.kingfisher.compprice.repository.StageProductSearchRepository;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class StageProductService {

	private final StageProductRepository stageProductRepository;
	private final StageProductSearchRepository stageProductSearchRepo;
	private final BaseValidationFactory stageValidation;
	private final StorePriceService storePriceService;
	private final ProductTools productTools;
	private final PriceTools priceTools;
	private final PricelistParser pricelistParser;
	private final WarlistParser warlistParser;
	private final LogService logService;
	private final ChangeRequestConfiguration crConfig;


	@Transactional
	public StageProductSearchResponse searchStageProducts(final ProductSearchPaging paging, final ProductSearchCriteria searchCriteria,
														  final CurrentUser user) {
		return stageProductSearchRepo.findStageProducts(paging, searchCriteria, user.getUser());
	}

	public long getTotalStageCountForUser(final User user) {
		return getStageProductsByUserAndStoreAndTenant(user).size();
	}

	/**
	 *
	 * @param file InputStream
	 * @param user User
	 * @return PriceListResponse
	 *
	 *         This service method is used to generate data-set as per available
	 *         data in the PriceList file. All the price details will be validated
	 *         against validation rule. If there is any invalid data, then the error
	 *         list will be respond back to client. Or-else the data will be
	 *         committed into staging product table
	 */
	@Transactional
	public PriceListResponse importBulkUploadPriceList(final MultipartFile file, final User user) throws IOException {
		StopWatch stopWatch = logService.logStopWatchStart("importBulkUploadPriceList");

		final PriceListResponse response = new PriceListResponse();
		List<Product> prodList = new ArrayList<>();
		final ExcelDataDetails dataDetails = pricelistParser.savePriceFromFileToStage(file, prodList, user);
		final List<ExcelValidation> excelData = dataDetails.getExcelData();

		if (CollectionUtils.isNotEmpty(excelData)) {
			prepareErrorMessages(dataDetails, excelData, response);
			stageValidatedProducts(dataDetails, excelData, prodList, response, user);
		} else {
			prepareResponseForEmptySheet(response);
		}
		priceTools.saveErrorMessagesResponse(response);
		logService.logStopWatchStop(stopWatch);
		return response;
	}

	private void prepareErrorMessages(final ExcelDataDetails dataDetails, final List<ExcelValidation> excelData,
									  PriceListResponse response) {
		if (dataDetails.isHasHeaderError() || dataDetails.isHasError()) {
			final List<ExcelValidation> bulkUploadErrors = new ArrayList<>();
			excelData.stream().filter(ex -> ex.getErrorCount() > 0).forEach(bulkUploadErrors::add);
			response.setPricelistErrors(bulkUploadErrors);
		}
	}

	private void prepareResponseForEmptySheet(PriceListResponse response) {
		final Set<ExcelError> excelErrors = new HashSet<>();
		ExcelDataValidation.setErrorDetail(excelErrors, EMPTY_STR, BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_STATUS,
				BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET, BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_ID, EMPTY_STR);
		ExcelValidation emptySheetError = new ExcelValidation();
		emptySheetError.setErrors(excelErrors);
		response.setPricelistErrors(List.of(emptySheetError));
	}

	private void stageValidatedProducts(final ExcelDataDetails dataDetails, final List<ExcelValidation> excelData,
										final List<Product> prodList, PriceListResponse response, final User user) {
		if ((crConfig.isMassUpload() && !dataDetails.isHasHeaderError()) || !dataDetails.isHasError()) {
			final long count = priceTools.saveBulkUploadProducts(excelData, prodList, user);
			log.info("Bulk upload::Total count: {}", count);
			response.setSuccessMsg("Price list has successfully updated for " + count + " product(s)");
		}
	}

	/***
	 * This method is used to stop the local price for given ean It will use the
	 * price from store local price and change the end date to today's date and save
	 * in stage table Exceptions: It will update the stage for previous items stage
	 * for same ean and save flag as price stop to true
	 *
	 * @param req StageDataRequest
	 * @param user logged user data
	 * @return stage data response
	 */
	@Transactional
	public StageDataResponse stopLocalPrice(final StageDataRequest req, final User user) {
		Product product = new Product();
		product.setEan(req.getEan());
		final StorePrice storePrice = storePriceService.findActiveStorePriceByProduct(product, user.getStore());
		req.setPrice(String.valueOf(storePrice.getPrice()));
		req.setSDate(DateUtils.getDateAsString(storePrice.getStartDate(), DateUtils.DATE_FORMAT));
		req.setEDate(DateUtils.getDateAsString(crConfig.isStopPriceEmergency() ? LocalDateTime.now() :
				LocalDateTime.now().plusDays(1), DateUtils.DATE_FORMAT));
		return saveOrUpdateStageProduct(req, user, true); // NOSONAR
	}

	@Transactional
	public StageDataResponse saveOrUpdateStageProduct(final StageDataRequest req, final User user, boolean isStoppedPrice) {
		final Product product = productTools.findProductByEanAndSalesUnitsAndType(req.getEan(), productTools.determineSalesOrg(user), req.getPrdType());
		final StageProduct stageProduct = stageProductSearchRepo.saveStageProduct(req, isStoppedPrice, user, product);
		final StageDataResponse response = stageProductSearchRepo.setStageResponse(req, product, stageProduct);
		response.setStageCount(getTotalStageCountForUser(user));
		return response;
	}

	public Optional<List<StageProduct>> findStageProductsByUserAndStoreAndTenantAndIgnoreSaving(final CurrentUser currentUser) {
		return stageProductRepository.findAllByUserAndStoreAndTenantAndIgnoreSaving(currentUser.getUser(),
				currentUser.getUser().getStore(), currentUser.getUser().getTenant(), false);
	}

	@Transactional
	public RemoveStageResponse deleteStageData(final String ean, final String prdType, final User user) {
		final RemoveStageResponse res = new RemoveStageResponse();
		final Optional<StageProduct> stageProd = stageProductRepository.findByProductAndUserAndStoreAndPrdTypeAndTenant(
				productTools.findProductByEanAndUser(ean, user), user, user.getStore(), ProductType.valueOf(prdType),
				user.getTenant());
		if (stageProd.isPresent()) {
			stageProductRepository.delete(stageProd.get());
			res.setStageCount(getTotalStageCountForUser(user));
		} else {
			throw new DetailsNotFoundException(ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_APP_EXP,
					ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_HTTP_STATUS,
					ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_DETAILS,
					ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_ID,
					ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_POINTER, ean,
					ExceptionConstants.StageProductExceptions.STG_PRODUCT_NOT_FOUND_TITLE);
		}
		return res;
	}

	@Transactional
	public String resetStageDetails(final User user) {
		synchronized (user.getStore()) {
			final List<StageProduct> stageProducts = getStageProductsByUserAndStoreAndTenant(user);
			if (!stageProducts.isEmpty()) {
				stageProductRepository.deleteAll(stageProducts);
			}
		}
		return STATUS_OK;
	}

	@Transactional
	public void resetChainStageDetails(final User user, final String chainId) {
		synchronized (user.getStore()) {
			final Optional<List<StageProduct>> stageProduct = stageProductRepository
					.findAllByUserAndStoreAndTenantAndGroupingCode(user, user.getStore(), user.getTenant(), chainId);
			stageProduct.ifPresent(stageProductRepository::deleteAll);
		}
	}

	@Transactional
	public StageDatesResponse updateValidityOfStagedProducts(final ProductSearchCriteria searchCriteria, final CurrentUser user) {
		StageDatesResponse stgDatesRes = new StageDatesResponse();
		List<StageProduct> stageProducts = stageProductSearchRepo.getStageData(user.getUser());
		stgDatesRes.setProducts(updateDatesForStageData(searchCriteria, stageProducts, user.getUser()));
		return stgDatesRes;
	}

	private List<EanDates> updateDatesForStageData(final ProductSearchCriteria criteria, final List<StageProduct> stageProducts,
												   final User user) {
		List<EanDates> eanDates = new ArrayList<>();
		stageProducts.forEach(stageProduct -> setStartDateAndEndDate(criteria, stageProduct, eanDates, user));
		stageProductRepository.saveAll(stageProducts);
		return eanDates;
	}

	public void setStartDateAndEndDate(final ProductSearchCriteria criteria, final StageProduct stageProduct,
									   final List<EanDates> eanDates, final User user) {
		LocalDateTime newSDate = DateUtils.formattedDate(criteria.getSDate());
		LocalDateTime newEDate = DateUtils.formattedDate(criteria.getEDate());
		if (!stageProduct.isPriceStopped() && ProductType.PVLocal.equals(stageProduct.getPrdType())) {
			stageProduct.setSDate(newSDate);
			stageProduct.setEDate(DateUtils.formattedDate("9999-12-31"));
		} else if (!stageProduct.isPriceStopped() && ProductType.WarList.equals(stageProduct.getPrdType())) {
			stageProduct.setSDate(newSDate);
			stageProduct.setEDate(DateUtils.isBefore(newEDate, newSDate.plusDays(45)) ? newEDate : newSDate.plusDays(44));
		} else if (!stageProduct.isPriceStopped() && (ProductType.SlowMoving.equals(stageProduct.getPrdType()) ||
				ProductType.OutOfRange.equals(stageProduct.getPrdType()))) {
			stageProduct.setSDate(newSDate);
			stageProduct.setEDate(newEDate);
		}
		stageValidation.validation(user.getTenant()).isValidDatesToStage(stageProduct.getProduct().getEan(), stageProduct.getSDate(),
				stageProduct.getEDate(), stageProduct.getPrdType().toString(), false);
		stageProduct.setLastUpdatedTime(LocalDateTime.now());

		eanDates.add(new EanDates(stageProduct.getProduct().getEan(),
				stageProduct.getSDate().toLocalDate().toString(),
				stageProduct.getEDate().toLocalDate().toString()));
	}

	public List<StageProduct> getStageProductsByUserAndStoreAndTenant(final User user) {
		return stageProductRepository.findAllByUserAndStoreAndTenant(user, user.getStore(), user.getTenant());
	}

	@Transactional
	public List<Category> findHierarchyForStageProduct(final User user) {
		final List<Category> categories = new ArrayList<>(this.findTreeCategories(user).values());
		categories.sort(Comparator.comparing(Category::getName, String.CASE_INSENSITIVE_ORDER));
		return categories;
	}

	public Map<String, Category> findTreeCategories(final User user) {
		final Set<Product> products = findStageProductsForHierarchy(user);
		Map<String, Category> categoryTree;
		if (CollectionUtils.isNotEmpty(products)) {
			final Map<String, Category> mapOfFilter = new HashMap<>();
			categoryTree = warlistParser.getCategoryTree(products, mapOfFilter);
		} else {
			throw new DetailsNotFoundException(ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_APP_EXP,
					ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_HTTP_STATUS, ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_DETAILS,
					ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_ID, ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_POINTER,
					user.getStore().getStoreCode(),
					ExceptionConstants.WarListExceptions.WAR_PRODUCT_NOT_FOUND_TITLE);
		}
		return categoryTree;
	}

	public Set<Product> findStageProductsForHierarchy(final User user) {
		Set<Product> products = new HashSet<>();
		List<StageProduct> listOfSp = stageProductRepository.findByStoreAndTenantAndUser(user.getStore(), user.getTenant(), user);
		if (CollectionUtils.isNotEmpty(listOfSp)) {
			products = listOfSp.stream().map(StageProduct::getProduct).collect(Collectors.toSet());
		}
		return products;
	}

}