package com.kingfisher.compprice;

import com.ibm.mq.spring.boot.MQAutoConfiguration;
import com.kingfisher.compprice.configuration.FunctionalityConfiguration;
import com.kingfisher.compprice.filter.TokenValidationFilter;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jms.JmsAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//@SpringBootApplication
@SpringBootApplication(scanBasePackages = { "com.kingfisher" })
@EnableAsync
@EntityScan({ "com.kingfisher", "com.kingfisher.mq" })
@ComponentScan({ "com.kingfisher" })
@EnableTransactionManagement
@EnableCaching
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30S")
@EnableAutoConfiguration(exclude = {JmsAutoConfiguration.class, MQAutoConfiguration.class})
public class Application {

	@Value("${auth.azure.authority}")
	private String authority;
	@Value("${auth.azure.clientID}")
	private String clintId;
	@Value("${auth.azure.tenantID}")
	private String tenantId;
	@Autowired
	private FunctionalityConfiguration funConfig;

	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public FilterRegistrationBean < TokenValidationFilter > filterRegistrationBean() {
		final FilterRegistrationBean < TokenValidationFilter > registrationBean = new FilterRegistrationBean<>();
		final TokenValidationFilter customURLFilter = new TokenValidationFilter(authority, clintId, tenantId, funConfig);
		registrationBean.setFilter(customURLFilter);
		registrationBean.addUrlPatterns("/api/v1/*", "/api/v2/*");
		registrationBean.setOrder(2); //set precedence
		return registrationBean;
	}


	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {

			@Override
			public void addCorsMappings(final CorsRegistry registry) {
				registry.addMapping("/api/**")
						.allowedOrigins("*")
						.allowedMethods("PUT", "DELETE","POST","GET", "PATCH")
						.allowedHeaders("*")
						.exposedHeaders("*")
						.allowCredentials(false).maxAge(3600);
			}
		};
	}
}
