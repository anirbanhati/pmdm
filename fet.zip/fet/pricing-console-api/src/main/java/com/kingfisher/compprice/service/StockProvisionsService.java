package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Provisions;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.response.CurrentStock;
import com.kingfisher.compprice.dao.response.StockInfo;
import com.kingfisher.compprice.dao.response.WeeklyStock;
import com.kingfisher.compprice.dao.response.search.Recommandation;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;

@Slf4j
@RequiredArgsConstructor
@Service
public class StockProvisionsService {

	private final HelperService helperService;


	public StockInfo getStockInfo(final User user, final Product prd, final int currentStock, final Double costPrice) {
		final StockInfo stInfo = new StockInfo();
		final CurrentStock cStock = new CurrentStock();
		cStock.setQty(currentStock);
		cStock.setValue(DecimalUtils.roundOf(currentStock * Optional.ofNullable(costPrice).orElse(0.0),
				ROUND_OF_2));
		stInfo.setCurrentStock(cStock);
		final WeeklyStock wStock = new WeeklyStock();
		final Provisions provision = helperService.findStockForEan(user, prd);
		wStock.setFinProv(DecimalUtils.roundOf(provision.getProvStock(), ROUND_OF_2));
		wStock.setPRate(provision.getProvRate());
		wStock.setQty(DecimalUtils.roundOf(provision.getQuantity(), DecimalUtils.ROUND_OF_0));
		wStock.setValue(DecimalUtils.roundOf(provision.getStockValue(), ROUND_OF_2));
		stInfo.setWeeklyStock(wStock);
		return stInfo;
	}

	public Recommandation getRecommendation(final StockInfo stockInfo, final double stdPrice) {
		Recommandation recommandation = new Recommandation();
		double factor;
		if (stockInfo.getWeeklyStock().getPRate() > 0 && stockInfo.getWeeklyStock().getPRate() <= 25) {
			factor = 0.25;
		} else if (stockInfo.getWeeklyStock().getPRate() > 25 && stockInfo.getWeeklyStock().getPRate() <= 50) {
			factor = 0.5;
		} else if (stockInfo.getWeeklyStock().getPRate() > 50 && stockInfo.getWeeklyStock().getPRate() <= 75) {
			factor = 0.75;
		} else {
			factor = 0.9;
		}
		final double stockQty = Double.parseDouble(stockInfo.getWeeklyStock().getQty());
		final double qtyToSell = stockQty * factor;
		final double salesPrice = (stdPrice
				* (1 - stockInfo.getWeeklyStock().getPRate() / 100
				+ (stockInfo.getWeeklyStock().getPRate() / 100 * 0.3)));
		final double remQty = qtyToSell - stockQty + stockInfo.getCurrentStock().getQty();
		recommandation.setQtyToSell(DecimalUtils.roundOf(qtyToSell, DecimalUtils.ROUND_OF_0));
		recommandation.setRemQtyToSell(DecimalUtils.roundOf((Math.max(remQty, 0.0)), DecimalUtils.ROUND_OF_0));
		recommandation.setSalesPrice(DecimalUtils.roundOf(salesPrice, ROUND_OF_2));
		return recommandation;
	}

}