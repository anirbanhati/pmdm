package com.kingfisher.compprice.exception;

public class BulkUploadExceptionConstant {

	private BulkUploadExceptionConstant(){
		throw new IllegalStateException("Constant class");
	}

	public static final String BULK_UPLOAD_PRODUCT_NOT_FOUND_STATUS = "404";
	public static final String BULK_UPLOAD_PRODUCT_NOT_FOUND_DETAILS = "Product Not Available";
	public static final String BULK_UPLOAD_PRODUCT_NOT_FOUND_ID = "LSP_BU_DE_01";

	public static final String BULK_UPLOAD_EAN_NULL_STATUS = "500";
	public static final String BULK_UPLOAD_EAN_NULL = "EAN is null";
	public static final String BULK_UPLOAD_EAN_NULL_ID = "LSP_BU_DE_04";

	public static final String BULK_UPLOAD_EAN_INVALID_STATUS = "400";
	public static final String BULK_UPLOAD_EAN_INVALID = "Invalid EAN";
	public static final String BULK_UPLOAD_EAN_INVALID_ID = "LSP_BU_DE_05";

	public static final String BULK_UPLOAD_PRIX_NULL_STATUS = "500";
	public static final String BULK_UPLOAD_PRIX_NULL = "Prix is null";
	public static final String BULK_UPLOAD_PRIX_NULL_ID = "LSP_BU_DE_06";

	public static final String BULK_UPLOAD_PRIX_INVALID_FORMAT_STATUS = "400";
	public static final String BULK_UPLOAD_PRIX_INVALID_FORMAT = "Invalid Prix format";
	public static final String BULK_UPLOAD_PRIX_INVALID_FORMAT_ID = "LSP_BU_DE_07";

	public static final String BULK_UPLOAD_DATE_NULL_STATUS = "500";
	public static final String BULK_UPLOAD_DATE_NULL = " Date is null";
	public static final String BULK_UPLOAD_DATE_NULL_ID = "LSP_BU_DE_08";

	public static final String BULK_UPLOAD_DATE_INVALID_STATUS = "400";
	public static final String BULK_UPLOAD_DATE_INVALID = " Date is Invalid";
	public static final String BULK_UPLOAD_DATE_INVALID_ID = "LSP_BU_DE_09";

	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_STATUS = "402";
	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_PRIX = "Product price should not be higher than standard price";
	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_PRIX_ID = "LSP_BU_DE_11";

	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_STATUS = "402";
	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE = "Product price should not be lower than minimal price calculated with MAX Decrease %";
	public static final String BULK_UPLOAD_PRODUCT_INCORRECT_MINIMAL_PRICE_ID = "LSP_BU_DE_12";

	public static final String BULK_UPLOAD_DATE_FUTURE_DATE_STATUS = "402";
	public static final String BULK_UPLOAD_DATE_FUTURE_DATE = " Date should be future date";
	public static final String BULK_UPLOAD_DATE_FUTURE_DATE_ID = "LSP_BU_DE_13";

	public static final String BULK_UPLOAD_INCORRECT_END_DATE_STATUS = "402";
	public static final String BULK_UPLOAD_INCORRECT_END_DATE = "End date should be start date or after for product_type OutOfRange";
	public static final String BULK_UPLOAD_INCORRECT_END_DATE_ID = "LSP_BU_DE_14";

	public static final String BULK_UPLOAD_DATE_INCORRECT_END_DATE_STATUS = "402";
	public static final String BULK_UPLOAD_DATE_INCORRECT_END_DATE = "End date should be between start date and start date + 45 if the product_type is WarList/SlowMoving";
	public static final String BULK_UPLOAD_DATE_INCORRECT_END_DATE_ID = "LSP_BU_DE_15";

	public static final String BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_STATUS = "500";
	public static final String BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET = "Provided sheet is empty";
	public static final String BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_ID = "LSP_BU_DE_16";

	public static final String BULK_UPLOAD_HEADER_INVALID_STATUS = "500";
	public static final String BULK_UPLOAD_HEADER_INVALID = "Invalid Header ";
	public static final String BULK_UPLOAD_HEADER_INVALID_ID = "LSP_BU_DE_17";
	
	public static final String BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE_STATUS = "402";
	public static final String BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE = "Local price is stopped for this product";
	public static final String BULK_UPLOAD_PRODUCT_STOPED_LOCAL_PRICE_ID = "LSP_BU_DE_18";
	
	public static final String BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS_CODE = "402";
	public static final String BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS = "Fixed price is applied to this product";
	public static final String BULK_UPLOAD_PRODUCT_FIXED_PRICE_STATUS_ID = "LSP_BU_DE_19";

	public static final String BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS_CODE = "402";
	public static final String BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS = "Product is removed from warlist in SAP, so the product is not available in FET";
	public static final String BULK_UPLOAD_PRODUCT_WARLIST_DETAG_STATUS_ID = "LSP_BU_DE_20";

	public static final String BULK_UPLOAD_BDFR_INCORRECT_END_DATE_STATUS = "402";
	public static final String BULK_UPLOAD_BDFR_INCORRECT_END_DATE = "End date should be between start date and start date + 60 if the product_type is PVMax/PVLocal";
	public static final String BULK_UPLOAD_BDFR_INCORRECT_END_DATE_ID = "LSP_BU_DE_21";

	public static final String BULK_UPLOAD_INVALID_PRODUCT_TYPE_STATUS = "400";
	public static final String BULK_UPLOAD_INVALID_PRODUCT_TYPE = "This Product type is not allowed for staging";
	public static final String BULK_UPLOAD_INVALID_PRODUCT_TYPE_ID = "LSP_BU_DE_22";

	public static final String BULK_UPLOAD_COST_PRICE_MISSING_STATUS = "400";
	public static final String BULK_UPLOAD_COST_PRICE_MISSING_MESSAGE = "No cost price Available";
	public static final String BULK_UPLOAD_COST_PRICE_MISSING_ID = "LSP_BU_DE_23";

	public static final String BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_STATUS = "404";
	public static final String BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_DETAILS = "Product is not available in store";
	public static final String BULK_UPLOAD_STORE_PRODUCT_NOT_FOUND_ID = "LSP_BU_DE_24";

	public static final String BULK_UPLOAD_INVALID_PRD_TYPE_STATUS = "404";
	public static final String BULK_UPLOAD_INVALID_PRD_TYPE = "OutOfRange is not allowed";
	public static final String BULK_UPLOAD_INVALID_PRD_TYPE_ID = "LSP_BU_DE_25";

	public static final String BULK_UPLOAD_FIXED_PRICE_STATUS = "404";
	public static final String BULK_UPLOAD_FIXED_PRICE_DETAILS = "Item with fixed price, reading not authorized, please remove it from the import file";
	public static final String BULK_UPLOAD_FIXED_PRICE_ID = "LSP_BU_DE_26";

	public static final String BULK_UPLOAD_INVALID_OOR_STATUS_CODE = "402";
	public static final String BULK_UPLOAD_INVALID_OOR = "Invalid Oor Product";
	public static final String BULK_UPLOAD_INVALID_OOR_STATUS_ID = "LSP_BU_DE_27";

	public static final String BULK_UPLOAD_PRICE_NOT_FOUND_STATUS_CODE= "402";
	public static final String BULK_UPLOAD_PRICE_NOT_FOUND_DETAILS = "Price not found for this product";
	public static final String BULK_UPLOAD_PRICE_NOT_FOUND_STATUS_ID = "LSP_BU_DE_28";

	public static final String BULK_UPLOAD_INVALID_PRODUCT_STATUS_CODE = "402";
	public static final String BULK_UPLOAD_INVALID_PRODUCT_STATUS_DETAILS = "Invalid status for this product";
	public static final String BULK_UPLOAD_INVALID_PRODUCT_STATUS_STATUS_ID = "LSP_BU_DE_29";

	public static final String BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_CODE = "402";
	public static final String BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_DETAILS = "Product is not listed";
	public static final String BULK_UPLOAD_INVALID_PRD_LISTING_STATUS_ID = "LSP_BU_DE_30";

}