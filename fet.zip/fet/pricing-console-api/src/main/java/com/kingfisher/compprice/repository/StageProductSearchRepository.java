package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.StageProduct;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.request.StageChainRequest;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.dao.response.SearchItem;
import com.kingfisher.compprice.dao.response.SearchPagination;
import com.kingfisher.compprice.dao.response.StageDataResponse;
import com.kingfisher.compprice.dao.response.StageProductSearchResponse;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.dao.search.WarListSearchCriteria;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.UserException;
import com.kingfisher.compprice.service.*;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.tools.PriceValidation;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.BaseValidationFactory;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.kingfisher.compprice.exception.ExceptionConstants.StorePriceExceptions.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Repository
@RequiredArgsConstructor
@Slf4j
public class StageProductSearchRepository {

	@PersistenceContext
	private EntityManager entityManager;
	private final StageProductRepository stageProductRepository;
	private final StoreProductService storeProductService;
	private final StorePriceService storePriceService;
	private final ClusterPriceService clusterPriceService;
	private final ThirdPartyAPIService thirdPartyAPIService;
	private final ProductListingService productListingService;
	private final StorePriceTools storePriceTools;
	private final ProductTools productTools;
	private final PriceTools priceTools;
	private final BaseValidationFactory stageValidation;
	private final PriceValidation priceValidation;


	public StageProductSearchResponse findStageProducts(final ProductSearchPaging page, final ProductSearchCriteria criteria,
														final User user) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<StageProduct> criteriaQuery = criteriaBuilder.createQuery(StageProduct.class);
		final Root<StageProduct> stageProduct = criteriaQuery.from(StageProduct.class);
		final Join<Object, Object> userJoin = stageProduct.join(USER, JoinType.INNER);
		final Join<Object, Object> storeJoin = stageProduct.join(STORE, JoinType.INNER);
		final Join<Object, Object> productJoin = stageProduct.join(PRODUCT, JoinType.INNER);
		criteriaQuery.where(this.getPredicates(criteria, userJoin, storeJoin, productJoin, user, criteriaBuilder));
		criteriaQuery.orderBy(criteriaBuilder.asc(productJoin.get(PRODUCT_CATEGORY)),
				criteriaBuilder.asc(productJoin.get(PRODUCT_SUB_CATEGORY)),
				criteriaBuilder.asc(productJoin.get(PRODUCT_BRICK_NAME)),
				criteriaBuilder.asc(productJoin.get(DESCRIPTION)));

		final TypedQuery<StageProduct> typedQuery = this.entityManager.createQuery(criteriaQuery);
		final long count = this.getCount(criteria, user, criteriaBuilder);

		productTools.setPageSizeAndNumCpt(page, count);
		int pSize = page.getPageSize();
		int pNum = page.getPageNum();

		typedQuery.setFirstResult((pNum - 1) * pSize);
		typedQuery.setMaxResults(pSize);
		return getSearchResponse(typedQuery.getResultList(), this.getPageable(page, pSize, pNum), count, pSize, user);
	}

	private Pageable getPageable(final ProductSearchPaging page, final int pSize, final int pageNum) {
		final Sort sort = Sort.by(page.getSortDirection(), WAR_LIST_PRODUCT_CAT_NAME,
				WAR_LIST_PRODUCT_SUB_CAT_NAME, WAR_LIST_PRODUCT_BRICK_NAME);
		return PageRequest.of(pageNum - 1, pSize, sort);
	}

	private StageProductSearchResponse getSearchResponse(final List<StageProduct> resultList, final Pageable pageable,
														 final long count, final int pSize, final User user) {
		final StageProductSearchResponse response = new StageProductSearchResponse();
		final List<SearchItem> items = new ArrayList<>();
		var products = resultList.stream().map(StageProduct::getProduct).toList();
		var listOfEan = productTools.getListOfEanFromProducts(products);
		var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, List.of(), user.getStore());
		var productStoreProductMap = storeProductService.getProductStoreProductMap(products, List.of(), user);
		var validPrdListingMap = productListingService.validateProductListing(products, List.of(), user.getStore());
		var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
		var eanCostPriceMap = thirdPartyAPIService.getCostPriceDetails(products, user, true);
		MasterData masterData = MasterData.builder().eanStorePriceMap(eanStorePriceMap).productStoreProductMap(productStoreProductMap)
				.validPrdListingMap(validPrdListingMap).eanClusterPriceMap(eanClusterPriceMap).eanCostPriceMap(eanCostPriceMap)
				.products(products).build();

		resultList.forEach(stgProd -> {
			final SearchItem item = new SearchItem();
			item.setProduct(priceTools.setStagedProductItem(stgProd.getProduct(), stgProd.getPrdType().toString(),
					user, masterData));
			items.add(item);
		});
		response.setItems(items);
		response.setTotalRecords(count);
		response.setPagination(preparePageableResponse(resultList, pageable, count, pSize));
		return response;
	}

	private SearchPagination preparePageableResponse(final List<StageProduct> resultList, final Pageable pageable, final long count, final int pSize) {
		final SearchPagination sPagination = new SearchPagination();
		sPagination.setPageNumber(pageable.getPageNumber() + 1);
		sPagination.setPageSize(pageable.getPageSize());
		sPagination.setTotalElements(count);
		sPagination.setNumberOfElements(resultList.size());
		sPagination.setTotalPages(((int) count + pSize - 1) / pSize);
		return sPagination;
	}

	private Predicate getPredicates(final WarListSearchCriteria criteria, final Join<Object, Object> userJoin,
									final Join<Object, Object> store, final Join<Object, Object> productJoin,
									final User user, CriteriaBuilder criteriaBuilder) {
		final List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(store.get(STORE_CODE), user.getStore().getStoreCode()));
		predicates.add(criteriaBuilder.equal(userJoin.get(USER_ID), user.getUserId()));
		predicates.add(criteriaBuilder.equal(userJoin.get(TENANT), user.getTenant()));
		if (CollectionUtils.isNotEmpty(criteria.getCodes())) {
			predicates.add(criteriaBuilder.and(productJoin.get(PRODUCT_BRICK_CODE).in(criteria.getCodes())));
		}
		if (StringUtils.isNotEmpty(criteria.getEanOrDesc())) {
			if (StringUtils.isNumeric(criteria.getEanOrDesc())) {
				final Predicate eanPredicate = criteriaBuilder.like(productJoin.get(PRODUCT_EAN),
						PERCENTAGE + criteria.getEanOrDesc() + PERCENTAGE);
				final Predicate artCodePredicate = criteriaBuilder.like(productJoin.get(PRODUCT_CODE),
						PERCENTAGE + criteria.getEanOrDesc() + PERCENTAGE);
				final Predicate predicateEanOrCode = criteriaBuilder.or(eanPredicate, artCodePredicate);
				predicates.add(predicateEanOrCode);
			}  else {
				predicates.add(criteriaBuilder.like(criteriaBuilder.lower(productJoin.get(DESCRIPTION)),
						PERCENTAGE + criteria.getEanOrDesc().toLowerCase() + PERCENTAGE));
			}
		}
		return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	}

	private long getCount(final WarListSearchCriteria criteria, final User user, final CriteriaBuilder criteriaBuilder) {
		final CriteriaQuery<Long> countQ = criteriaBuilder.createQuery(Long.class);
		final Root<StageProduct> countRoot = countQ.from(StageProduct.class);
		final Join<Object, Object> userJoin = countRoot.join("user", JoinType.INNER);
		final Join<Object, Object> store = countRoot.join("store", JoinType.INNER);
		final Join<Object, Object> product = countRoot.join("product", JoinType.INNER);
		countQ.select(criteriaBuilder.count(countRoot))
				.where(this.getPredicates(criteria, userJoin, store, product, user, criteriaBuilder));
		return this.entityManager.createQuery(countQ).getSingleResult();
	}

	public List<StageProduct> getStageData(final User user) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<StageProduct> criteriaQuery = criteriaBuilder.createQuery(StageProduct.class);
		final Root<StageProduct> stageProduct = criteriaQuery.from(StageProduct.class);
		final Join<Object, Object> userJoin = stageProduct.join(USER, JoinType.INNER);
		final Join<Object, Object> storeJoin = stageProduct.join(STORE, JoinType.INNER);
		final Join<Object, Object> productJoin = stageProduct.join(PRODUCT, JoinType.INNER);

		final List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(storeJoin.get(STORE_CODE), user.getStore().getStoreCode()));
		predicates.add(criteriaBuilder.equal(userJoin.get(USER_ID), user.getUserId()));
		predicates.add(criteriaBuilder.equal(userJoin.get(TENANT), user.getTenant()));

		criteriaQuery.where(criteriaBuilder.and(predicates.toArray(new Predicate[0])));
		criteriaQuery.orderBy(criteriaBuilder.asc(productJoin.get(PRODUCT_CATEGORY)),
				criteriaBuilder.asc(productJoin.get(PRODUCT_SUB_CATEGORY)),
				criteriaBuilder.asc(productJoin.get(PRODUCT_BRICK_NAME)),
				criteriaBuilder.asc(productJoin.get(DESCRIPTION)));

		final TypedQuery<StageProduct> typedQuery = this.entityManager.createQuery(criteriaQuery);
		return typedQuery.getResultList();
	}

	@Transactional
	public List<StageDataResponse> stageChainProducts(final User user, final String chainId, final StageChainRequest chainReq) {
		final List<Product> products = productTools.getChainProductsByChainId(chainId, user);
		List<StageDataResponse> response = null;
		List<StoreProduct> validStgProducts = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(products)) {
			products.forEach(product -> {
				StoreProduct storeProd = product.getStoreProduct().stream()
						.filter(sProduct -> user.getStore().getStoreId().equals(sProduct.getStore().getStoreId()))
						.findFirst().orElse(null);
				if (null != storeProd && !ProductType.PVMax.equals(storeProd.getPrdType())) {
					validStgProducts.add(storeProd);
				}
			});

			response = validStgProducts.stream().map(validStgProduct -> {
				final StageDataRequest req = new StageDataRequest();
				req.setEan(validStgProduct.getProduct().getEan());
				req.setPrice(chainReq.getPrice());
				req.setSDate(chainReq.getSDate());
				req.setEDate(chainReq.getEDate());
				req.setPrdType(chainReq.getPrdType());
				req.setChainId(chainId);
				req.setReview(true);

				final StageProduct stageProduct = saveStageProduct(req, false, user, validStgProduct.getProduct());
				return setStageResponse(req, validStgProduct.getProduct(), stageProduct);
			}).toList();
		}
		return response;
	}

	public StageDataResponse  setStageResponse(final StageDataRequest req, final Product product,
											   final StageProduct stageProduct) {
		final StageDataResponse response = new StageDataResponse();
		response.setEan(product.getEan());
		response.setEDate(stageProduct.getEDate());
		response.setSDate(stageProduct.getSDate());
		response.setLDate(stageProduct.getLastUpdatedTime());
		response.setPriceStop(stageProduct.isPriceStopped());

		if (STAGING_PRD_TYPES.contains(req.getPrdType())) {
			response.setPriceSU(DecimalUtils.roundOf(stageProduct.getPriceSU(), DecimalUtils.ROUND_OF_2));
			response.setCmRate(DecimalUtils.roundOf(stageProduct.getMarginRate(), DecimalUtils.ROUND_OF_2));
			response.setIndex(DecimalUtils.roundOf(stageProduct.getIndex(), DecimalUtils.ROUND_OF_2));
			response.setNmRate(DecimalUtils.roundOf(stageProduct.getNewMarginRate(), DecimalUtils.ROUND_OF_2));
			response.setMgDiff(DecimalUtils.roundOf(stageProduct.getMarginDiff(), DecimalUtils.ROUND_OF_2));
			response.setPriceUOM(DecimalUtils.roundOf(stageProduct.getPriceUM(), DecimalUtils.ROUND_OF_3));
		} else {
			response.setPriceUOM(DecimalUtils.roundOf(stageProduct.getPriceUM(), DecimalUtils.ROUND_OF_3));
			response.setNrv(DecimalUtils.roundOf(stageProduct.getNrv(), DecimalUtils.ROUND_OF_0));
			response.setPriceSU(DecimalUtils.roundOf(stageProduct.getPriceSU(), DecimalUtils.ROUND_OF_2));
		}
		response.setMiOnStock(null != stageProduct.getMarginImpact() ?
				DecimalUtils.roundOf(stageProduct.getMarginImpact(), DecimalUtils.ROUND_OF_0)
				: null);
		return response;
	}

	/**
	 * @param req             StageDataRequest req : Input req to save price in stage
	 * @param isStoppedPrice  whether price stopped
	 * @param user            user
	 * @param product         product
	 * @return Saving the price in stage and then return the object
	 */
	public StageProduct saveStageProduct(final StageDataRequest req, boolean isStoppedPrice, final User user,
										 final Product product) {
		StageProduct stgProduct;

		var storePrice = storePriceTools.getActiveStorePrice(product, user.getStore());
		if (null == storePrice) {
			throw new UserException(STORE_PRICE_NOT_FOUND_APP_EXP, STORE_PRICE_NOT_FOUND_HTTP_STATUS, STORE_PRICE_NOT_FOUND_DETAILS,
					STORE_PRICE_NOT_FOUND_ID, STORE_PRICE_CODE_NOT_FOUND_POINTER, req.getEan() + PIPE_SEPARATOR +
					user.getStore().getStoreCode(), STORE_PRICE_NOT_FOUND_TITLE);
		}

		var storeProduct = storeProductService.getStoreProductByProductAndStore(product, user.getStore());
		var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
		var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
		var stdPrice = storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice);
		var stageProduct = stageProductRepository.findByProductAndUserAndStoreAndPrdTypeAndTenant(product, user, user.getStore(),
				ProductType.valueOf(req.getPrdType()), user.getTenant()).orElse(null);
		req.setStorePrice(storePriceService.getStorePriceWithCluster(nPrice, storePrice, user, clusterPrice));

		log.info("{} {} {} {} {} {} {}", StructuredArguments.keyValue("method", "saveStageProduct"),
				StructuredArguments.keyValue("ean", req.getEan()), StructuredArguments.keyValue("price", req.getPrice()),
				StructuredArguments.keyValue("clusterPrice", clusterPrice), StructuredArguments.keyValue("nPrice", nPrice),
				StructuredArguments.keyValue("stdPrice", stdPrice), StructuredArguments.keyValue("prdType", req.getPrdType()));

		priceValidationForStaging(req, isStoppedPrice, user, product, stdPrice, storeProduct);
		if (StringUtils.isNotEmpty(req.getSDate()) && StringUtils.isNotEmpty(req.getEDate())) {
			final LocalDateTime startDate = DateUtils.formattedDate(req.getSDate());
			final LocalDateTime endDate = DateUtils.formattedDate(req.getEDate());
			stageValidation.validation(user.getTenant()).isValidDatesToStage(req.getEan(), startDate, endDate,
					req.getPrdType(), isStoppedPrice);
		}
		final Map<String, String> costPriceDetailsMap = thirdPartyAPIService.getCostPriceDetails(List.of(product), user, true);
		final double costPrice = thirdPartyAPIService.getCostPrice(product, costPriceDetailsMap);
		final Map<String, Integer> productCurrentStock = thirdPartyAPIService.getCurrentStockDetails(List.of(product), user.getStore());
		req.setStdPrice(stdPrice);
		req.setCostPrice(costPrice);
		stgProduct = priceTools.saveStageInRepository(req, product, user, stageProduct, isStoppedPrice,
				productCurrentStock.getOrDefault(product.getEan(), 0));

		return stgProduct;
	}

	public void priceValidationForStaging(final StageDataRequest req, final boolean isStoppedPrice, final User user,
										  final Product product, final Double stdPrice, final StoreProduct storeProduct) {
		if (StringUtils.isNotEmpty(req.getPrice()) && !isStoppedPrice) {
			stageValidation.validation(user.getTenant()).isValidPriceToStage(
					product,
					priceTools.getStageSUPrice(Double.parseDouble(req.getPrice()), isStoppedPrice, req.isReview(), product, req.getPriceType()),
					priceValidation.calculateMinimalPrice(stdPrice, storeProduct.getMaxDecrease()),
					priceValidation.calculateMaxPrice(stdPrice, storeProduct.getMaxIncrease(), user.getTenant()));
		}
	}

}