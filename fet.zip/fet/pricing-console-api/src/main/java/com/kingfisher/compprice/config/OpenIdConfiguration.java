package com.kingfisher.compprice.config;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenIdConfiguration {

	@JsonAlias("jwks_uri")
	private String jwksUri;

	public String getJwksUri() {
		return this.jwksUri;
	}

	public void setJwksUri(String jwksUri) {
		this.jwksUri = jwksUri;
	}
}
