package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.PostgreSQLEnumType;
import com.kingfisher.compprice.enums.ProductType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.dialect.PostgreSQLEnumJdbcType;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "stg_product")
@Convert(attributeName = "pgsql_enum", converter = PostgreSQLEnumType.class)
public class StageProduct implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -6383537643264974159L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name="price_uom")
	private Double priceUM;

	@Column(name="price_su")
	private Double priceSU;

	@Column(name = "cost_price")
	private Double costPrice;

	@Column(name="price_index")
	private Double index;

	@Column(name="price_margin_rate")
	private Double marginRate;

	@Column(name = "price_new_mg_rate")
	private Double newMarginRate;

	@Column(name = "theroritical_mg_rate")
	private Double theoriticalMarginRate;

	@Column(name = "req_mg_rate")
	private Double reqMarginRate;

	@Column(name = "mg_diff")
	private Double marginDiff;

	@Column(name = "nrv")
	private Double nrv;

	@Column(name = "mg_impact")
	private Double marginImpact;

	@Column(name = "start_time")
	private LocalDateTime sDate;

	@Column(name = "end_time")
	private LocalDateTime eDate;

	@Column(name = "tenant")
	private String tenant;

	@Column(name = "grouping_code")
	private String groupingCode;

	@Column(name = "price_stopped")
	private boolean priceStopped;

	@Column(name = "ignore_in_save")
	private boolean ignoreSaving;

	@Column(name = "last_updated")
	@JsonProperty("modTime")
	private LocalDateTime lastUpdatedTime;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;

	@Column(name = "prd_type")
	@Enumerated(EnumType.STRING)
	@JdbcType(PostgreSQLEnumJdbcType.class)
	private ProductType prdType;

}