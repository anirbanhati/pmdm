package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.FunctionalityConfiguration;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.repository.CompetitorProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Service
public class CompetitorProductService {

    private final CompetitorProductRepository competitorProductRepo;
    private final FunctionalityConfiguration funConfig;
    private final ProductTools productTools;
    private final LogService logService;


    public List<CompetitorProduct> getCompProductsProductsByListOfEanAndCompNames(final List<String> listOfEan, final Set<String> compNames) {
        StopWatch stopWatch = logService.logStopWatchStart("getCompProductsProductsByListOfEanAndCompNames");
        List<CompetitorProduct> competitorProducts = competitorProductRepo.findByEanInAndCompNameIn(listOfEan, compNames);
        logService.logStopWatchStop(stopWatch);
        return competitorProducts;
    }

    public Map<String, Map<String, CompetitorProduct>> getEanWithCompNameCompProductMap(final List<String> listOfEan, final List<Long> collectionIds) {
        StopWatch stopWatch = logService.logStopWatchStart("getEanWithCompNameCompProductMap");

        Map<String, Map<String, CompetitorProduct>> eanwithCompNameCompProductMap = new HashMap<>();
        Set<StoreCollection> storeCollections = productTools.getStoreCollections(collectionIds);
        Set<String> compNames = storeCollections.stream().map(StoreCollection::getCsName).collect(Collectors.toSet());

        List<CompetitorProduct> competitorProducts = getCompProductsProductsByListOfEanAndCompNames(listOfEan, compNames);
        if (CollectionUtils.isNotEmpty(competitorProducts)) {
            Map<String, List<CompetitorProduct>> eanCompProductsMap = competitorProducts.stream()
                    .collect(Collectors.groupingBy(CompetitorProduct::getEan));

            eanCompProductsMap.forEach((ean, compProducts) -> {
                Map<String, CompetitorProduct> compNameCompProductMap = new HashMap<>();
                Map<String, List<CompetitorProduct>> compNameCompProductsMap = compProducts.stream()
                        .collect(Collectors.groupingBy(CompetitorProduct::getCompName));
                compNameCompProductsMap.forEach((compName, cProducts) -> {
                    cProducts.sort(Comparator.comparing(CompetitorProduct::getLastUpdatedDate).reversed());
                    compNameCompProductMap.put(compName, cProducts.get(0));
                });
                eanwithCompNameCompProductMap.put(ean, compNameCompProductMap);
            });
        }
        logService.logStopWatchStop(stopWatch);
        return eanwithCompNameCompProductMap;
    }

    public CompetitorProduct getValidCompProds(final Product product, final CompetitorStore compStore) {
        StopWatch stopWatch = logService.logStopWatchStart("getValidCompProds");
        var compProd = competitorProductRepo.findByEan(product.getEan());
        String code = Optional.ofNullable(compStore).orElse(new CompetitorStore()).getCode();
        CompetitorProduct compProduct = filterCompetitorProduct(compProd, code);
        logService.logStopWatchStop(stopWatch);
        return compProduct;
    }

    public CompetitorProduct filterCompetitorProduct(final List<CompetitorProduct> compProd, final String code) {
        CompetitorProduct compProduct = new CompetitorProduct();
        if (CollectionUtils.isNotEmpty(compProd)) {
            compProduct = compProd.stream()
                    .filter(cProd -> {
                        List<String> compName = Stream.of(Optional.ofNullable(code).orElse(EMPTY_STR).split(UNDER_SCORE))
                                .sorted(Collections.reverseOrder()).toList();
                        return compName.get(0).equalsIgnoreCase(cProd.getCompName());
                    })
                    .max(Comparator.comparing(CompetitorProduct::getLastUpdatedDate)).orElse(new CompetitorProduct());
        }
        return compProduct;
    }

    public CompetitorProduct findCompProductByEanAndCode(final String ean, final String code) {
        List<CompetitorProduct> competitorProducts = competitorProductRepo.findByEan(ean);
        return filterCompetitorProduct(competitorProducts, code);
    }

    public Set<CompetitorProduct> filterCompProductByCompName(final Assignment assignment, final String compShortName) {
        Set<CompetitorProduct> competitorProducts = new HashSet<>();
        assignment.getProduct().getComProduct().stream()
                .filter(Objects::nonNull)
                .filter(comProd -> compShortName.equalsIgnoreCase(comProd.getCompName()))
                .filter(comProd -> funConfig.isPrdAssoc() ? (!DELETED_COMP_PRODUCT.equals(comProd.getDeleteFlag()))
                        : (!DELETED_FLAG_2.equals(comProd.getDeleteFlag())))
                .max(Comparator.comparing(CompetitorProduct::getLastUpdatedDate))
                .ifPresentOrElse(compProd -> competitorProducts.add(updateCompetitorProduct(compProd)),
                        () -> log.debug("filterCompProductByCompName :: No compProds")
                );
        return competitorProducts;
    }

    private CompetitorProduct updateCompetitorProduct(final CompetitorProduct compProd) {
        CompetitorProduct competitorProduct = new CompetitorProduct();
        competitorProduct.setEan(compProd.getEan());
        competitorProduct.setCompEan(compProd.getCompEan());
        competitorProduct.setCode(compProd.getCompArticleNumber());
        competitorProduct.setDescription(compProd.getCompDescription());
        competitorProduct.setCompName(compProd.getCompName());
        competitorProduct.setSalesUnit(compProd.getSalesUnit());
        competitorProduct.setUom(compProd.getUom());
        competitorProduct.setUomPrice(compProd.getUomPrice());
        competitorProduct.setCreationDate(compProd.getCreationDate());
        competitorProduct.setDeleteFlag(compProd.getDeleteFlag());
        competitorProduct.setCoef(compProd.getCoef());
        competitorProduct.setCompArticleNumber(compProd.getCompArticleNumber());
        competitorProduct.setLastUpdatedDate(compProd.getLastUpdatedDate());
        competitorProduct.setCompDescription(compProd.getCompDescription());
        return competitorProduct;
    }

}