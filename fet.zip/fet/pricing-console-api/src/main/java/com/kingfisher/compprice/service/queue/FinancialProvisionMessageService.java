package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Provisions;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dto.FinancialProvision;
import com.kingfisher.compprice.dto.FinancialProvisions;
import com.kingfisher.compprice.repository.FinancialProvisionRepository;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.FINANCIAL_PROVISION_MESSAGE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class FinancialProvisionMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final FinancialProvisionRepository financialProvisionRepository;
    private final MessageServicesHelper servicesHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return FINANCIAL_PROVISION_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Financial Provision Feed :: {}", message);
        }
        final String methodName = "processMessage";
        try {
            log.info("Start processing message {}::{}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message {}::{}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata) throws JAXBException {
        FinancialProvisions provisions = getFinancialProvisionFeed(messageMetadata);
        List<Provisions> provisionList = new ArrayList<>();
        deleteDataFromRepo();
        Optional.ofNullable(provisions).ifPresent(pf ->
            pf.getFinancialProvision().forEach(financialProvision ->
                addFinancialFeedDetailsIntoRepository(financialProvision, provisionList)
            )
        );
        if (CollectionUtils.isNotEmpty(provisionList)) {
            financialProvisionRepository.saveAll(provisionList);
        }
    }

    private void deleteDataFromRepo() {
        Optional<Provisions> provisions = financialProvisionRepository.findTopByOrderByLastUpdatedDesc();
        if (provisions.isPresent() && DateUtils.isBefore(provisions.get().getLastUpdated(), LocalDateTime.now().minusDays(2))) {
            financialProvisionRepository.deleteAllInBatch();
        }
    }

    private FinancialProvisions getFinancialProvisionFeed(String message) throws JAXBException {
        FinancialProvisions financialFeed = null;
        final String methodName = "getFinancialProvisionFeed";
        log.debug("Entering ::{} :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(FinancialProvisions.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            financialFeed = (FinancialProvisions) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting ::{} ::{} ", this.getClass().getSimpleName(), methodName);
        return financialFeed;
    }

    @Transactional
    public void addFinancialFeedDetailsIntoRepository(FinancialProvision financialProvision, List<Provisions> provisions) {
        final String methodName = "addFinancialFeedDetailsIntoRepository";
        log.debug("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        Product existingProduct = servicesHelper.getProductByEanAndSalesUnit(financialProvision.getEan(), financialProvision.getSalesOrg());
        if (Optional.ofNullable(existingProduct).isPresent()) {
            refreshRepositoryForFinancialFeed(financialProvision, existingProduct, provisions);
        } else {
            addProductAndRefreshFinancialFeedIntoRepository(financialProvision, provisions);
        }
        log.debug("Exiting :: {} :: {} ", this.getClass().getSimpleName(), methodName);
    }

    private void addProductAndRefreshFinancialFeedIntoRepository(FinancialProvision financialProvision, List<Provisions> provisions) {
        Product newlySavedProduct = servicesHelper.createProduct(financialProvision.getEan(), financialProvision.getArticleNumber(),
                financialProvision.getSalesOrg());
        refreshRepositoryForFinancialFeed(financialProvision, newlySavedProduct, provisions);
    }

    private void refreshRepositoryForFinancialFeed(FinancialProvision financialProvision, Product product, List<Provisions> provisions) {
        Store existingStore = servicesHelper.findStoreByStoreCode(financialProvision.getStoreCode());
        if (provisions.size() == 1000) {
            financialProvisionRepository.saveAll(provisions);
            provisions.clear();
        }
        provisions.add(createFinancialProvisionInfo(financialProvision, product, existingStore));
    }

    private Provisions createFinancialProvisionInfo(FinancialProvision financialProvision, Product product, Store existingStore) {
        Provisions provision = new Provisions();
        provision.setProvRate(financialProvision.getProvRate());
        provision.setProvStock(financialProvision.getProvStock());
        provision.setStockValue(financialProvision.getStockValue());
        provision.setQuantity(financialProvision.getQuantityValue());
        provision.setLastUpdated(LocalDateTime.now());
        provision.setProduct(product);
        provision.setStore(existingStore);
        return provision;
    }

}
