package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.PriceControllerSwagger;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.ExcelData;
import com.kingfisher.compprice.dao.price.PriceSubmissionRequest;
import com.kingfisher.compprice.dao.request.PriceUpdateStatusReq;
import com.kingfisher.compprice.dao.response.PriceUpdateResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationUpdateResponse;
import com.kingfisher.compprice.helper.PriceExcelPrepHelper;
import com.kingfisher.compprice.service.PriceUpdateService;
import com.kingfisher.compprice.service.UserService;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(PRICE_BASE_URL)
public class PriceController implements PriceControllerSwagger {

	private static final String ATTACHMENT_FILENAME = "attachment; filename=";
	private static final String APPLICATION_VND_MS_EXCEL = "application/vnd.ms-excel";

	private final PriceExcelPrepHelper priceExcelHelper;
	private final PriceUpdateService priceUpdateService;
	private final UserService userService;
	private final CurrentUser cUser;

	Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'EXPORT_REPORT')")
	@GetMapping(PRICE_DOWNLOAD)
	public ResponseEntity<Resource> downloadFileForChangesMadeForGivenStore(final HttpServletResponse response,
			@PathVariable(required = false) final String tenant, @RequestParam final String storeCode) {
		log.info("Price: downloadFileForChangesMadeForGivenStore --> {}, {}, {}", tenant, storeCode, gson.toJson(response));
		String filename = "HO_" + LocalDateTime.now() + EXCEL_FORMAT;
		Map<String, List<ExcelData>> priceUpdates = null;
		if (userService.isHeadOfficeUser(cUser.getUserId())) {
			priceUpdates = priceExcelHelper.getPriceUpdateData(cUser.getUser());
		} else if (null != storeCode) {
			filename = storeCode + UNDER_SCORE + LocalDateTime.now() + EXCEL_FORMAT;
			priceUpdates = priceExcelHelper.getPriceUpdateDataForStore(cUser.getUser(), storeCode);
		}
		final InputStreamResource file = new InputStreamResource(priceExcelHelper.prepareFileDataForBulk(priceUpdates));
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_FILENAME + filename)
				.contentType(MediaType.parseMediaType(APPLICATION_VND_MS_EXCEL)).body(file);
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'MODIFY_COLLECTION_PRICE')")
	@PostMapping
	public ResponseEntity<String> saveValidatedPriceForLsp() {
		log.info("Price: saveValidatedPriceForLsp");
		return new ResponseEntity<>(priceUpdateService.saveFinalPrice(cUser), HttpStatus.OK);
	}

	@GetMapping(APPROVALS)
	public SingleDataResponse<PriceValidationResponse> getPriceForVerificationForCurrentUser() {
		log.info("Price: getPriceForVerificationForCurrentUser");
		return JsonApiResponse.singleDataResponse(priceUpdateService.findPriceForVerification(cUser.getUser()));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'UPDATE_PRICE_STATUS')")
	@PostMapping(APPROVALS)
	public SingleDataResponse<PriceValidationUpdateResponse> updatePriceStatus(@RequestBody final PriceUpdateStatusReq request) {
		log.info("Price: updatePriceStatus --> {}", gson.toJson(request));
		return JsonApiResponse.singleDataResponse(
				priceUpdateService.updatePriceValidationStatus(cUser.getUser(), request.getId(), request.getStatus()));
	}

	@GetMapping(PRICE_DELTA_DOWNLOAD)
	public ResponseEntity<Resource> downloadValidatedStoreCollectionFile(@PathVariable(TENANT) final String tenant,
																		 @PathVariable("reference") final String reference,
																		 @RequestParam final String storeCode) {
		log.info("Price: downloadValidatedStoreCollectionFile --> {}, {}, {}", tenant, reference, storeCode);
		final String filename = "store_" + LocalDateTime.now() + EXCEL_FORMAT;

		final InputStreamResource file = new InputStreamResource(
				priceExcelHelper.prepareFileData(cUser.getUser().getTenant(), reference, storeCode));

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_FILENAME + filename)
				.contentType(MediaType.parseMediaType(APPLICATION_VND_MS_EXCEL)).body(file);
	}

	@PostMapping(Constants.POST_STORE_COLLECTION_SAVE_FINAL_PRICE)
	public SingleDataResponse<PriceUpdateResponse> savePricesForStoreCollection(@RequestBody final PriceSubmissionRequest priceRequest) {
		log.info("Price: savePricesForStoreCollection --> {}", gson.toJson(priceRequest));
		return JsonApiResponse.singleDataResponse(priceUpdateService.saveStoreCollectionPrice(priceRequest, cUser.getUser()));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'ARTICLE_BULK_UPLOAD')")
	@GetMapping(DOWNLOAD_IMPORT_ERROR)
	@Override
	public ResponseEntity<Resource> downloadImportErrorsFile(@NotNull @RequestParam final String errorKey) {
		final String filename = "Rejet_import_en_masse_" + DateUtils.getTimestamp(LocalDateTime.now(), IMPORT_DATE_FORMAT_YYYYMMDD_HHMMSS)
				+ EXCEL_FORMAT;
		final InputStreamResource file = new InputStreamResource(priceExcelHelper.prepareImportErrorsFile(errorKey));
		log.info("Price: downloadImportErrorsFile --> errorKey: {}, fileName: {}", errorKey, filename);

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_FILENAME + filename)
				.contentType(MediaType.parseMediaType(APPLICATION_VND_MS_EXCEL)).body(file);
	}

}