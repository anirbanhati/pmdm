package com.kingfisher.compprice.dao.entity;

import com.kingfisher.compprice.dao.response.PriceListResponse;
import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "lsp_import_errors")
@Convert(attributeName = "jsonb", converter = JsonBinaryType.class)
public class ImportErrors implements Serializable {
    private static final long serialVersionUID = 4035247442943738898L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "error_key")
    private String errorKey;

    @Type(JsonBinaryType.class)
    @Column(name = "error_json")
    private PriceListResponse errorJson;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

}