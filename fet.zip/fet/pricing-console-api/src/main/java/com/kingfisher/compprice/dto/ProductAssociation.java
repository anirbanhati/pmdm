package com.kingfisher.compprice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@XmlRootElement(name = "ProductAssociation")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductAssociation {

    @XmlElement(name = "compCode")
    private String compCode;
    @XmlElement(name = "compEAN")
    private String compEAN;
    @XmlElement(name = "compArticleNumber")
    private String compArticleNumber;
    @XmlElement(name = "ean")
    private String ean;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "uom")
    private String uom;
    @XmlElement(name = "coef")
    private String coef;
    @XmlElement(name = "competitorArticleDescription")
    private String compArticleDescription;
    @XmlElement(name = "creationDate")
    private String creationDate;
    @XmlElement(name = "deleteFlag")
    private String deleteFlag;

    public String getCompCode() {
        return compCode;
    }

    public void setCompCode(String compCode) {
        this.compCode = compCode;
    }

    public String getCompEAN() {
        return compEAN;
    }

    public void setCompEAN(String compEAN) {
        this.compEAN = compEAN;
    }

    public String getCompArticleNumber() {
        return compArticleNumber;
    }

    public void setCompArticleNumber(String compArticleNumber) {
        this.compArticleNumber = compArticleNumber;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getCoef() {
        return coef;
    }

    public void setCoef(String coef) {
        this.coef = coef;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getCompArticleDescription() {
        return compArticleDescription;
    }

    public void setCompArticleDescription(String compArticleDescription) {
        this.compArticleDescription = compArticleDescription;
    }
}
