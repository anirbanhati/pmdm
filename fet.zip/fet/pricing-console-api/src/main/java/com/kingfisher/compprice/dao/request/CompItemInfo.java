package com.kingfisher.compprice.dao.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.kingfisher.compprice.dao.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompItemInfo {

    @JsonProperty("compNames")
    private List<String> compStoreLongNames;

    @JsonProperty("storeCode")
    private String storeId;

    private List<String> storeCodes;

    private String name;

    @JsonProperty("cBy")
    private String createdBy;

    private String expDate;

    @JsonProperty("products")
    private List<ProductInfo> products;

    @JsonProperty("hoClName")
    private String hoClName;

    @JsonProperty("hoClId")
    private Long hoClId;

    @JsonProperty("prdList")
    private List<Product> productList;

}