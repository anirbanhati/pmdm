package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dto.AssignmentDTO;
import com.kingfisher.compprice.dto.CompetitorStoreDTO;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;

@Getter
@Setter
@ToString
public class StoreCollectionItemResponse implements Serializable, Resource {
    private static final long serialVersionUID = 8790858940796979052L;

    private long id;

    private String storeCode;

    private CompetitorStoreDTO competitor;

    private String name;

    private String createdBy;

    private String tenant;

    private String assignTo;

    private String lastModifiedBy;

    private String categoryType;

    private CollectionStatus status;

    private LocalDateTime creationTime;

    private LocalDateTime lastModifiedTime;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private LocalDateTime expDate;

    @Transient
    private int numOfItems;

    @JsonProperty("items")
    private List<AssignmentDTO> assignment = new ArrayList<>();


    @Override
    public String getJsonApiDataId() {
        return EMPTY_STR;
    }

    @Override
    public String getJsonApiDataType() {
        return EMPTY_STR;
    }

}