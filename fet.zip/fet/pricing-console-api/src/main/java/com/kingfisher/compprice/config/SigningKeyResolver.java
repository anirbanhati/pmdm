package com.kingfisher.compprice.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.SigningKeyResolverAdapter;

import java.io.IOException;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;

public class SigningKeyResolver extends SigningKeyResolverAdapter{
	private final AADKeySet keySet;

	public SigningKeyResolver(final String authority) throws IOException {
		this.keySet = this.getSigningKeys(authority);
	}

	@Override
	public Key resolveSigningKey(final JwsHeader jwsHeader, final Claims claims) {

		final String tokenKeyId = jwsHeader.getKeyId();
		for(final JsonWebKey key: this.keySet.getKeys()){
			if(key.getKid().equalsIgnoreCase(tokenKeyId)){
				return this.generatePublicKey(key);
			}
		}

		throw new JwtValidationException("Signature validation failed: Could not find a key with matching kid");
	}

	private AADKeySet getSigningKeys(final String authority)throws IOException {
		final OpenIdConnectConfiguration openIdConfig = this.getOpenIdConfiguration(authority);
		return this.getKeysFromJwkUri(openIdConfig.getJwksUri());
	}

	private OpenIdConnectConfiguration getOpenIdConfiguration(final String authority) throws IOException {

		final String openIdConnectDiscoveryEndpoint = authority + "/.well-known/openid-configuration";

		final OkHttpClient client = new OkHttpClient();
		final Request request = new Request.Builder()
				.url(openIdConnectDiscoveryEndpoint)
				.build();

		final Response response = client.newCall(request).execute();
		final String responseJson =  response.body().string();

		final ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(responseJson, OpenIdConnectConfiguration.class);
	}
	private AADKeySet getKeysFromJwkUri(final String jwksUri) throws IOException {

		final OkHttpClient client = new OkHttpClient();
		final Request request = new Request.Builder()
				.url(jwksUri)
				.build();

		final Response response = client.newCall(request).execute();
		final String responseJson =  response.body().string();

		final ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(responseJson, AADKeySet.class);
	}

	private PublicKey generatePublicKey(final JsonWebKey key) {
		try {
			final BigInteger modulus = new BigInteger(1, Base64.getUrlDecoder().decode(key.getN()));
			final BigInteger exponent = new BigInteger(1, Base64.getUrlDecoder().decode(key.getE()));

			final RSAPublicKeySpec publicSpec = new RSAPublicKeySpec(modulus, exponent);
			final KeyFactory factory = KeyFactory.getInstance("RSA");
			return factory.generatePublic(publicSpec);
		} catch(final Exception e){
			throw new JwtValidationException("Key generation failed", e);
		}
	}
}
