package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.util.constants.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

@Tag(name = Constants.TAG_STORE_COLLECTION_V2)
public interface StoreCollectionControllerV2Swagger {

	@Operation(description = "Download Store Collection CSV File")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<Resource> downloadCsvFile(HttpServletResponse response) throws IOException;

}