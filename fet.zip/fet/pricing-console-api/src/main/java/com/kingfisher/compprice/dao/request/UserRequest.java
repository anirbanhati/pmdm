package com.kingfisher.compprice.dao.request;

import com.kingfisher.compprice.enums.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class UserRequest {

    @NotNull
    @Size(max = 40)
    @NotBlank
    private String firstName;

    @NotNull
    @Size(max = 40)
    private String lastName;

    @NotNull
    @Size(max = 30, message = "Max Allowed length is 30")
    private String userId;

    @NotNull
    private Role role;

    private String storeCode;
    private String tenant;
    private Long workerId;
    private String subArea;
    private String loginId;
    private String fullName;
    private String emailAddress;
    private String workerStatusCode;
    private LocalDateTime lastUpdateTime;

}