package com.kingfisher.compprice.dao.response.search;


import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductItem extends ProductResponse implements Resource {
	private static final long serialVersionUID = 8478268437334127682L;

	private LatestPriceHistory hisPrice;
	private String storeAppPrice;
	private PriceConversion pConversion;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}
