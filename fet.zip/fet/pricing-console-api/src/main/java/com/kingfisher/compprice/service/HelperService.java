package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.ProvisionDetails;
import com.kingfisher.compprice.dao.RoundingConfigs;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.search.PriceConversion;
import com.kingfisher.compprice.dao.response.search.StagePrice;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.repository.FinancialProvisionRepository;
import com.kingfisher.compprice.repository.RollingDaysRepository;
import com.kingfisher.compprice.repository.SchedulerStatusRepository;
import com.kingfisher.compprice.repository.StageProductRepository;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.exception.ExceptionConstants.ProductExceptions.*;
import static com.kingfisher.compprice.util.constants.CacheConstants.ROLLING_DAYS_CACHE;
import static com.kingfisher.compprice.util.constants.CacheConstants.STOCK_PROVISIONS_CACHE;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class HelperService {


    private final StageProductRepository stageProductRepository;
    private final RollingDaysRepository rollingDaysRepository;
    private final SchedulerStatusRepository schedulerStatusRepository;
    private final FinancialProvisionRepository finProvRepository;
    private final RoundingPriceService roundingPriceService;
    private final ProductTools productTools;
    private final LogService logService;


    public PriceConversion getConversionDetails(final Product product, CategoryRoundingResponse cRounding) {
        StopWatch stopWatch = logService.logStopWatchStart("getConversionDetails");
        final RoundingType roundingType = fetchRoundingType(product, cRounding);
        PriceConversion conversion = new PriceConversion();
        if (roundingType != null) {
            if (RoundingType.UV.toString().equals(roundingType.toString())) {
                conversion.setRUL(false);
            } else if (RoundingType.UL.toString().equals(roundingType.toString())) {
                conversion.setRUV(false);
            }
        }
        logService.logStopWatchStop(stopWatch);
        return conversion;
    }

    public StagePrice getStagePriceInfo(final Product product, final String type, final User user, final double costPrice,
                                        final List<StageProduct> stgProducts, final ProvisionDetails provDetails, final double storePrice) {
        StagePrice stgPrice;
        StageProduct stgProd = getStageProduct(product, stgProducts, type, user);
        if (stgProd != null) {
            stgPrice = setStagePriceData(product, type, user, stgProd, provDetails, storePrice);
        } else {
            stgPrice = setDefaultResponse(product, user, storePrice, costPrice);
        }
        return stgPrice;
    }

    private StageProduct getStageProduct(final Product product, final List<StageProduct> stageProducts, final String type, final User user) {
        StageProduct stageProduct;
        if (null != stageProducts) {
            stageProduct = stageProducts.stream()
                    .filter(stgPrd -> product.getEan().equals(stgPrd.getProduct().getEan()))
                    .findFirst().orElse(null);
        } else {
            stageProduct = getStageProductFromRepo(product, ProductType.valueOf(type), user);
        }
        return stageProduct;
    }

    private StagePrice setStagePriceData(final Product product, final String type, final User user, final StageProduct stageProduct,
                                         final ProvisionDetails provDetails, final double storePrice) {
        StagePrice stgPrice = new StagePrice();
        stgPrice.setSDate(stageProduct.getSDate());
        stgPrice.setEDate(stageProduct.getEDate());
        stgPrice.setLDate(stageProduct.getLastUpdatedTime());
        stgPrice.setPriceStop(stageProduct.isPriceStopped());
        if (ProductType.WarList.toString().equals(type) || ProductType.PVMax.toString().equals(type) || ProductType.PVLocal.toString().equals(type)) {
            saveDetailsForInRangeAndWarListProducts(stgPrice, stageProduct);
        } else {
            saveDetailsForOutOfRangeAndSlowMovingProducts(stgPrice, stageProduct);
        }
        stgPrice.setTRate(DecimalUtils.roundOf(Optional.ofNullable(stageProduct.getTheoriticalMarginRate()).orElse(0.0), ROUND_OF_2));
        stgPrice.setReqRate(DecimalUtils.roundOf(Optional.ofNullable(stageProduct.getReqMarginRate()).orElse(0.0), ROUND_OF_2));
        if (null != provDetails.getRecommandation()) {
            productTools.updateNrvAndMargin(type, stageProduct, stageProduct.getPriceSU(), storePrice, provDetails,
                    productTools.getVATByJurisdictionIdAndClassificationCode(product.getVatCategory(), user));
        }
        stgPrice.setNrv(DecimalUtils.roundOf(Optional.ofNullable(stageProduct.getNrv()).orElse(0.0), DecimalUtils.ROUND_OF_0));
        stgPrice.setMiOnStock(DecimalUtils.roundOf(Optional.ofNullable(stageProduct.getMarginImpact()).orElse(0.0), DecimalUtils.ROUND_OF_0));
        return stgPrice;
    }

    public StageProduct getStageProductFromRepo(final Product product, final ProductType prdType, final User user) {
        return stageProductRepository.findByProductAndUserAndStoreAndPrdTypeAndTenant(product, user, user.getStore(), prdType, user.getTenant())
                .orElse(null);
    }

    private void saveDetailsForInRangeAndWarListProducts(final StagePrice stgPrice, final StageProduct stageProduct) {
        stgPrice.setCmRate(DecimalUtils.roundOf(stageProduct.getMarginRate(), ROUND_OF_2));
        stgPrice.setIndex(DecimalUtils.roundOf(stageProduct.getIndex(), ROUND_OF_2));
        stgPrice.setPriceUOM(null != stageProduct.getPriceUM() ? DecimalUtils.roundOf(stageProduct.getPriceUM(), DecimalUtils.ROUND_OF_3) : null);
        stgPrice.setPriceSU(null != stageProduct.getPriceSU()
                ? DecimalUtils.roundOf(stageProduct.getPriceSU(), ROUND_OF_2)
                : null);
        stgPrice.setNewMargingRate(DecimalUtils.roundOf(null != stageProduct.getNewMarginRate()
                ? stageProduct.getNewMarginRate() : 0, ROUND_OF_2));
        stgPrice.setMgDiff(DecimalUtils.roundOf(null != stageProduct.getMarginDiff()
                ? stageProduct.getMarginDiff() : 0, ROUND_OF_2));
    }

    private void saveDetailsForOutOfRangeAndSlowMovingProducts(final StagePrice stgPrice, final StageProduct stageProduct) {
        stgPrice.setPriceUOM(null != stageProduct.getPriceUM()
                ? DecimalUtils.roundOf(stageProduct.getPriceUM(), DecimalUtils.ROUND_OF_3)
                : null);
        stgPrice.setPriceSU(null != stageProduct.getPriceSU()
                ? DecimalUtils.roundOf(stageProduct.getPriceSU(), DecimalUtils.ROUND_OF_3)
                : null);
        stgPrice.setNewMargingRate(DecimalUtils.roundOf(null != stageProduct.getNewMarginRate()
                ? stageProduct.getNewMarginRate() : 0, ROUND_OF_2));
    }

    private StagePrice setDefaultResponse(final Product prod, final User user, final double storePrice,
                                          final double costPrice) {
        StagePrice stgPrice = new StagePrice();
        stgPrice.setPriceSU(null);
        stgPrice.setEDate(null);
        stgPrice.setLDate(null);
        stgPrice.setMiOnStock(DecimalUtils.roundOf(0, DecimalUtils.ROUND_OF_0));
        stgPrice.setNewMargingRate(DecimalUtils.roundOf(0, ROUND_OF_2));
        stgPrice.setNewPriceUM(null);
        stgPrice.setNrv(DecimalUtils.roundOf(0, DecimalUtils.ROUND_OF_0));
        stgPrice.setPriceUOM(null);
        stgPrice.setSDate(null);
        final double vat = productTools.getVATByJurisdictionIdAndClassificationCode(prod.getVatCategory(), user);
        double cmRate = (((storePrice / vat) - costPrice) / costPrice) * 100;
        stgPrice.setCmRate(DecimalUtils.roundOf(cmRate, ROUND_OF_2));
        stgPrice.setReqRate(stgPrice.getNewMargingRate());
        stgPrice.setTRate(stgPrice.getCmRate());
        return stgPrice;
    }

    public RoundingType fetchRoundingType(final Product product, CategoryRoundingResponse cRounding) {
        final RoundingConfig roundingConfig = findRoundingConfig(product, cRounding);
        return roundingPriceService.deriveRoundingType(roundingConfig);
    }

    private RoundingConfig findRoundingConfig(final Product product, CategoryRoundingResponse cRounding) {
        StopWatch stopWatch = logService.logStopWatchStart("findRoundingConfig");

        RoundingConfig roundingConfig = null;
        Pair<CategoryRoundingConfig, ProductRoundingConfig> configs;

        if (CollectionUtils.isEmpty(cRounding.getConfigs())) {
            configs = roundingPriceService.getCategoryAndProductRounding(product);
        } else {
            RoundingConfigs rConfigs = cRounding.getConfigs().stream().filter(conf -> product.getEan().equals(conf.getEan())).findFirst().orElse(new RoundingConfigs());
            configs = Pair.of(rConfigs.getCategoryConfig(), rConfigs.getProductConfig());
        }

        if (configs.getRight() != null) {
            roundingConfig = configs.getRight();
        } else if (configs.getLeft() != null) {
            roundingConfig = configs.getLeft();
        } else if (BDFR_SALES_ORGS.contains(product.getSalesUnit())) {
            throw new DetailsNotFoundException(ROUNDING_NOT_FOUND_APP_EXP, ROUNDING_NOT_FOUND_HTTP_STATUS,
                    ROUNDING_NOT_FOUND_DETAILS, ROUNDING_NOT_FOUND_ID, ROUNDING_NOT_FOUND_POINTER,
                    product.getEan(), ROUNDING_NOT_FOUND_TITLE);
        }
        cRounding.setCategoryConfig(configs.getLeft());
        cRounding.setRType(null != cRounding.getCategoryConfig() ?
                roundingPriceService.deriveRoundingType(cRounding.getCategoryConfig()) : RoundingType.UV);

        logService.logStopWatchStop(stopWatch);
        return roundingConfig;
    }

    @Cacheable(value = STOCK_PROVISIONS_CACHE, key = "{#product.ean, #user.store.storeCode}")
    public Provisions findStockForEan(final User user, final Product product) {
        StopWatch stopWatch = logService.logStopWatchStart("findStockForEan");

        final Optional<Provisions> provisions = finProvRepository.findTopByStoreAndProductOrderByLastUpdatedDesc(user.getStore(), product);
        if (provisions.isPresent()) {
            logService.logStopWatchStop(stopWatch);
            return provisions.get();
        } else {
            final Provisions prov = new Provisions();
            prov.setProvRate(0);
            prov.setProvStock(0);
            prov.setStockValue(0);
            prov.setQuantity(0);
            logService.logStopWatchStop(stopWatch);
            return prov;
        }
    }

    @Cacheable(value = ROLLING_DAYS_CACHE)
    public int getRollingDaysForPVMax() {
        int rollingDays = rollingDaysRepository.findTopByOrderByLastUpdatedDesc().map(RollingDays::getDays).orElse(30);
        log.debug("PVMax rolling days:: {}", rollingDays);
        return rollingDays;
    }

    @Transactional
    public void saveSchedulerStatusInfo(final String schedulerName, final LocalDateTime startTime, final String status) {
        final SchedulerStatus schedulerStatus = new SchedulerStatus();
        schedulerStatus.setSchedulerName(schedulerName);
        schedulerStatus.setStatus(status);
        schedulerStatus.setStartTime(startTime);
        schedulerStatus.setEndTime(LocalDateTime.now());
        schedulerStatus.setUpdatedAt(LocalDateTime.now());
        schedulerStatusRepository.save(schedulerStatus);
    }

}