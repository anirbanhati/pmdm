package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductRoundingConfig;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoundingConfigs {

    private String ean;
    private Product product;
    private CategoryRoundingConfig categoryConfig;
    private ProductRoundingConfig productConfig;

}