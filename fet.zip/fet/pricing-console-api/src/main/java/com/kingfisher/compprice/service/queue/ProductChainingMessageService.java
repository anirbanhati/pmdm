package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductChainingInfo;
import com.kingfisher.compprice.dto.ProductChaining;
import com.kingfisher.compprice.dto.ProductChainings;
import com.kingfisher.compprice.repository.ProductChainingRepository;
import com.kingfisher.compprice.repository.ProductRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.domain.Tenant.BDFR;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductChainingMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final ProductChainingRepository productChainingRepository;
    private final ProductRepository productRepository;
    private final MessageServicesHelper messageServiceHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return MessageService.ProcessedByType.PRODUCT_CHAINING_FEED_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Product Chaining Feed :: {}", message);
        }
        final String methodName = "processMessage()";
        try {
            log.info("Start processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String message) throws JAXBException {
        if (StringUtils.isNotEmpty(message)) {
            ProductChainings productChainings = getProductChainingObject(message);
            final List<String> salesUnits = messageServiceHelper.determineSalesOrgByTenant(BDFR.getTenantId());
            Optional.ofNullable(productChainings).ifPresent(pcs -> pcs.getProductChainingList()
                            .forEach(pc -> processProductChain(pc, salesUnits)));
        } else
            log.info(":::The invalid empty message received in Product chaining inbound feed:::");
    }

    private void processProductChain(final ProductChaining productChain, final List<String> salesUnits) {
        if (isValidProductChainDetails(productChain)) {
            refreshProductChainRepository(productChain, salesUnits);
        } else
            log.info("::The product chain details are not valid::");
    }

    private void refreshProductChainRepository(final ProductChaining productChainData, final List<String> salesUnits) {
        List<Product> existingProducts = productRepository.findByEanAndSalesUnitIn(productChainData.getEan(), salesUnits);

        salesUnits.forEach( salesUnit -> {
            var existingProduct = existingProducts.stream()
                    .filter(products -> Objects.equals(salesUnit, products.getSalesUnit())).findFirst();
            if (existingProduct.isPresent()) {
                refreshProductChainRepositoryWithExistingProduct(productChainData, existingProduct.get());
            } else {
                createNewProductAndRefreshProductChainRepo(productChainData, salesUnit);
            }
        });
    }

    private void refreshProductChainRepositoryWithExistingProduct(final ProductChaining productChainData, Product existingProduct) {
        ProductChainingInfo existingProductChainingInfo = productChainingRepository.findByProduct(existingProduct).orElse(null);
        if (null != existingProductChainingInfo) {
            refreshExistingProductChainDetails(productChainData, existingProductChainingInfo);
        } else {
            saveNewProductChainRecordsInRepo(productChainData, existingProduct);
        }
    }

    private void createNewProductAndRefreshProductChainRepo(ProductChaining productChainData, final String salesUnit) {
        Product newProduct = messageServiceHelper.createProduct(productChainData.getEan(), productChainData.getArticleNumber(), salesUnit);
        saveNewProductChainRecordsInRepo(productChainData, newProduct);
    }

    private void refreshExistingProductChainDetails(ProductChaining productChainData, ProductChainingInfo prodChain) {
        populateProductChainDetails(productChainData, prodChain);
        productChainingRepository.save(prodChain);
    }

    private void saveNewProductChainRecordsInRepo(ProductChaining productChainData, Product newProduct) {
        ProductChainingInfo newProductChainInfo = new ProductChainingInfo();
        populateProductChainDetails(productChainData, newProductChainInfo);
        newProductChainInfo.setProduct(newProduct);
        productChainingRepository.save(newProductChainInfo);
    }

    private void populateProductChainDetails(ProductChaining productChainData, ProductChainingInfo prodChain) {
        prodChain.setGroupingCode(productChainData.getGroupingCode());
        prodChain.setGroupingDescription(productChainData.getGroupingDescription());
        prodChain.setUom(productChainData.getUom());
        prodChain.setCoefType(productChainData.getCoefType());
        prodChain.setCoef(productChainData.getCoef());
        prodChain.setCoefMin(productChainData.getCoefMin());
        prodChain.setCoefMax(productChainData.getCoefMax());
        prodChain.setDeleteFlag(productChainData.getDeleteFlag());
        prodChain.setCreationDate(messageServiceHelper.getLocalDateTime(productChainData.getCreationDate()));
        prodChain.setLastUpdated(LocalDateTime.now());
    }

    private boolean isValidProductChainDetails(ProductChaining productChain) {
        return StringUtils.isNotEmpty(productChain.getGroupingCode()) && StringUtils.isNotEmpty(productChain.getEan()) && StringUtils.isNotEmpty(productChain.getArticleNumber());
    }

    private ProductChainings getProductChainingObject(final String message) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(ProductChainings.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (ProductChainings) unmarshaller.unmarshal(new StringReader(message));
    }

}