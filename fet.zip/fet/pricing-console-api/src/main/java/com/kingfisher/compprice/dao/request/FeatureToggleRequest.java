package com.kingfisher.compprice.dao.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FeatureToggleRequest {

    private String name;
    private String description;

}