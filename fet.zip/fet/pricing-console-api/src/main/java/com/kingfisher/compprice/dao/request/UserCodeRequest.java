package com.kingfisher.compprice.dao.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserCodeRequest {

	private Long workGroupCode;
	private String workGroupDesc;
	private String salesOrg;
	private List<String> permissionName;

}