package com.kingfisher.compprice.dao;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EanDates implements Serializable {

    private static final long serialVersionUID = -6400885273437831417L;

    private String ean;

    @JsonProperty("startDate")
    private String sDate;

    @JsonProperty("endDate")
    private String eDate;

}