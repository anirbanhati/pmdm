package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.UserControllerSwagger;
import com.kingfisher.compprice.dao.entity.FeaturesPermissions;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.entity.UserCode;
import com.kingfisher.compprice.dao.request.*;
import com.kingfisher.compprice.dao.response.Roles;
import com.kingfisher.compprice.dao.response.UserWithPermissionsResponse;
import com.kingfisher.compprice.dao.response.user.UserRoleResponse;
import com.kingfisher.compprice.dto.Workers;
import com.kingfisher.compprice.service.UserService;
import com.kingfisher.compprice.service.queue.LocalStorePricingUserService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequestMapping(USER_BASE_URL)
@RequiredArgsConstructor
public class UserController implements UserControllerSwagger {

	private final UserService userService;
	private final LocalStorePricingUserService localStorePricingUserService;

	Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

	@PostMapping(UPLOAD)
	public ResponseEntity<String> importUsersList(@RequestParam(REQUEST_PARAM_FILE) final MultipartFile file) throws IOException {
		log.info("User: importUsersList");
		final InputStream fileStream = file.getInputStream();
		userService.importUsersList(fileStream);
		return new ResponseEntity<>("Items are created in database.", HttpStatus.CREATED);
	}

	@Override
	@PostMapping
	public SingleDataResponse<User> saveUserDetails(@Valid @RequestBody final UserRequest userRequest) {
		log.info("User: saveUserDetails --> {}", gson.toJson(userRequest));
		final var newUser = userService.createNewUser(userRequest);
		return JsonApiResponse.singleDataResponse(newUser);
	}

	@Override
	@PutMapping(URI_USER_ID)
	public SingleDataResponse<User> updateUserByUserId(@NotNull @PathVariable(USER_ID) final String userId,
													   @RequestBody final UserRequest userRequest) {
		log.info("User: updateUserByUserId --> {}, {}", userId, gson.toJson(userRequest));
		return JsonApiResponse.singleDataResponse(userService.updateUser(userId, userRequest));
	}

	@Override
	@GetMapping
	public MultiDataResponse<User> getAllUser() {
		log.info("User: getAllUser");
		return JsonApiResponse.multiDataResponse(userService.findAllUsers());
	}

	@Override
	@GetMapping(USER_ROLES)
	public SingleDataResponse<Roles> getUserRoles() {
		log.info("User: getUserRoles");
		return JsonApiResponse.singleDataResponse(userService.fetchRoles());
	}

	@Override
	@GetMapping(URI_USER_ID)
	public SingleDataResponse<User> getUserDetailsByUserId(@NotNull @PathVariable(USER_ID) final String userId) {
		log.info("User: getUserRoles --> {}", userId);
		return JsonApiResponse.singleDataResponse(userService.findUserByUserId(userId));
	}

	@Override
	@GetMapping(URI_STORE)
	public MultiDataResponse<User> getUsersByStoreCode(@NotNull @RequestParam(STORE_CODE) final String storeCode) {
		log.info("User: getUsersByStoreCode --> {}", storeCode);
		final List<User> users = userService.findUserByStoreCode(storeCode);
		return JsonApiResponse.multiDataResponse(users);
	}

	@GetMapping(USER_BY_ROLE)
	public MultiDataResponse<UserRoleResponse> getUserByRole(@RequestParam("role") String role) {
		log.info("User: getUserByRole --> {}", role);
		return JsonApiResponse.multiDataResponse(userService.findAllUsersByRole(role));
	}

	@Override
	@DeleteMapping(URI_USER_ID)
	public SingleDataResponse<User> deleteUserDetails(@NotNull @PathVariable(USER_ID) final String userId) {
		log.info("User: deleteUserDetails --> {}", userId);
		final User user = new User();
		user.setUserId(userId);
		userService.deleteUser(userId);
		return JsonApiResponse.singleDataResponse(user);
	}

	@Override
	@PostMapping(FEATURE_PERMISSIONS)
	public List<FeaturesPermissions> postFeaturePermission(@RequestBody final List<PermissionRequest> requests) {
		log.info("User: postFeaturePermission --> {}", gson.toJson(requests));
		return userService.storeFeatures(requests);
	}

	@Override
	@PostMapping(WORKGROUP_PERMISSIONS)
	public List<UserCode> createAndMapFeaturesPermissions(@RequestBody final List<UserCodeRequest> requests) {
		log.info("User: createAndMapFeaturesPermissions --> {}", gson.toJson(requests));
		return userService.createAndMapFeaturesPermissionsService(requests);
	}

	@Override
	@PutMapping(WORKGROUP_PERMISSIONS_WORK_GROUP_CODE)
	public String updatePermissionsOfWorkgroupCode(@PathVariable("workGroupCode") long workGroupCode,
												   @RequestBody UserCodeUpdateRequest updateReq) {
		log.info("User: updatePermissionsOfWorkgroupCode --> {}, {}", workGroupCode, gson.toJson(updateReq));
		userService.updatePermissionOfWorkgroupCodeService(workGroupCode, updateReq);
		return STATUS_OK;
	}

	@Override
	@GetMapping(PERMISSIONS_BY_USER_ID)
	public SingleDataResponse<UserWithPermissionsResponse> getUserWithPermissions(@NotNull @PathVariable(USER_ID) String userId) {
		log.info("User: getUserWithPermissions --> {}", userId);
		return JsonApiResponse.singleDataResponse(userService.getUserWithPermissionsService(userId));
	}

	@GetMapping(STORE_ASSIGN_TO)
	public MultiDataResponse<User> getAssignToUsersByStoreCode(@RequestParam(STORE_CODE) final String storeCode) {
		log.info("User: getAssignToUsersByStoreCode --> {}", storeCode);
		final List<User> users = userService.findUsersAssignedToByStoreCode(storeCode);
		return JsonApiResponse.multiDataResponse(users);
	}

	@DeleteMapping(FEATURE_PERMISSIONS)
	public String deleteAllFeaturesPermissions() {
		log.info("User: deleteAllFeaturesPermissions");
		userService.deleteAllFeaturesPermissionsService();
		return STATUS_OK;
	}

	@Override
	@PostMapping(value = UPLOAD_XML, consumes = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<String> uploadUsersXml(@RequestBody Workers workers) {
		log.info("User: uploadUsersXml --> {}", gson.toJson(workers));
		Optional.ofNullable(workers).ifPresent(workerList ->
				workerList.getWorkerList().forEach(localStorePricingUserService::saveWorkerDetailsFeedToRepository));
		return ResponseEntity.ok("User XML imported successfully");
	}

}