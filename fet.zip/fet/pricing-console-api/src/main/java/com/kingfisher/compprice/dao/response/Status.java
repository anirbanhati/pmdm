package com.kingfisher.compprice.dao.response;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.jsonapi.Resource;

public class Status implements Resource {

	/**
	 *
	 */
	private static final long serialVersionUID = -1096332319122103313L;

	@JsonProperty("status")
	private Set<String> cStatus;

	public Set<String> getcStatus() {
		return cStatus;
	}

	public void setcStatus(final Set<String> cStatus) {
		this.cStatus = cStatus;
	}

	@Override
	public String getJsonApiDataId() {
		return "sId";
	}

	@Override
	public String getJsonApiDataType() {
		return "status";
	}

}