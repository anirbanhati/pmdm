package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.entity.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductProvision implements Serializable {
    private static final long serialVersionUID = 2304938992901761699L;

    private Product product;
    private String category;
    private String subCategory;
    private String brickName;
    private String description;
    private Double provStock;

}