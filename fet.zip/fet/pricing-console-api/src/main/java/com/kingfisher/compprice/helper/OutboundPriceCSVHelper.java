package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.entity.PriceUpdate;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dto.outbound.PriceUpdateCSVData;
import com.kingfisher.compprice.enums.PriceValidationStatus;
import com.kingfisher.compprice.repository.PriceUpdateRepository;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.opencsv.ICSVWriter.DEFAULT_SEPARATOR;

@Slf4j
@RequiredArgsConstructor
@Component
public class OutboundPriceCSVHelper {

    private static final String FILE_PREFIX = "store";

    private final PriceUpdateRepository priceUpdateRepository;
    private final MessageServiceTools messageServiceTools;
    private final StorePriceTools storePriceTools;


    public List<PriceUpdateCSVData> prepareFileData(final List<PriceUpdate> priceUpdates) {
        final List<PriceUpdateCSVData> updatedPriceList = new ArrayList<>();
        priceUpdates.forEach(priceUpdate -> updatedPriceList.add(getPriceUpdateCSVData(priceUpdate)));
        return updatedPriceList;
    }

    private PriceUpdateCSVData getPriceUpdateCSVData(final PriceUpdate priceUpdate) {
        final PriceUpdateCSVData updatedPrice =  new PriceUpdateCSVData();
        updatedPrice.setEan(priceUpdate.getProduct().getEan());
        updatedPrice.setArticle(priceUpdate.getProduct().getProductCode());
        updatedPrice.setUom(priceUpdate.getProduct().getUom());
        updatedPrice.setSalesOrg(priceUpdate.getProduct().getSalesUnit());
        updatedPrice.setStoreCode(priceUpdate.getStore().getStoreCode());
        updatedPrice.setValidFrom(priceUpdate.getStartDate());
        updatedPrice.setValidTo(priceUpdate.getEndDate());
        updatedPrice.setPrice(priceUpdate.getPrice());
        updatedPrice.setUser(priceUpdate.getPUser().getUserId());
        updatedPrice.setArticleType(getProductType(priceUpdate));
        updatedPrice.setCurrency(populateCurrency(priceUpdate.getProduct(), priceUpdate.getStore()));
        updatedPrice.setTenant(priceUpdate.getTenant());
        updatedPrice.setStoppedPrice(priceUpdate.getStoppedPrice());
        updatedPrice.setReasonCode(populateReasonCode(updatedPrice.getArticleType(), priceUpdate.getTenant()));
        return updatedPrice;
    }

    private String getProductType(final PriceUpdate priceUpdate) {
        return Optional.ofNullable(priceUpdate.getPrdType()).isPresent() ? priceUpdate.getPrdType().getpType() : EMPTY_STR;
    }

    private String populateCurrency(final Product product, final Store store) {
        final StorePrice storePrice = storePriceTools.getActiveStorePrice(product, store);
        return Optional.ofNullable(storePrice).isPresent() && StringUtils.isNotEmpty(storePrice.getCurrency()) ? storePrice.getCurrency() : null;
    }

    public String populateReasonCode(final String articleType, final String tenant) {
        if (StringUtils.equalsIgnoreCase(TENANT_CAFR, tenant)) {
            return
                    switch (articleType) {
                        case SLOW_MOVING -> REASON_CODE_SLOW;
                        case OUT_OF_RANGE -> REASON_CODE_EXIT_STOCK;
                        default -> EMPTY_STR;
                    };
        } else {
            return EMPTY_STR;
        }
    }

    public Map<File,String> getOutboundPriceFileForBucketUpload() throws IOException {
        final List<PriceUpdateCSVData> priceUpdateData = prepareFileData(getDeltaPriceUpdatesForOutboundFeed());
        return CollectionUtils.isNotEmpty(priceUpdateData) ? getOutboundPriceCSVFileForUpload(priceUpdateData) : null;
    }

    private Map<File, String> getOutboundPriceCSVFileForUpload(final List<PriceUpdateCSVData> priceUpdateData) throws IOException {
        Map<File, String> fileTenantMap = new HashMap<>();
        final List<String[]> csvData = prepareOutboundPriceFeedDataForCSVFile(priceUpdateData);
        final String salesOrg = priceUpdateData.get(0).getSalesOrg();
        if (StringUtils.isNotEmpty(salesOrg)) {
            final File tempFileToUpload = messageServiceTools.getFileToUpload(csvData, FILE_PREFIX, salesOrg, DEFAULT_SEPARATOR);
            fileTenantMap.put(tempFileToUpload, priceUpdateData.get(0).getTenant());
        } else
            log.info("Invalid Sales org or tenant::{}", FILE_PREFIX);
        return fileTenantMap;
    }

    private List<String[]> prepareOutboundPriceFeedDataForCSVFile(final List<PriceUpdateCSVData> priceUpdateData) {
        final List<String[]> records = new ArrayList<>();
        records.add(OUTBOUND_PRICE_HEADERS);
        priceUpdateData.forEach(outboundData ->
                records.add(new String[]{outboundData.getEan(), outboundData.getArticle(), outboundData.getUom(), outboundData.getSalesOrg(), outboundData.getStoreCode(), outboundData.getCurrency(), outboundData.getArticleType(),
                        DateUtils.getValidDateFormatForOutbound(outboundData.getValidFrom()), DateUtils.getValidDateFormatForOutbound(outboundData.getValidTo()), String.valueOf(outboundData.getPrice()), outboundData.getUser(),
                        outboundData.getStoppedPrice(), outboundData.getReasonCode()})
        );
        return records;
    }

    private List<PriceUpdate> getDeltaPriceUpdatesForOutboundFeed() {
        List<PriceUpdate> price = priceUpdateRepository.findByStatusAndPriceGreaterThan(PriceValidationStatus.APPROVED.getStatus(), 0);
        log.info("Total valid records fetched for processing (Price) ::{}", price.size());
        if (CollectionUtils.isNotEmpty(price)) {
            price.forEach(pu -> {
                pu.setStatus(PriceValidationStatus.EXTRACTED.getStatus());
                log.debug("Updated status to extracted (Price) ::{} to ::{}", pu.getId(), pu.getStatus());
                pu.setExtractedDate(LocalDateTime.now());
            });
            priceUpdateRepository.saveAll(price);
        }
        return price;
    }

}