package com.kingfisher.compprice.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.DESCRIPTION;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Getter
@Setter
@Table(name = "lsp_comp_product")
public class CompetitorProduct implements Serializable {
    private static final long serialVersionUID = -1713674748306701836L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cmp_id")
    @JsonIgnore
    private Long id;

    @Column(name = "ean")
    private String ean;

    @Column(name = "comp_ean")
    private String compEan;

    @Column(name = "code")
    private String code;

    @Column(name = DESCRIPTION)
    private String description;

    @Column(name = "comp_description")
    @JsonProperty("desc")
    private String compDescription;

    @Column(name = "comp_name")
    private String compName;

    @Column(name = "comp_sales_unit")
    private String salesUnit;

    @Column(name = "comp_uom")
    private String uom;

    @Column(name = "comp_uom_price")
    private Double uomPrice = 0d;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    @JsonIgnore
    private Product comProd;

    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @Column(name = "delete_flag")
    private String deleteFlag;

    @Column(name = "coef")
    private Integer coef;

    @Column(name = "comp_article_number")
    @JsonProperty()
    private String compArticleNumber;

    @Column(name = "last_updated_date")
    private LocalDateTime lastUpdatedDate;


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((compEan == null) ? 0 : compEan.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((compName == null) ? 0 : compName.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((ean == null) ? 0 : ean.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((salesUnit == null) ? 0 : salesUnit.hashCode());
        result = prime * result + ((uom == null) ? 0 : uom.hashCode());
        result = prime * result + ((uomPrice == null) ? 0 : uomPrice.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CompetitorProduct other = (CompetitorProduct) obj;
        if (compEan == null) {
            if (other.compEan != null)
                return false;
        } else if (!compEan.equals(other.compEan))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (compName == null) {
            if (other.compName != null)
                return false;
        } else if (!compName.equals(other.compName))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (ean == null) {
            if (other.ean != null)
                return false;
        } else if (!ean.equals(other.ean))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (salesUnit == null) {
            if (other.salesUnit != null)
                return false;
        } else if (!salesUnit.equals(other.salesUnit))
            return false;
        if (uom == null) {
            if (other.uom != null)
                return false;
        } else if (!uom.equals(other.uom))
            return false;
        if (uomPrice == null) {
            return other.uomPrice == null;
        } else
            return uomPrice.equals(other.uomPrice);
    }

}