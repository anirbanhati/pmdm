package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.request.StageChainRequest;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import com.opencsv.exceptions.CsvValidationException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Tag(name = Constants.TAG_STAGE_PRODUCT)
public interface StageProductControllerSwagger {

	@Operation(description = "Search products")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = RESPONSE_MESSAGE_404) })
	SingleDataResponse<StageProductSearchResponse> searchStagedProducts(@RequestBody ProductSearchCriteria searchCriteria);

	@Operation(description = "Save Stage products")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
	SingleDataResponse<StageDataResponse> saveStageData(@RequestBody StageDataRequest req);

	@Operation(description = "Get Stage products Hierarchy")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) }) MultiDataResponse<Category> getProductsFilterOptionByProdType();

	@Operation(description = "Update Staging price for chained products", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	MultiDataResponse<StageDataResponse> stageChainProducts(@PathVariable String chainId, @RequestBody StageChainRequest req);

	@Operation(description = "Remove Stage product by type")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
	SingleDataResponse<RemoveStageResponse> removeStageData(@PathVariable(Constants.PRODUCT_EAN) String ean,
															@PathVariable(Constants.PRD_TYPE) String prdType);

	@Operation(description = "Stop local price")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
	SingleDataResponse<StageDataResponse> stopLocalPriceForLsp(@RequestBody final StageDataRequest req);

	@Operation(description = "Reset Stage price")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
	ResponseEntity<String> resetStageData();

	@Operation(description = "Staging price using import file")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	SingleDataResponse<PriceListResponse> importPriceList(
			@RequestParam(REQUEST_PARAM_FILE) final MultipartFile file) throws IOException, CsvValidationException;

	@Operation(description = "Reset Stage price for chained article ")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200, content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
	ResponseEntity<String> resetChainedStageData(String chainId);


	@Operation(description = "Save date for product for staging", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409) })
	SingleDataResponse<StageDatesResponse> saveGlobalCalendarDate(@RequestBody ProductSearchCriteria searchCriteria);

}