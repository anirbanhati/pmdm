package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.repository.StoreProductRepository;
import com.kingfisher.compprice.util.ExcelDataValidation;
import com.kingfisher.compprice.dao.ExcelError;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.StorePriceExceptions.*;
import static com.kingfisher.compprice.util.constants.CacheConstants.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class StoreProductService {

	private final StoreProductRepository storeProductRepository;
	private final StorePriceService storePriceService;
	private final LogService logService;


	public Set<StoreProduct> isStoreProductAvailableByProductAndStoreAndTenantAndTypes(Product product, Set<ExcelError> excelErrors, User user) {
		boolean isOor = false;
		Set<StoreProduct> storePrd = storeProductRepository.findByStoreAndProduct(user.getStore(), product);
		if (CollectionUtils.isNotEmpty(storePrd)) {
			isOor = storePrd.stream().anyMatch(sPrd -> null!=sPrd.getPrdType() && sPrd.getPrdType().equals(ProductType.OutOfRange));
		}
		if (isOor) {
			ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_EAN, BULK_UPLOAD_INVALID_PRD_TYPE_STATUS,
					BULK_UPLOAD_INVALID_PRD_TYPE, BULK_UPLOAD_INVALID_PRD_TYPE_ID, product.getEan());
		} else {
			final StorePrice storePrice = storePriceService.findActiveStorePriceByProduct(product, user.getStore());
			if (null == storePrice) {
				ExcelDataValidation.setErrorDetail(excelErrors, PRICE_LIST_EAN, STORE_PRICE_NOT_FOUND_HTTP_STATUS,
						STORE_PRICE_NOT_FOUND_DETAILS, STORE_PRICE_NOT_FOUND_ID, product.getEan());
			}
		}
		return storePrd;
	}

	@Transactional
	@Cacheable(value = STORE_PRODUCT_GET_CACHE, key = "{#product.ean, #store.storeCode}")
	public StoreProduct getStoreProductByProductAndStore(final Product product, final Store store) {
		StopWatch stopWatch = logService.logStopWatchStart("getStoreProductByProductAndStore");
		Optional<StoreProduct> sProd = product.getStoreProduct().stream()
				.filter(sProduct -> null != sProduct && null != sProduct.getStore() && store.getStoreId().equals(sProduct.getStore().getStoreId()))
				.findFirst();
		logService.logStopWatchStop(stopWatch);
		return sProd.orElse(new StoreProduct());
	}

	@Cacheable(value = STORE_PRODUCT_CACHE, key = "{#product.ean, #user.store.storeCode}")
	public StoreProduct getStoreProdByProductAndStore(final Product product, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getStoreProdByProductAndStore");
		Optional<StoreProduct> sProd = product.getStoreProduct().stream()
				.filter(sProduct -> null!=sProduct &&  null!=sProduct.getStore() && user.getStore().getStoreId().equals(sProduct.getStore().getStoreId()))
				.findFirst();
		logService.logStopWatchStop(stopWatch);
		return sProd.orElse(null);
	}

	public StoreProduct getStoreProductByProductAndStoreFromRepo(final Product product, final User user) {
		return storeProductRepository.findTopByStoreAndProduct(user.getStore(), product);
	}

	public String getProductTypeFromProduct(final Product product, final User user) {
		StoreProduct storeProduct = getStoreProductByProductAndStoreFromRepo(product, user);
		if (null!=storeProduct && null!=storeProduct.getPrdType()) {
			return storeProduct.getPrdType().toString();
		} else {
			return ProductType.PVMax.toString();
		}
	}

	public boolean isLocalPricingStopped(final StoreProduct storeProduct, final User user) {
		return !(TENANT_CAFR.equals(user.getTenant()) && "OutOfRange".equals(storeProduct.getPrdType().toString())) &&
				(StringUtils.isNotBlank(storeProduct.getLocalPricing()) && PRICE_FLAG_NO.equalsIgnoreCase(storeProduct.getLocalPricing()));
	}

	public Set<StoreProduct> getStoreProductsFromEans(final User user, final List<String> listOfEan) {
		StopWatch stopWatch = logService.logStopWatchStart("getStoreProductsFromEans");
		Set<StoreProduct> storeProducts = storeProductRepository.findByStoreAndProduct_EanIn(user.getStore(), listOfEan);
		logService.logStopWatchStop(stopWatch);
		return storeProducts;
	}

	public Map<Product, StoreProduct> getProductStoreProductMap(final List<Product> products, List<String> listOfEan, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getProductStoreProductMap");

		Map<Product, StoreProduct> productStoreProductMap = new HashMap<>();
		if (CollectionUtils.isEmpty(listOfEan)) {
			listOfEan = products.stream().map(Product::getEan).toList();
		}

		var listOfStoreProducts = getStoreProductsFromEans(user, listOfEan);
		if (CollectionUtils.isNotEmpty(listOfStoreProducts)) {
			Map<Product, List<StoreProduct>> productStoreProductsMap = listOfStoreProducts.stream()
					.collect(Collectors.groupingBy(StoreProduct::getProduct));
			productStoreProductsMap.forEach((product, storeProducts) -> {
				storeProducts.sort(Comparator.comparing(StoreProduct::getModTime).reversed());
				productStoreProductMap.put(product, storeProducts.get(0));
			});
		}
		logService.logStopWatchStop(stopWatch);
		return productStoreProductMap;
	}

	public boolean isShowDatePicker(final String prdType, final User user) {
		return TENANT_CAFR.equals(user.getTenant()) || ProductType.PVMax.toString().equals(prdType)
				|| ProductType.OutOfRange.toString().equals(prdType);
	}

}