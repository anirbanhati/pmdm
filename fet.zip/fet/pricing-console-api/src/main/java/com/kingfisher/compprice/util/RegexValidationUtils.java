package com.kingfisher.compprice.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class RegexValidationUtils {

	public boolean matchWithValidationRegex(final String value, final String regex) {
		return value.matches(regex);
	}

	public boolean isValidLength(final String value, final int length) {
		final String lengthValidationRex = "^\\d{" + length + "}$";
		return matchWithValidationRegex(value, lengthValidationRex) ? Boolean.FALSE : Boolean.TRUE;
	}

	public boolean isBlankField(final String cValue) {
		return StringUtils.isNotEmpty(cValue) ? Boolean.FALSE : Boolean.TRUE;
	}

}