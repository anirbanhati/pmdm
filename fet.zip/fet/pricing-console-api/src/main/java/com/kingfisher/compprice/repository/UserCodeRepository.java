package com.kingfisher.compprice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kingfisher.compprice.dao.entity.UserCode;

@Repository
public interface UserCodeRepository extends JpaRepository<UserCode, Long> {

	 Optional<UserCode> findByWorkGroupCode(Long workGroupCode);

}