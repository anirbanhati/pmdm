package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dto.Worker;
import com.kingfisher.compprice.dto.Workers;
import com.kingfisher.compprice.enums.Role;
import com.kingfisher.compprice.repository.UserCodeRepository;
import com.kingfisher.compprice.repository.UserRepository;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.USER_MESSAGE_SERVICE;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class LocalStorePricingUserService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final UserRepository userRepository;
    private final UserCodeRepository userCodeRepository;
    private final MessageServiceTools messageServiceTools;
    private final MessageServicesHelper messageServiceHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return USER_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("User Feed :: {}", message);
        }
        try {
            final String methodName = "processMessage";
            log.info("Start processing message :: {} :: {}", this.getClass().getSimpleName(), methodName);
            final String refinedMessage=message.startsWith(BYTE_ORDER_MARK_CHARACTER)?message.replace(BYTE_ORDER_MARK_CHARACTER,EMPTY_STR):message;
            doProcessMessage(refinedMessage);
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} :: {} ", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String messageMetadata) throws JAXBException {
        Workers workers = getWorkersFromFeed(messageMetadata);
        Optional.ofNullable(workers).ifPresent(workerList ->
                workerList.getWorkerList().forEach(this::saveWorkerDetailsFeedToRepository));
    }

    private Workers getWorkersFromFeed(final String message) throws JAXBException {
        Workers workers = null;
        final String methodName = "getWorkersFromFeed";
        log.debug("Entering ::{}  :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(Workers.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            workers = (Workers) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting ::{} :: {}", this.getClass().getSimpleName(), methodName);
        return workers;
    }

    @Transactional
    public void saveWorkerDetailsFeedToRepository(final Worker worker) {
        final String methodName = "saveWorkerDetailsFeedToRepository";
        log.info("Entering {}:: Method:: {}", this.getClass().getSimpleName(), methodName);
        Store existingStore = !isSiegeSubAreaPresent(worker) ? messageServiceHelper.findStoreByStoreCode(worker.getStoreCode()) : null;
        if (isFeedValidToBeprocessed(worker, existingStore)) {
            processUserFeed(worker, existingStore);
        } else
            log.info("Invalid feed :: either worker id or company code is missing in feed or store code not present in repo :: {}", methodName);
    }

    private void processUserFeed(final Worker worker, final Store existingStore) {
        final String userId= worker.getLoginId().split("@")[0];
        Optional<User> existingUser = userRepository.findByUserIdAndTenant(userId, messageServiceTools.getTenantFromSalesOrg(worker.getCompanyCode()));
        if (existingUser.isPresent()) {
            refreshWorkerRepository(existingUser.get(), worker, existingStore);
        } else {
            User newUser = new User();
            newUser.setUserId(userId);
            refreshWorkerRepository(newUser, worker, existingStore);
        }
    }

    private boolean isFeedValidToBeprocessed(Worker worker, Store existingStore) {
        log.info("{} {} {} {} {} {} {}",
                StructuredArguments.keyValue("method", "isFeedValidToBeprocessed::"),
                StructuredArguments.keyValue("storeCode", worker.getStoreCode()),
                StructuredArguments.keyValue("store", existingStore),
                StructuredArguments.keyValue("subArea", worker.getSubArea()),
                StructuredArguments.keyValue("workerId", worker.getWorkerId()),
                StructuredArguments.keyValue("companyCode", worker.getCompanyCode()),
                StructuredArguments.keyValue("LoginId", worker.getLoginId()));
        return (Optional.ofNullable(existingStore).isPresent()|| isSiegeSubAreaPresent(worker)) && isValidWorkerFeedForProcessing(worker);
    }

    private boolean isSiegeSubAreaPresent(Worker worker) {
        return SUB_AREA_SIEGE.equalsIgnoreCase(worker.getSubArea());
    }

    private boolean isValidWorkerFeedForProcessing(Worker worker) {
        return null != worker.getWorkerId() && StringUtils.isNotEmpty(worker.getCompanyCode()) && isValidLoginIdPresent(worker);
    }

    private void refreshWorkerRepository(final User user, final Worker worker,final Store store) {
        if (CollectionUtils.isNotEmpty(worker.getWorkGroupAssignmentList())) {
            worker.getWorkGroupAssignmentList().forEach(workGroupAssignment -> {
                user.setUserCode(userCodeRepository.findByWorkGroupCode(workGroupAssignment.getWorkGroupCode()).orElse(null));
                populateWorkersDetails(user, worker,store);
                userRepository.save(user);
            });
        } else {
            populateWorkersDetails(user, worker,store);
            userRepository.save(user);
        }
    }

    private void populateWorkersDetails(final User user,final Worker worker,final Store store) {
        user.setWorkerId(worker.getWorkerId());
        if (StringUtils.isNotEmpty(worker.getCompanyCode())) {
            user.setTenant(messageServiceTools.getTenantFromSalesOrg(worker.getCompanyCode()));
        }
        user.setEmailAddress(worker.getEmailAddress());
        user.setFirstName(worker.getFirstName());
        user.setFullName(worker.getFullName());
        user.setLastName(worker.getLastName());
        user.setLoginId(worker.getLoginId());
        user.setSubArea(worker.getSubArea());
        user.setWorkerStatusCode(worker.getWorkerStatusCode());
        user.setRole(StringUtils.isNotEmpty(worker.getSubArea()) && roleToSubAreaMap.containsKey(worker.getSubArea()) ? roleToSubAreaMap.get(worker.getSubArea()) : Role.Store);
        user.setLastUpdateTime(LocalDateTime.now());
        user.setStore(store);
    }

    private boolean isValidLoginIdPresent(Worker worker) {
        return StringUtils.isNotEmpty(worker.getLoginId()) && worker.getLoginId().contains("@");
    }

}