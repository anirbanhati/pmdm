package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ProductTaxClassification")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductTaxClassification {

    @XmlElement(name = "ProductTaxClassificationCode")
    private String productTaxClassificationCode;

    @XmlElement(name = "TaxGroupRule")
    private List<TaxGroupRule> taxGroupRule;

    public String getProductTaxClassificationCode() {
        return productTaxClassificationCode;
    }

    public void setProductTaxClassificationCode(String productTaxClassificationCode) {
        this.productTaxClassificationCode = productTaxClassificationCode;
    }



    public List<TaxGroupRule> getTaxGroupRule() {
        return taxGroupRule;
    }

    public void setTaxGroupRule(List<TaxGroupRule> taxGroupRule) {
        this.taxGroupRule = taxGroupRule;
    }
}
