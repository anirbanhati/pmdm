package com.kingfisher.compprice.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
@Slf4j
public class InMemoryUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(final String arg0) throws UsernameNotFoundException {
		log.info("UserDetailsService invoked");
		return null;
	}

}
