package com.kingfisher.compprice.dao.response.search;


import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductChainItem implements Resource {

	/**
	 *
	 */
	private static final long serialVersionUID = 8478268437334127682L;
	private String ean;
	private String desc;
	private String cat;
	private String sCat;
	private String bName;
	private String pCode;
	private String pkg2;
	private String uom;
	private String storeAppPrice;
	private String sDate;
	private String eDate;
	private String stdPrice;
	private String type;
	private String fixedPriceFlag;
	private String chainId;
	private Product prd;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}
