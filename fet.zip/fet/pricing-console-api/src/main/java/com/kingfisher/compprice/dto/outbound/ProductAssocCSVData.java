package com.kingfisher.compprice.dto.outbound;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductAssocCSVData {

    private String compCode;
    private String compEan;
    private String compArticleNumber;
    private String articleName;
    private String articleNumber;
    private String compPkgUnit;
    private double priceSu;
    private double priceUom;
    private String packaging1;
    private String packaging2;
    private String creationDate;
    private String deleteFlag;
    private String tenant;
    private String coeff;
    private String storeCode;
    private String compName;
    private String compLongName;
    private double compPriceSu;
    private double compPriceUom;
    private String comments;
}
