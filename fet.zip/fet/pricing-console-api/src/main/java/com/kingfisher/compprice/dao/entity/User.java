package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kingfisher.compprice.dao.PostgreSQLEnumType;
import com.kingfisher.compprice.enums.Role;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.dialect.PostgreSQLEnumJdbcType;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.USER;

@Entity
@Table(name = USER)
@Getter
@Setter
@Convert(attributeName = "pgsql_enum", converter = PostgreSQLEnumType.class)
public class User implements Resource, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5816128975837554995L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "first_name")
    @Size(min = 1, max = 40, message = "Min length is 1 and max length is 40")
    @NotNull
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "tenant")
    private String tenant;

    @Column(name = "user_id")
    @NotNull
    private String userId;

    @Column(name = "role")
    @Enumerated(EnumType.STRING)
    @JdbcType(PostgreSQLEnumJdbcType.class)
    @NotNull
    private Role role;

    @Column(name = "worker_id")
    private Long workerId;

    @Column(name = "sub_area")
    private String subArea;

    @Column(name = "login_id")
    private String loginId;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "email_address")
    private String emailAddress;

    @Column(name = "worker_status_code")
    private String workerStatusCode;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdateTime;

    @JsonIgnore
    @OneToMany(mappedBy = "pUser", cascade = CascadeType.ALL)
    private Set<PriceUpdate> pUpdate = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = USER, cascade = CascadeType.ALL)
    private Set<StageProduct> stageProd = new HashSet<>();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "store_id")
    private Store store;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "workgroup_code_id")
    private UserCode userCode;

    @Override
    public String getJsonApiDataId() {
        return String.valueOf(id);
    }

    @Override
    public String getJsonApiDataType() {
        return USER;
    }

}