package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.OpCoFeatures;
import com.kingfisher.compprice.dao.entity.FeatureEntity;
import com.kingfisher.compprice.dao.request.FeatureToggleRequest;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Tag(name = Constants.TAG_FEATURE)
public interface FeatureToggleControllerSwagger {

	@Operation(description = "Create Feature with Name & Description", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	MultiDataResponse<FeatureEntity> createFeature(@RequestBody List<FeatureEntity> features);

	@Operation(description = "Updates Feature with Name & Description", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	MultiDataResponse<FeatureEntity> updateFeature(@PathVariable String featureId, @RequestBody FeatureToggleRequest request);

	@Operation(description = "Get All Features")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	MultiDataResponse<FeatureEntity> getAllFeatures();

	@Operation(description = "Manage Feature with Tenant", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<OpCoFeatures> manageFeatureForOpCo(@RequestBody OpCoFeatures feature);

	@Operation(description = "Get Feature Toggle Status with Name & Tenant")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<OpCoFeatures> getFeatureDetailsByName(@PathVariable String tenant, @PathVariable String featureName);

	@Operation(description = "Get All Features for Tenant")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<OpCoFeatures> getAllFeaturesByTenant(@PathVariable String tenant);

	@Operation(description = "Get All Enabled Features for Tenant")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<OpCoFeatures> getAllEnabledFeaturesByTenant(@PathVariable String tenant);

}