package com.kingfisher.compprice.dto;

import lombok.Getter;
import lombok.Setter;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.Set;

@XmlRootElement(name = "FinancialProvisions")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class FinancialProvisions {
    @XmlElement(name = "FinancialProvision")
    private Set<FinancialProvision> financialProvision;
}
