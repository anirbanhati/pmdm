package com.kingfisher.compprice.dao.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class SearchPagination implements Serializable {

    private static final long serialVersionUID = -3502408442027146372L;
    private int pageNumber;
    private int pageSize;
    private long totalElements;
    private long numberOfElements;
    private int totalPages;

}