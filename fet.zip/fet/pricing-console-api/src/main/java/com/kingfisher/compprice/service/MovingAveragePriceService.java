package com.kingfisher.compprice.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.dao.entity.MapPrice;
import com.kingfisher.compprice.dao.response.map.ExternalMapAPIResponse;
import com.kingfisher.compprice.repository.MapPriceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static com.kingfisher.compprice.util.constants.CacheConstants.MAP_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.KITS_REQUEST_ID;
import static com.kingfisher.compprice.util.constants.Constants.UNDER_SCORE;

@Service
@RequiredArgsConstructor
@Slf4j
public class MovingAveragePriceService {

	private final MapPriceRepository mapRepo;
	private final MapStoreDataService mapService;
	private final HttpClientProvider httpClientProvider;
	private final LogService logService;


	public String getCostPriceDetails() {
		String baseUrl = "https://integrationservice-v.kfplc.com:7083/StoreMap/BDFR/stores/2330/products/5013529139040";
		return mapResponseFromMapApi(baseUrl);
	}

	@Cacheable(value = MAP_CACHE)
	public Map<String, String> invokeApiAndGetResponse(final String baseUrl, String[] eans, final String storeCode) {
		StopWatch stopWatch = logService.logStopWatchStart("invokeApiAndGetResponse");

		Map<String, String> costDataMap = new HashMap<>();
		List<MapPrice> mapList = mapRepo.findByEanInAndStoreCode(eans, storeCode);

		if (CollectionUtils.isEmpty(mapList) || mapList.size()!=eans.length) {
			log.info(":: Ean(s) not present in DB ::");
			refreshMapData(baseUrl, costDataMap, storeCode, eans);
		} else {
			log.debug(":: Ean(s) present in DB ::");
			costDataMap = mapService.getEanCostPriceMap(mapList);
			Map<String, String> finalCostDataMap = costDataMap;
			CompletableFuture.runAsync(() -> refreshMapData(baseUrl, finalCostDataMap, storeCode, eans));
		}
		logService.logStopWatchStop(stopWatch);
		return costDataMap;
	}

	public void refreshMapData(final String baseUrl, Map<String, String> costDataMap, final String storeCode, String[] eans) {
		StopWatch stopWatch = logService.logStopWatchStart("refreshMapData");

		log.debug("Refreshing Map DB ::::");
		String apiResponse = mapResponseFromMapApi(baseUrl);
		formatMapApiResponse(costDataMap, apiResponse);
		mapService.storeDataInDB(costDataMap, storeCode, List.of(eans));
		logService.logStopWatchStop(stopWatch);
	}

	public String mapResponseFromMapApi(String baseUrl) {
		String apiResponse;
		try {
			HttpClient httpClient = httpClientProvider.buildHttpClient(30000,30000,30000,5);
			HttpUriRequest request = setHeaderForMapApi(baseUrl);
			HttpResponse response = httpClient.execute(request);
			apiResponse = EntityUtils.toString(response.getEntity());
		} catch (GeneralSecurityException | IOException e) {
			apiResponse = e.getMessage();
		}
		return apiResponse;
	}

	public  HttpUriRequest setHeaderForMapApi(String baseUrl) {
		String timeStamp = new SimpleDateFormat("ddMMyyyyHHmss").format(new java.util.Date());
		UUID uuid = UUID.randomUUID();
		return RequestBuilder.get()
				.setUri(baseUrl)
				.setHeader(KITS_REQUEST_ID, "FET_" + timeStamp + UNDER_SCORE + uuid)
				.build();
	}

	public void formatMapApiResponse(Map<String, String> costDataMap, final String apiResponse) {
		log.info("MAP API Response::{}", apiResponse);
		if (StringUtils.isNotEmpty(apiResponse) && isValid(apiResponse)) {
			final Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
			final ExternalMapAPIResponse mapDetails = gson.fromJson(apiResponse, ExternalMapAPIResponse.class);

			if (CollectionUtils.isNotEmpty(mapDetails.getData())) {
				mapDetails.getData().forEach(data -> costDataMap.put(data.getId(), data.getAttributes().getMap()));
			} else {
				log.info("No data found");
			}
		}
	}

	public boolean isValid(final String json) {
		try {
			new JSONObject(json);
		} catch (JSONException e) {
			return false;
		}
		return true;
	}

}