package com.kingfisher.compprice.dao.response.search;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WarListProductItem extends ProductItem {

	private static final long serialVersionUID = 6225012440174442693L;
	private String cpUom;
	private String spUom;
	@JsonProperty("margin")
	private MarginInfo marginInfo;

}
