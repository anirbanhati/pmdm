package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kingfisher.compprice.dao.PostgreSQLEnumType;
import com.kingfisher.compprice.enums.ProductType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.dialect.PostgreSQLEnumJdbcType;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name="store_product_mapping")
@Convert(attributeName = "pgsql_enum", converter = PostgreSQLEnumType.class)
public class StoreProduct implements Serializable {
	private static final long serialVersionUID = 711095020063639031L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

	@Column(name= "last_updated")
	private LocalDateTime modTime;

	@JsonIgnore
	@ManyToOne (fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;

	@Column(name = "prd_type")
	@Enumerated(EnumType.STRING)
	@JdbcType(PostgreSQLEnumJdbcType.class)
	private ProductType prdType;

	@Column(name = "fixed_price")
	private String fixedPrice;

	@Column(name = "max_decrease")
	private Double maxDecrease;

	@Column(name = "max_increase")
	private Double maxIncrease;

	@Column(name = "local_pricing")
	private String localPricing;

	@Column(name = "oor_date")
	private String oorDate;

	@Column(name="is_editable")
	private boolean isEditable;

}