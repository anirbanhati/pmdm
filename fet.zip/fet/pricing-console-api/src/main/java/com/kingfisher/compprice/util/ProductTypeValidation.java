package com.kingfisher.compprice.util;

import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.dao.entity.StoreProduct;

public class ProductTypeValidation extends ProductTypeValidationRule {

    @Override
    public ProductType getPrdTypeFromStoreProduct(final StoreProduct storeProduct) {
        return null != storeProduct ? storeProduct.getPrdType() : ProductType.SlowMoving;
    }

}