package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;

import static com.kingfisher.compprice.util.constants.Constants.ID;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
@Getter
@Setter
@Table(name = "user_role")
public class WorkersInfo implements Serializable {

	private static final long serialVersionUID = -2431376807525453196L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = ID)
	private Long id;

	@Column(name = "worker_id")
	private Long workerId;

	@Column(name = "company_code")
	private String companyCode;

	@Column(name = "sub_area")
	private String subArea;

	@Column(name = "login_id")
	private String loginId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "full_name")
	private String fullName;

	@Column(name = "email_address")
	private String emailAddress;

	@Column(name = "worker_status_code")
	private String workerStatusCode;

	@Column(name = "work_group_code")
	private Long workGroupCode;

}