package com.kingfisher.compprice.dao.response;

import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import com.kingfisher.compprice.dao.entity.ProductRoundingConfig;
import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@ToString
@Getter
@Setter
public class RoundingConfigSpreadsheetData implements Resource {
    /**
     *
     */
    private static final long serialVersionUID = -1354877102434162746L;

    private List<CategoryRoundingConfig> categoryRoundingConfigs;
    private List<ProductRoundingConfig> productRoundingConfigs;
    private boolean hasError;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}