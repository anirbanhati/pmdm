package com.kingfisher.compprice.dao;

import lombok.Data;

@Data
public class FeatureToggle {

  private String name;
  private String description;
  private boolean isEnabled;
  
  public FeatureToggle(String name, String description, boolean isEnabled) {
    super();
    this.name = name;
    this.description = description;
    this.isEnabled = isEnabled;
  }
  
  public FeatureToggle() {
    super();
  }
  
  
}