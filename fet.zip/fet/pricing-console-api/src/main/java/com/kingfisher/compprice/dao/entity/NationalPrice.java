package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name="lsp_national_price")
public class NationalPrice implements Serializable {

	private static final long serialVersionUID = -3501243563382923817L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name="last_updated")
	private LocalDateTime lastUpdateTime;

	@Column(name="start_date")
	private LocalDateTime startDate;

	@Column(name = "tenant")
	private String tenant;

	@Column(name="end_date")
	private LocalDateTime endDate;

	@Column(name="national_price")
	private Double price;

	@Column(name="currency")
	private String currency;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;

}