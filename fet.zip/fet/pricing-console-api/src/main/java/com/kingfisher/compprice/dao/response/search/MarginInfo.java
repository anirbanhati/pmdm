package com.kingfisher.compprice.dao.response.search;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class MarginInfo implements Serializable {

	private static final long serialVersionUID = 4250629158072121279L;
	private double rate;
	private double newRate;
	private double diff;
	private double mImpact;
}
