package com.kingfisher.compprice.configuration.queue;

import com.kingfisher.compprice.service.queue.MessageProcessor;
import com.kingfisher.compprice.service.queue.MessageServiceFactory;
import com.kingfisher.mq.MessageListenerFactory;
import com.kingfisher.mq.MqErrorHandler;
import com.kingfisher.mq.MqMetricHandler;
import com.kingfisher.mq.MqProperties;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.locks.Lock;

import static java.util.Collections.singletonList;

@Slf4j
@Component
public class ProductsMessageListenerFactory implements MessageListenerFactory<MessageProcessor> {

    private final MeterRegistry meterRegistry;
    @Autowired // NOSONAR
    private Lock messageProcessingLock;
    @Autowired // NOSONAR
    private MessageServiceFactory messageServiceFactory;

    @Autowired
    public ProductsMessageListenerFactory(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public MessageProcessor build(String group, String tenant, MqProperties properties) {
        val metricHandler = createMqMetricHandler(properties);
        val mqErrorHandler = createMqErrorHandler(metricHandler);

        if (group.equalsIgnoreCase(MessageSource.PRODUCT_FEED.getSource())) {
            log.info("Test Variable value is {}", properties.getQueueManager());
        }
        return new MessageProcessor(singletonList(messageServiceFactory.getMessageService(group)), mqErrorHandler, metricHandler, tenant, messageProcessingLock);
    }

    private MqMetricHandler createMqMetricHandler(MqProperties mqProperties) {
        return new MqMetricHandler(meterRegistry, mqProperties);
    }

    private MqErrorHandler createMqErrorHandler(MqMetricHandler metricHandler) {
        return new MqErrorHandler(metricHandler);
    }
}
