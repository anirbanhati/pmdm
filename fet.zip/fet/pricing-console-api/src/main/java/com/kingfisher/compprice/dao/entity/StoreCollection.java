package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.PostgreSQLEnumType;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcType;
import org.hibernate.dialect.PostgreSQLEnumJdbcType;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Entity
@Getter
@Setter
@Table(name = "lsp_store_collection")
@Convert(attributeName = "pgsql_enum", converter = PostgreSQLEnumType.class)
public class StoreCollection implements Serializable, Resource {
	private static final long serialVersionUID = -7881635204350904849L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = ID)
	private long id;

	@Column(name = SC_STORE_CODE)
	@JsonProperty("storeId")
	private String storeCode;

	@JsonIgnore
	@Column(name = "competitor_store_id")
	private Long compId;

	@Column(name = COLLECTION_LIST_NAME)
	private String name;

	@Column(name = "created_by")
	@JsonProperty("cBy")
	private String createdBy;

	@Column(name = "tenant")
	@JsonProperty("tenant")
	private String tenant;

	@JsonProperty("assignTo")
	@Column(name = "assign_to")
	private String assignTo;

	@Column(name = "last_modified_by")
	@JsonProperty("modBy")
	private String lastModifiedBy;

	@Column(name = CATEGORY_TYPE)
	@JsonProperty("type")
	private String categoryType;

	@Column(name = STATUS)
	@Enumerated(EnumType.STRING)
	@JdbcType(PostgreSQLEnumJdbcType.class)
	private CollectionStatus status;

	@JsonProperty("cTime")
	@Column(name = "creation_date")
	private LocalDateTime creationTime;

	@JsonProperty("modTime")
	@Column(name = "last_modified")
	private LocalDateTime lastModifiedTime;

	@JsonIgnore
	@Column(name = "effective_start_date")
	private LocalDateTime startDate;

	@JsonIgnore
	@Column(name = EFFECTIVE_END_DATE)
	private LocalDateTime endDate;

	@Column(name = "exp_date")
	private LocalDateTime expDate;

	@JsonIgnore
	@JsonProperty("items")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "storeCollection")
	private List<Assignment> assignment = new ArrayList<>();

	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL }, mappedBy = "storeCollection")
	@JsonIgnore
	private  Set<PriceUpdate> priceUpdates = new HashSet<>();

	@Column(name = "cl_cs_code")
	private String clCsCode;

	@Column(name = "cs_name")
	private String csName;

	@Column(name = HO_CL_NAME)
	private String hoClName;

	@Column(name = HO_CL_ID)
	private Long hoClId;

	@Column(name = "has_store_clone")
	@JsonProperty("hasStoreClone")
	private boolean hasStoreClone;

	@Column(name = "key")
	private String key;

	@Column(name = "collected_date")
	private LocalDateTime collectedDate;


	public StoreCollection() {
		super();
	}

	public int getNumOfItems() {
		return this.assignment.size();
	}

	public void setAssignment(final List<Assignment> assignment) {
		this.assignment = assignment;
		for (final Assignment assign : assignment) {
			assign.setStoreCollection(this);
		}
	}

	@Override
	public String getJsonApiDataId() {
		return String.valueOf(this.id);
	}

	@Override
	public String getJsonApiDataType() {
		return "clItem";
	}

}