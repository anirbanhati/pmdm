package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.CollectionAssginment;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.dao.request.ProductInfo;
import com.kingfisher.compprice.dao.request.StoreCollectionPricesRequest;
import com.kingfisher.compprice.dao.request.StoreCollectionUpdatesInfo;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.repository.AssignmentRepository;
import com.kingfisher.compprice.util.CacheUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.COMPETITOR_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.*;
import static java.util.stream.Collectors.groupingBy;

@Service
@RequiredArgsConstructor
@Slf4j
public class AssignmentItemService {

    private final AssignmentRepository assignmentRepository;
    private final ChangeRequestConfiguration crConfig;
    private final ProductTools productTools;
    private final CacheUtils cacheUtils;
    private final LogService logService;


    @Cacheable(value = COMPETITOR_PRICE_CACHE, key = "{#product.ean, #user.store.storeCode}")
    public double setCompetitorPrice(final Product product, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("setCompetitorPrice");
        Set<Assignment> assignments = findAssignmentByStatusSCAndProd(user.getStore().getStoreCode(), product);
        double value = assignments.stream().min(Comparator.comparing(Assignment::getCollectedPrice)).orElse(new Assignment()).getCollectedPrice();
        logService.logStopWatchStop(stopWatch);
        return value;
    }

    public Set<Assignment> findAssignmentByStatusSCAndProd(final String storeCode, final Product product) {
        return assignmentRepository.findByProductAndStoreCollection_StatusInAndStoreCollection_StoreCodeAndCollectedPriceGreaterThan(product,
                List.of(CollectionStatus.Reported, CollectionStatus.Completed), storeCode, 0);
    }

    private List<Assignment> findAssignmentsByProductAndStatusAndStoreCode(final List<Product> products, final User user) {
        return assignmentRepository.findByProductInAndStoreCollection_StatusInAndStoreCollection_StoreCodeAndCollectedPriceGreaterThan(products,
                List.of(CollectionStatus.Reported, CollectionStatus.Completed), user.getStore().getStoreCode(), 0);
    }

    public void saveProductDetails(final ProductInfo productInfo, final Product product, final Assignment newAssignment, final User user) {
        newAssignment.setProduct(product);
        newAssignment.setTenant(user.getTenant());
        newAssignment.setCollectedArticleCode(productInfo.getCollectedArticleCode());
        newAssignment.setCollectedPrice(-1 == productInfo.getCollectedPrice() ? 0 : productInfo.getCollectedPrice());
        newAssignment.setHasPromo(productInfo.isHasPromo());
        newAssignment.setCollectedPackage(productInfo.getCollectedPackage());
        newAssignment.setNotes(productInfo.getNotes());
        newAssignment.setCollectedEan(productInfo.getCollectedEan());
        newAssignment.setLinkArticle(productInfo.isLinkedArticle());
        newAssignment.setPromoInfo(productInfo.getPromoInfo());
        newAssignment.setMasterDataMissing(null == product || productInfo.isLinkedArticle());
        newAssignment.setCollectedDescription(productInfo.getCollectedDescription());
        newAssignment.setCollectedPkgUnit(productInfo.getCollectedPackageUnit());
        newAssignment.setCollectedPkgValue(productInfo.getCollectedPackageValue());
        if (null != product) {
            cacheUtils.evictCacheByKey(COMPETITOR_PRICE_CACHE, List.of(product.getEan(), user.getStore().getStoreCode()));
        }
    }

    public Map<Product, List<Assignment>> getProductAssignmentsMap(final Set<Assignment> assignments, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getProductAssignmentListMap");

        Map<Product, List<Assignment>> productAssignmentsMap;
        if (TENANT_CAFR.equals(user.getTenant())) {
            productAssignmentsMap = assignments.stream()
                    .filter(assignment -> assignment.getCollectedPrice() > 0)
                    .collect(groupingBy(Assignment::getProduct));
        } else {
            productAssignmentsMap = assignments.stream().collect(groupingBy(Assignment::getProduct));
        }
        logService.logStopWatchStop(stopWatch);
        return productAssignmentsMap;
    }

    public Set<Assignment> getAssignmentsFromSCLists(final StoreCollectionPricesRequest collectionPriceRequest, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getAssignmentsFromSCLists");
         Set<Assignment> assignments = TENANT_BDFR.equals(user.getTenant()) ?
                assignmentRepository.findByStoreCollection_IdInAndProductIsNotNull(collectionPriceRequest.getCollectionIds()) :
                assignmentRepository.findByStoreCollection_IdInAndCollectedPriceGreaterThanAndProductIsNotNull(collectionPriceRequest.getCollectionIds(), 0.0);
        logService.logStopWatchStop(stopWatch);
        return assignments;
    }

    public Optional<Assignment> getAssignmentsBySCAndProduct(StoreCollection storeCollection, Product product) {
        return assignmentRepository.findByStoreCollectionAndProduct(storeCollection, product);
    }

    public void removeAssignment(final StoreCollectionUpdatesInfo clUpdateInfo, final StoreCollection storeCollection) {
        Set<Assignment> assignments = assignmentRepository.findByStoreCollection(storeCollection);
        deleteAssignments(clUpdateInfo, storeCollection, assignments);
    }

    public void deleteAssignments(final StoreCollectionUpdatesInfo scUpdateInfo, final StoreCollection storeCollection,
                                  final Set<Assignment> assignments) {
        if (null != scUpdateInfo.getProducts() && CollectionUtils.isNotEmpty(assignments)) {
            final List<Assignment> removedItems = (List<Assignment>) CollectionUtils
                    .removeAll(assignments, storeCollection.getAssignment());
            if (CollectionUtils.isNotEmpty(removedItems)) {
                for (final Assignment item : removedItems) {
                    assignmentRepository.deleteById(item.getId());
                }
            }
        }
    }

    public List<CollectionAssginment> getCollectedItems(final MasterData masterData, final Set<StoreCollection> storeCollections,
                                                        final Product product, final User user) {
        final List<CollectionAssginment> responseAssignments = new ArrayList<>();
        final List<Assignment> subAssignments = TENANT_BDFR.equals(user.getTenant()) ?
                assignmentRepository.findByProductAndStoreCollectionIn(product, storeCollections) :
                assignmentRepository.findByProductAndStoreCollectionInAndCollectedPriceGreaterThan(product, storeCollections, 0);
        prepareCollectionAssignments(product, responseAssignments, subAssignments, masterData);
        return responseAssignments;
    }

    public void prepareCollectionAssignments(final Product product, final List<CollectionAssginment> responseAssignments,
                                             final List<Assignment> subAssignment, final MasterData masterData) {
        StopWatch stopWatch = logService.logStopWatchStart("prepareCollectionAssignments");

        subAssignment.forEach(assignment -> {
            final CollectionAssginment collAssignment = new CollectionAssginment();
            String csLongName = null != assignment.getStoreCollection().getCsName() ? assignment.getStoreCollection().getCsName() : EMPTY_STR;

            var compNameCompProductMap = masterData.getEanwithCompNameCompProductMap().get(product.getEan());
            final CompetitorProduct compProd = null!=compNameCompProductMap ? compNameCompProductMap.get(csLongName) : null;

            if (null != assignment.getCollectedEan()) {
                collAssignment.setEan(assignment.getCollectedEan());
            } else if (null != compProd) {
                collAssignment.setEan(compProd.getEan());
                collAssignment.setArticleCode(compProd.getCode());
            }
            collAssignment.setArticleCode(assignment.getCollectedArticleCode());
            collAssignment.setPkg(assignment.getCollectedPackage());
            collAssignment.setCreationTime(assignment.getStoreCollection().getCreationTime());
            collAssignment.setStoreCode(assignment.getStoreCollection().getStoreCode());
            collAssignment.setId(assignment.getId());
            collAssignment.setHasPromo(assignment.isHasPromo());
            collAssignment.setNotes(assignment.getNotes());
            collAssignment.setPromoInfo(assignment.getPromoInfo());
            collAssignment.setCompititorName(csLongName);
            collAssignment.setName(assignment.getStoreCollection().getName());
            collAssignment.setPrice(assignment.getCollectedPrice());
            collAssignment.setLinkedArticle(assignment.isLinkArticle());
            if (null != compProd) {
                collAssignment.setSalesUnit(compProd.getSalesUnit());
                collAssignment.setPriceUOM(compProd.getUomPrice());
                collAssignment.setUom(compProd.getUom());
            }
            responseAssignments.add(collAssignment);
        });
        logService.logStopWatchStop(stopWatch);
    }

    public Map<Product, String>  getProductMinCPriceMap(final List<Product> products, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getProductMinCPriceMap");

        Map<Product, String> productMinCPriceMap = new HashMap<>();

        var listOfAssignments = findAssignmentsByProductAndStatusAndStoreCode(products, user);
        if (CollectionUtils.isNotEmpty(listOfAssignments)) {
            Map<Product, List<Assignment>> productAssignmentsMap = listOfAssignments.stream()
                    .collect(Collectors.groupingBy(Assignment::getProduct));
            productAssignmentsMap.forEach((product, assignments) -> productMinCPriceMap.put(product,
                    DecimalUtils.roundOf(assignments.stream().min(Comparator.comparing(Assignment::getCollectedPrice))
                            .orElse(new Assignment()).getCollectedPrice(), DecimalUtils.ROUND_OF_2)));
        }
        logService.logStopWatchStop(stopWatch);
        return productMinCPriceMap;
    }

    public Map<String, List<Assignment>> getSectorScNameWithAssignmentsMap(final CompItemInfo compItemInfo, final User user,
                                                                           List<Assignment> listOfAssignments, List<Product> products) {
        Map<String, List<Assignment>> scNameWithAssignmentsMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(products)) {
            if (crConfig.isSplitHoSc() && StringUtils.isNotEmpty(compItemInfo.getHoClName())) {
                scNameWithAssignmentsMap = classifyAssignmentsBySector(user, getCategoryMap(), compItemInfo, products);
            } else {
                setAssignmentDetailsForStoreCollection(products, listOfAssignments, user);
                scNameWithAssignmentsMap.put(compItemInfo.getName(), listOfAssignments);
            }
        }
        return scNameWithAssignmentsMap;
    }

    public void setAssignmentDetailsForStoreCollection(final List<Product> products, List<Assignment> listOfAssignments,
                                                       final User user) {
        products.stream()
                .filter(productTools::filterNonEligibleProductByStatus)
                .forEach(product -> {
                    Assignment newAssignment = new Assignment();
                    newAssignment.setProduct(product);
                    newAssignment.setTenant(user.getTenant());
                    listOfAssignments.add(newAssignment);
                });
    }

    public Map<String, List<Assignment>> classifyAssignmentsBySector(final User user, final Map<String, String> categoryMap,
                                                                     final CompItemInfo compItemInfo, final List<Product> products) {
        Map<String, List<Assignment>> scNameWithAssignmentsMap = new HashMap<>();
        List<Assignment> development = new ArrayList<>();
        List<Assignment> technical = new ArrayList<>();
        List<Assignment> construction = new ArrayList<>();

        final String scName = compItemInfo.getName();
        final String storeCode = user.getStore().getStoreCode();
        products.forEach(product -> {
            if (productTools.filterNonEligibleProductByStatus(product)) {
                Assignment assignment = new Assignment();
                assignment.setTenant(user.getTenant());

                switch (categoryMap.getOrDefault(product.getCategory(), EMPTY_STR)) {
                    case SECTOR_A:
                        assignment.setProduct(product);
                        development.add(assignment);
                        break;
                    case SECTOR_C:
                        assignment.setProduct(product);
                        construction.add(assignment);
                        break;
                    case SECTOR_T:
                        assignment.setProduct(product);
                        technical.add(assignment);
                        break;
                    default:
                        break;
                }
            }
        });

        if (CollectionUtils.isNotEmpty(development)) {
            scNameWithAssignmentsMap.put(scName + UNDER_SCORE + storeCode + "_Aménagement", development);
        }
        if (CollectionUtils.isNotEmpty(construction)) {
            scNameWithAssignmentsMap.put(scName + UNDER_SCORE + storeCode + "_Construction", construction);
        }
        if (CollectionUtils.isNotEmpty(technical)) {
            scNameWithAssignmentsMap.put(scName + UNDER_SCORE + storeCode + "_Technique", technical);
        }
        return scNameWithAssignmentsMap;
    }

    public Map<String, String> getCategoryMap() {
        Map<String, String> categoryMap = new HashMap<>();
        categoryMap.put("01_Construction Part 1", SECTOR_C);
        categoryMap.put("02_Construction Part 2", SECTOR_C);
        categoryMap.put("01_Construction", SECTOR_C);
        categoryMap.put("02_bois et construction intérieure", SECTOR_C);
        categoryMap.put("03_Menuiserie", SECTOR_C);
        categoryMap.put("17_Aménagmt jardin et Loisirs extérieurs", SECTOR_C);
        categoryMap.put("04_Plomberie et Chauffage Central", SECTOR_A);
        categoryMap.put("07_Salle de bains", SECTOR_A);
        categoryMap.put("08_Rangement", SECTOR_A);
        categoryMap.put("09_Meubles de Cuisine", SECTOR_A);
        categoryMap.put("10_Eviers, Robinets et Electroménager", SECTOR_A);
        categoryMap.put("11_REVETEMENT SOL ET MUR", SECTOR_A);
        categoryMap.put("11_Revêtement sol et mur", SECTOR_A);
        categoryMap.put("19_Quincaillerie", SECTOR_A);
        categoryMap.put("05_Electricité", SECTOR_T);
        categoryMap.put("06_Chauff. élect. & traitement de l'air", SECTOR_T);
        categoryMap.put("12_Décoration", SECTOR_T);
        categoryMap.put("13_Eclairage", SECTOR_T);
        categoryMap.put("14_Peinture intérieure", SECTOR_T);
        categoryMap.put("15_Peint. ext, outils peintre, droguerie", SECTOR_T);
        categoryMap.put("16_Jardinage", SECTOR_T);
        categoryMap.put("18_Outillage", SECTOR_T);
        return categoryMap;
    }

}