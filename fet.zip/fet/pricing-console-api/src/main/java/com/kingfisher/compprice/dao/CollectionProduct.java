package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.response.product.ScProductResponse;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class CollectionProduct implements Serializable {

	private static final long serialVersionUID = -1322577478649360894L;

	private DesiredPrice price;
	private String chainId;
	private ScProductResponse product;
	private List<CollectionAssginment> assignments;
	private double priceSU;
	private double priceUOM;
	private double collectedPrice;

}