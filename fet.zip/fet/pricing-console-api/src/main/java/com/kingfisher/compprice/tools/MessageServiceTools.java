package com.kingfisher.compprice.tools;

import com.kingfisher.compprice.configuration.FeedDataConfiguration;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.dto.ProductInfo;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.repository.ProductRepository;
import com.kingfisher.compprice.repository.StoreProductRepository;
import com.opencsv.CSVWriter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.opencsv.ICSVParser.DEFAULT_ESCAPE_CHARACTER;
import static com.opencsv.ICSVWriter.DEFAULT_LINE_END;
import static com.opencsv.ICSVWriter.NO_QUOTE_CHARACTER;

@Slf4j
@RequiredArgsConstructor
@Component
public class MessageServiceTools {

    private final ProductRepository productRepository;
    private final StoreProductRepository storeProductRepository;
    private final FeedDataConfiguration configuration;


    public void addOrUpdateArticleFeedDetailsIntoRepository(final ProductInfo productInfo, final Store storeData) {
        final Optional<Product> savedProduct = productRepository.findProductByEanAndSalesUnit(productInfo.getEan(), productInfo.getSalesOrg());
        if (savedProduct.isPresent()) {
            refreshRepositoryForExistingArticle(productInfo, savedProduct.get(), storeData);
        } else {
            addDetailsForNewArticle(productInfo, storeData);
        }
    }

    private void addDetailsForNewArticle(final ProductInfo productInfo, final Store storeData) {
        final Product product = new Product();
        product.setEan(productInfo.getEan());
        populateProductDetails(productInfo, product);
        if (StringUtils.isNotEmpty(productInfo.getStoreCode())) {
            final Set<StoreProduct> storeProductSet = new HashSet<>();
            final StoreProduct spr = createProductStoreMappingDetails(productInfo, product, storeData);
            storeProductSet.add(spr);
            product.setStoreProduct(storeProductSet);
            productRepository.save(product);
        } else {
            final StoreProduct storeProduct = populateStoreProductMapping(productInfo, product);
            final Set<StoreProduct> storeProductMapping = new HashSet<>();
            storeProductMapping.add(storeProduct);
            product.setStoreProduct(storeProductMapping);
            productRepository.save(product);
        }
    }

    private StoreProduct populateStoreProductMapping(final ProductInfo productInfo, final Product product) {
        final StoreProduct storeProduct = new StoreProduct();
        if (StringUtils.isNotEmpty(productInfo.getProductType())) {
            storeProduct.setPrdType(getProductType(productInfo.getProductType()));
        }
        storeProduct.setEditable(true);
        storeProduct.setModTime(LocalDateTime.now());
        storeProduct.setProduct(product);
        return storeProduct;
    }

    private void refreshRepositoryForExistingArticle(final ProductInfo productInfo, final Product savedProduct, final Store storeData) {
        populateProductDetails(productInfo, savedProduct);
        if (StringUtils.isNotEmpty(productInfo.getStoreCode())) {
            saveProductWhenStoreCodeIsNotEmpty(productInfo, savedProduct, storeData);
        } else {
            saveProductWhenStoreCodeIsEmpty(productInfo, savedProduct);
        }
    }

    private void saveProductWhenStoreCodeIsNotEmpty(final ProductInfo productInfo, final Product savedProduct, final Store storeData) {
        final Set<StoreProduct> storeProduct = storeProductRepository.findByStoreAndProduct(storeData, savedProduct);
        if (StringUtils.isEmpty(productInfo.getProductType()) || isNotValidForExclusion(productInfo, savedProduct, storeProduct) || StringUtils.isNotEmpty(productInfo.getProductType())) {
            final StoreProduct spr = createProductStoreMappingDetails(productInfo, savedProduct, storeData);
            if (CollectionUtils.isNotEmpty(storeProduct)) {
                storeProduct.stream().findFirst().ifPresent(sp -> {
                    sp.setModTime(spr.getModTime());
                    sp.setEditable(isEditable(spr, sp));
                    sp.setOorDate(spr.getOorDate());
                    sp.setPrdType(spr.getPrdType());
                    if (StringUtils.isNotEmpty(spr.getLocalPricing())) {
                        sp.setLocalPricing(spr.getLocalPricing());
                    }
                    sp.setMaxDecrease(spr.getMaxDecrease());
                    sp.setMaxIncrease(spr.getMaxIncrease());
                    sp.setFixedPrice(spr.getFixedPrice());
                });
                savedProduct.setStoreProduct(storeProduct);
            } else {
                final Set<StoreProduct> storeProductSet = new HashSet<>();
                storeProductSet.add(spr);
                savedProduct.setStoreProduct(storeProductSet);
            }
            productRepository.save(savedProduct);
        }
    }

    private static boolean isEditable(final StoreProduct spr, final StoreProduct sp) {
        return !ProductType.PVMax.equals(sp.getPrdType()) || !ProductType.OutOfRange.equals(spr.getPrdType());
    }

    private void saveProductWhenStoreCodeIsEmpty(final ProductInfo productInfo, final Product savedProduct) {
        final StoreProduct storeProduct = populateStoreProductMapping(productInfo, savedProduct);
        final Set<StoreProduct> storeProductMapping = storeProductRepository.findByProduct(savedProduct);
        final Set<StoreProduct> sp = storeProductRepository.findByStoreAndProduct(null, savedProduct);
        if (sp.stream().findFirst().isEmpty()) {
            storeProductMapping.add(storeProduct);
            savedProduct.setStoreProduct(storeProductMapping);
        }
        productRepository.save(savedProduct);
    }

    private boolean isNotValidForExclusion(ProductInfo productInfo, Product savedProduct, Set<StoreProduct> storeProduct) {
        String storeProductType = getStoreProductType(storeProduct);

        final boolean isNotValidForExclusion =
                !CollectionUtils.isNotEmpty(storeProduct) || !isProductExcludedForUpdate(savedProduct.getSalesUnit(),
                                storeProductType, productInfo.getProductType());

        log.info("ean,store :: {}/{} IsExcluded for update :: {}", productInfo.getEan(), productInfo.getStoreCode(), isNotValidForExclusion);

        return isNotValidForExclusion;
    }

    public boolean isProductExcludedForUpdate(final String salesOrg, String existingProductType, String productTypeFromFeed){
        String tenant = getTenantFromSalesOrg(salesOrg);
        List<String> exclusions = configuration.getUpdateExclusion().get(tenant);
        if (CollectionUtils.isNotEmpty(exclusions)) {
            return exclusions.contains(existingProductType) && !StringUtils.isEmpty(productTypeFromFeed) && !existingProductType.equalsIgnoreCase(productTypeFromFeed);
        }
        return false;
    }

    public String getTenantFromSalesOrg(final String salesOrg) {
        return TENANT_SALES_ORGS_MAP.entrySet().stream()
                .filter(map -> map.getValue().contains(salesOrg))
                .map(Map.Entry::getKey)
                .findAny().orElse(null);
    }

    public String getSalesOrgFromTenant(final String tenant) {
        return TENANT_SALES_ORGS_MAP.getOrDefault(tenant, new ArrayList<>()).stream().findFirst().orElse(EMPTY_STR);
    }

    private static String getStoreProductType(final Set<StoreProduct> storeProduct) {
        String productType = null;
        Optional<StoreProduct> storePrd = storeProduct.stream().findFirst();
        if (storePrd.isPresent() && null != storePrd.get().getPrdType()) {
            productType = storePrd.get().getPrdType().toString();
        }
        return productType;
    }

    private StoreProduct createProductStoreMappingDetails(final ProductInfo productInfo, final Product product, final Store storeData) {
        final StoreProduct spr = new StoreProduct();
        spr.setProduct(product);
        spr.setModTime(LocalDateTime.now());
        spr.setStore(storeData);
        if (StringUtils.isNotEmpty(productInfo.getProductType())) {
            spr.setPrdType(getProductType(productInfo.getProductType()));
        } else {
            spr.setPrdType(null);
        }
        spr.setFixedPrice(productInfo.getFixedPrice());
        spr.setMaxDecrease(StringUtils.isNotEmpty(productInfo.getMaxDecrease()) ?
                Double.parseDouble(productInfo.getMaxDecrease()) : null);
        spr.setMaxIncrease(StringUtils.isNotEmpty(productInfo.getMaxIncrease()) ?
                Double.parseDouble(productInfo.getMaxIncrease()) : null);
        spr.setLocalPricing(productInfo.getLocalPricing());
        spr.setOorDate(productInfo.getOorDate());
        spr.setEditable(true);
        return spr;
    }

    private void populateProductDetails(final ProductInfo productInfo, final Product product) {
        product.setProductCode(productInfo.getArticleNumber());
        product.setSalesUnit(productInfo.getSalesOrg());
        log.debug("category : {}, SubCategory {}, brickName {}", productInfo.getCategory(), productInfo.getSubCategory(), productInfo.getBrickName());
        product.setCategory(productInfo.getCategory());
        product.setSubCategory(productInfo.getSubCategory());
        product.setUom(productInfo.getUom());
        product.setConversion(Double.parseDouble(productInfo.getConversion()));
        product.setDescription(productInfo.getDescription());
        product.setBrickCode(productInfo.getBrickCode());
        product.setBrickName(productInfo.getBrickName());
        product.setPkg1(productInfo.getPackaging1());
        product.setPkg2(productInfo.getPackaging2());
        product.setVatCategory(productInfo.getVatCategory());
        product.setLastUpdated(LocalDateTime.now());
        if (null != productInfo.getProductStatus()) {
            product.setProductStatus(Double.parseDouble(productInfo.getProductStatus()));
        }
    }

    private ProductType getProductType(String type) {
        ProductType productType = null;
        if (StringUtils.isNotEmpty(type)) {
            type = type.replace(" ", EMPTY_STR);
            if (ProductType.OutOfRange.name().equalsIgnoreCase(type)) {
                productType = ProductType.OutOfRange;
            }
            if (ProductType.WarList.name().equalsIgnoreCase(type)) {
                productType = ProductType.WarList;
            }
            if (ProductType.SlowMoving.name().equalsIgnoreCase(type)) {
                productType = ProductType.SlowMoving;
            }
            if (ProductType.PVMax.name().equalsIgnoreCase(type)) {
                productType = ProductType.PVMax;
            }
            if (ProductType.PVLocal.name().equalsIgnoreCase(type)) {
                productType = ProductType.PVLocal;
            }
        }
        return productType;
    }

    public String getCoefValue(final String productPackaging, final String competitorPackaging, final String collectedPackageUnit, final String productPackageUnit) {
        String coefValue = DEFAULT_VALUE_1;
        log.debug("The packaging1 and packaging2 values :: {} :: {}", productPackaging, competitorPackaging);
        if (isPackagingDetailsPresent(productPackaging, competitorPackaging) && isPackagingUnitValidForCoefCaculation(collectedPackageUnit, productPackageUnit)) {
            coefValue = getCalculatedCoefValue(productPackaging, competitorPackaging, coefValue);
        }
        log.debug("The calculated coEff Value :: {}", coefValue);
        return coefValue;
    }

    private String getCalculatedCoefValue(String productPackaging, String competitorPackaging, String coefValue) {
        final double prdPackage = Double.parseDouble(productPackaging);
        final double compPackage = Double.parseDouble(competitorPackaging);
        if (Double.compare(prdPackage, 0.0) > 0 && Double.compare(compPackage, 0.0) > 0) {
            coefValue = getCoefValue(prdPackage, compPackage);
        }
        return coefValue;
    }

    private String getCoefValue(final double productPackaging, final double competitorPackaging) {
        String coefValue;
        DecimalFormat coefFormat = new DecimalFormat("#.##");
        coefValue = coefFormat.format(productPackaging / competitorPackaging);
        return coefValue;
    }

    private boolean isPackagingDetailsPresent(String productPackaging, String competitorPackaging) {
        return StringUtils.isNotEmpty(productPackaging) && StringUtils.isNotEmpty(competitorPackaging);
    }

    private boolean isPackagingUnitValidForCoefCaculation(String collectedPackageUnit, String productPackageUnit) {
        return StringUtils.isNotEmpty(collectedPackageUnit) && StringUtils.isNotEmpty(productPackageUnit) && collectedPackageUnit.equalsIgnoreCase(productPackageUnit) ;
    }

    public File getFileToUpload(final List<String[]> csvData, final String filePrefix, final String salesOrg, final char separator) throws IOException {
        final String fileNameForOutboundFeed = filePrefix + UNDER_SCORE + salesOrg + UNDER_SCORE +
                DateTimeFormatter.ofPattern(FILE_DATE_FORMAT_OUTBOUND).format(LocalDateTime.now()) + CSV_FORMAT;
        log.debug("File name ::{}", fileNameForOutboundFeed);
        final File tempFileForUpload = new FileSystemResource(fileNameForOutboundFeed).getFile();
        final FileOutputStream out = new FileOutputStream(tempFileForUpload);
        final OutputStreamWriter outputFile = new OutputStreamWriter(out, StandardCharsets.ISO_8859_1);
        final CSVWriter outBoundFeedWriter = new CSVWriter(outputFile, separator, NO_QUOTE_CHARACTER, DEFAULT_ESCAPE_CHARACTER, DEFAULT_LINE_END);
        outBoundFeedWriter.writeAll(csvData);
        outBoundFeedWriter.close();
        return tempFileForUpload;
    }

}