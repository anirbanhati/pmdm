package com.kingfisher.compprice.dto.outbound;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PriceUpdateCSVData {

    private String ean;
    private String article;
    private String uom;
    private String salesOrg;
    private String storeCode;
    private String currency;
    private String articleType;
    private LocalDateTime validFrom;
    private LocalDateTime validTo;
    private double price;
    private String user;
    private String tenant;
    private String stoppedPrice;
    private String reasonCode;

}