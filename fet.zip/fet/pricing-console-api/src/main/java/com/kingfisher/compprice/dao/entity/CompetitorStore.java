package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.LONG_NAME;


@Entity
@Table(name = "lsp_competitor_store")
@Getter
@Setter
public class CompetitorStore implements Resource, Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -3724138509497301150L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "comp_id")
	@JsonIgnore
	private Long id;

	@Column(name = "shortname")
	private String name;

	@Column(name = LONG_NAME)
	@JsonProperty("longname")
	private String longName;

	@Column(name = "code")
	private String code;

	@Column(name = "concurrent_ratio")
	@JsonIgnore
	private String ratio;

	@Column(name = "reg_date")
	@JsonIgnore
	private LocalDateTime registrationDate;

	@Column(name = "last_updated")
	private LocalDateTime lastUpdated;

	@JsonIgnore
	@OneToMany(mappedBy = "competitorStore", cascade = CascadeType.ALL)
	private Set<StoreCompetitorStoreMap> storeCompetitorStoreMaps = new HashSet<>();

	@Column(name = "cs_code")
	private String csCode;

	@Override
	public String getJsonApiDataId() {
		return String.valueOf(id);
	}

	@Override
	public String getJsonApiDataType() {
		return "compStore";
	}

}