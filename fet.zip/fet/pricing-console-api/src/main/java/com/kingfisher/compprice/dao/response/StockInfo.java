package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class StockInfo implements Serializable {

	private static final long serialVersionUID = -7918563063358816420L;

	@JsonProperty("cStock")
	private CurrentStock currentStock;

	@JsonProperty("wStock")
	private WeeklyStock weeklyStock;

	private double mImpact;

	private double nrv;

}