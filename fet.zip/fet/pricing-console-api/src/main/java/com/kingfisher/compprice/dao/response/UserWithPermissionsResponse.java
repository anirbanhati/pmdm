package com.kingfisher.compprice.dao.response;

import java.util.Set;

import com.kingfisher.compprice.enums.Role;
import com.kingfisher.compprice.dao.entity.FeaturesPermissions;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

import static com.kingfisher.compprice.util.constants.Constants.USER;

@Getter
@Setter
public class UserWithPermissionsResponse implements Resource{

	/**
	 *
	 */
	private static final long serialVersionUID = 3564667965132968137L;
	private String firstName;
	private String lastName;
	private String tenant;
	private String userId;
	private Role role;
	private Set<FeaturesPermissions> permissions;
	private Store store;
	private String storeCode;
	private Long storeId;


	@Override
	public String getJsonApiDataId() {
		return null;
	}
	@Override
	public String getJsonApiDataType() {
		return USER;
	}

}