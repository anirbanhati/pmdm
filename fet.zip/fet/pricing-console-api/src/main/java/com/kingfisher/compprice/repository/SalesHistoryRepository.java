package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.SalesHistory;
import com.kingfisher.compprice.dao.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SalesHistoryRepository extends JpaRepository<SalesHistory, Long> {

    List<SalesHistory> findByStoreAndEan(final Store store, final String ean);

    List<SalesHistory> findBySalesDateBefore(final LocalDateTime date);

}