package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.NationalPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NationalPriceRepository extends JpaRepository<NationalPrice, Long> {

    List<NationalPrice> findByProduct_EanAndProduct_SalesUnitAndTenant(final String ean, final String salesUnit, final String tenant);

    List<NationalPrice> findByProduct_EanAndProduct_SalesUnit(final String ean, final String salesUnit);

}