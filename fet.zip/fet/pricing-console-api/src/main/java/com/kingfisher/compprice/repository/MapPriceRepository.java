package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.MapPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MapPriceRepository extends JpaRepository<MapPrice, String> {

    List<MapPrice> findByEanInAndStoreCode(final String[] ean, final String storeCode);

}