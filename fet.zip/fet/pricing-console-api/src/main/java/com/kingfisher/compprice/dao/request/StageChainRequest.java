package com.kingfisher.compprice.dao.request;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StageChainRequest {

	private String ean;
	private String price;
	private String sDate;
	private String eDate;
	private String prdType;

}