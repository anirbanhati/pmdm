package com.kingfisher.compprice.dao;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
public class CollectionAssginment implements Serializable {
	private static final long serialVersionUID = 2518565966761377808L;

	private Long id;
	private String name;
	private String compititorName;
	private String ean;
	private LocalDateTime creationTime;
	private String articleCode;
	private double price;
	private String salesUnit;
	private String pkg;
	private boolean hasPromo;
	private String promoInfo;
	private String notes;
	private double priceUOM;
	private String uom;
	private boolean linkedArticle;
	private String storeCode;

}