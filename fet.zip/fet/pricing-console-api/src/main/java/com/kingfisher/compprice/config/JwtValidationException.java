package com.kingfisher.compprice.config;

public class JwtValidationException extends RuntimeException {
	/**
	 *
	 */
	private static final long serialVersionUID = 5948632575105212075L;

	public JwtValidationException(final String message, final Throwable e){
		super(message,e);
	}

	public JwtValidationException(final String message){
		super(message);
	}
}
