package com.kingfisher.compprice.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "funct")
@Getter
@Setter
public class FunctionalityConfiguration {

    private boolean prdAssoc;
    private boolean newListPagination;
    private boolean local;

}