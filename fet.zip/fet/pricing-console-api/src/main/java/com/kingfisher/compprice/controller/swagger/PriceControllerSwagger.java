package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.price.PriceSubmissionRequest;
import com.kingfisher.compprice.dao.request.PriceUpdateStatusReq;
import com.kingfisher.compprice.dao.response.PriceUpdateResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationUpdateResponse;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@Tag(name = Constants.TAG_PRICE)
public interface PriceControllerSwagger {

	@Operation(description = "Download Price File for Specific Tenant")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<Resource> downloadFileForChangesMadeForGivenStore(final HttpServletResponse response, @PathVariable(required = false) final String tenant, @RequestParam final String storeCode);

	@Operation(description = "Save Final Price for Current User")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<String> saveValidatedPriceForLsp();

	@Operation(description = "Fetch Price Details for Verification")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	SingleDataResponse<PriceValidationResponse> getPriceForVerificationForCurrentUser();

	@Operation(description = "Update Price Validation Status")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	SingleDataResponse<PriceValidationUpdateResponse> updatePriceStatus(final PriceUpdateStatusReq req);

	@Operation(description = "Download Delta Price File for Specific Tenant")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<Resource> downloadValidatedStoreCollectionFile(@PathVariable final String tenant, @PathVariable("reference") final String reference, @RequestParam final String storeCode);

	@Operation(description = "Save Store Collection Price", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	SingleDataResponse<PriceUpdateResponse> savePricesForStoreCollection(@RequestBody final PriceSubmissionRequest priceRequest);

	@Operation(description = "Download import errors")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<Resource> downloadImportErrorsFile(@NotNull @RequestParam String errorKey);

}