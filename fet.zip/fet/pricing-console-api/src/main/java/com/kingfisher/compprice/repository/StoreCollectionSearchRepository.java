package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.StoreCollection;
import com.kingfisher.compprice.dao.search.CompItemCriteria;
import com.kingfisher.compprice.dao.search.SearchPaging;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.service.ProductTools;
import com.kingfisher.compprice.tools.PerformanceExecution;
import com.kingfisher.compprice.util.constants.Constants;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Repository
@RequiredArgsConstructor
@Slf4j
public class StoreCollectionSearchRepository {

    @PersistenceContext
    private EntityManager entityManager;
    private final ProductTools productTools;


    @PerformanceExecution
    public List<StoreCollection> findFilteredStoreCollectionList(final SearchPaging storeCollectionPaging, final CompItemCriteria storeCollectionSearchCriteria) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<StoreCollection> storeCollectionCriteriaQuery = criteriaBuilder.createQuery(StoreCollection.class);
        final Root<StoreCollection> storeCollectionRoot = storeCollectionCriteriaQuery.from(StoreCollection.class);
        storeCollectionCriteriaQuery.where(prepareFilterCriteria(storeCollectionSearchCriteria, storeCollectionRoot, criteriaBuilder));
        final long count = getResultCount(storeCollectionSearchCriteria, criteriaBuilder);

        productTools.setPageSizeAndNum(storeCollectionPaging, count);
        int pNum = storeCollectionPaging.getPageNum();
        int pSize = storeCollectionPaging.getPageSize();

        final TypedQuery<StoreCollection> scQuery = entityManager.createQuery(storeCollectionCriteriaQuery);
        scQuery.setFirstResult((pNum - 1) * pSize);
        scQuery.setMaxResults(pSize);
        return scQuery.getResultList();
    }

    private Predicate prepareFilterCriteria(final CompItemCriteria criteria, final Root<StoreCollection> clRoot, CriteriaBuilder criteriaBuilder) {
        final List<Predicate> listOfFilter = prepareFilterList(criteria, clRoot, criteriaBuilder);
        return criteriaBuilder.and(listOfFilter.toArray(new Predicate[0]));
    }

    @PerformanceExecution
    public List<Predicate> prepareFilterList(final CompItemCriteria criteria, final Root<StoreCollection> clRoot, CriteriaBuilder criteriaBuilder) {
        final List<Predicate> listOfFilter = new ArrayList<>();

        if (StringUtils.isNotEmpty(criteria.getType())) {
            listOfFilter.add(criteriaBuilder.equal(clRoot.get(COMP_ITEM_TYPE), criteria.getType()));
        }

        if (StringUtils.isNotEmpty(criteria.getName())) {
            listOfFilter
                    .add(criteriaBuilder.like(criteriaBuilder.lower(clRoot.get(Constants.COLL_LIST_ENTITY_NAME)),
                            Constants.PERCENTAGE + criteria.getName().toLowerCase() + Constants.PERCENTAGE));
        }
        if (CollectionUtils.isNotEmpty(criteria.getAssignTo())) {
            final Set<String> users = criteria.getAssignTo().stream().map(String::toLowerCase)
                    .collect(Collectors.toSet());
            listOfFilter.add(criteriaBuilder
                    .and(criteriaBuilder.lower(clRoot.get(COLL_LIST_ENTITY_ASSIGN_TO)).in(users)));

        }
        if (CollectionUtils.isNotEmpty(criteria.getCreatedBy())) {
            final Set<String> createdByUsers = criteria.getCreatedBy().stream().map(String::toLowerCase)
                    .collect(Collectors.toSet());
            listOfFilter.add(criteriaBuilder.and(
                    criteriaBuilder.lower(clRoot.get(COLL_LIST_ENTITY_CREATED_BY)).in(createdByUsers)));
        }
        if (CollectionUtils.isNotEmpty(criteria.getStatus())) {
            final List<CollectionStatus> statusEnum = new ArrayList<>();
            for (final String status : criteria.getStatus()) {

                statusEnum.add(CollectionStatus.valueOf(status));
            }
            listOfFilter.add(criteriaBuilder.and(clRoot.get(Constants.STATUS).in(statusEnum)));
        }

        if (StringUtils.isNoneEmpty(criteria.getCreationTime())) {
            final String inputDate = criteria.getCreationTime() + " 00:00";
            final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            listOfFilter.add(criteriaBuilder.between(clRoot.get(Constants.COLL_LIST_ENTITY_CREATION_TIME),
                    LocalDateTime.parse(inputDate, formatter),
                    LocalDateTime.parse(inputDate, formatter).plusDays(1).minusSeconds(1)));
        }

        if (StringUtils.isNotEmpty(criteria.getStoreCode())) {
            listOfFilter.add(criteriaBuilder.equal(clRoot.get(Constants.COLL_LIST_ENTITY_STORE_CODE),
                    criteria.getStoreCode()));
        }
        if (CollectionUtils.isNotEmpty(criteria.getLastModifiedBy())) {
            final Set<String> lmUsers = criteria.getLastModifiedBy().stream().map(String::toLowerCase)
                    .collect(Collectors.toSet());
            listOfFilter.add(criteriaBuilder
                    .and(criteriaBuilder.lower(clRoot.get(Constants.COLL_LIST_ENTITY_LAST_MOD_BY)).in(lmUsers)));
        }
        if (CollectionUtils.isNotEmpty(criteria.getCompStoreNames())) {
            listOfFilter.add(criteriaBuilder.and(clRoot.get(Constants.COLL_LIST_ENTITY_COMP_STORE_NAME).in(criteria.getCompStoreNames())));
        }

        if (StringUtils.isNoneEmpty(criteria.getExpDate())) {
            final String inputDate = criteria.getExpDate() + " 00:00";
            final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            listOfFilter.add(criteriaBuilder.between(clRoot.get(Constants.COLL_LIST_ENTITY_EXP_DATE),
                    LocalDateTime.parse(inputDate, formatter),
                    LocalDateTime.parse(inputDate, formatter).plusDays(1).minusSeconds(1)));
        }
        return listOfFilter;
    }

    private long getResultCount(final CompItemCriteria criteria, final CriteriaBuilder criteriaBuilder) {
        final CriteriaQuery<Long> countQ = criteriaBuilder.createQuery(Long.class);
        final Root<StoreCollection> clRoot = countQ.from(StoreCollection.class);
        countQ.select(criteriaBuilder.count(clRoot)).where(prepareFilterCriteria(criteria, clRoot, criteriaBuilder));
        return entityManager.createQuery(countQ).getSingleResult();
    }

}
