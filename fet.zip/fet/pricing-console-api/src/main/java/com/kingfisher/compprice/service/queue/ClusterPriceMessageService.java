package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.ClusterPrice;
import com.kingfisher.compprice.dto.ClusterPriceInfo;
import com.kingfisher.compprice.dto.ClusterPrices;
import com.kingfisher.compprice.repository.ClusterPriceRepository;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.CacheUtils;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.CLUSTER_PRICE_MESSAGE_SERVICE;
import static com.kingfisher.compprice.util.constants.CacheConstants.CLUSTER_PRICE_CACHE;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClusterPriceMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final MessageServicesHelper servicesHelper;
    private final ClusterPriceRepository clusterPriceRepository;
    private final MessageServiceTools messageServiceTools;
    private final StorePriceTools storePriceTools;
    private final CacheUtils cacheUtils;


    @Override
    public ProcessedByType getProcessedBy() {
        return CLUSTER_PRICE_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Cluster Price Feed :: {}", message);
        }
        final String methodName = "processMessage";
        try {
            log.info("Start processing message {}::{}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message {}::{}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(final String message) throws JAXBException {
        if (StringUtils.isNotEmpty(message)) {
            JAXBContext context = JAXBContext.newInstance(ClusterPriceInfo.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            ClusterPriceInfo clusterPriceInfo = (ClusterPriceInfo) unmarshaller.unmarshal(new StringReader(message));
            if (Optional.ofNullable(clusterPriceInfo).isPresent()) {
                clusterPriceInfo.getPrices().forEach(price -> refreshClusterPricingDetails(price, clusterPriceInfo));
            }
        }
    }

    private void populateClusterPricingDetails(ClusterPrices clusterPrices, ClusterPriceInfo clusterPriceInfo, ClusterPrice clusterPrice) {
        if (null == clusterPrice) {
            clusterPrice = new ClusterPrice();
        }
        clusterPrice.setClusterID(clusterPriceInfo.getClusterID());
        clusterPrice.setLocale(clusterPriceInfo.getLocale());
        clusterPrice.setStartDate(servicesHelper.getLocalDateTime(clusterPrices.getStartDate()));
        clusterPrice.setEndDate(servicesHelper.getLocalDateTime(clusterPrices.getEndDate()));
        clusterPrice.setPrice(clusterPrices.getClusterPrice());
        clusterPrice.setLastUpdatedDate(LocalDateTime.now());
        clusterPrice.setCurrency(clusterPriceInfo.getCurrency());
        clusterPrice.setTenant(messageServiceTools.getTenantFromSalesOrg(clusterPriceInfo.getBannerID()));
        clusterPrice.setEan(clusterPrices.getEan());
        cacheUtils.evictCacheByKey(CLUSTER_PRICE_CACHE, List.of(clusterPrices.getEan(), clusterPriceInfo.getClusterID()));
        log.debug("Evicted Cluster Price cache for EAN : {}, ClusterId: {}", clusterPrices.getEan(), clusterPriceInfo.getClusterID());
        clusterPriceRepository.save(clusterPrice);
    }

    private void refreshClusterPricingDetails(ClusterPrices clusterPrices, ClusterPriceInfo clusterPriceInfo) {
        final String tenant = messageServiceTools.getTenantFromSalesOrg(clusterPriceInfo.getBannerID());
        List<ClusterPrice> clusterPriceList = storePriceTools.getActiveOrFutureClusterPrice(clusterPrices.getEan(), tenant,
                clusterPriceInfo.getClusterID());
        LocalDateTime startDateLocalTime = servicesHelper.getLocalDateTime(clusterPrices.getStartDate());
        ClusterPrice existingClusterPriceData = clusterPriceList.stream()
                .filter(clusterPriceDto -> DateUtils.isEqual(clusterPriceDto.getStartDate(), startDateLocalTime)).findFirst().orElse(null);
        populateClusterPricingDetails(clusterPrices, clusterPriceInfo, existingClusterPriceData);
    }

}