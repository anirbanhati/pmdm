package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "financial_provisions")
public class Provisions implements Serializable {
    private static final long serialVersionUID = -624178074775759993L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "quantity")
    private double quantity;

    @Column(name = "stockValue")
    private double stockValue;

    @Column(name = "provStock")
    private double provStock;

    @Column(name = "provRate")
    private double provRate;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "store_id", nullable = false)
    private Store store;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

}