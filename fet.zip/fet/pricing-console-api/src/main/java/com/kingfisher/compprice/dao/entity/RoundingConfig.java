package com.kingfisher.compprice.dao.entity;

import java.io.Serializable;
import java.util.Set;

import com.kingfisher.compprice.dao.ExcelError;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoundingConfig implements Serializable {
    private static final long serialVersionUID = 2726748030637600136L;


    private int rowNum;
    private int errorCount;
    private Set<ExcelError> errors;

}