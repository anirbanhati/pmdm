package com.kingfisher.compprice.configuration;

import com.amazonaws.ClientConfigurationFactory;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AwsCloudConfiguration {

    @Bean
    public AmazonS3 amazonS3Client() {
        var client = (new ClientConfigurationFactory()).getConfig();

        return AmazonS3ClientBuilder.standard()
                .withRegion(Regions.EU_WEST_1)
                .withClientConfiguration(client)
                .build();
    }
}
