package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.product.Brick;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.product.ProductHierarchy;
import com.kingfisher.compprice.dao.product.SubCategory;
import com.kingfisher.compprice.dao.response.ProductDetailsResponse;
import com.kingfisher.compprice.dao.response.ProductSearchResponse;
import com.kingfisher.compprice.dao.response.search.ProductChainItem;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ProductException;
import com.kingfisher.compprice.helper.ProductInfoHelper;
import com.kingfisher.compprice.repository.ProductRepository;
import com.kingfisher.compprice.repository.ProductSearchRepository;
import com.kingfisher.compprice.util.DateUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;
import static com.kingfisher.compprice.util.DecimalUtils.roundOf;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductService {

	private final UserService userService;
	private final ProductRepository productRepository;
	private final ProductSearchRepository productSearchRepository;
	private final ProductInfoHelper productInfoHelper;
	private final ClusterPriceService clusterPriceService;
	private final StorePriceService storePriceService;
	private final ProductTools productTools;
	private final LogService logService;


	@Transactional
	public ProductSearchResponse productSearchByType(final ProductSearchPaging paging,
													 @Valid final ProductSearchCriteria searchCriteria,
													 final CurrentUser currentUser) {
		if (ProductType.OutOfRange.toString().equals(searchCriteria.getPrdType())
				|| ProductType.SlowMoving.toString().equals(searchCriteria.getPrdType())) {
			return productSearchRepository.getProductsByPrdType(paging, searchCriteria, currentUser.getUser());
		} else {
			return productSearchRepository.getProductsByTypes(paging, searchCriteria, currentUser.getUser());
		}
	}

	public ProductDetailsResponse getProductInfo(final String ean, final String prdType, final CurrentUser currentUser) {
		final Product product = productTools.findProductByEanAndSalesUnitsAndType(ean, productTools.determineSalesOrg(currentUser.getUser()), prdType);
		final ProductDetailsResponse response = new ProductDetailsResponse();
		response.setProduct(productInfoHelper.setProductDetails(product, prdType, currentUser.getUser(), response));
		return response;
	}

	public List<Product> getProductsFromAssignments(final Set<Assignment> assignments) {
		StopWatch stopWatch = logService.logStopWatchStart("getProductsFromAssignments");
		List<Product> products = productRepository.findByAssignmentIn(assignments);
		logService.logStopWatchStop(stopWatch);
		return products;
	}

	/**
	 * This method will give a filtered list of chained products
	 * which are not included in the Collection List
	 *
	 * @param chainId      of the Product for which the chained products to be extracted
	 * @param user         - the user who has logged in
	 * @param products - list of all the products present in the Collection List
	 * @return List of Filtered Chained Products
	 */
	@Transactional
	public List<ProductChainItem> findChainedProductsFiltered(final String chainId, final User user, final boolean isSPrice,
															  final List<Product> products) {
		StopWatch stopWatch = logService.logStopWatchStart("findChainedProductsFiltered");
		if (null != chainId) {
			var productPrices = getChainedProductStorePriceMap(chainId, isSPrice, user);
			List<ProductChainItem> pItems = new ArrayList<>();
			if (MapUtils.isNotEmpty(productPrices)) {
				productPrices.forEach((product, storePrice) -> {
					if (!products.contains(product)) {
						products.add(product);
						pItems.add(productInfoHelper.getProductChainItem(isSPrice, product, storePrice));
					}
				});
			}
			log.info("::::::::::::: Length of pItems ::::{}", pItems.size());
			logService.logStopWatchStop(stopWatch);
			return pItems;
		}
		logService.logStopWatchStop(stopWatch);
		return List.of();
	}

	@Transactional
	public List<ProductChainItem> findChainedProducts(final String chainId, final User user) {
		var productPrices = getChainedProductStorePriceMap(chainId, true, user);
		List<ProductChainItem> pItems = new ArrayList<>();
		if (MapUtils.isNotEmpty(productPrices)) {
			for (Map.Entry<Product, StorePrice> entry : productPrices.entrySet()) {
				Product product = entry.getKey();
				StorePrice storePrice = entry.getValue();
				final ProductChainItem item = new ProductChainItem();
				item.setBName(product.getBrickName());
				item.setCat(product.getCategory());
				item.setDesc(product.getDescription());
				item.setEan(product.getEan());
				item.setPCode(product.getProductCode());
				item.setSCat(product.getSubCategory());
				if (null != storePrice) {
					var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
					var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
					item.setStoreAppPrice(roundOf(storePriceService.getStorePriceWithCluster(nPrice, storePrice, user, clusterPrice), ROUND_OF_2));
					item.setEDate(DateUtils.getDateAsString(storePrice.getEndDate(), DateUtils.DATE_FORMAT));
					item.setSDate(DateUtils.getDateAsString(storePrice.getStartDate(), DateUtils.DATE_FORMAT));
					item.setStdPrice(String.valueOf(storePriceService.deriveStandardPrice(nPrice, storePrice, user, clusterPrice)));
				}
				pItems.add(item);
			}
		}
		return pItems.isEmpty() ? null : pItems;
	}

	public Map<Product, StorePrice> getChainedProductStorePriceMap(final String chainId, final boolean isSPrice, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getChainedProductStorePriceMap");

		List<Product> products = new ArrayList<>();
		Map<Product, StorePrice> productStorePriceMap = new HashMap<>();

		var pChainOptional = productTools.findChainedProductByGroupingCodeAndDeleteFlag(chainId);
		if (pChainOptional.isPresent()) {
			products = pChainOptional.get().stream().map(ProductChainingInfo::getProduct).toList();
		}
		Map<Product, StorePrice> chainedProductStorePriceMap;
		if (isSPrice) {
			var validProducts = getValidProducts(products);
			chainedProductStorePriceMap = storePriceService.getProductStorePriceMap(validProducts, user.getStore());
		} else {
			getValidProducts(products).forEach(product -> productStorePriceMap.put(product, new StorePrice()));
			chainedProductStorePriceMap = productStorePriceMap;
		}
		logService.logStopWatchStop(stopWatch);
		return chainedProductStorePriceMap;
	}

	private List<Product> getValidProducts(final List<Product> products) {
		return products.stream()
				.filter(product -> null != product.getCategory())
				.filter(product -> CollectionUtils.isNotEmpty(product.getStoreProduct()))
				.filter(product -> product.getStoreProduct().stream().anyMatch(sp -> PRICE_FLAG_YES.equalsIgnoreCase(sp.getLocalPricing())))
				.toList();
	}

	public List<Category> getHierarchiesByPrdType(final Store store, final User user, final List<String> types) {
		var typesAsString = productTools.getTypesAsString(types, EMPTY_STR).toString();
		List<Object> products;
		if (userService.isHeadOfficeUser(user.getUserId())) {
			products = productTools.getHierarchyForHo();
		} else {
			products = productTools.getHierarchyForStore(store, types, typesAsString);
		}
		return getHierarchy(products);
	}

	private List<Category> getHierarchy(final List<Object> products) {
		List<Category> categories = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(products)) {
			List<ProductHierarchy> productHierarchies = products.stream().map(data -> {
				Object[] prdList = (Object[]) data;
				ProductHierarchy hierarchy = new ProductHierarchy();
				hierarchy.setCat((String) prdList[0]);
				hierarchy.setSCat((String) prdList[1]);
				hierarchy.setBrick((String) prdList[2]);
				hierarchy.setBCode((String) prdList[3]);
				return hierarchy;
			}).toList();

			var groupedByCategory = productHierarchies.stream()
					.filter(c -> c.getCat() != null && c.getSCat() != null && c.getBrick() != null && c.getBCode() != null)
					.collect(Collectors.groupingBy(ProductHierarchy::getCat));
			categories = groupedByCategory.entrySet().stream().map(k -> {
				Category category = new Category();
				category.setName(k.getKey());
				var subCategoryMap = k.getValue().stream().collect(Collectors.groupingBy(ProductHierarchy::getSCat));
				category.setSubCategory(getSubCat(subCategoryMap));
				return category;
			}).sorted(Comparator.comparing(Category::getName, String.CASE_INSENSITIVE_ORDER)).toList();
		}
		return categories;
	}

	private List<SubCategory> getSubCat(final Map<String, List<ProductHierarchy>> subCategoryMap) {
		return new ArrayList<>(subCategoryMap.entrySet().stream().map(k -> {
			SubCategory subCategory = new SubCategory();
			subCategory.setName(k.getKey());
			List<Brick> bricks = new ArrayList<>(k.getValue().stream().distinct().map(s -> {
				Brick brick = new Brick();
				brick.setName(s.getBrick());
				brick.setCode(s.getBCode());
				return brick;
			}).toList());
			subCategory.setBricks(bricks);
			return subCategory;
		}).toList());
	}

	public List<Product> getChainedProductsList(final List<Product> productList) {
		StopWatch stopWatch = logService.logStopWatchStart("getChainedProductsList");

		List<Product> products = new ArrayList<>();
		for (Product product : productList) {
			if (null != product.getProductChainingInfo() && !DELETED_CHAIN_PRODUCT.contains(product.getProductChainingInfo().getDeleteFlag())) {
				var pChainOptional = productTools.findChainedProductByGroupingCodeAndDeleteFlag(product.getProductChainingInfo().getGroupingCode());
				if (pChainOptional.isPresent()) {
					var productsL = pChainOptional.get().stream().map(ProductChainingInfo::getProduct).toList();
					products.addAll(productsL);
				}
			} else {
				products.add(product);
			}
		}
		var finalProducts = products.stream().filter(Objects::nonNull)
				.filter(product -> null != product.getCategory()).distinct().toList();
		logService.logStopWatchStop(stopWatch);
		return finalProducts;
	}

	public Map<String, Product> getEanProductMap(final List<String> listOfEan, List<Product> products, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getEanProductMap");

		Map<String, Product> eanProductMap = new HashMap<>();
		if (CollectionUtils.isNotEmpty(listOfEan)) {
			products = productTools.getProductsFromEans(listOfEan, user);
		}
		if (CollectionUtils.isNotEmpty(products)) {
			Map<String, List<Product>> eanProductsMap = products.stream().collect(Collectors.groupingBy(Product::getEan));
			eanProductsMap.forEach((ean, productList) -> {
				productList.sort(Comparator.comparing(Product::getLastUpdated).reversed());
				eanProductMap.put(ean, productList.get(0));
			});
		}
		logService.logStopWatchStop(stopWatch);
		return eanProductMap;
	}

	public Map<String, String> getChainIdFromProductPrice(final List<Product> productList) {
		StopWatch stopWatch = logService.logStopWatchStart("getChainIdFromProductPrice");
		Map<String, String> productChainIdMap = new HashMap<>();
		productList.forEach(product -> productChainIdMap.put(product.getEan(), productTools.getChainIdFromProduct(product)));
		logService.logStopWatchStop(stopWatch);
		return productChainIdMap;
	}

}