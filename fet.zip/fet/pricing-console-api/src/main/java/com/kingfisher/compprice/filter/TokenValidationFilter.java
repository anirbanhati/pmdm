package com.kingfisher.compprice.filter;

import com.kingfisher.compprice.config.JwtValidationException;
import com.kingfisher.compprice.config.SigningKeyResolver;
import com.kingfisher.compprice.configuration.FunctionalityConfiguration;
import io.jsonwebtoken.*;
import org.springframework.http.HttpStatus;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.kingfisher.compprice.util.constants.Constants.AUTHORIZATION;
import static com.kingfisher.compprice.util.constants.Constants.BASIC;

public class TokenValidationFilter implements Filter {

	public static final String TOKEN_SEPARATOR = " ";
	private final String tenantId;
	private final String authority;
	String clientId;
	private final FunctionalityConfiguration funConfig;

	public TokenValidationFilter(final String authority2, final String clientId, final String tenantId,
								 final FunctionalityConfiguration funConfig) {
		this.authority = authority2;
		this.tenantId = tenantId;
		this.clientId = clientId;
		this.funConfig = funConfig;
	}

	@Override
	public void doFilter(final ServletRequest servletRequest, final ServletResponse servletResponse, final FilterChain filterChain)
			throws ServletException, IOException {
		final HttpServletRequest request = (HttpServletRequest) servletRequest;
		final HttpServletResponse response = (HttpServletResponse) servletResponse;
		boolean isValidToken = true;
		try {
			final String authToken = request.getHeader(AUTHORIZATION);
			final String[] token = authToken.split(TOKEN_SEPARATOR);
			if (!funConfig.isLocal() && !BASIC.equalsIgnoreCase(token[0])) {
				final String authUrl = String.format(this.authority, this.tenantId);
				validateAccessToken(token[1], this.clientId, authUrl);
			}
		} catch (final Exception e) {
			isValidToken = false;
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			response.getWriter().write(e.getMessage());
		}
		if (isValidToken) {
			filterChain.doFilter(request, response);
		}
	}

	private static void validateAccessToken(final String accessToken, final String clientId, final String authUrl) throws IOException, JwtValidationException {
		final SigningKeyResolver signingKeyResolver = new SigningKeyResolver(authUrl);
		try {
			Jwts.parserBuilder()
					.setSigningKeyResolver(signingKeyResolver)
					.requireAudience(clientId)
					.requireIssuer(authUrl)
					.build()
					.parseClaimsJws(accessToken);
		} catch (final ExpiredJwtException ex) {
			throw new JwtValidationException("Jwt validation failed: access token us expired", ex);
		} catch (final MissingClaimException ex) {
			throw new JwtValidationException("Jwt validation failed: missing required claim", ex);
		} catch (final IncorrectClaimException ex) {
			throw new JwtValidationException("Jwt validation failed: required claim has incorrect value", ex);
		}
	}

}