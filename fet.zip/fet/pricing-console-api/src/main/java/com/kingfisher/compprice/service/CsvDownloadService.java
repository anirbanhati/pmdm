package com.kingfisher.compprice.service;

import com.kingfisher.compprice.helper.OutBoundDataCommonHelper;
import com.kingfisher.compprice.util.constants.Constants;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
@Service
public class CsvDownloadService {

    private final OutBoundDataCommonHelper outboundDataHelper;


    @Transactional
    public File getCsvFile() throws IOException {
        return writeDataToCsv();
    }

    private File writeDataToCsv() throws IOException {
        Map<File, String> fileForUpload = outboundDataHelper.getOutboundFile(Constants.PROD_ASSOC_OUTBOUND_TYPE);
        File fileToUpload = null;
        if (MapUtils.isNotEmpty(fileForUpload)) {
            fileToUpload = (File) fileForUpload.keySet().toArray()[0];
        }
        return fileToUpload;
    }

}