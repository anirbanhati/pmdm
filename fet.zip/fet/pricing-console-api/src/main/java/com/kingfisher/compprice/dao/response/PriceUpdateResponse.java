package com.kingfisher.compprice.dao.response;

import java.time.LocalDateTime;

import com.kingfisher.jsonapi.Resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class PriceUpdateResponse implements Resource{

	/**
	 *
	 */
	private static final long serialVersionUID = -924845684208703212L;

	private String reference;
	private LocalDateTime time;

	@Override
	public String getJsonApiDataId() {
		return "pId";
	}
	@Override
	public String getJsonApiDataType() {
		return "priceUpdate";
	}

}