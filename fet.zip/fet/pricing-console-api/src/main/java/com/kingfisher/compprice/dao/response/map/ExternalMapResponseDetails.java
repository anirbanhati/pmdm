package com.kingfisher.compprice.dao.response.map;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ExternalMapResponseDetails {

	private String id;
	private String type;
	private MapAttributes attributes;

}