package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.NationalPrice;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dto.PriceInfo;
import com.kingfisher.compprice.dto.Prices;
import com.kingfisher.compprice.repository.NationalPriceRepository;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.CacheUtils;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.N_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRICE_CACHE;

@Component
@RequiredArgsConstructor
@Slf4j
public class NationalPriceMessageServiceHelper {

    @Value("${enabled.fullfeed}")
    private boolean isFullFeedEnabled;

    private final MessageServicesHelper servicesHelper;
    private final MessageServiceTools messageServiceTools;
    private final StorePriceTools storePriceTools;
    private final NationalPriceRepository nationalPriceRepository;
    private final CacheUtils cacheUtils;


    public void refreshNationalPriceFeedDetails(final PriceInfo priceInfo) {
        log.debug("::National price inbound feed processing started::");
        if (CollectionUtils.isNotEmpty(priceInfo.getPrices())) {
            priceInfo.getPrices().forEach(priceDetails -> refreshNationalPriceRepo(priceInfo, priceDetails));
        }
    }

    private void refreshNationalPriceRepo(final PriceInfo priceInfo, final Prices priceDetails) {
        Product existingProduct = servicesHelper.getProductByEanAndSalesUnit(priceDetails.getEan(), priceInfo.getBannerID());
        if (Optional.ofNullable(existingProduct).isEmpty()) {
            createNewProductAndRefreshNationalPrice(priceInfo, priceDetails);
        } else {
            updateExistingNationalPriceDetails(priceInfo, priceDetails, existingProduct);
        }
    }

    private void updateExistingNationalPriceDetails(final PriceInfo priceInfo,final Prices priceDetails,final Product existingProduct) {
        final String tenant = getTenant(priceInfo);
        if (isFullFeedEnabled) {
            log.info("Is full load enabled for National price feed :: {}", isFullFeedEnabled);
            addNewNationalPrice(priceInfo, priceDetails, existingProduct, tenant);
        } else {
            refreshNationalPriceDetailsWithDeltaFeed(priceInfo, priceDetails, existingProduct, tenant);
        }
    }

    private void refreshNationalPriceDetailsWithDeltaFeed(PriceInfo priceInfo, Prices priceDetails, Product existingProduct, String tenant) {
        List<NationalPrice> nationalPrices = storePriceTools.getActiveOrFutureNationalPrice(existingProduct, tenant);
        Optional<NationalPrice> priceWithSameStartDate = getNationalPriceWithSameStartDate(nationalPrices, priceDetails.getStartDate());
        if (priceWithSameStartDate.isPresent()) {
            log.debug("National Price Found :: ean {}", priceDetails.getEan());
            populateNationalPriceDetails(priceInfo, priceDetails, priceWithSameStartDate.get(), tenant);
        } else {
            addNewNationalPrice(priceInfo, priceDetails, existingProduct, tenant);
        }
    }

    private String getTenant(PriceInfo priceInfo) {
        return messageServiceTools.getTenantFromSalesOrg(priceInfo.getBannerID());
    }

    private void createNewProductAndRefreshNationalPrice(PriceInfo priceInfo, Prices priceDetails) {
        Product newProduct = servicesHelper.createProduct(priceDetails.getEan(), priceDetails.getArticleNumber(), priceInfo.getBannerID());
        final String tenant = getTenant(priceInfo);
        addNewNationalPrice(priceInfo, priceDetails, newProduct,tenant);
    }

    private void populateNationalPriceDetails(PriceInfo priceInfo, Prices price, NationalPrice nationalPrice, final String tenant) {
        nationalPrice.setCurrency(priceInfo.getCurrency());
        nationalPrice.setLastUpdateTime(LocalDateTime.now());
        nationalPrice.setTenant(messageServiceTools.getTenantFromSalesOrg(priceInfo.getBannerID()));
        if (StringUtils.isNotEmpty(price.getStartDate())) {
            nationalPrice.setStartDate(servicesHelper.getLocalDateTime(price.getStartDate()));
        }
        if (StringUtils.isNotEmpty(price.getEndDate())) {
            nationalPrice.setEndDate(servicesHelper.getLocalDateTime(price.getEndDate()));
        }
        nationalPrice.setPrice(price.getCurrentNationalPrice());
        nationalPrice.setTenant(tenant);
        nationalPriceRepository.save(nationalPrice);
        cacheUtils.evictCacheByKey(STORE_PRICE_CACHE, List.of(price.getEan(), priceInfo.getStoreID()));
        cacheUtils.evictCacheByKey(N_PRICE_CACHE, List.of(price.getEan(), priceInfo.getBannerID()));
        log.debug("Evicted National Price cache(2) for EAN : {}", price.getEan());
    }

    private Optional<NationalPrice> getNationalPriceWithSameStartDate(List<NationalPrice> nationalPrices, String startDate) {
        for(NationalPrice price : nationalPrices){
            if(DateUtils.isEqual(price.getStartDate(), servicesHelper.getLocalDateTime(startDate))){
                return Optional.of(price);
            }
        }
        return Optional.empty();
    }

    private void addNewNationalPrice(PriceInfo priceInfo, Prices priceDetails, Product newProduct, final String tenant) {
        log.debug("National Price Not Found :: ean {}", priceDetails.getEan());
        NationalPrice nationalPrice = new NationalPrice();
        nationalPrice.setPrice(priceDetails.getCurrentNationalPrice());
        nationalPrice.setLastUpdateTime(LocalDateTime.now());
        nationalPrice.setCurrency(priceInfo.getCurrency());
        nationalPrice.setStartDate(servicesHelper.getLocalDateTime(priceDetails.getStartDate()));
        nationalPrice.setEndDate(servicesHelper.getLocalDateTime(priceDetails.getEndDate()));
        nationalPrice.setProduct(newProduct);
        nationalPrice.setTenant(tenant);
        nationalPriceRepository.save(nationalPrice);
        cacheUtils.evictCacheByKey(STORE_PRICE_CACHE, List.of(priceDetails.getEan(), priceInfo.getStoreID()));
        cacheUtils.evictCacheByKey(N_PRICE_CACHE, List.of(priceDetails.getEan(), priceInfo.getBannerID()));
        log.debug("Evicted National Price cache(1) for EAN : {}", priceDetails.getEan());
    }

}