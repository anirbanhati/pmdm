package com.kingfisher.compprice.service.outbound;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.IOUtils;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.helper.OutBoundDataCommonHelper;
import com.kingfisher.compprice.service.queue.MessageServicesHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.constants.FeedConstants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class S3OutboundLoadService {

    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketName;
    @Value("${aws.s3.path}")
    private String scPath;
    @Value("${aws.s3.pricePath}")
    private String pricePath;

    private final AmazonS3 client;
    private final OutBoundDataCommonHelper outboundDataHelper;
    private final MessageServicesHelper messageServicesHelper;


    @Transactional
    public void uploadFile(String bucketName, String outBoundType) throws IOException {

        PutObjectRequest putObjectRequestForBucketUpload = getPutObjectRequestForFileUpload(bucketName, outBoundType);
        Optional.ofNullable(putObjectRequestForBucketUpload).ifPresent(uploadObject -> {
            log.info("Valid file to put into Amazon S3 Bucket::{} Outbound type ::{}", bucketName, outBoundType);
            client.putObject(uploadObject);
            log.info("Uploaded Successfully for outboundType:: {}", outBoundType);
        });
    }

    private PutObjectRequest getPutObjectRequestForFileUpload(String bucketName, String outBoundType) throws IOException {
        PutObjectRequest putObjectRequestForCSVData = null;
        Map<File, String> fileTenantBucketUpload = outboundDataHelper.getOutboundFile(outBoundType);
        if (MapUtils.isNotEmpty(fileTenantBucketUpload)) {
            File fileToUpload = (File) fileTenantBucketUpload.keySet().toArray()[0];
            String tenant = fileTenantBucketUpload.get(fileToUpload);
            log.info("The file has been created for upload :: {} Temporary file path ::{}", fileToUpload.getName(), fileToUpload.getAbsolutePath());
            putObjectRequestForCSVData = new PutObjectRequest(bucketName, outboundDataHelper.getFileNameBasedOnTenant(outBoundType, tenant, fileToUpload.getName()), fileToUpload);
        } else log.info("::Invalid file or sales org present for outbound type {}::", outBoundType);
        return putObjectRequestForCSVData;
    }

    public S3ObjectInputStream getFileContent(String bucketName, String fileName) {
        return client.getObject(bucketName, fileName).getObjectContent();
    }

    public List<String> getFileDetailsList(final String bucketName,String feedType,String fileExtensionType) {

        List<String> fileNameList = new ArrayList<>();
        ObjectListing objectList = client.listObjects(bucketName);
        if (null != objectList && Optional.ofNullable(objectList.getObjectSummaries()).isPresent()) {
            fileNameList = objectList.getObjectSummaries().stream().map(S3ObjectSummary::getKey).filter(s -> s.startsWith(SALES_UNIT_DF01 + FORWARD_SLASH + feedTypeToBucketFolderMap.get(feedType) + INBOUND_FOLDER) && (!s.contains(ARCHIVE_FOLDER) && !s.contains(FAILED_FOLDER)) && s.endsWith(fileExtensionType)).toList();
        } else
            log.info("No valid file file details identified in bucket :: {}", bucketName);
        return fileNameList;
    }

    public void moveFileFromSourceAndDelete(final String bucketName, final String fileNameWithPath, final String fileName, final String folderName, String feedType) {
        String desiredPath = buildDesiredPath(fileName, folderName, feedType);
        client.copyObject(bucketName, fileNameWithPath, bucketName, desiredPath);
        client.deleteObject(bucketName, fileNameWithPath);
        messageServicesHelper.saveFileDetails(fileName, feedType, folderName);
        log.info("The file has been moved and deleted :: {} ::{}", fileNameWithPath, folderName);
    }

    private String buildDesiredPath(final String fileName, final String folderName, final String feedType) {
        return SALES_UNIT_DF01 + FORWARD_SLASH + feedTypeToBucketFolderMap.get(feedType) + INBOUND_FOLDER + FORWARD_SLASH + folderName + FORWARD_SLASH + fileName;
    }

    public void uploadFileToS3Bucket(File fileToUpload) {
        log.debug(":Batch: File Uploading started for fileName --> {}", fileToUpload.getName());
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, scPath + fileToUpload.getName(), fileToUpload);
        client.putObject(putObjectRequest);
        fileToUpload.deleteOnExit();
    }

    public ByteArrayResource fetchStoreCollectionFileFromS3Bucket(final String bucketName, final String fileName) {
        log.debug(":Batch: pathKey --> {}{}", scPath, fileName);
        try {
            S3Object s3Object = client.getObject(bucketName, scPath + fileName);
            S3ObjectInputStream s3ObjectInputStream = s3Object.getObjectContent();
            return convertToExcel(s3ObjectInputStream, s3Object);
        } catch (AmazonS3Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
            throw new DetailsNotFoundException("CI06", "404", e.getMessage(), "CMP_PRC_CI_DE_06", FILE_NAME,
                    fileName, RESPONSE_MESSAGE_404);
        }
    }

    public String[] getS3BucketItems(final String path) {
        ListObjectsV2Request request = new ListObjectsV2Request();
        request.setBucketName(bucketName);
        request.setStartAfter("sc".equalsIgnoreCase(path) ? scPath : pricePath);

        return client.listObjectsV2(request).getObjectSummaries().stream()
                .map(S3ObjectSummary::getKey)
                .toArray(String[]::new);
    }

    private ByteArrayResource convertToExcel(S3ObjectInputStream s3ObjectInputStream, S3Object s3Object) {
        byte[] content = new byte[0];
        try {
            content = IOUtils.toByteArray(s3ObjectInputStream);
            s3Object.close();
        } catch(final IOException ex) {
            log.error("Exception occurred at convertToExcel --> {}", ex.getMessage());
        }
        return new ByteArrayResource(content);
    }

}