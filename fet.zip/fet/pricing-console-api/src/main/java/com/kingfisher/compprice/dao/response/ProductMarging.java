package com.kingfisher.compprice.dao.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProductMarging implements Serializable {
	private static final long serialVersionUID = 7431711468924398834L;

	@JsonProperty("tmRate")
	private String theoryMargingRate;
	@JsonProperty("rmRate")
	private String reqMargingRate;
	private String impact;
	private String nrv;

}