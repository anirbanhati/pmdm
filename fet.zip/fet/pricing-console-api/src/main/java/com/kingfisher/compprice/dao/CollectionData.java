package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.entity.CompetitorProduct;
import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import lombok.*;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CollectionData implements Serializable {
    private static final long serialVersionUID = -4271368848508657706L;

    private Map<String, CompetitorStore> csCodeCompStoreMap;
    private Map<String, List<CompetitorProduct>> eanCompProductsMap;
    private transient CategoryRoundingResponse crRounding;
    private Map<Store, Map<String, StorePrice>> storeWithEanStorePriceMap;

}