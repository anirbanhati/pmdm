package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.ProductProvision;
import com.kingfisher.compprice.dao.ProvisionDetails;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.dao.search.SearchPaging;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants;
import com.kingfisher.compprice.repository.*;
import com.kingfisher.compprice.tools.PerformanceExecution;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@RequiredArgsConstructor
@Component
@Slf4j
public class ProductTools {

    private static final double DEFAULT_VAT = 1.0;
    private static final List<Double> NON_ELIGIBLE_PRODUCT_STATUS = List.of(10.0, 11.0, 40.0, 99.0);

    private final UserService userService;
    private final ProductRepository productRepository;
    private final ClusterPriceRepository clusterPriceRepository;
    private final StageProductRepository stageProductRepository;
    private final ProductChainingRepository productChainingRepository;
    private final StoreCollectionRepository storeCollectionRepository;
    private final StorePriceTools storePriceTools;
    private final StoreProductService storeProductService;
    private final TaxClassificationService taxClassificationService;
    private final ChangeRequestConfiguration crConfig;
    private final LogService logService;

    public Product findProductByEanAndUser(final String ean, final User user) {
        return productRepository.findProductByEanAndSalesUnitIn(ean, determineSalesOrg(user)).orElse(null);
    }

    @Cacheable(value = GET_COUNT_OF_RECORDS_STORE_CACHE, key = "{#type, #user.store.storeCode, #criteria.eanOrDesc, #codes}")
    public long getCountOfRecordsStore(ProductSearchCriteria criteria, EntityManager entityManager, CriteriaBuilder criteriaBuilder,
                                       final User user, String type, String codes) {
        final CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        final Root<Product> countRoot = countQuery.from(Product.class);
        final Join<Object, Object> storeProductJoin = countRoot.join(STORE_PRODUCT, JoinType.INNER);
        final Join<Object, Object> storeJoin = storeProductJoin.join(STORE, JoinType.INNER);
        final Join<Object, Object> storePriceJoin = storeJoin.join(STORE_PRICE, JoinType.INNER);

        countQuery.select(criteriaBuilder.countDistinct(countRoot))
                .where(this.filterRecord(criteria, countRoot, storeProductJoin, storeJoin, storePriceJoin,
                        criteriaBuilder, user));
        return entityManager.createQuery(countQuery).getSingleResult();
    }

    @Cacheable(value = CPT_COUNT_STORE_CACHE, key = "{#type, #user.store.storeCode, #searchCriteria.eanOrDesc, #codes}")
    @PerformanceExecution
    public long getCountOfWarRecordsStore(final ProductSearchCriteria searchCriteria, EntityManager entityManager, CriteriaBuilder criteriaBuilder,
                                          final User user, String type, String codes) {
        final CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        final Root<Product> countRoot = countQuery.from(Product.class);
        final Join<Object, Object> storeProductJoin = countRoot.join(STORE_PRODUCT, JoinType.INNER);
        final Join<Object, Object> storeJoin = storeProductJoin.join(STORE, JoinType.INNER);
        final Join<Object, Object> storePriceJoin = storeJoin.join(STORE_PRICE, JoinType.INNER);

        countQuery.select(criteriaBuilder.countDistinct(countRoot))
                .where(this.filterWarRecord(searchCriteria, countRoot, storeProductJoin, storeJoin, storePriceJoin,
                        criteriaBuilder, user));
        return entityManager.createQuery(countQuery).getSingleResult();
    }

    public Predicate filterRecordsForStoreUsers(final ProductSearchCriteria criteria, final Root<Product> prodRoot,
                                                CriteriaBuilder criteriaBuilder, final User user) {
        final Join<Object, Object> storeProduct = prodRoot.join(STORE_PRODUCT, JoinType.INNER);
        final Join<Object, Object> storeJoin = storeProduct.join(STORE, JoinType.INNER);
        final Join<Object, Object> storePrice = storeJoin.join(STORE_PRICE, JoinType.INNER);
        return this.filterWarRecord(criteria, prodRoot, storeProduct, storeJoin, storePrice, criteriaBuilder, user);
    }

    @Cacheable(value = CPT_COUNT_HO_CACHE, key = "{#type, #searchCriteria.eanOrDesc, #codes}")
    @PerformanceExecution
    public long getCountOfWarRecordsHo(final ProductSearchCriteria searchCriteria, EntityManager entityManager, CriteriaBuilder criteriaBuilder,
                                       final User user, String type, String codes) {
        final CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        final Root<Product> countRoot = countQuery.from(Product.class);
        final Join<Object, Object> storeProductsJoin = countRoot.join(STORE_PRODUCT, JoinType.INNER);
        final Join<Object, Object> storeJoin = storeProductsJoin.join(STORE, JoinType.INNER);
        final Join<Object, Object> storePriceJoin = storeJoin.join(STORE_PRICE, JoinType.INNER);

        countQuery.select(criteriaBuilder.countDistinct(countRoot))
                .where(this.filterWarRecord(searchCriteria, countRoot, storeProductsJoin, storeJoin, storePriceJoin,
                        criteriaBuilder, user));
        return entityManager.createQuery(countQuery).getSingleResult();
    }

    public Predicate filterRecord(ProductSearchCriteria criteria, Root<Product> productRoot, Join<Object, Object> storeProduct,
                                  Join<Object, Object> store, final Join<Object, Object> storePrice, CriteriaBuilder criteriaBuilder, final User user) {
        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(criteriaBuilder.equal(storePrice.get(PRODUCT_EAN), productRoot.get(PRODUCT_EAN)));
        predicates.add(criteriaBuilder.equal(store.get(STORE_CODE), user.getStore().getStoreCode()));
        predicates.add(criteriaBuilder.greaterThan(storePrice.get(REF_PRICE), 0));
        predicates.add(criteriaBuilder.greaterThan(storePrice.get(PRODUCT_PRICE), 0));
        predicates.add(criteriaBuilder.greaterThan(storeProduct.get(MAX_DECREASE), 0));
        predicates.add(criteriaBuilder.lessThanOrEqualTo(storePrice.get(START_DATE).as(LocalDate.class),LocalDate.now()));
        predicates.add(criteriaBuilder.greaterThanOrEqualTo(storePrice.get(END_DATE).as(LocalDate.class),LocalDate.now()));
        predicates.add(criteriaBuilder.equal(storeProduct.get(STORE), storePrice.get(STORE)));
        if ( !("OutOfRange".equals(criteria.getPrdType()) && TENANT_CAFR.equals(user.getTenant())) ) {
            predicates.add(criteriaBuilder.equal(storeProduct.get(LOCAL_PRICE_FLAG), PRICE_FLAG_YES));
        }
        if (StringUtils.isNotEmpty(criteria.getPrdType())) {
            predicates.add(criteriaBuilder.equal(storeProduct.get(PRD_TYPE), ProductType.valueOf(criteria.getPrdType())));
        }
        if (CollectionUtils.isNotEmpty(criteria.getTypes())) {
            final List<ProductType> listOfProductTypes = criteria.getTypes().stream().map(ProductType::valueOf).toList();
            predicates.add(criteriaBuilder.and(storeProduct.get(PRD_TYPE).in(listOfProductTypes)));
        }
        if (CollectionUtils.isNotEmpty(criteria.getCodes())) {
            predicates.add(criteriaBuilder.and(productRoot.get(PRODUCT_BRICK_CODE).in(criteria.getCodes())));
        }
        if (crConfig.isPrdStatus()) {
            Predicate prdStatusNotNull = criteriaBuilder.and(productRoot.get(PRODUCT_STATUS).in(40, 99).not());
            Predicate prdStatusNull = criteriaBuilder.and(productRoot.get(PRODUCT_STATUS).isNull());
            Predicate predicatePrdStatus = criteriaBuilder.or(prdStatusNull, prdStatusNotNull);
            predicates.add(predicatePrdStatus);
        }
        if (crConfig.isExcludePl()) {
            predicates.add(criteriaBuilder.and(productRoot.get(UOM).in(SALES_UNIT_PL1, SALES_UNIT_PL2, SALES_UNIT_PL3).not()));
        }
        filterByEanDescOrArticleNumber(criteria.getEanOrDesc(), productRoot, predicates, criteriaBuilder);
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    public Predicate filterWarRecord(final ProductSearchCriteria criteria, final Root<Product> productRoot,
                                     final Join<Object, Object> storeProduct, final Join<Object, Object> store,
                                     final Join<Object, Object> storePrice, CriteriaBuilder criteriaBuilder, final User user) {
        final String type = criteria.getPrdType();
        final List<Predicate> predicates = new ArrayList<>();
        predicates.add(criteriaBuilder.and(productRoot.get(PRODUCT_LAST_UPDATED).isNotNull()));
        if (!userService.isHeadOfficeUser(user.getUserId())) {
            predicates.add(criteriaBuilder.equal(store.get(STORE_CODE), user.getStore().getStoreCode()));
        }
        predicates.add(criteriaBuilder.equal(storePrice.get(PRODUCT_EAN), productRoot.get(PRODUCT_EAN)));
        predicates.add(criteriaBuilder.greaterThan(storePrice.get(REF_PRICE), 0));
        predicates.add(criteriaBuilder.greaterThan(storePrice.get(PRODUCT_PRICE), 0));
        predicates.add(criteriaBuilder.greaterThan(storeProduct.get(MAX_DECREASE), 0));
        predicates.add(criteriaBuilder.lessThanOrEqualTo(storePrice.get(START_DATE).as(LocalDate.class),LocalDate.now()));
        predicates.add(criteriaBuilder.greaterThanOrEqualTo(storePrice.get(END_DATE).as(LocalDate.class),LocalDate.now()));
        predicates.add(criteriaBuilder.equal(storeProduct.get(STORE), storePrice.get(STORE)));
        predicates.add(criteriaBuilder.equal(storeProduct.get(LOCAL_PRICE_FLAG), PRICE_FLAG_YES));
        predicates.add(criteriaBuilder.equal(storeProduct.get(FIXED_PRICE_FLAG), PRICE_FLAG_NO));
        if (StringUtils.isNotEmpty(type)) {
            predicates.add(criteriaBuilder.equal(storeProduct.get(PRD_TYPE), ProductType.valueOf(type)));
        }
        if (CollectionUtils.isNotEmpty(criteria.getTypes())) {
            final List<ProductType> listOfProductTypes = criteria.getTypes().stream().map(ProductType::valueOf).toList();
            predicates.add(criteriaBuilder.and(storeProduct.get(PRD_TYPE).in(listOfProductTypes)));
        }
        if (CollectionUtils.isNotEmpty(criteria.getCodes())) {
            predicates.add(criteriaBuilder.and(productRoot.get(PRODUCT_BRICK_CODE).in(criteria.getCodes())));
        }
        if (crConfig.isPrdStatus()) {
            Predicate prdStatusNotNull = criteriaBuilder.and(productRoot.get(PRODUCT_STATUS).in(10, 11, 40, 99).not());
            Predicate prdStatusNull = criteriaBuilder.and(productRoot.get(PRODUCT_STATUS).isNull());
            Predicate predicatePrdStatus = criteriaBuilder.or(prdStatusNull, prdStatusNotNull);
            predicates.add(predicatePrdStatus);
        }
        if (crConfig.isExcludePl()) {
            predicates.add(criteriaBuilder.and(productRoot.get(UOM).in(SALES_UNIT_PL1, SALES_UNIT_PL2, SALES_UNIT_PL3).not()));
        }
        filterByEanDescOrArticleNumber(criteria.getEanOrDesc(), productRoot, predicates, criteriaBuilder);
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    private void filterByEanDescOrArticleNumber(String eanOrDesc, final Root<Product> productRoot,
                                                final List<Predicate> predicates, CriteriaBuilder criteriaBuilder) {
        if (StringUtils.isNotEmpty(eanOrDesc)) {
            if (StringUtils.isNumeric(eanOrDesc)) {
                final Predicate eanPredicate = criteriaBuilder.like(productRoot.get(PRODUCT_EAN),
                        PERCENTAGE + eanOrDesc + PERCENTAGE);
                final Predicate artCodePredicate = criteriaBuilder.like(productRoot.get(PRODUCT_CODE),
                        PERCENTAGE + eanOrDesc + PERCENTAGE);
                final Predicate predicateEanOrCode = criteriaBuilder.or(eanPredicate, artCodePredicate);
                predicates.add(predicateEanOrCode);
            } else {
                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(productRoot.get(DESCRIPTION)),
                        PERCENTAGE + eanOrDesc.toLowerCase() + PERCENTAGE));
            }
        }
    }

    @Cacheable(value = GET_PRODUCTS_STORE_CACHE, key = "{#type, #user.store.storeCode, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    public List<Product> getProductsStore(final TypedQuery<Product> typedQuery, ProductSearchCriteria criteria, User user, String type, String codes) {
        return typedQuery.getResultStream().toList();
    }

    @Cacheable(value = GET_PRODUCTS_HO_CACHE, key = "{#type, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    @Transactional
    public List<Product> getProductsHo(final TypedQuery<Product> typedQuery, ProductSearchCriteria criteria, User user, String type, String codes) {
        return typedQuery.getResultStream().toList();
    }

    @Cacheable(value = GET_CPT_PRODUCTS_STORE_CACHE, key = "{#type, #user.store.storeCode, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    @PerformanceExecution
    public List<Product> getCptProductsStore(final TypedQuery<Product> typedQuery, ProductSearchCriteria criteria, User user, String type, String codes) {
        return typedQuery.getResultStream().toList();
    }

    @Cacheable(value = GET_CPT_PRODUCTS_HO_CACHE, key = "{#type, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    @PerformanceExecution
    public List<Product> getCptProductsHo(final TypedQuery<Product> typedQuery, ProductSearchCriteria criteria, User user, String type, String codes) {
        return typedQuery.getResultStream().toList();
    }

    @Cacheable(value = GET_PRD_PROVISION_STORE_CACHE, key = "{#type, #user.store.storeCode, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    public List<ProductProvision> getProductProvisionListStore(final TypedQuery<ProductProvision> typedQuery, ProductSearchCriteria criteria,
                                                               User user, String type, String codes) {
        return typedQuery.getResultList();
    }

    @Cacheable(value = GET_PRD_PROVISION_HO_CACHE, key = "{#type, #user.store.storeCode, #criteria.eanOrDesc, #codes, #criteria.paging.pageNum}")
    @PerformanceExecution
    public List<ProductProvision> getProductProvisionListHo(final TypedQuery<ProductProvision> typedQuery, ProductSearchCriteria criteria,
                                                            User user, String type, String codes) {
        return typedQuery.getResultList();
    }

    public StringBuilder getTypesAsString(final List<String> types, final String prdType) {
        StringBuilder type = new StringBuilder();
        if (CollectionUtils.isNotEmpty(types) && types.size()==2) {
            type.append(types.get(0)).append(types.get(1));
        } else if (CollectionUtils.isNotEmpty(types) && types.size()==1) {
            type.append(types.get(0));
        } else {
            type.append(prdType);
        }
        return type;
    }

    @Cacheable(value = HIERARCHY_STORE_CACHE, key = "{#store.storeCode, #typeAsString}")
    public List<Object> getHierarchyForStore(final Store store, List<String> types, String typeAsString) {
        List<Object> products;
        Long storeId = store.getStoreId();
        if (types.contains("PVMax")) {
            products = productRepository.findAllDistinctData(storeId, types);
        } else if (types.contains("OutOfRange")) {
            products = productRepository.findAllDistinctDataForOor(storeId, types);
        } else if (types.contains("SlowMoving")) {
            products = productRepository.findAllDistinctDataForSlowMoving(storeId, types);
        } else {
            products = productRepository.findAllDistinctDataForWarList(storeId, types);
        }
        return products;
    }

    @Cacheable(value = HIERARCHY_HO_CACHE)
    public List<Object> getHierarchyForHo() {
        return productRepository.findAllDistinctData();
    }

    public void setPageSizeAndNum(final SearchPaging page, final long count) {
        if (page.getPageNum() < 1 || page.getPageSize() < 1) {
            page.setPageSize( (count < 1) ? 1 : (int) count );
            page.setPageNum( 1 );
        }
    }

    public void setPageSizeAndNumCpt(final ProductSearchPaging page, final long count) {
        if (page.getPageNum() < 1 || page.getPageSize() < 1) {
            page.setPageSize( (count < 1) ? 1 : (int) count );
            page.setPageNum( 1 );
        }
    }

    public List<Product> getProductsFromEans(final List<String> listOfEan, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getProductsFromEans");
        List<Product> products = productRepository.findAllByEanInAndSalesUnitInAndLastUpdatedIsNotNull(listOfEan,
                determineSalesOrg(user));
        logService.logStopWatchStop(stopWatch);
        return products;
    }

    public List<Product> findProductByListOfEanAndType(final List<String> listOfEan, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("findProductByListOfEanAndType");
        List<Product> products = productRepository.findProductByEanInAndSalesUnitIn(listOfEan, determineSalesOrg(user));
        logService.logStopWatchStop(stopWatch);
        return products;
    }

    public Product findProductByEanAndSalesUnitsAndType(final String ean, final List<String> salesUnits, final String prdType) {
        final Optional<Product> productOptional = productRepository.findByEanAndSalesUnitInAndStoreProduct_PrdType(ean, salesUnits, ProductType.valueOf(prdType));
        if (productOptional.isPresent()) {
            return productOptional.get();
        } else {
            throw new DetailsNotFoundException(ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_APP_EXP,
                    ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_HTTP_STATUS, ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_DETAILS,
                    ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_ID, ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_POINTER,
                    ean + PIPE_SEPARATOR + prdType, ExceptionConstants.ProductExceptions.PRODUCT_NOT_FOUND_TITLE);
        }
    }

    public List<String> getListOfEanFromProducts(final List<Product> products) {
        StopWatch stopWatch = logService.logStopWatchStart("getListOfEanFromProducts");
        List<String> listOfEan = org.apache.commons.collections.CollectionUtils.isNotEmpty(products) ?
                products.stream().map(Product::getEan).toList() : new ArrayList<>();
        logService.logStopWatchStop(stopWatch);
        return listOfEan;
    }

    public Optional<Set<ProductChainingInfo>> findChainedProductByGroupingCodeAndDeleteFlag(final String chainId) {
        return productChainingRepository.findByGroupingCodeAndDeleteFlagNotIn(chainId, DELETED_CHAIN_PRODUCT);
    }

    public List<Product> getChainProductsByChainId(final String chainId, final User user) {
        List<Product> products = null;
        var pChainOptional = findChainedProductByGroupingCodeAndDeleteFlag(chainId);
        if (pChainOptional.isPresent()) {
            products = pChainOptional.get().stream().map(ProductChainingInfo::getProduct)
                    .filter(product -> {
                        StoreProduct storeProduct = storeProductService.getStoreProductByProductAndStore(product, user.getStore());
                        return null != storePriceTools.getActiveSPrice(product, storeProduct, user.getStore());
                    })
                    .toList();
        }
        return products;
    }

    @Cacheable(value = CHAIN_ID_CACHE, key = "#product.ean")
    public String getChainIdFromProduct(final Product product) {
        StopWatch stopWatch = logService.logStopWatchStart("getChainIdFromProduct");

        String chainId = (null == product.getProductChainingInfo() ||
                (DELETED_CHAIN_PRODUCT.contains(product.getProductChainingInfo().getDeleteFlag()))) ?
                null : product.getProductChainingInfo().getGroupingCode();
        logService.logStopWatchStop(stopWatch);
        return chainId;
    }

    public boolean filterNonEligibleProductByStatus(final Product product) {
        boolean prdStatus = true;
        if (crConfig.isPrdStatus()) {
            prdStatus = !(null != product.getProductStatus() && NON_ELIGIBLE_PRODUCT_STATUS.contains(product.getProductStatus()));
        }
        return prdStatus;
    }

    @Cacheable(value = CLUSTER_PRICE_CACHE, key = "{#product.ean, #clusterStoreMapping.clusterId}")
    public Double findClusterPriceByEanAndClusterId(final Product product, final ClusterStoreMapping clusterStoreMapping) {
        List<ClusterPrice> clusterPrices = clusterPriceRepository.findByEanAndClusterID(product.getEan(), clusterStoreMapping.getClusterId());
        Double clusterPrice = null;
        if (CollectionUtils.isNotEmpty(clusterPrices)) {
            clusterPrice = clusterPrices.stream()
                    .filter(clPrice -> DateUtils.isInBetween(clPrice.getStartDate(), clPrice.getEndDate().plusDays(1), LocalDateTime.now()))
                    .max(Comparator.comparing(ClusterPrice::getLastUpdatedDate))
                    .map(ClusterPrice::getPrice)
                    .orElse(null);
        }
        return clusterPrice;
    }

    public double getVATByJurisdictionIdAndClassificationCode(final String taxClassificationCode, final User user) {
        var taxDetails = taxClassificationService.findByTaxIdAndTaxClassificationCode(determineSalesOrg(user), taxClassificationCode);
        return taxDetails.map(productTaxClassificationInfo -> (1 + productTaxClassificationInfo.getPercent() / 100)).orElse(DEFAULT_VAT);
    }

    public List<String> determineSalesOrg(final User user) {
        if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
            return switch (user.getStore().getStoreType()) {
                case STORE_TYPE_CLASSIC -> List.of(SALES_UNIT_DF01);
                case STORE_TYPE_BD1K -> List.of(SALES_UNIT_DF10);
                default -> new ArrayList<>();
            };
        } else {
            return StringUtils.equalsIgnoreCase(STORE_TYPE_CLASSIC, user.getStore().getStoreType()) ? List.of(SALES_UNIT_CF01) : List.of();
        }
    }

    @Transactional
    public void updateScStatusAndSave(final Set<StoreCollection> listOfSc) {
        StopWatch stopWatch = logService.logStopWatchStart("updateScStatusAndSave");
        listOfSc.forEach(sc -> {
            sc.setStatus(CollectionStatus.Completed);
            sc.setLastModifiedTime(LocalDateTime.now());
        });
        storeCollectionRepository.saveAll(listOfSc);
        logService.logStopWatchStop(stopWatch);
    }

    public Set<StoreCollection> getStoreCollections(final List<Long> scIds) {
        StopWatch stopWatch = logService.logStopWatchStart("getStoreCollections");

        Set<StoreCollection> storeCollections = storeCollectionRepository.findByIdIn(scIds);
        logService.logStopWatchStop(stopWatch);
        return storeCollections;
    }

    private List<StageProduct> getStageProductsFromProducts(final List<Product> products, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getStageProductsFromProducts");
        List<StageProduct> stageProducts = stageProductRepository.findByProductInAndUserAndStoreAndTenant(products, user,
                user.getStore(), user.getTenant());
        logService.logStopWatchStop(stopWatch);
        return stageProducts;
    }

    public Map<Product, StageProduct> getProductStageProductMap(final List<Product> products, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getProductStageProductMap");

        Map<Product, StageProduct> productStageProductMap = new HashMap<>();

        var listOfStageProducts = getStageProductsFromProducts(products, user);
        if (CollectionUtils.isNotEmpty(listOfStageProducts)) {
            Map<Product, List<StageProduct>> productStageProductsMap = listOfStageProducts.stream()
                    .collect(Collectors.groupingBy(StageProduct::getProduct));
            productStageProductsMap.forEach((product, stageProducts) -> {
                stageProducts.sort(Comparator.comparing(StageProduct::getLastUpdatedTime).reversed());
                productStageProductMap.put(product, stageProducts.get(0));
            });
        }
        logService.logStopWatchStop(stopWatch);
        return productStageProductMap;
    }

    public void updateNrvAndMargin(final String prdType, final StageProduct stageProduct, final double stgPrice,
                                   final double storePrice, final ProvisionDetails provDetails,
                                   final double vatRate) {
        if (ProductType.SlowMoving.toString().equals(prdType) || ProductType.OutOfRange.toString().equals(prdType)) {
            double pRate = null != provDetails.getProvRate() ? provDetails.getProvRate() / 100 : 0.0;
            final double nrv = stgPrice > 0 ?
                    DecimalUtils.convertNegativeZero(( ( (stgPrice / vatRate) - (storePrice / vatRate) )
                            * Double.parseDouble(provDetails.getRecommandation().getRemQtyToSell()) )
                            + ( provDetails.getCStockQty() * (pRate) ) )
                    : 0;
            stageProduct.setNrv(nrv);
            stageProduct.setMarginImpact(null != stageProduct.getPriceSU() ?
                    DecimalUtils.convertNegativeZero(((stageProduct.getPriceSU() / vatRate) -
                            (storePrice / vatRate)) * Double.parseDouble(provDetails.getRecommandation().getRemQtyToSell()))
                    : 0);
        }
    }

}