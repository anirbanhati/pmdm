package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDetailsResponse implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = 1619782726987415010L;

    private ProductItemDetails product;
    private boolean stockApiError = false;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}