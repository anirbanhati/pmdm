package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.entity.InboundFileDetails;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dto.ProductInfo;
import com.kingfisher.compprice.dto.outbound.ProductAssocCSVData;
import com.kingfisher.compprice.repository.InboundFileDetailsRepository;
import com.kingfisher.compprice.repository.ProductRepository;
import com.kingfisher.compprice.repository.StoreRepository;
import com.kingfisher.compprice.tools.MessageServiceTools;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Component
public class MessageServicesHelper {

    private static final String FILE_PREFIX = "productAssociation";

    private final CurrentUser cUser;
    private final StoreRepository storeRepository;
    private final ProductRepository productRepository;
    private final InboundFileDetailsRepository inboundRepository;
    private final MessageServiceTools messageServiceTools;


    public Product createProduct(final String ean, final String articleNumber, final String salesUnit) {
        Product product = getProduct(ean, articleNumber, salesUnit);
        productRepository.save(product);
        return product;
    }

    private static Product getProduct(final String ean, final String articleNumber, final String salesUnit) {
        Product product = new Product();
        product.setEan(ean);
        product.setProductCode(articleNumber);
        product.setSalesUnit(salesUnit);
        product.setLastUpdated(LocalDateTime.now());
        return product;
    }

    public Product createProductWithUOM(final String ean, final String articleNumber, final String salesUnit, final String uom) {
        Product product = getProduct(ean, articleNumber, salesUnit);
        product.setUom(uom);
        productRepository.save(product);
        return product;
    }

    public boolean isSalesOrgValid(final String salesOrg) {
        return StringUtils.isNotEmpty(salesOrg) && StringUtils.isNotEmpty(messageServiceTools.getTenantFromSalesOrg(salesOrg));
    }

    public LocalDateTime getLocalDateTime(final String date) {
        if (StringUtils.isNotEmpty(date)) {
            return LocalDateTime.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT_YYYYMMDDWITHDOT));
        }
        return null;
    }

    public Product getProductByEanAndSalesUnit(final String ean, final String salesOrg) {
        if (StringUtils.isNotEmpty(ean)) {
            return productRepository.findProductByEanAndSalesUnit(ean, salesOrg).orElse(null);
        }
        return null;
    }

    public Store findStoreByStoreCode(String storeCode) {
        if (StringUtils.isNotEmpty(storeCode)) {
            Optional<Store> store = storeRepository.findByStoreCode(storeCode);
            return store.orElse(null);
        }
        return null;
    }

    @Transactional
    public void saveProductFeedToRepository(final ProductInfo productInfo, final Map<String, String> invalidStores) {
        final String methodName = "saveProductFeedToRepository";

        log.debug("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        Store storeData = findStoreByStoreCode(productInfo.getStoreCode());
        if (isSalesOrgValid(productInfo.getSalesOrg()) && StringUtils.isNotEmpty(productInfo.getStoreCode()) && null != storeData) {
            messageServiceTools.addOrUpdateArticleFeedDetailsIntoRepository(productInfo, storeData);
        } else {
            invalidStores.put(productInfo.getStoreCode(), "Invalid Store in article feed ");
            log.info("Invalid stores in Article Feed :: ean {} , salesOrg {} , Invalid stores {} ", productInfo.getEan(), productInfo.getSalesOrg(), productInfo.getStoreCode());
        }
        log.debug("Exiting :: {} :: {}", this.getClass().getSimpleName(), methodName);
    }

    @Transactional
    public void saveFileDetails(final String fileName, String feedType, String folderName) {
        InboundFileDetails inboundFileDetails = new InboundFileDetails();
        inboundFileDetails.setFileName(fileName);
        inboundFileDetails.setProcessedDate(LocalDateTime.now());
        inboundFileDetails.setFeedName(feedType);
        if (Objects.equals(folderName, "archive")) {
            inboundFileDetails.setStatus("Success");
        } else {
            inboundFileDetails.setStatus("Failed");
        }
        inboundRepository.save(inboundFileDetails);
        log.info("The file details have been saved in repo :: {}", inboundFileDetails);
    }

    public Map<File, String> getOutboundCSVFileForUpload(final List<ProductAssocCSVData> productAssocData) throws IOException {
        Map<File, String> fileTenantMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(productAssocData)) {
            final String salesOrg = messageServiceTools.getSalesOrgFromTenant(productAssocData.get(0).getTenant());
            if (StringUtils.isNotEmpty(productAssocData.get(0).getTenant()) && StringUtils.isNotEmpty(salesOrg)) {
                final List<String[]> csvData = prepareOutBoundFeedDataForCSVFile(productAssocData, productAssocData.get(0).getTenant());
                final File tempFileToUpload = messageServiceTools.getFileToUpload(csvData, FILE_PREFIX, salesOrg, SEMI_COLON_CHAR);
                fileTenantMap.put(tempFileToUpload, productAssocData.get(0).getTenant());
            } else log.info("There is no valid tenant or sales org  for ::{}", FILE_PREFIX);
        } else {
            sendEmptyCsvFile(fileTenantMap);
        }
        return fileTenantMap;
    }

    public List<String> determineSalesOrgByTenant(final String tenant) {
        return TENANT_BDFR.equalsIgnoreCase(tenant) ? BDFR_SALES_ORGS : CAFR_SALES_ORGS;
    }

    private void sendEmptyCsvFile(Map<File, String> fileTenantMap) throws IOException {
        final List<String[]> records = new ArrayList<>();
        User user = cUser.getUser();
        if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
            records.add(OUTBOUND_PROD_ASSOC_HEADER_BRICO);
            records.add(OUTBOUND_PROD_ASSOC_HEADERS_BRICO);
        } else if (TENANT_CAFR.equalsIgnoreCase(user.getTenant())) {
            records.add(OUTBOUND_PROD_ASSOC_HEADER_CASTO);
            records.add(OUTBOUND_PROD_ASSOC_HEADERS_CASTO);
        }
        final File tempFileToUpload = messageServiceTools.getFileToUpload(records, FILE_PREFIX, EMPTY_STR, SEMI_COLON_CHAR);
        fileTenantMap.put(tempFileToUpload, user.getTenant());
    }

    private List<String[]> prepareOutBoundFeedDataForCSVFile(final List<ProductAssocCSVData> productAssocCSVData, final String tenant) {
        final List<String[]> records = new ArrayList<>();
        if (TENANT_BDFR.equalsIgnoreCase(tenant)) {
            records.add(OUTBOUND_PROD_ASSOC_HEADER_BRICO);
            records.add(OUTBOUND_PROD_ASSOC_HEADERS_BRICO);
        } else if (TENANT_CAFR.equalsIgnoreCase(tenant)) {
            records.add(OUTBOUND_PROD_ASSOC_HEADER_CASTO);
            records.add(OUTBOUND_PROD_ASSOC_HEADERS_CASTO);
        }
        productAssocCSVData.forEach(outboundData ->
                records.add(new String[]{outboundData.getStoreCode(), outboundData.getArticleNumber(), outboundData.getArticleName(), Double.toString(outboundData.getPriceSu()),
                        Double.toString(outboundData.getPriceUom()), outboundData.getPackaging1(), outboundData.getPackaging2(), outboundData.getCompName(), outboundData.getCompLongName(),
                        Double.toString(outboundData.getCompPriceSu()), Double.toString(outboundData.getCompPriceUom()), outboundData.getCoeff(), outboundData.getCompPkgUnit(),
                        outboundData.getCompArticleNumber(), outboundData.getCompEan(), outboundData.getCreationDate(), outboundData.getComments()})
        );
        return records;
    }

}