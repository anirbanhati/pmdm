package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Vendor")
@XmlAccessorType(XmlAccessType.FIELD)
public class VendorInfo {

    @XmlElement(name = "vendor")
    private String vendor;
    @XmlElement(name = "ean")
    private String  ean;
    @XmlElement(name = "articleNumber")
    private String articleNumber;
    @XmlElement(name = "salesOrg")
    private String salesOrg;

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getArticleNumber() {
        return articleNumber;
    }

    public void setArticleNumber(String articleNumber) {
        this.articleNumber = articleNumber;
    }

    public String getSalesOrg() {
        return salesOrg;
    }

    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
}
