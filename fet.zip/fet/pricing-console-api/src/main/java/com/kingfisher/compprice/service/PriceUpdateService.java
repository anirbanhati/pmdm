package com.kingfisher.compprice.service;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.price.PriceSubmissionDetails;
import com.kingfisher.compprice.dao.price.PriceSubmissionRequest;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.PriceUpdateResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationResponse;
import com.kingfisher.compprice.dao.response.price.PriceValidationUpdateResponse;
import com.kingfisher.compprice.dao.response.search.LatestPriceHistory;
import com.kingfisher.compprice.dao.response.search.PendingPriceProductItem;
import com.kingfisher.compprice.dao.response.search.PriceConversion;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.helper.ProductInfoHelper;
import com.kingfisher.compprice.repository.PriceUpdateRepository;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.tools.PriceValidation;
import com.kingfisher.compprice.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.enums.PriceValidationStatus.*;
import static com.kingfisher.compprice.util.constants.CacheConstants.COMPETITOR_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Service
public class PriceUpdateService {

	private final PriceUpdateRepository priceUpdateRepo;
	private final ThirdPartyAPIService thirdPartyAPIService;
	private final ProductService productService;
	private final StoreProductService storeProductService;
	private final StorePriceService storePriceService;
	private final StageProductService stageProductService;
	private final ProductListingService productListingService;
	private final ClusterPriceService clusterPriceService;
	private final HelperService helperService;
	private final ProductInfoHelper prodHelper;
	private final PriceValidation priceValidation;
	private final BaseValidationFactory prdValidation;
	private final ProductTools productTools;
	private final PriceTools priceTools;
	private final CacheUtils cacheUtils;
	private final LogService logService;
	private final ChangeRequestConfiguration crConfig;


	/**
	 * This method is used to load stage data into price table
	 *
	 * @param currentUser logged user data
	 * @return status message
	 */
	@Transactional
	public String saveFinalPrice(final CurrentUser currentUser) {
		Optional<List<StageProduct>> sProductOptional = stageProductService.findStageProductsByUserAndStoreAndTenantAndIgnoreSaving(currentUser);
		Set<PriceUpdate> priceDetails = new HashSet<>();
		List<StageProduct> stageProducts = null;
		if (sProductOptional.isPresent()) {
			stageProducts = sProductOptional.get();
			stageProducts.forEach(stageProduct -> priceTools.savePriceUpdate(priceDetails, currentUser.getUser(), stageProduct, "lsp"));
		}
		priceTools.saveFinalPriceDetails(priceDetails, stageProducts);
		return STATUS_OK;
	}

	public LatestPriceHistory setLatestPriceHistory(final Product prd, final Store store) {
		LatestPriceHistory pHistory = null;
		final PriceUpdate priceUpdate = priceUpdateRepo.findByProductAndStore(prd, store);
		if (null != priceUpdate) {
			pHistory = new LatestPriceHistory();
			pHistory.setLastUpdateBy(priceUpdate.getPUser().getUserId());
			pHistory.setLastUpdateTime(priceUpdate.getModTime());
			pHistory.setPrice(DecimalUtils.roundOf(priceUpdate.getPrice(), DecimalUtils.ROUND_OF_2));
			pHistory.setStatus(priceUpdate.getStatus());
			pHistory.setId(priceUpdate.getId());
		}
		return pHistory;
	}

	@Transactional
	public PriceValidationResponse findPriceForVerification(final User user) {
		final PriceValidationResponse response = new PriceValidationResponse();
		final Set<PriceUpdate> prices = priceUpdateRepo.findByTenantAndStoreAndStatusIn(user.getTenant(), user.getStore(),
				List.of(PENDING.getStatus()));
		var products = prices.stream().map(PriceUpdate::getProduct).toList();
		var listOfEan = productTools.getListOfEanFromProducts(products);
		var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, listOfEan, user.getStore());
		var validPrdListingMap = productListingService.validateProductListing(products, listOfEan, user.getStore());
		var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
		MasterData masterData = new MasterData(Map.of(), eanStorePriceMap, Map.of(), validPrdListingMap, Map.of(),
				Map.of(), eanClusterPriceMap, Map.of(), Map.of(), Map.of(), products);
		setPendingArticlesResponse(user, response, prices, masterData);
		return response;
	}

	private void setPendingArticlesResponse(final User user, PriceValidationResponse response, final Set<PriceUpdate> prices,
											final MasterData masterData) {
		if (CollectionUtils.isNotEmpty(prices)) {
			response.setProduct(prices.stream()
					.filter(price -> LocalDate.now().atStartOfDay().isBefore(price.getEndDate()))
					.filter(price -> productTools.filterNonEligibleProductByStatus(price.getProduct())
							&& masterData.getValidPrdListingMap().getOrDefault(price.getProduct().getEan(), true))
					.map(price -> prodHelper.setPendingPriceProductItem(price, masterData, user))
					.toList());
			response.setTotalRecord(response.getProduct().size());
		}
	}

	@Transactional
	public void rejectExpiredItems() {
		final List<PriceUpdate> prices = priceUpdateRepo.findByStatus(PENDING.getStatus());
		log.info("Total Pending status records:: {}", prices.size());
		List<PriceUpdate> priceUpdates = prices.stream().filter(Objects::nonNull).map(this::updateStatusAsReject).toList();
		if (CollectionUtils.isNotEmpty(priceUpdates)) {
			priceUpdateRepo.saveAll(priceUpdates);
			log.info("Total Rejected status records:: {}", prices.size());
		}
	}

	private PriceUpdate updateStatusAsReject(PriceUpdate priceUpdate) {
		if (null == priceUpdate.getEndDate() || DateUtils.isAfterStartOfDay(priceUpdate.getEndDate())) {
			priceUpdate.setStatus(REJECT.getStatus());
			priceUpdate.setModTime(LocalDateTime.now());
		}
		return priceUpdate;
	}

	@Transactional
	public PriceValidationUpdateResponse updatePriceValidationStatus(final User user, final List<Long> id, final String status) {
        final PriceValidationUpdateResponse response = new PriceValidationUpdateResponse();
        Set<PriceUpdate> priceDetails = new HashSet<>();

		final Set<PriceUpdate> priceUpdates = priceUpdateRepo.findByIdIn(id);
        if (CollectionUtils.isNotEmpty(priceUpdates)) {
            var products = priceUpdates.stream().map(PriceUpdate::getProduct).toList();
            var listOfEan = productTools.getListOfEanFromProducts(products);
            var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, List.of(), user.getStore());
            var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
            MasterData masterData = new MasterData(Map.of(), eanStorePriceMap, Map.of(), Map.of(), Map.of(), Map.of(),
                    eanClusterPriceMap, Map.of(), Map.of(), Map.of(), products);

			for (PriceUpdate pUpdates : priceUpdates) {
                cacheUtils.evictCacheByKey(COMPETITOR_PRICE_CACHE, List.of(pUpdates.getProduct().getEan(), user.getStore().getStoreCode()));
                PendingPriceProductItem productResponse = prodHelper.setPendingPriceProductItem(pUpdates, masterData, user);

				if (priceTools.isUsefulPrice(pUpdates.getProduct().getEan(), pUpdates.getPrice(), Double.parseDouble(productResponse.getStdPrice()))
						&& LocalDate.now().atStartOfDay().isBefore(pUpdates.getEndDate())) {
					if (pUpdates.getStartDate().isBefore(LocalDate.now().atStartOfDay()) && APPROVED.getStatus().equals(status)) {
						pUpdates.setStartDate(LocalDate.now().plusDays(1).atStartOfDay());
						productResponse.setSDate(DateUtils.getDateAsString(LocalDate.now().plusDays(1).atStartOfDay(), DateUtils.DATE_FORMAT));
					}
					pUpdates.setStatus(getStatusValue(status));
					productResponse.setStatus(getStatusValue(status));

				} else {
					pUpdates.setStatus(REJECT.getStatus());
					productResponse.setStatus(REJECT.getStatus());
				}
				pUpdates.setPUser(user);
				priceUpdateRepo.saveAll(priceDetails);
			}
		}
		return response;
	}

	@Transactional
	public PriceUpdateResponse saveStoreCollectionPrice(final PriceSubmissionRequest priceRequest, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("saveStoreCollectionPrice");

		Set<PriceSubmissionDetails> setOfPriceDetails = priceRequest.getPrdPrice();
		Set<PriceUpdate> priceUpdates = new HashSet<>();
		Set<StoreCollection> listOfSc = productTools.getStoreCollections(priceRequest.getScIds());

		var listOfEan = setOfPriceDetails.stream().map(PriceSubmissionDetails::getEan).toList();
		var listOfProducts = productTools.getProductsFromEans(listOfEan, user);
		var eanProductMap = productService.getEanProductMap(listOfEan, listOfProducts, user);
		var eanStorePriceMap = storePriceService.getEanStorePriceMap(listOfProducts, listOfEan, user.getStore());
		var productStoreProductMap = storeProductService.getProductStoreProductMap(listOfProducts, listOfEan, user);
		var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
		var eanCostPriceMap = thirdPartyAPIService.getCostPriceDetails(listOfProducts, user, true);
		MasterData masterData = new MasterData(eanProductMap, eanStorePriceMap, productStoreProductMap, Map.of(),
				Map.of(), Map.of(), eanClusterPriceMap, Map.of(), Map.of(), eanCostPriceMap, listOfProducts);

		updateFinalPriceIfChainedProducts(listOfProducts, setOfPriceDetails);

		final UUID uuid = UUID.randomUUID();
		final String referenceKey = uuid.toString();
		for (final PriceSubmissionDetails priceDetails : setOfPriceDetails) {
			Product product = masterData.getEanProductMap().get(priceDetails.getEan());
			setScPriceDetails(priceUpdates, user, priceDetails, product, referenceKey, listOfSc, masterData);
		}
		priceTools.savePriceDetails(priceUpdates, listOfSc);
		PriceUpdateResponse response = new PriceUpdateResponse(referenceKey, LocalDateTime.now());

		logService.logStopWatchStop(stopWatch);
		return response;
	}

	private void updateFinalPriceIfChainedProducts(final List<Product> listOfProducts, final Set<PriceSubmissionDetails> setOfPriceDetails) {
		StopWatch stopWatch = logService.logStopWatchStart("updateFinalPriceIfChainedProducts");

		Map<String, String> eanChainIdMap = getEanChainIdMap(listOfProducts);
		Map<String, Double> chainIdLowestPriceMap = getChainIdWithLowestPriceMap(setOfPriceDetails, eanChainIdMap);
		log.info("::::::::: Price Update :::::: chain details {}, True or false {}", eanChainIdMap, chainIdLowestPriceMap.isEmpty());
		setLowestPricesForProducts(setOfPriceDetails, chainIdLowestPriceMap, eanChainIdMap);

		logService.logStopWatchStop(stopWatch);
	}

	public void setLowestPricesForProducts(final Set<PriceSubmissionDetails> setOfPriceDetails, final Map<String, Double> chainIdLowestPriceMap,
										   final Map<String, String> eanChainIdMap) {
		StopWatch stopWatch = logService.logStopWatchStart("setLowestPricesForProducts");
		setOfPriceDetails.stream()
				.filter(priceDetails -> StringUtils.isNotEmpty(eanChainIdMap.get(priceDetails.getEan())))
				.forEach(priceDetails -> {
					if (priceDetails.isChainRequired()) {
						priceDetails.setPrice(chainIdLowestPriceMap.get(eanChainIdMap.get(priceDetails.getEan())));
					} else {
						String ean = priceDetails.getEan();
						priceDetails.setPrice(!chainIdLowestPriceMap.isEmpty()
								&& (chainIdLowestPriceMap.get(eanChainIdMap.get(ean))) < priceDetails.getPrice() ?
								chainIdLowestPriceMap.get(eanChainIdMap.get(ean)) : priceDetails.getPrice());
					}
				});
		logService.logStopWatchStop(stopWatch);
	}

	private Map<String, Double> getChainIdWithLowestPriceMap(final Set<PriceSubmissionDetails> setOfPriceDetails, final Map<String, String> eanChainIdMap) {
		StopWatch stopWatch = logService.logStopWatchStart("getChainIdWithLowestPriceMap");

		Map<String, Double> chainIdLowestPriceMap = new HashMap<>();
		setOfPriceDetails.stream()
				.filter(priceDetails -> priceDetails.isChainRequired() && StringUtils.isNotEmpty(eanChainIdMap.get(priceDetails.getEan())))
				.forEach(priceDetails -> {
					String ean = priceDetails.getEan();
					if (chainIdLowestPriceMap.containsKey(eanChainIdMap.get(ean))) {
						if (priceDetails.getPrice() != 0.0 && checkProductPriceWithChain(chainIdLowestPriceMap, eanChainIdMap, priceDetails)) {
							chainIdLowestPriceMap.put(eanChainIdMap.get(ean), priceDetails.getPrice());
						}
					} else {
						chainIdLowestPriceMap.put(eanChainIdMap.get(ean), priceDetails.getPrice());
					}
				});
		logService.logStopWatchStop(stopWatch);
		return chainIdLowestPriceMap;
	}

	public boolean checkProductPriceWithChain(final Map<String, Double> chainIdLowestPriceMap,
											  final Map<String, String> eanChainIdMap,
											  final PriceSubmissionDetails priceDetails) {
		return (chainIdLowestPriceMap.get(eanChainIdMap.get(priceDetails.getEan())) == 0.0) ||
				(chainIdLowestPriceMap.get(eanChainIdMap.get(priceDetails.getEan())) > priceDetails.getPrice());
	}

	private Map<String, String> getEanChainIdMap(final List<Product> listOfProducts) {
		StopWatch stopWatch = logService.logStopWatchStart("getEanChainIdMap");

		Map<String, String> eanChainIdMap = new HashMap<>();
		listOfProducts.forEach(product -> eanChainIdMap.put(product.getEan(), productTools.getChainIdFromProduct(product)));

		logService.logStopWatchStop(stopWatch);
		return eanChainIdMap;
	}

	private void setScPriceDetails(final Set<PriceUpdate> priceUpdates, final User user, final PriceSubmissionDetails priceDetails,
								   final Product product, final String ref, final Set<StoreCollection> listOfSc,
								   final MasterData masterData) {
		StopWatch stopWatch = logService.logStopWatchStart("setScPriceDetails");

		StoreProduct sProd = null != product ? masterData.getProductStoreProductMap().get(product) : null;
		boolean isValidSProd = null != sProd && PRICE_FLAG_NO.equals(sProd.getFixedPrice()) && PRICE_FLAG_YES.equals(sProd.getLocalPricing());
		ProductType prdType = prdValidation.typeValidation((user.getTenant())).getPrdTypeFromStoreProduct(sProd);

		if ((priceDetails.getPrice() != 0.0) && isValidSProd && (prdType != ProductType.OutOfRange)) {
			var sPrice = masterData.getEanStorePriceMap().get(product.getEan());
			var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
			var clusterPrice = masterData.getEanClusterPriceMap().get(product.getEan());
			var stdPrice = storePriceService.deriveStandardPrice(nPrice, sPrice, user, clusterPrice);
			double costPrice = Double.parseDouble(masterData.getEanCostPriceMap().getOrDefault(product.getEan(), MAP_0));

			double priceSu;
			if (priceTools.isUsefulPrice(product.getEan(), priceDetails.getPrice(), nPrice)) {
				PriceConversion pConv = helperService.getConversionDetails(product, new CategoryRoundingResponse());
				priceSu = getPriceSu(user, priceDetails, pConv);

				priceValidation.isValidPrice(product, sProd, stdPrice, costPrice, user, priceSu);
				PriceUpdate pUpdate = getPriceUpdateDetails(user, priceSu, product, stdPrice, costPrice, prdType, priceDetails);
				pUpdate.setRef(ref);
				pUpdate.setStoreCollection(listOfSc);
				priceUpdates.add(pUpdate);
			} else {
				if (TENANT_BDFR.equalsIgnoreCase(user.getTenant()) && crConfig.isStopPriceCpt()) {
					priceValidation.isValidPrice(product, sProd, stdPrice, costPrice, user, priceDetails.getPrice());
					PriceUpdate pUpdate = getPriceUpdateDetails(user, priceDetails.getPrice(), product, stdPrice, costPrice, prdType, priceDetails);
					pUpdate.setRef(ref);
					pUpdate.setStoreCollection(listOfSc);
					priceUpdates.add(pUpdate);
				}
			}
		}
		logService.logStopWatchStop(stopWatch);
	}

	public double getPriceSu(final User user, final PriceSubmissionDetails priceDetails, final PriceConversion pConv) {
		return TENANT_CAFR.equalsIgnoreCase(user.getTenant()) || (pConv.isRUL() && pConv.isRUV())
				? Double.parseDouble(DecimalUtils.getRounded(priceDetails.getPrice()))
				: Double.parseDouble(DecimalUtils.roundOf(RoundOffPrice.roundOffPrice(priceDetails.getPrice(), false), DecimalUtils.ROUND_OF_2));
	}

	private PriceUpdate getPriceUpdateDetails(final User user, final double priceSu, final Product product,
											  final Double stdPrice, final double costPrice, final ProductType prdType,
											  final PriceSubmissionDetails priceDetails) {
		StopWatch stopWatch = logService.logStopWatchStart("getPriceUpdateDetails");

		PriceUpdate pUpdate = getPriceUpdateByProductAndPrdType(user, product, prdType);
		pUpdate.setPUser(user);
		pUpdate.setProduct(product);
		pUpdate.setStore(user.getStore());
		pUpdate.setPrdType(prdType);
		pUpdate.setCPrice(costPrice);
		pUpdate.setTenant(user.getTenant());
		pUpdate.setModTime(LocalDateTime.now());
		pUpdate.setPrice(priceSu);
		pUpdate.setStoppedPrice(PRICE_FLAG_NO);
		pUpdate.setStartDate(DateUtils.formattedDate(priceDetails.getStartDate()));
		pUpdate.setEndDate(DateUtils.formattedDate(priceDetails.getEndDate()));
		pUpdate.setIndex(Double.parseDouble(
				DecimalUtils.roundOf(((Optional.ofNullable(stdPrice).orElse(0.0) / priceSu) * 100), DecimalUtils.ROUND_OF_3))
		);
		pUpdate.setStatus(priceValidation.calculateCostPriceInclusiveOfVat(costPrice, product, user) > priceSu
				? PENDING.getStatus() : APPROVED.getStatus());

		cacheUtils.evictCacheByKey(COMPETITOR_PRICE_CACHE, List.of(product.getEan(), user.getStore().getStoreCode()));
		logService.logStopWatchStop(stopWatch);
		return pUpdate;
	}

	private PriceUpdate getPriceUpdateByProductAndPrdType(final User user, final Product product, final ProductType prdType) {
		StopWatch stopWatch = logService.logStopWatchStart("getPriceUpdateByProductAndPrdType");
		PriceUpdate priceUpdate = priceUpdateRepo.findByProductAndStoreAndPrdType(product, user.getStore(), prdType).orElseGet(PriceUpdate::new);
		logService.logStopWatchStop(stopWatch);
		return priceUpdate;
	}

	public Set<PriceUpdate> getPriceUpdates(final String tenant) {
		return priceUpdateRepo.findByTenantAndPriceGreaterThanOrderByProduct_ProductCodeAsc(tenant, 0);
	}

	public Set<PriceUpdate> getPriceUpdatesByStore(final String tenant, final Store store) {
		return priceUpdateRepo.findByTenantAndStoreAndPriceGreaterThanOrderByProduct_ProductCodeAsc(tenant,
				store, 0);
	}

	public List<PriceUpdate> getDeltaPriceUpdates(final String tenant, final String ref) {
		List<PriceUpdate> price = priceUpdateRepo.findByTenantAndRefAndPriceGreaterThan(tenant, ref, 0);
		if (CollectionUtils.isNotEmpty(price)) {
			return price;
		}
		return Collections.emptyList();
	}

	private List<PriceUpdate> getPriceUpdatesFromProducts(final List<Product> products, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getPriceUpdatesFromProducts");
		List<PriceUpdate> priceUpdates = priceUpdateRepo.findByProductInAndStore(products, user.getStore());
		logService.logStopWatchStop(stopWatch);
		return priceUpdates;
	}

	public Map<Product, PriceUpdate> getProductPriceUpdateMap(final List<Product> products, final User user) {
		StopWatch stopWatch = logService.logStopWatchStart("getProductPriceUpdateMap");

		Map<Product, PriceUpdate> productPriceUpdateMap = new HashMap<>();

		var listOfPriceUpdates = getPriceUpdatesFromProducts(products, user);
		if (CollectionUtils.isNotEmpty(listOfPriceUpdates)) {
			Map<Product, List<PriceUpdate>> productPriceUpdatesMap = listOfPriceUpdates.stream()
					.collect(Collectors.groupingBy(PriceUpdate::getProduct));
			productPriceUpdatesMap.forEach((product, priceUpdates) -> {
				priceUpdates.sort(Comparator.comparing(PriceUpdate::getModTime).reversed());
				productPriceUpdateMap.put(product, priceUpdates.get(0));
			});
		}
		logService.logStopWatchStop(stopWatch);
		return productPriceUpdateMap;
	}

	private String getStatusValue(final String status) {
		return REJECTED.equals(status) ? REJECT.getStatus() : status;
	}

}