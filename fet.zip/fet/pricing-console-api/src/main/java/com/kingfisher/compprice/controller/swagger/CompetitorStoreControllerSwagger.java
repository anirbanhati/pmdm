package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Tag(name = Constants.TAG_COMPETITOR_STORE)
public interface CompetitorStoreControllerSwagger {

	@Operation(description = "Create Competitor Store Details", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
	@ApiResponses(value = {@ApiResponse(responseCode = "202", description = Constants.RESPONSE_MESSAGE_202),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	ResponseEntity<String> saveCompStoreDetails(@RequestBody final List<CompetitorStore> stores);

	@Operation(description = "Retrieve Competitor Store Details")
	@ApiResponses(value = {@ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	MultiDataResponse<CompetitorStore> getCompStoreDetails();

	@Operation(description = "Retrieve Competitor Store Details for Specific Store")
	@ApiResponses(value = {@ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
			@ApiResponse(responseCode = "400", description = Constants.RESPONSE_MESSAGE_400),
			@ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
			@ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
			@ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404),
			@ApiResponse(responseCode = "409", description = Constants.RESPONSE_MESSAGE_409),
			@ApiResponse(responseCode = "500", description = Constants.RESPONSE_MESSAGE_500)})
	MultiDataResponse<CompetitorStore> getCompStoreDetailsByStoreCode(@PathVariable String storeCode);

}