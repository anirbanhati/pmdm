package com.kingfisher.compprice.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.jsonapi.Resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = TBL_CATEGORY_ROUNDING_CONFIG)
public class CategoryRoundingConfig extends RoundingConfig implements Resource, Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -5873058253242747582L;

	@Id
	@Column(name = COL_BRICK_CODE_PK)
	private Long brickCode;

	@Column(name = COL_CAT_LVL_1)
	private Long catLvl1;
	@Column(name = COL_CAT_LVL_2)
	private Long catLvl2;
	@Column(name = COL_CAT_LVL_3)
	private Long catLvl3;
	@Column(name = COL_CAT_LVL_4)
	private Long catLvl4;
	@Column(name = COL_CAT_LVL_5)
	private Long catLvl5;
	@Column(name = ROUNDING_TYPE)
	private RoundingType type;
	@Column(name = COL_PERFORM_ROUNDING)
	private Boolean performRounding;


	@Override
	public String getJsonApiDataId() {
		return String.valueOf(brickCode);
	}

	@Override
	public String getJsonApiDataType() {
		return TBL_CATEGORY_ROUNDING_CONFIG;
	}

}
