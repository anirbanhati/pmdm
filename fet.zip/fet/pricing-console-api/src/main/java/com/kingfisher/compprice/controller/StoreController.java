package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.StoreControllerSwagger;
import com.kingfisher.compprice.dao.entity.RollingDays;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.request.RollingDaysRequest;
import com.kingfisher.compprice.dao.request.UpdateStoreRequest;
import com.kingfisher.compprice.dao.response.StoreResponse;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@RestController
@RequestMapping(STORE_BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class StoreController implements StoreControllerSwagger {

    private final StoreService storeService;

    Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

    @Override
    @PostMapping(path = POST_STORES)
    public MultiDataResponse<Store> createStores(@RequestBody final List<Store> stores) throws JSONException {
        log.info("Store: createStores --> {}", gson.toJson(stores));
        final List<Store> storeList = storeService.saveStoreDetails(stores);
        return JsonApiResponse.multiDataResponse(storeList);
    }

    @PreAuthorize("hasPermission(#id, 'PermissionName', 'MODIFY_ROLLING_DAYS')")
    @Override
    @PostMapping(path = ROLLING_DAYS)
    public ResponseEntity<String> configurePVMaxRollingDays(@RequestBody final RollingDaysRequest rollingDaysRequest) {
        log.info("Store: configurePVMaxRollingDays --> {}", gson.toJson(rollingDaysRequest));
        storeService.configurePVMaxRollingDays(rollingDaysRequest);
        return new ResponseEntity<>("Configured PVMax Rolling Days.", HttpStatus.OK);
    }

    @Override
    @GetMapping(path = ROLLING_DAYS_INFO)
    public SingleDataResponse<RollingDays> getPVMaxRollingDaysInfo() {
        log.info("Store: getPVMaxRollingDaysInfo");
        return JsonApiResponse.singleDataResponse(storeService.getPVMaxRollingDays());
    }

    @Override
    @GetMapping(path = GET_STORES)
    public MultiDataResponse<Store> getAllStores() {
        log.info("Store: getAllStores");
        final List<Store> allStoreDetails = storeService.getAllStoreDetails();
        return JsonApiResponse.multiDataResponse(allStoreDetails);
    }

    @Override
    @GetMapping(path = GET_STORE_BY_CODE)
    public SingleDataResponse<Store> getStoreByStoreCode(@NotNull @PathVariable final String code) {
        log.info("Store: getStoreByStoreCode --> {}", code);
        return JsonApiResponse.singleDataResponse(storeService.getStoreByCode(code));
    }

    @Override
    @GetMapping(path = GET_STORES_LIST)
    public MultiDataResponse<StoreResponse> getStoresList() {
        log.info("Store: getStoresList");
        final List<StoreResponse> allStoreDetails = storeService.getAllStoreList();
        return JsonApiResponse.multiDataResponse(allStoreDetails);
    }

    @Override
    @PutMapping(value = STORE_UPDATE)
    public ResponseEntity<String> bulkUpdateStores(@RequestBody final Set<UpdateStoreRequest> storeRequests) {
        log.info("Store: bulkUpdateStores --> {}", gson.toJson(storeRequests));
        storeService.updateStores(storeRequests);
        return new ResponseEntity<>("All Items has been updated", HttpStatus.OK);
    }

    @Override
    @PatchMapping(path = STORE_BY_ID)
    public SingleDataResponse<Store> updateStore(@RequestBody final UpdateStoreRequest storeReq,
                                                 @NotNull @PathVariable(ID) final String storeCode) {
        log.info("Store: updateStore --> {}, {}", storeCode, gson.toJson(storeReq));
        return JsonApiResponse.singleDataResponse(storeService.updateStore(storeReq, storeCode));
    }

    @Override
    @DeleteMapping(path = DELETE_STORES)
    public ResponseEntity<String> deleteStoresByIds(@RequestBody final List<String> ids) {
        log.info("Store: deleteStoreByIds --> {}", gson.toJson(ids));
        storeService.deleteStores(ids);
        return new ResponseEntity<>("All Items have been deleted", HttpStatus.OK);
    }

    @Override
    @DeleteMapping(path = ALL)
    public ResponseEntity<String> deleteAllStore() {
        log.info("Store: deleteAllStore");
        storeService.deleteStores();
        return new ResponseEntity<>("All Items have been deleted", HttpStatus.OK);
    }

}