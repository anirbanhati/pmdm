package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.RoundingConfigs;
import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductRoundingConfig;
import com.kingfisher.compprice.dao.entity.RoundingConfig;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.dao.response.RoundingConfigSpreadsheetData;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.helper.PricelistParser;
import com.kingfisher.compprice.repository.CategoryRoundingConfigRepository;
import com.kingfisher.compprice.repository.ProductRoundingConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.ROUNDING_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.HEADER_COLS_CATEGORY_ROUNDING_CONFIG;
import static com.kingfisher.compprice.util.constants.Constants.HEADER_COLS_PRODUCT_ROUNDING_CONFIG;

@Service
@RequiredArgsConstructor
@Slf4j
public class RoundingPriceService {

    private final CategoryRoundingConfigRepository categoryRoundingConfigRepository;
    private final ProductRoundingConfigRepository productRoundingConfigRepository;
    private final CategoryRoundingConfigRepository categoryConfigRepo;
    private final ProductRoundingConfigRepository productConfigRepo;
    private final PricelistParser pricelistParser;
    private final CacheManager cacheManager;
    private final LogService logService;


    public RoundingType deriveRoundingType(final RoundingConfig roundingConfig) {
        RoundingType roundingType = null;
        if (roundingConfig instanceof CategoryRoundingConfig categoryRoundingConfig) {
            roundingType = categoryRoundingConfig.getType();
        } else if (roundingConfig instanceof ProductRoundingConfig productRoundingConfig &&
                BooleanUtils.isTrue(productRoundingConfig.getPerformRounding())) {
            roundingType = productRoundingConfig.getType();
        }
        return roundingType;
    }

    @Cacheable(value = ROUNDING_CACHE, key = "#product.ean")
    public Pair<CategoryRoundingConfig, ProductRoundingConfig> getCategoryAndProductRounding(final Product product) {
        log.debug("Inside rounding type");
        Optional<CategoryRoundingConfig> categoryRoundingConfig = categoryRoundingConfigRepository
                .findById(Long.parseLong(product.getBrickCode()));
        Optional<ProductRoundingConfig> productRoundingConfig = productRoundingConfigRepository
                .findById(Long.parseLong(product.getProductCode()));
        return Pair.of(categoryRoundingConfig.orElse(null), productRoundingConfig.orElse(null));
    }

    public CategoryRoundingResponse getRoundingConfigs(final List<Product> products) {
        StopWatch stopWatch = logService.logStopWatchStart("getRoundingConfigs");
        CategoryRoundingResponse cRounding = new CategoryRoundingResponse();
        List<Long> brickCodes = new ArrayList<>();
        List<Long> productCodes = new ArrayList<>();

        var filteredProducts = products.stream()
                .filter(prd -> StringUtils.isNotBlank(prd.getProductCode()) && StringUtils.isNotBlank(prd.getBrickCode()))
                .collect(Collectors.toSet());

        filteredProducts.forEach(prd -> {
            brickCodes.add(Long.parseLong(prd.getBrickCode()));
            productCodes.add(Long.parseLong(prd.getProductCode()));
        });

        Set<CategoryRoundingConfig> categoryConfigs = categoryConfigRepo.findByBrickCodeIn(brickCodes);
        Set<ProductRoundingConfig> productConfigs = productConfigRepo.findByArticleNumberIn(productCodes);

        cRounding.setConfigs(filteredProducts.stream().map(prd -> {
            RoundingConfigs config = new RoundingConfigs();
            config.setProduct(prd);
            config.setEan(prd.getEan());
            config.setProductConfig(productConfigs.stream().filter(pConfig -> pConfig.getArticleNumber().equals(Long.parseLong(prd.getProductCode()))).findFirst().orElse(null));
            config.setCategoryConfig(categoryConfigs.stream().filter(cConfig -> cConfig.getBrickCode().equals(Long.parseLong(prd.getBrickCode()))).findFirst().orElse(null));
            return config;
        }).toList());
        logService.logStopWatchStop(stopWatch);
        return cRounding;
    }

    @Transactional
    public RoundingConfigSpreadsheetData saveRoundingConfig(final InputStream fileStream) throws IOException {

        final LocalDateTime processStartTime = LocalDateTime.now();
        log.info("Uploading Rounding Config::Starting process::time:: {}", processStartTime);
        final RoundingConfigSpreadsheetData response = pricelistParser.readRoundingConfigForCategoryAndProduct(fileStream,
                HEADER_COLS_CATEGORY_ROUNDING_CONFIG, HEADER_COLS_PRODUCT_ROUNDING_CONFIG);
        if (!response.isHasError()) {
            categoryRoundingConfigRepository.deleteAll();
            productRoundingConfigRepository.deleteAll();
            log.info("Deleted existing table data");
            categoryRoundingConfigRepository.saveAll(response.getCategoryRoundingConfigs());
            productRoundingConfigRepository.saveAll(response.getProductRoundingConfigs());
            Objects.requireNonNull(cacheManager.getCache("roundingCache")).clear();
            Objects.requireNonNull(cacheManager.getCache("roundingConfigsCache")).clear();
            log.info("Reloaded all successful rows into DB");
        } else {
            log.info("There are some error in the data. Hence not uploading to Database");
        }
        final LocalDateTime processEndTime = LocalDateTime.now();
        log.info("Uploading Rounding Config::End time::time:: {}", processEndTime);
        log.info("Uploading Rounding Config::Processing time::time:: {}",
                Duration.between(processEndTime, processStartTime));
        return response;
    }

}