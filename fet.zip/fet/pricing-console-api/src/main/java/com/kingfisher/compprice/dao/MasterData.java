package com.kingfisher.compprice.dao;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.entity.PriceUpdate;
import lombok.*;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MasterData implements Serializable {

    private static final long serialVersionUID = -5187309149846088237L;

    @Builder.Default
    private Map<String, Product> eanProductMap = Map.of();
    @Builder.Default
    private Map<String, StorePrice> eanStorePriceMap = Map.of();
    @Builder.Default
    private Map<Product, StoreProduct> productStoreProductMap = Map.of();
    @Builder.Default
    private Map<String, Boolean> validPrdListingMap = Map.of();
    @Builder.Default
    private Map<Product, String> productMinCPriceMap = Map.of();
    @Builder.Default
    private Map<String, Map<String, CompetitorProduct>> eanwithCompNameCompProductMap = Map.of();
    @Builder.Default
    private Map<String, Double> eanClusterPriceMap = Map.of();
    @Builder.Default
    private Map<Product, PriceUpdate> productPriceUpdateMap = Map.of();
    @Builder.Default
    private Map<Product, StageProduct> productStageProductMap = Map.of();
    @Builder.Default
    private Map<String, String> eanCostPriceMap = Map.of();
    @Builder.Default
    private List<Product> products = List.of();

}