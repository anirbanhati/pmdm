package com.kingfisher.compprice.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "feed")
@Getter
@Setter
public class FeedDataConfiguration {

	Map<String, List<String>> updateExclusion;

}
