package com.kingfisher.compprice.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.UOM;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "product_chaining")
public class ProductChainingInfo implements Serializable {

    private static final long serialVersionUID = -8425085811677052907L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_chain_id")
    private Long id;

    @Column(name = "grouping_code")
    private String groupingCode;

    @Column(name = "grouping_description")
    private String groupingDescription;

    @Column(name = UOM)
    private String uom;

    @Column(name = "coef_type")
    private String coefType;

    @Column(name = "coef")
    private Integer coef;

    @Column(name = "coef_min")
    private Integer coefMin;

    @Column(name = "coef_max")
    private Integer coefMax;

    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @Column(name = "delete_flag")
    private String deleteFlag;

    @Column(name = "last_updated_date")
    private LocalDateTime lastUpdated;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

}