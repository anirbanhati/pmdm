package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.compprice.dao.CollectionProduct;
import com.kingfisher.jsonapi.Resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StoreCollectionPricesResponse implements Resource {

    /**
     *
     */
    private static final long serialVersionUID = -5342604687050740476L;
    private String storeCode;
    private String userId;
    private List<CollectionProduct> productList;
    private List<Long> collectionIds;
    private int rollingDays;

    @Override
    public String getJsonApiDataId() {
        return "clpr";
    }

    @Override
    public String getJsonApiDataType() {
        return "priceRes";
    }

}