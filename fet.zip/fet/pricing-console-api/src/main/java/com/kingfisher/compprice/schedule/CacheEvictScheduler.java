package com.kingfisher.compprice.schedule;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.kingfisher.compprice.util.constants.CacheConstants.MAP_CACHE;

@Slf4j
@Component
@RequiredArgsConstructor
public class CacheEvictScheduler {

    private final CacheManager cacheManager;


    @Scheduled(cron = "${cron.cacheEvict.allCache}")
    @ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
    public void evictAllCacheValues() {
        cacheManager.getCacheNames()
                .forEach(cacheName -> Objects.requireNonNull(cacheManager.getCache(cacheName)).clear());
        log.info("Removed all cache :::");
    }

    @Scheduled(cron = "${cron.cacheEvict.mapCache}")
    @ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
    public void clearMapCache() {
        Objects.requireNonNull(cacheManager.getCache(MAP_CACHE)).clear();
        log.info("Removed map cache :::");
    }

}