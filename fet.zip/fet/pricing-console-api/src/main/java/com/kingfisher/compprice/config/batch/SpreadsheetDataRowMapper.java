package com.kingfisher.compprice.config.batch;

import com.kingfisher.compprice.dao.StoreCollectionHoSpreadsheetData;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

import static com.kingfisher.compprice.util.constants.Constants.*;

public class SpreadsheetDataRowMapper implements RowMapper<StoreCollectionHoSpreadsheetData> {

    @Override
    public StoreCollectionHoSpreadsheetData mapRow(ResultSet rs, int rowNum) throws SQLException {

        return StoreCollectionHoSpreadsheetData.builder()
                .collectionListId(rs.getLong(HO_CL_ID) == 0 ? rs.getLong(ID) : rs.getLong(HO_CL_ID))
                .collectionListName(Objects.requireNonNullElse(rs.getString(HO_CL_NAME), rs.getString(COLLECTION_LIST_NAME)))
                .endDate(getOrSetDefaultValue(rs.getString(EFFECTIVE_END_DATE), null))
                .storeCode(getOrSetDefaultValue(rs.getString(SC_STORE_CODE), EMPTY_STR))
                .storeName(getOrSetDefaultValue(rs.getString(STORE_NAME), EMPTY_STR))
                .storeCollectionId(STORE.equalsIgnoreCase(rs.getString(CATEGORY_TYPE)) ? String.valueOf(rs.getLong(ID)) : EMPTY_STR)
                .storeCollectionListName(rs.getString(COLLECTION_LIST_NAME) + HYPHEN_SEPARATOR + getOrSetDefaultValue(rs.getString(STORE_NAME), EMPTY_STR))
                .competitorStoreCode(getOrSetDefaultValue(rs.getString(CL_CS_CODE), null))
                .competitorName(getOrSetDefaultValue(rs.getString(LONG_NAME), null))
                .category(getOrSetDefaultValue(rs.getString(PRODUCT_CATEGORY), EMPTY_STR))
                .collectionListCode(getOrSetDefaultValue(rs.getString(COL_PRODUCT_CODE), EMPTY_STR))
                .ean(getOrSetDefaultValue(rs.getString(P_EAN), EMPTY_STR))
                .productLabel(getOrSetDefaultValue(rs.getString(DESCRIPTION), EMPTY_STR))
                .uom(rs.getString(UOM))
                .packaging(getOrSetDefaultValue(rs.getString(PACKAGING_1), DECIMAL_3_ZEROS))
                .collectedPkgValue(getOrSetDefaultValue(rs.getString(COLLECTED_PKG_VALUE), EMPTY_STR))
                .collectedPrice(rs.getDouble(COLLECTED_PRICE))
                .notes(rs.getString(NOTES))
                .hasPromo(rs.getBoolean(HAS_PROMO))
                .status(rs.getString(STATUS))
                .catRoundingType(rs.getInt(ROUNDING_TYPE))
                .conversion(rs.getDouble(CONVERSION))
                .salesUnit(rs.getString(SALES_UNIT))
                .build();
    }

    private String getOrSetDefaultValue(final String value, final String defaultValue) {
        return StringUtils.isNotEmpty(value) ? value : defaultValue;
    }

}