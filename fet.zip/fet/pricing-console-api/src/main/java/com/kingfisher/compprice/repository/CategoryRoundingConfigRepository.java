package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface CategoryRoundingConfigRepository extends JpaRepository<CategoryRoundingConfig, Long> {

    Set<CategoryRoundingConfig> findByBrickCodeIn(final List<Long> brickCodes);

}