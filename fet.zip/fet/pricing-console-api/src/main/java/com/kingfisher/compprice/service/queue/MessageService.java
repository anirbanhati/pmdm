package com.kingfisher.compprice.service.queue;

import com.kingfisher.mq.MqMetricHandler;

public interface MessageService {

    enum ProcessedByType {
        PRODUCT_MESSAGE_SERVICE,
        PRICE_MESSAGE_SERVICE,
        VENDOR_MESSAGE_SERVICE,
        FINANCIAL_PROVISION_MESSAGE_SERVICE,
        SALES_HISTORY_MESSAGE_SERVICE,
        TAX_CLASSIFICATION_SERVICE,
        COST_PRICE_SERVICE,
        USER_MESSAGE_SERVICE,
        STORE_ASSOCIATION_MESSAGE_SERVICE,
        PRODUCT_ASSOCIATION_MESSAGE_SERVICE,
        PRODUCT_CHAINING_FEED_SERVICE,
        CLUSTER_PRICE_MESSAGE_SERVICE
    }

    ProcessedByType getProcessedBy();

    void processMessage(String message, MqMetricHandler metricHandler);

}