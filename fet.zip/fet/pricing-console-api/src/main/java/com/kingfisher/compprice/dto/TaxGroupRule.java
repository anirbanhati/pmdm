package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ProductTaxClassification")
@XmlAccessorType(XmlAccessType.FIELD)
public class TaxGroupRule {


    @XmlElement(name = "TaxJurisdictionID")
    private String taxJurisdictionId;

    @XmlElement(name = "TaxCode")
    private String taxCode;

    @XmlElement(name = "Description")
    private String description;

    @XmlElement(name = "TaxRateRule")
    private List<TaxRateRule> taxRateRule;

    public List<TaxRateRule> getTaxRateRule() {
        return taxRateRule;
    }

    public void setTaxRateRule(List<TaxRateRule> taxRateRule) {
        this.taxRateRule = taxRateRule;
    }


    public String getTaxJurisdictionId() {
        return taxJurisdictionId;
    }

    public void setTaxJurisdictionId(String taxJurisdictionId) {
        this.taxJurisdictionId = taxJurisdictionId;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
