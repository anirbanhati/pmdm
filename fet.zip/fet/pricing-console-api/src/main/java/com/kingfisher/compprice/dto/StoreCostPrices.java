package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "AllStoreCostPrices")
@XmlAccessorType(XmlAccessType.FIELD)
public class StoreCostPrices {

    @XmlElement(name = "costPrices")
    private List<StoreCostPricesInfo> storePricesInfoList;

    public List<StoreCostPricesInfo> getStorePricesInfoList() {
        return storePricesInfoList;
    }
    public void setStorePricesInfoList(List<StoreCostPricesInfo> storePricesInfoList) {
        this.storePricesInfoList = storePricesInfoList;
    }
}
