package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name="store_price")
public class StorePrice implements Serializable {

	private static final long serialVersionUID = 5334999885467376446L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name="last_updated")
	private LocalDateTime lastUpdateTime;

	@Column(name="start_date")
	private LocalDateTime startDate;

	@Column(name = "tenant")
	private String tenant;

	@Column(name="end_date")
	private LocalDateTime endDate;

	@Column(name="store_price")
	private Double price;

	@Column(name="ref_price")
	private Double refPrice;

	@Column(name="locale")
	private String locale;

	@Column(name="currency")
	private String currency;

	@Column(name="banner_id")
	private String bannerId;

	@Column(name="price_type_flag")
	private String priceTypeFlag;

	@Column(name="ean")
	private String ean;

	@Column(name = "product_id")
	private Long productId;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

}