package com.kingfisher.compprice.dao.response.search;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceHistory implements Serializable {

	private static final long serialVersionUID = 1068399439788202201L;
	private String refPrice;
	private String appPrice;
	private String spType;
	private int sqty;
	private String avgPrice;
	private LocalDateTime sDate;
	private LocalDateTime eDate;
}
