package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductSearchResponse implements Resource{

	/**
	 *
	 */
	private static final long serialVersionUID = -7434852544913078570L;

	private List<SearchItem> items;
	private long stageCount = 0;
	private long totalRecords;
	private SearchPagination pagination;
	private boolean stockApiError = false;
	private boolean isCurrentStockValidated = false;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}