package com.kingfisher.compprice.dao.price;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.CollectionAssginment;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import com.kingfisher.compprice.dao.response.search.PriceConversion;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductPrice implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7960266008738554765L;

	private String ean;
	private double price;
	private String startDate;
	private String endDate;
	private double index;
	private boolean showDatePicker;
	private boolean chainRequired = false;
	private double collectedPrice;
	private double convertedPrice;
	private double costPrice;
	private String catType;
	private boolean validPrd;
	private double conversion;
	@JsonProperty("sPrice")
	private StorePrice sPrice;
	@JsonProperty("sProd")
	private StoreProduct sProd;
	@JsonProperty("nPrice")
	private Double nPrice;
	@JsonProperty("pConv")
	private PriceConversion pConv;
	@JsonProperty("assignments")
	private List<CollectionAssginment> assignments;

}