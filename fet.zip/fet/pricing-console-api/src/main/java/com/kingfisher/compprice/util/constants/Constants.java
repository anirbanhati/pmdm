package com.kingfisher.compprice.util.constants;

import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.enums.Role;
import lombok.experimental.UtilityClass;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.kingfisher.compprice.enums.Role.HeadOffice;
import static com.kingfisher.compprice.enums.Role.Store;
import static java.util.Map.entry;

@UtilityClass
public class Constants {

	public static final String TENANT_CAFR = "CAFR";
	public static final String TENANT_BDFR = "BDFR";
	public static final String TENANT_BQUK = "BQUK";

	// Uri
	public static final String STORE_BASE_URL = "/api/v1/stores";
	public static final String PRICE_BASE_URL = "/api/v1/price";
	public static final String CACHE_BASE_URL = "/api/v1/cache";
	public static final String COLL_LIST_BASE_URL = "/api/v1/collectionlist";
	public static final String COLL_LIST_2_BASE_URL = "/api/v1/download";
	public static final String WARLIST_BASE_URL = "/api/v1/warlist";
	public static final String WARLIST_PRODUCTS = "/products";
	public static final String PRODUCT_BASE_URL = "/api/v1/products";
	public static final String STG_PRODUCT_BASE_URL = "/api/v1/stage";
	public static final String USER_BASE_URL = "/api/v1/users";
	public static final String COMP_STORE_BASE_URL = "/api/v1/compstores";
	public static final String CLUSTER_PRICE_BASE_URL = "/api/v1/clusterPrice";
	public static final String FEATURES_URL = "/api/v1/config/features";
	public static final String ROUNDING_PRICE_BASE_URL = "/api/rounding/price";
	public static final String JOB_BASE_URL = "/api/v1/jobs";
	public static final String EXPORT_FILE = "/exportFile";
	public static final String GET_KEYS = "/getKeys";
	public static final String CREATE_FEATURE = "/create";
	public static final String UPDATE_FEATURE = "/upate/{featureId}";
	public static final String COMP_FEATURE_BY_NAME = "/{tenant}/{featureName}";
	public static final String COMP_ALL_FEATURES_BY_TENANT = "/tenant/{tenant}";
	public static final String COMP_ALL_ENABLED_FEATURES_BY_TENANT = "/tenant/true/{tenant}";
	public static final String ALL = "/all";
	public static final String UPLOAD_CONFIG = "/config/upload";
	public static final String COLL_LIST_LOWEST_PRICES = "/lowestPrices";
	public static final String UPLOAD = "/upload";
	public static final String APPROVALS = "/approvals";

	// Swagger

	public static final String TAG_PRICE = "Price API";
	public static final String TAG_FEATURE = "Feature Toggle API";
	public static final String TAG_WAR_LIST = "WarList API";
	public static final String TAG_STAGE_PRODUCT = "Stage Product API";
	public static final String TAG_STORE_COLLECTION = "Store Collection API";
	public static final String TAG_STORE_COLLECTION_V2 = "Store Collection V2 API";
	public static final String TAG_ROUNDING_CONFIG = "Rounding Config API";
	public static final String TAG_EVICT_CACHE = "Evict-Cache";
	public static final String TAG_CLUSTER_PRICE = "Cluster Price API";
	public static final String TAG_COMPETITOR_STORE = "Competitor Store API";
	public static final String TAG_PRODUCT = "Product API";
	public static final String TAG_USER = "User API";
	public static final String TAG_STORE = "Store API";


	public static final String USER = "user";
	public static final String STORE = "store";
	public static final String PRODUCT = "product";

	public static final String TENANT = "tenant";
	public static final String START_DATE = "startDate";
	public static final String END_DATE = "endDate";
	public static final String REQUEST_PARAM_FILE = "file";
	public static final String GET_STORE_BY_CODE = "/{code}";
	public static final String STORE_UPDATE = "/update";
	public static final String ROLLING_DAYS = "/rollingDays";
	public static final String ROLLING_DAYS_INFO = "/rollingDays/info";
	public static final String PRICE_DOWNLOAD = "/download/{tenant}";
	public static final String COLLECTION_LIST_DOWNLOAD = "/download";
	public static final String COLLECTION_LIST_CSV_DOWNLOAD = "/store-collection";
	public static final String PRICE_DELTA_DOWNLOAD = "/download/{tenant}/{reference}";
	public static final String GET_STORES = "/";
	public static final String DELETE_STORES = "/";
	public static final String COMP_STORE_BY_STORE_CODE = "/{storeCode}";
	public static final String POST_STORES = "/";
	public static final String POST_CLUSTER_STORES = "/";
	public static final String GET_CLUSTER_BY_STORE_CODE = "/{code}";
	public static final String DELETE_CLUSTER_STORES = "delete/{code}";
	public static final String GET_CLUSTERS_DETAILS = "/list";

	public static final String POST_COMP_STORES = "/";
	public static final String POST_CREATE_STORE_COLLECTION = "/";
	public static final String POST_CREATE_BULK_STORE_COLLECTION = "/file";
	public static final String POST_STORE_COLL_SEARCH = "/search";
	public static final String USER_ROLES = "/roles";
	public static final String USER_ID = "userId";
	public static final String URI_USER_ID = "/{userId}";
	public static final String URI_STORE = "/store";
	public static final String STORE_CODE = "storeCode";
	public static final String COLL_LIST_BY_ID = "/{id}";
	public static final String STORE_BY_ID = "/{id}";
	public static final String COLL_LIST_UPDATE_BULK = "/bulk/update";
	public static final String COLL_LIST_STATUS = "/status";
	public static final String POST_STORE_COLLECTION_SAVE_FINAL_PRICE = "/save";
	public static final String STORE_COLLECTION_BY_USER_STATUS = "/{user}/{status}";
	public static final String GET_PRODUCT_HIERARCHY_BY_TYPE = "/hierarchy";
	public static final String BULK_PRICE_IMPORT = "/price/import";
	public static final String RESET_STG_DATA = "/reset";
	public static final String RESET_STG_DATA_CHAIN = "/reset/chain/{chainId}";
	public static final String UPDATE_CHAIN_PRODUCT = "/chain/{chainId}";
	public static final String STOP_STG_DATA = "/stop";
	public static final String DELETE_STG_DATA_BY_EAN = "/{ean}/{prdType}";
	public static final String UPDATE_GLOBAL_DATES = "/globalDates";
	public static final String DOWNLOAD_IMPORT_ERROR = "/download";
	public static final String GET_PRODUCT_FILTER_OPTIONS = "/{id}/hierarchy";
	public static final String STAGE_PRODUCT_SEARCH = "/search";
	public static final String PRODUCT_SEARCH = "/search";
	public static final String URI_PRICES = "/prices";
	public static final String ROUNDED_OFF_PRODUCT_PRICE = "/price/rounding";
	public static final String PRODUCT_CHAIN = "/chain/{chainId}";
	public static final String SEARCH_FOREIGN_PRODUCTS = "/foreignProducts/search";
	public static final String USER_BY_ROLE ="/byRole";
	public static final String WORKGROUP_PERMISSIONS = "/workgroup/permissions";
	public static final String WORKGROUP_PERMISSIONS_WORK_GROUP_CODE = "/workgroup/permissions/{workGroupCode}";
	public static final String FEATURE_PERMISSIONS = "/feature/permissions";
	public static final String PERMISSIONS_BY_USER_ID = "/permissions/{userId}";
	public static final String STORE_ASSIGN_TO = "/store/assignto";
	public static final String URI_CACHE_NAME = "/{cacheName}";
	public static final String UPLOAD_XML = "/upload-xml";


	// Response
	public static final String RESPONSE_MESSAGE_204 = "No Content";
	public static final String RESPONSE_MESSAGE_400 = "Bad Request";
	public static final String RESPONSE_MESSAGE_409 = "Conflict";
	public static final String RESPONSE_MESSAGE_403 = "Forbidden";
	public static final String RESPONSE_MESSAGE_404 = "Not Found";
	public static final String RESPONSE_MESSAGE_401 = "Unauthorized";
	public static final String RESPONSE_MESSAGE_200 = "OK";
	public static final String RESPONSE_MESSAGE_202 = "Accepted";
	public static final String RESPONSE_MESSAGE_500 = "Internal Error";

	// Entity Constants
	public static final String STATUS = "status";
	public static final String LAST_UPDATE_TIME = "lastUpdateTime";
	public static final String COLL_LIST_ENTITY_NAME = "name";
	public static final String COLL_LIST_ENTITY_ASSIGN_TO = "assignTo";
	public static final String COLL_LIST_ENTITY_CREATED_BY = "createdBy";
	public static final String COLL_LIST_ENTITY_LAST_MOD_BY = "lastModifiedBy";
	public static final String COLL_LIST_ENTITY_CREATION_TIME = "creationTime";
	public static final String COLL_LIST_ENTITY_STORE_CODE = "storeCode";
	public static final String COLL_LIST_ENTITY_COMP_STORE_NAME = "csName";
	public static final String COLL_LIST_ENTITY_EXP_DATE = "expDate";


	public static final String PRODUCT_PRICE = "price";
	public static final String PRODUCT_EAN = "ean";
	public static final String CLUSTER_ID = "clusterID";
	public static final String BULK_IMPORT_EAN = "ean";
	public static final String ID = "id";
	public static final String DESCRIPTION = "description";
	public static final String PRODUCT_CATEGORY = "category";
	public static final String PRODUCT_CODE = "productCode";
	public static final String PRODUCT_SUB_CATEGORY = "subCategory";
	public static final String PRODUCT_BRICK_CODE = "brickCode";
	public static final String PRODUCT_STATUS = "productStatus";
	public static final String PRODUCT_LAST_UPDATED = "lastUpdated";
	public static final String PRODUCT_BRICK_NAME = "brickName";

	public static final String WAR_LIST_ID_LATEST = "latest";

	// Excel file constants
	public static final String WAR_LIST_PRODUCT_DESC = "Description";
	public static final String WAR_LIST_PRODUCT_EAN = "EAN";
	public static final String WAR_LIST_PRODUCT_CAT_NAME = "Category name";
	public static final String WAR_LIST_PRODUCT_SUB_CAT_NAME = "Sub Category name";
	public static final String WAR_LIST_PRODUCT_BRICK_NAME = "Brick name";

	// Separators
	public static final String COMMA_SEPARATOR = ",";
	public static final String COMMA = ",";
	public static final String DOT_SEPARATOR = ".";
	public static final String HYPHEN_SEPARATOR = "-";
	public static final String PIPE_SEPARATOR = "|";
	public static final String COLON_SEPARATOR = ":";
	public static final String AMPERSAND = "&";
	public static final String SEMI_COLON_SEPARATOR = ";";
	public static final String NEW_LINE_SEPARATOR = "\n";
	public static final char SEMI_COLON_CHAR = ';';

	public static final String PRD_TYPE = "prdType";
	public static final String LOCAL_PRICE_FLAG = "localPricing";
	public static final String FIXED_PRICE_FLAG = "fixedPrice";
	public static final String PERCENTAGE = "%";
	public static final String PRICE_FLAG_NO = "N";
	public static final String PRICE_FLAG_YES = "Y";
	public static final String PROMO_ON = "O";
	public static final String UOM_EA = "EA";
	public static final String UOM_PC = "/PC";
	public static final String REJECTED = "Rejected";

	//Inbound Feed Constant
	public static final String NATIONAL_PRICE = "NATIONAL";

	public static final String PRODUCT_PRICE_SU = "SU";
	public static final String PRODUCT_PRICE_UOM = "UOM";

	//Sales Price Type
	public static final String VKP0 = "VKP0";
	public static final String VKA0 = "VKA0";
	public static final String ZMKD = "ZMKD";

	//Price list Header
	public static final String PRICE_LIST_EAN = "EAN";
	public static final String PRICE_LIST_PRIX = "Prix";
	public static final String PRICE_LIST_START_DATE = "Date de début";
	public static final String PRICE_LIST_END_DATE = "Date de fin";
	public static final String DATE_FORMAT_YYYYMMDDWITHDOT = "yyyy.MM.dd HH:mm:ss";

	// Property Names
	public static final String STORE_PRODUCT = "storeProduct";
	public static final String STORE_PRICE= "storePrice";
	public static final String PROVISIONS = "provisions";
	public static final String PROV_STOCK = "provStock";
	public static final String MAX_DECREASE = "maxDecrease";
	public static final String REF_PRICE = "refPrice";
	public static final String COMP_ITEM_TYPE = "categoryType";

	//Reusable Constants and Forward Reference
	public static final String CONCURRENT = "Concurrent";
	public static final String CONDITIONNEMENT = "Conditionnement";
	public static final String COMMENTAIRE = "Commentaire";
	public static final String SUB_AREA_SIEGE="siege";
	public static final String MASTER_DATA_MISSING = "masterDataMissing";
	public static final String STORE_COLLECTION = "storeCollection";
	public static final String CACHE_NAME = "cacheName";

	public static final String[] OUTBOUND_PRICE_HEADERS = new String[] { "EAN", "ARTICLE", "UOM", "SALES_ORG", "STORE_CODE", "CURRENCY","ARTICLE_TYPE",
			"VALIDFROM", "VALIDTO", "PRICE", "USER", "STOPPED_PRICE", "REASON_CODE"};
	public static final String[] OUTBOUND_PROD_ASSOC_HEADER_CASTO = new String[]{"Castorama", "", "", "", "", "", "", CONCURRENT,
			"", "", "", "", "", "", "", "", ""};
	public static final String[] OUTBOUND_PROD_ASSOC_HEADERS_CASTO = new String[]{"Site Casto", "Code CA", "Libellé CA",
			"PV Casto UV", "PV Casto UL", CONDITIONNEMENT, "Unité Condit", "Enseigne concurrent", "Nom magasin concurrent",
			"PV concurrent UV", "PV concurrent UL", "Coeff concurrent", "Condit", "Code concurrent", "EAN concurrent", "Date creation lien",
			COMMENTAIRE};
	public static final String[] OUTBOUND_PROD_ASSOC_HEADER_BRICO = new String[]{"Brico depot", "", "", "", "", "", "",
			CONCURRENT, "", "", "", "", "", "", "", "", ""};
	public static final String[] OUTBOUND_PROD_ASSOC_HEADERS_BRICO = new String[]{"Site Brico", "Code BD", "Libellé BD",
			"PV brico UV", "PV Brico UL", CONDITIONNEMENT, "Unité Condit", "Enseigne concurrent", "Nom magasin concurrent",
			"PV concurrent UV", "PV concurrent UL", "Coeff concurrent", "Condit", "Code concurrent", "EAN concurrent", "Date creation lien",
			COMMENTAIRE};

	//Stock API Constants
	public static final String STOCK_AUTH_HEADER = "Atmosphere atmosphere_app_id=";
	public static final String JSON_TYPE = "application/json";
	public static final String FILTER_STORE = "filter[storeId]=";
	public static final String FILTER_EAN = "filter[ean]=";
	public static final String FILTER_EANS = "filter%5Beans%5D=";
	public static final String FILTER_SOURCE = "filter[source]=";
	public static final String EMPTY_STR = "";

	//BOM Character
	public static final String BYTE_ORDER_MARK_CHARACTER = "ï»¿";

	//ROUNDING CONFIG EXCEL HEADER
	public static final String EXCEL_COL_ROUNDING_TYPE = "Type of Roundings";
	public static final String EXCEL_COL_PRODUCT_CODE = "PRODUCT_CODE";
	public static final String EXCEL_COL_FLAG_OF_ROUNDING = "Flag of Roundings";
	public static final List<String> HEADER_COLS_CATEGORY_ROUNDING_CONFIG = List.of("Code of level 1",
			"Code of level 2", "Code of level 3", "Code of level 4", "Code of level 5", EXCEL_COL_ROUNDING_TYPE,
			"FLAG DELETE");
	public static final List<String> HEADER_COLS_PRODUCT_ROUNDING_CONFIG = List.of(EXCEL_COL_PRODUCT_CODE, "UNIT",
			EXCEL_COL_ROUNDING_TYPE, EXCEL_COL_FLAG_OF_ROUNDING);
	public static final String TBL_CATEGORY_ROUNDING_CONFIG = "category_rounding_config";
	public static final String COL_BRICK_CODE_PK = "brick_code";
	public static final String COL_CAT_LVL_1 = "cat_lvl_1";
	public static final String COL_CAT_LVL_2 = "cat_lvl_2";
	public static final String COL_CAT_LVL_3 = "cat_lvl_3";
	public static final String COL_CAT_LVL_4 = "cat_lvl_4";
	public static final String COL_CAT_LVL_5 = "cat_lvl_5";
	public static final String COL_PERFORM_ROUNDING = "perform_rounding";
	public static final String COL_UNIT_OF_MEASURE = "unit_of_measure";
	public static final String TBL_PRODUCT_ROUNDING_CONFIG = "product_rounding_config";

	public static final String EXCEL_FORMAT = ".xlsx";
	public static final String CSV_FORMAT = ".csv";
	public static final String DELETED_COMP_PRODUCT = "1";
	public static final String DELETED_FLAG_2 = "2";
	public static final List<String> DELETED_CHAIN_PRODUCT = List.of(DELETED_FLAG_2);
	public static final String SHEET_NAME = "Collection_List";

	public static final String[] COLLECTION_LIST_HEADERS_CAFR = {"Catégorie", "Sous Catégorie", "Brick", "Article code",
			"EAN", "Libellé (Kingfisher)", "Unité de vente", CONDITIONNEMENT, "Prix national", CONCURRENT,
			"Libellé (Concurrent)", "Code (Concurrent)", "EAN saisi", "Code article saisi", "Unité de conditionnement",
			"Quantité conditionnement", "Prix conc", "Promo O/N", COMMENTAIRE};
	public static final String[] COLLECTION_LIST_HEADERS_BDFR = { "Catégorie", "EAN", "Libellé (Kingfisher)", "Unité de \nvente",
			CONDITIONNEMENT, "Prix de \nvente \ndépot", CONCURRENT, "Code (Concurrent)", "Unité \nutilisé \npour le", "Prix concurrent", "Promo O/N", COMMENTAIRE};

	public static final String[] COLLECTION_LIST_HEADERS_FOR_HO = { "N° Relevé \n sièg", "Libellé Relevé siège", "Date fin \n relevé siège", "N°\ndépot", "Libellé dépot",
			"N° relevé dépôt", "Libellé relevé dépôt", "Code \nconcurrent", "Libellé \nConcurrent", "Categorie","Code Easier", "EAN", "Libellé(Kingfisher)", "Unit de \nvente",
			"Condition\nnement", "Prix de \nvente \ndepot \nen UV", CONCURRENT, "Code\n(Concurrent)", "Unité \nutilisé \npour le \nrelevé", "Prix \nConcurrent", "Prix  validé", "Promo \nO/N", COMMENTAIRE};

	public static final String IMPORT_DATE_FORMAT_YYYYMMDD_HHMMSS = "yyyyMMdd_HHmmss";
	public static final String DATE_FORMAT_DD_MM_YYYY_HH_MM = "dd-MM-yyyy HH:mm";
	public static final String FILE_DATE_FORMAT_OUTBOUND = "yyyyMMddHHmmss";
	public static final String DATE_FORMAT_EXCEL = "dd/MM/yyyy";

	public static final String UNDER_SCORE = "_";

	public static final String PROD_COLL_OUTBOUND_TYPE = "productCollection";

	public static final String PROD_ASSOC_OUTBOUND_TYPE = "productAssociation";

	public static final String PRICE_OUTBOUND_TYPE = "price";
	public static final Map<String, Role> roleToSubAreaMap = Map.of("magasin", Store, SUB_AREA_SIEGE, HeadOffice);

	public static final String STORE_HEADER = "x-store-code";
	public static final String GET_STORES_LIST = "/list";

	public static final String KITS_REQUEST_ID = "kits-request-id";

	public static final String SALES_UNIT_DF01 = "DF01";
	public static final String SALES_UNIT_DF10 = "DF10";
	public static final String SALES_UNIT_CF01 = "CF01";

	public static final String STORE_TYPE_CLASSIC = "Classic";
	public static final String STORE_TYPE_BD1K = "BD1K";

	public static final String SALES_UNIT_PL1 = "PL1";
	public static final String SALES_UNIT_PL2 = "PL2";
	public static final String SALES_UNIT_PL3 = "PL3";

	public static final String MAP_0 = "0";
	public static final String MAP_0_0 = "0.0";
	public static final String MAP_0_00  = "0.00";
	public static final String ZERO_ZERO = "0,0";
	public static final String DEFAULT_VALUE_1 = "1";

	public static final String SECTOR_A = "A";
	public static final String SECTOR_C = "C";
	public static final String SECTOR_T = "T";

	public static final String DECIMAL_3_ZEROS = "0.000";
	public static final String DOUBLE_CURLY_BRACES = "{} {}";

	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILURE = "FAILURE";

	public static final String JSON_TEMPLATE_MAP_COST_PRICE_RESPONSE = "json-template/map-cost-price-response.json";
	public static final String IS_LOGGING_ENABLED = "isLoggingEnabled";
	public static final String EXPORT = "Export";
	public static final String BULK_EXPORT = "bulk export";
	public static final String STATUS_OK = "OK";
	public static final String STORES = "stores";
	public static final String NAME = "name";
	public static final String EXP_DATE = "expDate";
	public static final String SLOW_MOVING = "Slow Moving";
	public static final String OUT_OF_RANGE = "Out of Range";
	public static final String REASON_CODE_SLOW = "SLOW";
	public static final String REASON_CODE_EXIT_STOCK = "EXIT_STOCK";
	public static final String COMP_STORE_LONG_NAMES = "compStoreLongNames";
	public static final String COLLECTION_LIST_FILENAME_PREFIX = "CL_";
	public static final String ERROR_KEY = "Error";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BASIC = "Basic";

	public static final String SC_NAME = "scName";
	public static final String SC_ID = "scId";
	public static final String OUTPUT_FILE_NAME = "outputFileName";
	public static final String FILE_NAME = "fileName";
	public static final String SC_STORE_CODE = "sc_store_code";
	public static final String LONG_NAME = "longname";
	public static final String P_EAN = "p_ean";
	public static final String HO_CL_ID = "ho_cl_id";
	public static final String HO_CL_NAME = "ho_cl_name";
	public static final String COLLECTION_LIST_NAME = "collection_list_name";
	public static final String EFFECTIVE_END_DATE = "effective_end_date";
	public static final String STORE_NAME = "store_name";
	public static final String CL_CS_CODE = "cl_cs_code";
	public static final String COL_PRODUCT_CODE = "product_code";
	public static final String PACKAGING_1 = "packaging1";
	public static final String CATEGORY_TYPE = "category_type";
	public static final String COLLECTED_PKG_VALUE = "collected_pkg_value";
	public static final String COLLECTED_PRICE = "collected_price";
	public static final String NOTES = "notes";
	public static final String HAS_PROMO = "has_promo";
	public static final String ROUNDING_TYPE = "rounding_type";
	public static final String CONVERSION = "conversion";
	public static final String SALES_UNIT = "sales_unit";
	public static final String UOM = "uom";
	public static final String ERR = "err";


	public static final List<String> STAGING_PRD_TYPES = Arrays.asList(ProductType.PVLocal.toString(),
			ProductType.WarList.toString(), ProductType.PVMax.toString());

	public final List<String> BDFR_SALES_ORGS = Arrays.asList(SALES_UNIT_DF01, SALES_UNIT_DF10);
	public final List<String> CAFR_SALES_ORGS = List.of(SALES_UNIT_CF01);
	public final Map<String, List<String>> TENANT_SALES_ORGS_MAP = Map.ofEntries(
			entry(TENANT_BDFR, BDFR_SALES_ORGS),
			entry(TENANT_CAFR, CAFR_SALES_ORGS));

}