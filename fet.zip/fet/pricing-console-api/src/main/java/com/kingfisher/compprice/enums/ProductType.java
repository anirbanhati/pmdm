package com.kingfisher.compprice.enums;

public enum ProductType {
	OutOfRange("Out of Range"),
	WarList("War List"),
	SlowMoving("Slow Moving"),
	PVMax("PV Max"),
	PVLocal("PV Local");

	private final String pType;

	ProductType(String pType) {
		this.pType = pType;
	}

	public String getpType() {
		return pType;
	}

}