package com.kingfisher.compprice.dao.response.search;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Recommandation implements Serializable {

	private static final long serialVersionUID = 6391879447943195651L;
	@JsonProperty("qSell")
	private String qtyToSell;
	@JsonProperty("rqSell")
	private String remQtyToSell;
	@JsonProperty("sPrice")
	private String salesPrice;
	@JsonIgnore
	private double currentStock;
}
