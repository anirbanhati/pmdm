package com.kingfisher.compprice.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import static com.kingfisher.compprice.util.constants.Constants.DOUBLE_CURLY_BRACES;

@Slf4j
@Service
public class LogService {

    /**
     *
     * GET:
     * /loggers            - Get complete log level details of project
     * /loggers/ROOT       - Get log level of project ROOT
     * /loggers/{package}  - Get log level of {package}

     * POST:
     * /loggers/ROOT       - modify log level of project ROOT
     * /loggers/{package}  - modify log level of {package}
     * JSON Request:
     * {   "configuredLevel": "DEBUG"   }

     */


    public StopWatch logStopWatchStart(final String name) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start(name);
        return stopWatch;
    }

    public void logStopWatchStop(StopWatch stopWatch) {
        if (log.isDebugEnabled()) {
            stopWatch.stop();
            log.debug(DOUBLE_CURLY_BRACES, stopWatch.getLastTaskInfo(), stopWatch.getTotalTimeMillis());
        }
    }

}