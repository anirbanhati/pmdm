package com.kingfisher.compprice.dao.price;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PriceSubmissionDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -7960266008738554765L;

    private String ean;
    private double price;
    private String startDate;
    private String endDate;
    private double index;
    private boolean chainRequired = false;

}
