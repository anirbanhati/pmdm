package com.kingfisher.compprice.util;

import com.kingfisher.compprice.util.constants.Constants;
import lombok.experimental.UtilityClass;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@UtilityClass
public class DateUtils {

	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_FORMAT_WITH_TIME = "yyyy-MM-dd HH:mm";
	private static final String OUTBOUND_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static LocalDateTime formattedDate(final String date) {
		final String inputDate = date + " 00:00";
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_WITH_TIME);
		return LocalDateTime.parse(inputDate, formatter);
	}

	public static boolean isBefore(final LocalDateTime input1, final LocalDateTime input2) {
		return input1.isBefore(input2);
	}

	public static boolean isAfter(final LocalDateTime input1, final LocalDateTime input2) {
		return input1.isAfter(input2);
	}

	public static boolean isEqual(final LocalDateTime input1, final LocalDateTime input2) {
		return input1.toLocalDate().isEqual(input2.toLocalDate());
	}

	public static String getDateAsString(final LocalDateTime date, final String format) {
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		return formatter.format(date);
	}

	public static LocalDateTime getFormattedDateWithFormatter(final String date, final String dateFormat) {
		final String inputDate = date + " 00:00";
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
		return LocalDateTime.parse(inputDate, formatter);
	}

	public static boolean isInBetween(final LocalDateTime startDate, final LocalDateTime endDate, final LocalDateTime comparisonDate){
		return isAfter(comparisonDate, startDate) && isBefore(comparisonDate, endDate);
	}

	public static String getValidDateFormatForOutbound(final LocalDateTime validDate) {
		return Optional.ofNullable(validDate).isPresent() ? validDate.format(DateTimeFormatter.ofPattern(OUTBOUND_DATE_FORMAT)) : Constants.EMPTY_STR;
	}

	public static boolean isAfterStartOfDay(final LocalDateTime time) {
		return isAfter(LocalDate.now().atStartOfDay(), time);
	}

	public static String getTimestamp(final LocalDateTime inputDate, final String pattern) {
		return inputDate.format(DateTimeFormatter.ofPattern(pattern));
	}

}