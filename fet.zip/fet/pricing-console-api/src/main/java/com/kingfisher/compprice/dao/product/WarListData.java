package com.kingfisher.compprice.dao.product;

import java.util.Map;
import java.util.Set;

import com.kingfisher.compprice.dao.entity.Product;

public class WarListData {

	private Set<Product> products;
	private Set<Map<String, Object>> compProdData;

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(final Set<Product> products) {
		this.products = products;
	}

	public Set<Map<String, Object>> getCompProdData() {
		return compProdData;
	}

	public void setCompProdData(final Set<Map<String, Object>> compProdData) {
		this.compProdData = compProdData;
	}

}
