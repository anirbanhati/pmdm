package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.ExcelDataDetails;
import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.entity.CategoryRoundingConfig;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductRoundingConfig;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.response.RoundingConfigSpreadsheetData;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;

@Slf4j
@RequiredArgsConstructor
@Component
public class PricelistParser {

	private final ExcelDataValidatorRules validatorRules;
    private final ExcelDataRead excelDataRead;
    private final LogService logService;


	public ExcelDataDetails savePriceFromFileToStage(final MultipartFile file, List<Product> prodList, final User user)
			throws IOException {
		StopWatch stopWatch = logService.logStopWatchStart("savePriceFromFileToStage");

		ExcelDataDetails dataDetails = excelDataRead.readBulkPriceDataFromExcel(file, prodList, user);

		logService.logStopWatchStop(stopWatch);
		return dataDetails;
	}

	public RoundingConfigSpreadsheetData readRoundingConfigForCategoryAndProduct(final InputStream inputStream, final List<String> headerColumnsForCategoryRounding,
																				 final List<String> headerColumnsForProductRounding)
			throws IOException {
		final RoundingConfigSpreadsheetData roundingConfigSpreadsheetData = new RoundingConfigSpreadsheetData();
		final XSSFWorkbook workBook = SpreadsheetUtils.getInputStreamAsWorkBook(inputStream);
		log.info("Successfully Loaded the spreadsheet as workbook");
		final XSSFSheet categorySheet = workBook.getSheetAt(0);
		final XSSFSheet productExceptionSheet = workBook.getSheetAt(1);
		log.info("Successfully Loaded both the sheets");
		populateCategoryRoundingConfig(headerColumnsForCategoryRounding, roundingConfigSpreadsheetData, categorySheet);
		populateProductRoundingConfig(headerColumnsForProductRounding, roundingConfigSpreadsheetData, productExceptionSheet);
		log.info("Returning roundingConfigSpreadsheetData as:: {}", roundingConfigSpreadsheetData);
		return roundingConfigSpreadsheetData;
	}

	private void populateCategoryRoundingConfig(final List<String> headerColumnsForCategoryRounding, final RoundingConfigSpreadsheetData roundingConfigSpreadsheetData,
												final XSSFSheet categorySheet) {
		final List<CategoryRoundingConfig> categoryRoundingConfigList = new ArrayList<>();
		boolean hasError = false;
		final Set<ExcelError> excelHeaderErrors = new HashSet<>();
		final Row headerRow = validateAndPopulateHeaderRowErrors(headerColumnsForCategoryRounding, categorySheet, excelHeaderErrors);
		if (CollectionUtils.isNotEmpty(excelHeaderErrors)) {
			hasError = true;
			populateCategoryRoundingConfigWithErrors(categoryRoundingConfigList, excelHeaderErrors);
		} else {
			for (int row = 1; row < categorySheet.getPhysicalNumberOfRows(); row++) {
				final Row currentRow = categorySheet.getRow(row);
				final CategoryRoundingConfig validateRow = validatorRules.validateCategoryRoundingConfigRow(currentRow, headerRow, headerColumnsForCategoryRounding);
				if (validateRow.getErrorCount() > 0) {
					hasError = true;
				}
				categoryRoundingConfigList.add(validateRow);
			}
		}
		roundingConfigSpreadsheetData.setCategoryRoundingConfigs(categoryRoundingConfigList);
		roundingConfigSpreadsheetData.setHasError(hasError);
		log.info("Populated roundingConfigSpreadsheetData with Category Rounding Config:: {}", roundingConfigSpreadsheetData);
	}

	private void populateProductRoundingConfig(final List<String> headerColumnsForProductRounding,
                                               final RoundingConfigSpreadsheetData roundingConfigSpreadsheetData, final XSSFSheet productSheet) {
        final List<ProductRoundingConfig> productRoundingConfigList = new ArrayList<>();
		boolean hasError = false;
		final Set<ExcelError> excelHeaderErrors = new HashSet<>();
		final Row headerRow = validateAndPopulateHeaderRowErrors(headerColumnsForProductRounding, productSheet, excelHeaderErrors);
		if (CollectionUtils.isNotEmpty(excelHeaderErrors)) {
			hasError = true;
			populateProductRoundingConfigWithErrors(productRoundingConfigList, excelHeaderErrors);
		} else {
			for (int row = 1; row < productSheet.getPhysicalNumberOfRows(); row++) {
				log.debug("Consuming Product Rounding Config data at row no: {}", row);
				final Row currentRow = productSheet.getRow(row);
				final ProductRoundingConfig validateRow = validatorRules.validateProductRoundingConfigRow(currentRow, headerRow, headerColumnsForProductRounding);
				if (validateRow.getErrorCount() > 0) {
					hasError = true;
				}
				productRoundingConfigList.add(validateRow);
			}
		}
		roundingConfigSpreadsheetData.setProductRoundingConfigs(productRoundingConfigList);
		roundingConfigSpreadsheetData.setHasError(hasError);
		log.info("Populated roundingConfigSpreadsheetData with Product Rounding Config:: {}", roundingConfigSpreadsheetData);
	}

	private void populateCategoryRoundingConfigWithErrors(final List<CategoryRoundingConfig> categoryRoundingConfigList,
														  final Set<ExcelError> excelHeaderErrors) {
		final CategoryRoundingConfig categoryRoundingConfigWithErrors = new CategoryRoundingConfig();
		categoryRoundingConfigWithErrors.setErrorCount(excelHeaderErrors.size());
		categoryRoundingConfigWithErrors.setErrors(excelHeaderErrors);
		categoryRoundingConfigList.add(categoryRoundingConfigWithErrors);
	}

	private void populateProductRoundingConfigWithErrors(final List<ProductRoundingConfig> productRoundingConfigList,
																											 final Set<ExcelError> excelHeaderErrors) {
		final ProductRoundingConfig productRoundingConfigWithErrors = new ProductRoundingConfig();
		productRoundingConfigWithErrors.setErrorCount(excelHeaderErrors.size());
		productRoundingConfigWithErrors.setErrors(excelHeaderErrors);
		productRoundingConfigList.add(productRoundingConfigWithErrors);
	}

	private Row validateAndPopulateHeaderRowErrors(final List<String> headerColumnList, final XSSFSheet firstSheet,
																								 final Set<ExcelError> excelHeaderErrors) {
		final Row headerRow = firstSheet.getRow(0);
		for(int column = 0; column < headerRow.getPhysicalNumberOfCells(); column++) {
			if(!headerColumnList.contains(headerRow.getCell(column).getStringCellValue().trim())) {

				ExcelDataValidation.setErrorDetail(excelHeaderErrors, headerColumnList.get(column),
						BULK_UPLOAD_HEADER_INVALID_STATUS,
						BULK_UPLOAD_HEADER_INVALID + headerColumnList.get(column), BULK_UPLOAD_HEADER_INVALID_ID,
						headerRow.getCell(column).getStringCellValue());
			}
		}
		return headerRow;
	}

}