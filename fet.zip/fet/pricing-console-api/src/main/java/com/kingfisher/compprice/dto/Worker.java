package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "Worker")
@XmlAccessorType(XmlAccessType.FIELD)
public class Worker {


    @XmlElement(name = "WorkerID")
    private Long workerId;

    @XmlElement(name = "CompanyCode")
    private String companyCode;

    @XmlElement(name = "Subarea")
    private String subArea;

    @XmlElement(name = "LoginID")
    private String loginId;

    @XmlElement(name = "FirstName")
    private String firstName;

    @XmlElement(name = "LastName")
    private String lastName;

    @XmlElement(name = "FullName")
    private String fullName;

    @XmlElement(name = "EmailAddress")
    private String emailAddress;

    @XmlElement(name = "WorkerStatusCode")
    private String workerStatusCode;

    @XmlElement(name = "StoreCode")
    private String storeCode;

    @XmlElement(name = "WorkgroupAssignment")
    private List<WorkGroupAssignment> workGroupAssignmentList;

    public Long getWorkerId() {
        return workerId;
    }

    public void setWorkerId(Long workerId) {
        this.workerId = workerId;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getSubArea() {
        return subArea;
    }

    public void setSubArea(String subArea) {
        this.subArea = subArea;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getWorkerStatusCode() {
        return workerStatusCode;
    }

    public void setWorkerStatusCode(String workerStatusCode) {
        this.workerStatusCode = workerStatusCode;
    }

    public List<WorkGroupAssignment> getWorkGroupAssignmentList() {
        return workGroupAssignmentList;
    }

    public void setWorkGroupAssignmentList(List<WorkGroupAssignment> workGroupAssignmentList) {
        this.workGroupAssignmentList = workGroupAssignmentList;
    }
    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }


}
