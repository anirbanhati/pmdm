package com.kingfisher.compprice.controller;

import com.kingfisher.compprice.controller.swagger.RoundingPriceControllerSwagger;
import com.kingfisher.compprice.dao.response.RoundingConfigSpreadsheetData;
import com.kingfisher.compprice.service.RoundingPriceService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(ROUNDING_PRICE_BASE_URL)
public class RoundingPriceController implements RoundingPriceControllerSwagger {

	private final RoundingPriceService roundingPriceService;

	@Override
	@PostMapping(path = UPLOAD_CONFIG)
	public SingleDataResponse<RoundingConfigSpreadsheetData> uploadConfiguration(@RequestParam(REQUEST_PARAM_FILE) final MultipartFile file)
					throws IOException {
		log.info("RoundingPrice: uploadConfiguration");
		return JsonApiResponse.singleDataResponse(roundingPriceService.saveRoundingConfig(file.getInputStream()));
	}

}