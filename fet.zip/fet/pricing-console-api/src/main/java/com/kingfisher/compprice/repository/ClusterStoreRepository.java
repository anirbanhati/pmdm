package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ClusterStoreMapping;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

import static com.kingfisher.compprice.util.constants.CacheConstants.CLUSTER_STORE_CACHE;

@Repository
public interface ClusterStoreRepository extends JpaRepository<ClusterStoreMapping, Long> {

    @Cacheable(value = CLUSTER_STORE_CACHE, key = "#storeCode")
    Optional<ClusterStoreMapping> findByStoreCode(final String storeCode);

}