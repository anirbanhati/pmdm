package com.kingfisher.compprice.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.response.stock.ExternalStockAPIResponse;
import com.kingfisher.compprice.tools.PerformanceExecution;
import com.kingfisher.compprice.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ThirdPartyAPIService {

    protected static final String ERROR_KEY = "Error";

    @Value("${api.stock.accessKey}")
    private String accessKey;
    @Value("${api.stock.url}")
    private String url;
    @Value("${api.map.url}")
    private String baseUrl;
    @Value("${api.mock.map}")
    private boolean useMock;

    private final MovingAveragePriceService movingAveragePriceService;
    private final RestTemplate restTemplate;
    private final LogService logService;


    /**
     * @param products List<Product> : list of products to call GAPI API for getting the current stock
     * @param store    Store: Store code to pass to GAPI API for getting the current stock
     * @return Store current stock against product into map
     */
    @PerformanceExecution
    public Map<String, Integer> getCurrentStockDetails(final List<Product> products, final Store store) {
        final Map<String, Integer> stockMap = new HashMap<>();
        final String[] eanArray = products.stream().map(Product::getEan).toArray(String[]::new);
        final HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, JSON_TYPE);
        headers.set(HttpHeaders.CONTENT_TYPE, JSON_TYPE);
        headers.set(HttpHeaders.AUTHORIZATION, STOCK_AUTH_HEADER + accessKey);

        final StringBuilder deviceProfileInfoURL = new StringBuilder(url);
        deviceProfileInfoURL.append(FILTER_STORE).append(store.getStoreCode()).append(AMPERSAND).append(FILTER_EAN).append(String.join(COMMA, eanArray)).append(AMPERSAND).append(FILTER_SOURCE).append(STORE.toUpperCase());
        log.info("Stock API Request ::{}", deviceProfileInfoURL);
        final HttpEntity<String> request = new HttpEntity<>(headers);
        final ResponseEntity<String> response = restTemplate.exchange(deviceProfileInfoURL.toString(), HttpMethod.GET, request, String.class);
        log.info("Stock API Response ::{}", response);
        if (response.getStatusCode() == HttpStatus.OK && movingAveragePriceService.isValid(response.getBody())) {
            final String responseString = response.getBody();
            final Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
            final ExternalStockAPIResponse stockDetails = gson.fromJson(responseString, ExternalStockAPIResponse.class);
            stockDetails.getData().forEach(stock -> stockMap.put(stock.getAttributes().getEan(), stock.getAttributes().getStockValue()));
        } else {
            stockMap.put(ERROR_KEY, -1);
            log.info("Stock API Response ::{}", response.getBody());
        }
        return stockMap;
    }

    /**
     * @param products     List<Product> : list of products to call GAPI API for getting the current stock
     * @param user         Store: Store code to pass to GAPI API for getting the current stock
     * @param hasCostPrice whether cost price available or not
     * @return Store current stock against product into map
     */
    public Map<String, String> getCostPriceDetails(final List<Product> products, final User user, final boolean hasCostPrice) {
        StopWatch stopWatch = logService.logStopWatchStart("getCostPriceDetails");

        Map<String, String> costDataMap = new HashMap<>();
        StringBuilder deviceProfileInfoURL = null;
        if (hasCostPrice) {
            final String[] eanArray = products.stream().map(Product::getEan).toArray(String[]::new);

            deviceProfileInfoURL = new StringBuilder(StringUtils.replaceEach(baseUrl, new String[]{"{0}", "{1}"},
                    new String[]{user.getTenant(), user.getStore().getStoreCode()}));
            deviceProfileInfoURL.append(FILTER_EANS).append(String.join(COMMA, eanArray));

            if (this.useMock) {
                movingAveragePriceService.formatMapApiResponse(costDataMap, FileUtils.readFile(JSON_TEMPLATE_MAP_COST_PRICE_RESPONSE));
            } else {
                costDataMap = movingAveragePriceService.invokeApiAndGetResponse(deviceProfileInfoURL.toString(), eanArray, user.getStore().getStoreCode());
            }
        }
        log.info("MAP URL:: {} :: costPriceMap:: {}", deviceProfileInfoURL, costDataMap);
        logService.logStopWatchStop(stopWatch);
        return costDataMap;
    }

    public double getCostPrice(final Product product, final Map<String, String> costPriceDetailsMap) {
        return (StringUtils.isNotEmpty(costPriceDetailsMap.get(product.getEan())) ?
                Double.parseDouble(costPriceDetailsMap.get(product.getEan())) : Double.parseDouble(MAP_0));
    }

}