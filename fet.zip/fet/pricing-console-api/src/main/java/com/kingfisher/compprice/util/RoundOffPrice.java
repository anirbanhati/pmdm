package com.kingfisher.compprice.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class RoundOffPrice {

    /**
     * This method takes a product price in double, rounds off
     * the price according to some rounding logics and returns
     * the price as a String
     * Rules:
     * If the price is between 0€ et 10€, then 2nd decimal must be 9. Ex: 4,39€
     * If the price is between 10€ and 100€, then 1st decimal must be 5 or 9. Ex: 12,50€  89,99€
     * If the price is over 100€, then no decimal and the last digit must be 0 or 5 or 9. Ex: 120€   125€   129€
     * @param price a product price in double
     * @return the rounded price as a String
     */
    public static double roundOffPrice(final double price, final boolean isRoundingAllowed) {
        double roundOffPrice = price;
        if (isRoundingAllowed) {
            if (price > 0.00 && price < 10.00 && hasDecimal(price)) {
                roundOffPrice = Math.floor(price * 10) / 10.0 + 0.09;
            } else if (price >= 10.00 && price < 100.00 && hasDecimal(price)) {
                roundOffPrice = roundOffFirstDecimal(price);
            } else if (price >= 100.00) {
                int lastDigit = (int) price % 10;
                roundOffPrice = lastDigit == 0 ? price : roundOffUnitsPlace(price, lastDigit);
            }
            return (double) Math.round(roundOffPrice * 100) / 100;
        }
        return roundOffPrice;
    }

    private static double roundOffUnitsPlace(final double price, final int lastDigit) {
        return Math.floor(price / 10) * 10 + (lastDigit <= 5 ? 5 : 9);
    }

    private static double roundOffFirstDecimal(final double price) {
        double wholePart = Math.floor(price);
        double decimalPart = price - wholePart;
        int firstDecimal = (int) (decimalPart * 10);
        double roundedFirstDecimal = (firstDecimal <= 5) ? 0.5 : 0.9;
        return wholePart + roundedFirstDecimal + (decimalPart - ((double) firstDecimal / 10));
    }

    private static boolean hasDecimal(final double value) {
        return value % 1 != 0;
    }

}