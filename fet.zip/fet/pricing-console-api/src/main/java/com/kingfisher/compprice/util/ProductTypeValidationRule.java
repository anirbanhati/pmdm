package com.kingfisher.compprice.util;

import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.dao.entity.StoreProduct;

public abstract class ProductTypeValidationRule {

    public abstract ProductType getPrdTypeFromStoreProduct(final StoreProduct storeProduct);

}