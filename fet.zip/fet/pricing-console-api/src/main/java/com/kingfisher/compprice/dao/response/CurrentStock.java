package com.kingfisher.compprice.dao.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CurrentStock implements Serializable {

	private static final long serialVersionUID = 5419667649012402324L;
	private double qty;
	private String value;

}