package com.kingfisher.compprice.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.enums.ProductType;
import com.kingfisher.compprice.dao.entity.StageProduct;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;

@Repository
public interface StageProductRepository extends CrudRepository<StageProduct, Long> {

	Optional<StageProduct> findByProductAndUserAndStoreAndPrdTypeAndTenant(final Product prod, final User user, final Store store,
																		   final ProductType prdType, final String tenant);

	Set<StageProduct> findByProductAndUserAndStoreAndTenantAndPrdTypeIn(final Product prod, final User user, final Store store,
																		final String tenant, final List<ProductType> prdType);

	Optional<List<StageProduct>> findAllByUserAndStoreAndTenantAndIgnoreSaving(final User user, final Store store,
																			   final String tenant, final boolean ignore);

	List<StageProduct> findByStoreAndTenantAndUser(final Store store, final String tenant, final User user);

	List<StageProduct> findByProduct_EanAndStoreAndTenant(final String ean, final Store store, final String tenant);

	List<StageProduct> findAllByUserAndStoreAndTenant(final User user, final Store store, final String tenant);

	Optional<List<StageProduct>> findAllByUserAndStoreAndTenantAndGroupingCode(final User user, final Store store,
																			   final String tenant, final String chainId);

	List<StageProduct> findByProductInAndUserAndStoreAndTenant(final List<Product> products, final User user, final Store store, final String tenant);

}