package com.kingfisher.compprice.configuration;

import com.kingfisher.compprice.util.CustomPermissionEvaluator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

/**
 * This is a configuration class that extends GlobalMethodSecurityConfiguration class and overrides
 * the createExpressionHandler() method for adding the CustomPermissionEvaluator to the Security config
 * CustomPermissionEvaluator is used to define or set custom rules to hasPermission() method
 * of annotation @PreAuthorize.
 */
@Configuration
@EnableMethodSecurity(securedEnabled = true, prePostEnabled = false)
public class MethodSecurityConfig {
    @Bean
    protected MethodSecurityExpressionHandler createExpressionHandler() {
        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
        expressionHandler.setPermissionEvaluator(new CustomPermissionEvaluator());
        return expressionHandler;
    }
}
