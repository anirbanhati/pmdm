package com.kingfisher.compprice.controller;

import static com.kingfisher.compprice.util.constants.Constants.COMP_STORE_BASE_URL;
import static com.kingfisher.compprice.util.constants.Constants.COMP_STORE_BY_STORE_CODE;
import static com.kingfisher.compprice.util.constants.Constants.POST_COMP_STORES;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kingfisher.compprice.controller.swagger.CompetitorStoreControllerSwagger;
import com.kingfisher.compprice.dao.entity.CompetitorStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;

@RequestMapping(COMP_STORE_BASE_URL)
@RestController
@RequiredArgsConstructor
@Slf4j
public class CompetitorStoreController implements CompetitorStoreControllerSwagger {

	private final StoreService storeService;

	Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();

	@PostMapping(path = POST_COMP_STORES)
	public ResponseEntity<String> saveCompStoreDetails(@RequestBody final List<CompetitorStore> competitorStores)
			throws JSONException {
		log.info("CompetitorStore: saveCompStoreDetails --> {}", gson.toJson(competitorStores));
		storeService.saveCompStoreDetails(competitorStores);
		return new ResponseEntity<>("Items are created in database.", HttpStatus.CREATED);
	}

	@GetMapping
	public MultiDataResponse<CompetitorStore> getCompStoreDetails() {
		log.info("CompetitorStore: getCompStoreDetails");
		return JsonApiResponse.multiDataResponse(storeService.getCompStoreDetails());
	}

	@GetMapping(path = COMP_STORE_BY_STORE_CODE)
	public MultiDataResponse<CompetitorStore> getCompStoreDetailsByStoreCode(@PathVariable final String storeCode) {
		log.info("CompetitorStore: getCompStoreDetailsByStoreCode --> {}", storeCode);
		return JsonApiResponse.multiDataResponse(storeService.getCompStoreByStoreCode(storeCode));
	}

}