package com.kingfisher.compprice.exception;

public class UserException extends ApplicationException {

	/**
	 *
	 */
	private static final long serialVersionUID = -8534031116828039208L;

	public UserException(final String applicationErrorCode, final String httpStatusCode, final String detail,
			final String id, final String pointer, final String parameter, final String title) {
		super(applicationErrorCode, httpStatusCode, detail, id, pointer, parameter, title);
	}
}
