package com.kingfisher.compprice.schedule;

import com.kingfisher.compprice.helper.OutboundHoCollectionHelper;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StopWatch;

import java.io.IOException;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.PROD_COLL_OUTBOUND_TYPE;

@Slf4j
@RequiredArgsConstructor
@Setter
@ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
public class ProductCollectionOutboundScheduler {

    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketName;

    private final S3OutboundLoadService feedLoadService;
    private final OutboundHoCollectionHelper outboundHoCollectionHelper;
    private final LogService logService;


    @Scheduled(cron = "${cron.outbound.productCollectionFeed}")
    @SchedulerLock(name = "productCollectionOutboundFeed")
    public void exportProductCollectionOutboundFeed() throws IOException {
        log.info("Product Collection feed upload process started :: {}", LocalDateTime.now());
        feedLoadService.uploadFile(bucketName, PROD_COLL_OUTBOUND_TYPE);
    }

    @Scheduled(cron = "${cron.outbound.uploadStoreCollection}")
    @SchedulerLock(name = "uploadStoreCollection")
    public void uploadStoreCollectionsToS3Bucket() {
        StopWatch stopWatch = logService.logStopWatchStart("uploadStoreCollectionsToS3Bucket");
        outboundHoCollectionHelper.uploadStoreCollections();
        logService.logStopWatchStop(stopWatch);
        log.info("Uploaded all HO Collections");
    }

}