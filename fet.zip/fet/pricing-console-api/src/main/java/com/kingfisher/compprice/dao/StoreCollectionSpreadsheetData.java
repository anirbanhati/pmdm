package com.kingfisher.compprice.dao;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StoreCollectionSpreadsheetData {

    private Long collectionListId;
    // Cat&#233;gorie
    private String category;
    // Sous Cat&#233;gorie
    private String subCategory;
    // Brick
    private String brickName;
    // Article code
    private String articleNumber;
    // EAN
    private String ean;
    // Libell&#233; (Kingfisher)
    private String description;
    // Unit&#233; de vente
    private String uom;
    // Conditionnement
    private String packaging;
    // Prix national
    private double nationalPrice;
    // Concurrent
    private String competitorName;
    // Libell&#233; (Concurrent)
    private String competitorProductDescription;
    // Code (Concurrent)
    private String competitorStoreCode;
    // EAN saisi : EAN Collected
    private String competitorProductCollectedEAN;
    // Code article saisi : Article Code Collected
    private String competitorProductCollectedArticleCode;
    // Unit&#233; de conditionnement : Packaging Unit
    private Double competitorConversionUnit;
    // Quantit&#233; conditionnement : Packaging Quantity
    private String competitorQuantity;
    // Prix conc
    private double competitorPrice;
    //  Unite utilise pour le : Assignment collected pkg value
    private String collectedPkgValue;
    // Promo O/N
    private String promoInfo;
    // Commentaire
    private String notes;

}