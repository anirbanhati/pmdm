package com.kingfisher.compprice.dao.search;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CompItemCriteria {

	private String name;
	private Set<String> createdBy;
	private Set<String> assignTo;
	private Set<String> lastModifiedBy;
	private String creationTime;
	private Set<String> status;
	private String storeCode;
	private String type;
	private Set<String> compStoreNames;
	private String expDate;

}