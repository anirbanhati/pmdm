package com.kingfisher.compprice.enums;

public enum CollectionStatus {
	Created, Assigned, WIP, Reported, Completed
}
