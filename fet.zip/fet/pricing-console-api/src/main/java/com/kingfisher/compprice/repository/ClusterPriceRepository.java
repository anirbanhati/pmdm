package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ClusterPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ClusterPriceRepository extends JpaRepository<ClusterPrice,Long> {

    List<ClusterPrice> findByEanAndClusterID(final String ean, final String clusterId);

    List<ClusterPrice> findByEanInAndClusterID(final List<String> listOfEan, final String clusterId);

    List<ClusterPrice> findByEndDateBefore(final LocalDateTime effectiveDate);

}