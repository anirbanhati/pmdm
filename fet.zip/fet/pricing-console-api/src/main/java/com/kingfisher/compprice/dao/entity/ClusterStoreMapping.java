package com.kingfisher.compprice.dao.entity;

import com.kingfisher.jsonapi.Resource;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Getter
@Setter
@Table(name = "cluster_store_mapping")
public class ClusterStoreMapping implements Resource, Serializable {
    private static final long serialVersionUID = -3321685929423982697L;

    @Id
    @Column(name = "store_code")
    private String storeCode;

    @Column(name = "cluster_id")
    private String clusterId;

    @Override
    public String getJsonApiDataId() {
        return null;
    }

    @Override
    public String getJsonApiDataType() {
        return null;
    }

}