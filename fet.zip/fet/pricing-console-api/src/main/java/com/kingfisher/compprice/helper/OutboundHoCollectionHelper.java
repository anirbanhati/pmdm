package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.entity.StoreCollection;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.service.StoreCollectionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.Constants.*;

@RequiredArgsConstructor
@Slf4j
@Component
public class OutboundHoCollectionHelper {

    private final Job exportStoreCollectionItems;
    private final JobLauncher jobLauncher;
    private final StoreCollectionService storeCollectionService;
    private final LogService logService;


    public void uploadStoreCollections() {
        List<StoreCollection> hoStoreCollections = storeCollectionService.getCollectionsByCategoryType();

        Map<String, List<StoreCollection>> scNameWithHoStoreCollectionsMap = hoStoreCollections.stream()
                .collect(Collectors.groupingBy(StoreCollection::getName));
        log.info("Size of HoStoreCollections(distinct) --> {}", scNameWithHoStoreCollectionsMap.size());

        scNameWithHoStoreCollectionsMap.forEach((scName, storeCollections) -> {
            StopWatch stopWatch = logService.logStopWatchStart("uploadStoreCollections");

            String fileName = scName + HYPHEN_SEPARATOR + LocalDate.now() + EXCEL_FORMAT;
            jobExecutionForExportCollection(exportStoreCollectionItems, fileName, scName, storeCollections.get(0).getId());
            storeCollectionService.saveKeyToStoreCollections(fileName, storeCollections);
            stopWatch.stop();
            log.info(DOUBLE_CURLY_BRACES, stopWatch.getLastTaskName(), stopWatch.getTotalTimeSeconds());
        });
    }

    private void jobExecutionForExportCollection(Job job, final String fileName, final String scName, long scId) {
        try {
            log.info("{} {} {} {}", StructuredArguments.keyValue("method", "jobExecutionForExportCollection"),
                    StructuredArguments.keyValue(SC_NAME, scName), StructuredArguments.keyValue(SC_ID, scId),
                    StructuredArguments.keyValue(FILE_NAME, fileName));

            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("jobName", job.getName())
                    .addString("date", LocalDateTime.now().toString())
                    .addString(OUTPUT_FILE_NAME, fileName)
                    .addString(SC_NAME, scName)
                    .addLong(SC_ID, scId)
                    .toJobParameters();
            jobLauncher.run(job, jobParameters);
        } catch (Exception e) {
            log.error("{} {} {} {} {}", StructuredArguments.keyValue("method", "jobExecutionForExportCollection"), StructuredArguments.keyValue(SC_NAME, scName), StructuredArguments.keyValue(SC_ID, scId),
                    StructuredArguments.keyValue(FILE_NAME, fileName), StructuredArguments.keyValue("Exception", e.getMessage()));
        }
    }

}