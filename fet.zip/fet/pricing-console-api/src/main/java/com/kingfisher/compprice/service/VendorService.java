package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Vendor;
import com.kingfisher.compprice.repository.VendorRepository;
import lombok.AllArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;

@Service
@AllArgsConstructor
public class VendorService {

    private VendorRepository vendorRepo;


    public String getVendorByProduct(final Product prd) {
        String vInfo = EMPTY_STR;
        final List<Vendor> vendors = vendorRepo.findByProduct(prd);
        if (CollectionUtils.isNotEmpty(vendors)) {
            vInfo = vendors.get(0).getVInfo();
        }
        return vInfo;
    }

}