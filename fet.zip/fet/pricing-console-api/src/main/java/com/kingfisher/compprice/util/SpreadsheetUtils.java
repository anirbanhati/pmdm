package com.kingfisher.compprice.util;

import lombok.experimental.UtilityClass;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;

@UtilityClass
public class SpreadsheetUtils {

    public static XSSFWorkbook getInputStreamAsWorkBook(final InputStream inputStream) throws IOException {
        XSSFWorkbook workBook;
        workBook = new XSSFWorkbook(inputStream);
        return workBook;
    }

}