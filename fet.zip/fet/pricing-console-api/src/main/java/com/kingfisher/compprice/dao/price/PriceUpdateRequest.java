package com.kingfisher.compprice.dao.price;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PriceUpdateRequest implements Serializable {

	private static final long serialVersionUID = -7145175529247758688L;

	private List<Long> clIds;
	private String userId;
	private Set<ProductPrice> prdPrice;

	private String storeCode;


}
