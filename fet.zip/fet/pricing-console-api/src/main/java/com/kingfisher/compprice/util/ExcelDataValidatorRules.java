package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.ExcelValidation;
import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.request.StageDataRequest;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.service.LogService;
import com.kingfisher.compprice.util.constants.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Component
public class ExcelDataValidatorRules {

	private final List<String> lspImportHeaders = new ArrayList<>(Arrays.asList(PRICE_LIST_EAN, PRICE_LIST_PRIX,
			PRICE_LIST_START_DATE, PRICE_LIST_END_DATE));

	private final ExcelDataValidation dataValidation;
	private final ExcelFieldValidation fieldValidation;
	private final LogService logService;


	public ExcelValidation validateRowExcel(final Row currentRow, final Row headerRow, final User user, final MasterData masterData) {
		StopWatch stopWatch = logService.logStopWatchStart("validateRow");

		final ExcelValidation excelData = new ExcelValidation();
		final Map<String, Object> excelValue = new HashMap<>();
		Product product = null;
		StoreProduct storeProduct = new StoreProduct();
		for (int column = 0; column < lspImportHeaders.size(); column++) {
			String headerValue = getHeaderColumnValue(headerRow, column);

			final Cell currentCell = currentRow.getCell(column);
			String cellValue = EMPTY_STR;
			if (null != currentCell) {
				cellValue = deriveCellTypeAndRetrieveValueExcel(headerValue, excelValue, currentCell, cellValue);

				final Set<ExcelError> excelErrors = fieldValidation.validateCellValue(headerValue, cellValue, excelData);
				if (CollectionUtils.isNotEmpty(excelErrors)) {
					excelValue.put(headerValue, ERR);
					cellValue = ERR;
				}

				product = dataValidation.validateDataForStaging(headerValue, cellValue, user, excelData, product,
						storeProduct, masterData);
				Set<ExcelError> errors = combineExcelErrors(excelData, excelErrors);
				excelData.setErrors(errors);
			}
		}

		excelData.setRowNum(currentRow.getRowNum());
		setDataForStaging(excelValue, excelData, product, masterData);

		logService.logStopWatchStop(stopWatch);
		return excelData;
	}

	public ExcelValidation validateRowCsv(final String[] currentRow, final String headerRow, final User user,
										  final MasterData masterData, final int rowNum) {
		StopWatch stopWatch = logService.logStopWatchStart("validateRowCsv");

		final ExcelValidation excelData = new ExcelValidation();
		final Map<String, Object> excelValue = new HashMap<>();
		Product product = null;
		StoreProduct storeProduct = new StoreProduct();
		String headerRowValues = headerRow.replaceAll("(\\r\\n|\\n|\\r)", EMPTY_STR);
		List<String> headerValues = new ArrayList<>(Arrays.asList(headerRowValues.split(SEMI_COLON_SEPARATOR)));

		for (int column = 0; column < lspImportHeaders.size(); column++) {
			String headerValue = getHeaderColumnValueForCsv(headerValues, column);
			String cellValue = currentRow[column].replaceAll("(\\r\\n|\\n|\\r)", EMPTY_STR);
			excelValue.put(headerValue, cellValue);

			final Set<ExcelError> excelErrors = fieldValidation.validateCellValue(headerValue, cellValue, excelData);
			if (CollectionUtils.isNotEmpty(excelErrors)) {
				cellValue = ERR;
				excelValue.put(headerValue, ERR);
			}

			product = dataValidation.validateDataForStaging(headerValue, cellValue, user, excelData, product, storeProduct, masterData);
			excelData.setErrors(combineExcelErrors(excelData, excelErrors));
		}

		excelData.setRowNum(rowNum);
		setDataForStaging(excelValue, excelData, product, masterData);

		logService.logStopWatchStop(stopWatch);
		return excelData;
	}

	public void setDataForStaging(final Map<String, Object> excelValue, final ExcelValidation excelData,
								  final Product product, final MasterData masterData) {
		StopWatch stopWatch = logService.logStopWatchStart("setDataForStaging");

		if ((CollectionUtils.isEmpty(excelData.getErrors()) || 0 == excelData.getErrorCount()) && null != product) {
			final StageDataRequest stageDataRequest = new StageDataRequest(excelValue.get(PRICE_LIST_EAN).toString(),
					Objects.requireNonNull(DecimalUtils.parse(excelValue.get(PRICE_LIST_PRIX).toString(), Locale.FRANCE)).toString(),
					PRODUCT_PRICE_SU,
					DateUtils.getDateAsString(DateUtils.getFormattedDateWithFormatter(excelValue.get(PRICE_LIST_START_DATE).toString().replace(DOT_SEPARATOR, HYPHEN_SEPARATOR),
							DATE_FORMAT_DD_MM_YYYY_HH_MM), DateUtils.DATE_FORMAT),
					DateUtils.getDateAsString(DateUtils.getFormattedDateWithFormatter(excelValue.get(PRICE_LIST_END_DATE).toString().replace(DOT_SEPARATOR, HYPHEN_SEPARATOR),
							DATE_FORMAT_DD_MM_YYYY_HH_MM), DateUtils.DATE_FORMAT),
					excelData.getPrdType(),
					masterData.getProductMinCPriceMap().getOrDefault(product, String.valueOf((new Assignment()).getCollectedPrice())),
					EMPTY_STR,
					Double.parseDouble(masterData.getEanCostPriceMap().getOrDefault(product.getEan(), MAP_0_0)),
					excelData.getStorePrice(),
					excelData.getStdPrice(),
					false,
					null);
			excelData.setRequest(stageDataRequest);
			excelData.setProduct(product);
			logService.logStopWatchStop(stopWatch);
		}
	}

	private Set<ExcelError> combineExcelErrors(ExcelValidation excelData, final Set<ExcelError> excelErrors) {
		Set<ExcelError> errors = excelData.getErrors();
		if (CollectionUtils.isNotEmpty(errors)) {
			errors.addAll(excelErrors);
		} else {
			errors = new HashSet<>(excelErrors);
		}
		return errors;
	}

	public CategoryRoundingConfig validateCategoryRoundingConfigRow(final Row currentRow, final Row headerRow,
			final List<String> headerColumnList) {
		final CategoryRoundingConfig categoryRoundingConfig = new CategoryRoundingConfig();
		final Set<ExcelError> excelErrorsForRow = new HashSet<>();
		final Map<String, Object> excelValue = new HashMap<>();
		ExcelValidation excelData = null;
		for (int column = 0; column < headerRow.getPhysicalNumberOfCells(); column++) {
			if (headerColumnList.contains(getHeaderColumnValue(headerRow, column))) {

				final Cell currentCell = currentRow.getCell(column);
				String cellValue = EMPTY_STR;
				if (null != currentCell) {
					cellValue = deriveCellTypeAndRetrieveValue(headerRow, excelValue, column, currentCell, cellValue);

					final Set<ExcelError> excelErrorsForColumn = this.fieldValidation
							.validateCellValue(getHeaderColumnValue(headerRow, column), cellValue, excelData);

					if (CollectionUtils.isNotEmpty(excelErrorsForColumn)) {
						excelValue.put(getHeaderColumnValue(headerRow, column), ERR);
						cellValue = ERR;
						excelErrorsForRow.addAll(excelErrorsForColumn);
					}
					switch (column) {
						case 0:
							categoryRoundingConfig.setCatLvl1(Long.parseLong(cellValue));
							break;
						case 1:
							categoryRoundingConfig.setCatLvl2(Long.parseLong(cellValue));
							break;
						case 2:
							categoryRoundingConfig.setCatLvl3(Long.parseLong(cellValue));
							break;
						case 3:
							categoryRoundingConfig.setCatLvl4(Long.parseLong(cellValue));
							break;
						case 4:
							categoryRoundingConfig.setCatLvl5(Long.parseLong(cellValue));
							categoryRoundingConfig.setBrickCode(Long.parseLong(cellValue));
							break;
						case 5:
							categoryRoundingConfig.setType(RoundingType.valueOf(cellValue));
							break;
						default:
							break;
					}
				}
			}
		}
		categoryRoundingConfig.setRowNum(currentRow.getRowNum());
		categoryRoundingConfig.setErrors(excelErrorsForRow);
		categoryRoundingConfig.setErrorCount(excelErrorsForRow.size());
		return categoryRoundingConfig;
	}

	public ProductRoundingConfig validateProductRoundingConfigRow(final Row currentRow, final Row headerRow,
			final List<String> headerColumnList) {
		final ProductRoundingConfig productRoundingConfig = new ProductRoundingConfig();
		final Map<String, Object> excelValue = new HashMap<>();
		final Set<ExcelError> excelErrorsForRow = new HashSet<>();
		ExcelValidation excelData = null;
		for (int column = 0; column < headerRow.getPhysicalNumberOfCells(); column++) {
			if (headerColumnList.contains(getHeaderColumnValue(headerRow, column))) {

				final Cell currentCell = currentRow.getCell(column);
				String cellValue = "";
				if (null != currentCell) {
					cellValue = deriveCellTypeAndRetrieveValue(headerRow, excelValue, column, currentCell, cellValue);

					final Set<ExcelError> excelErrorsForColumn = this.fieldValidation
							.validateCellValue(getHeaderColumnValue(headerRow, column), cellValue, excelData);

					if (CollectionUtils.isNotEmpty(excelErrorsForColumn)) {
						excelValue.put(getHeaderColumnValue(headerRow, column), ERR);
						cellValue = ERR;
						excelErrorsForRow.addAll(excelErrorsForColumn);
					}
					switch (column) {
						case 0:
							log.debug("Consuming Product Rounding Config data for: {}", cellValue);
							productRoundingConfig.setArticleNumber(Long.parseLong(cellValue));
							break;
						case 1:
							productRoundingConfig.setUnitOfMeasure(cellValue);
							break;
						case 2:
							log.debug("Consuming Product Rounding Config data Type value: {}", cellValue);
							productRoundingConfig.setType(RoundingType.valueOf(cellValue));
							break;
						case 3:
							productRoundingConfig.setPerformRounding(BooleanUtils.toBooleanObject(cellValue));
							break;
						default:
							break;
					}
				}
			}
		}
		productRoundingConfig.setRowNum(currentRow.getRowNum());
		productRoundingConfig.setErrors(excelErrorsForRow);
		productRoundingConfig.setErrorCount(excelErrorsForRow.size());
		return productRoundingConfig;
	}

	private String deriveCellTypeAndRetrieveValue(final Row headerRow, final Map<String, Object> excelValue, int column,
			final Cell currentCell, String cellValue) {
		switch (currentCell.getCellType()) {
		case STRING:
			cellValue = currentCell.getStringCellValue();
			excelValue.put(getHeaderColumnValue(headerRow, column), cellValue);
			break;
		case NUMERIC:
			cellValue = NumberToTextConverter.toText(currentCell.getNumericCellValue());
			excelValue.put(getHeaderColumnValue(headerRow, column), cellValue);
			break;
		default:
		}
		return cellValue;
	}

	private String deriveCellTypeAndRetrieveValueExcel(final String headerValue, final Map<String, Object> excelValue,
													   final Cell currentCell, String cellValue) {
		switch (currentCell.getCellType()) {
			case STRING:
				cellValue = currentCell.getStringCellValue();
				excelValue.put(headerValue, cellValue);
				break;
			case NUMERIC:
				cellValue = NumberToTextConverter.toText(currentCell.getNumericCellValue());
				excelValue.put(headerValue, cellValue);
				break;
			default:
		}
		return cellValue;
	}

	private String getHeaderColumnValue(final Row headerRow, final int column) {
		return headerRow.getCell(column).getStringCellValue();
	}

	private String getHeaderColumnValueForCsv(final List<String> headerRow, int column) {
		return headerRow.get(column);
	}

	public ExcelValidation validateEans(final String ean, List<Product> validPrdList, List<Product> productList,
										final boolean isHo, final User user) {
		final ExcelValidation excelData = new ExcelValidation();
		final Set<ExcelError> excelErrors = CollectionUtils.isNotEmpty(excelData.getErrors()) ? excelData.getErrors()
				: new HashSet<>();
		fieldValidation.eanFieldValidation(ean, Constants.BULK_IMPORT_EAN, excelErrors);
		Product product = dataValidation.isValidEanCpt(ean, productList, excelErrors);
		if (null != product) {
			if (!isHo) {
				dataValidation.isValidStoreProduct(product, excelErrors, user);
				dataValidation.isValidPrdListing(product, excelErrors, user);
			}
			dataValidation.isValidPrice(user, product, excelErrors);
			dataValidation.isValidPrdStatus(product, excelErrors);
		}
		excelData.setEan(ean);
		excelData.setErrors(excelErrors);
		excelData.setErrorCount((excelErrors.size()));
		if (excelErrors.isEmpty()) {
			validPrdList.add(product);
		}
		return excelData;
	}

	public String deriveCellType(final Cell currentCell) {
		String cellValue = EMPTY_STR;
		switch (currentCell.getCellType()) {
			case STRING:
				cellValue = currentCell.getStringCellValue();
				break;
			case NUMERIC:
				cellValue = NumberToTextConverter.toText(currentCell.getNumericCellValue());
				break;
			default:
		}
		return cellValue;
	}

}