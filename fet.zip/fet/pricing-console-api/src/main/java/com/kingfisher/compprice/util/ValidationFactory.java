package com.kingfisher.compprice.util;

public interface ValidationFactory {

	StagePriceValidatorRule validation(String type);

	ProductTypeValidationRule typeValidation(String type);

}