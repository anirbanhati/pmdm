package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "StoreAssociations")
@XmlAccessorType(XmlAccessType.FIELD)
public class StoreAssociations {

    @XmlElement(name = "StoreAssociation")
    private List<StoreAssociationInfo> storeAssociationInfoList;

    public List<StoreAssociationInfo> getStoreAssociationList() {
        return storeAssociationInfoList;
    }

    public void setStoreAssociationList(List<StoreAssociationInfo> storeAssociationInfoList) {
        this.storeAssociationInfoList = storeAssociationInfoList;
    }
}
