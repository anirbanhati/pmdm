package com.kingfisher.compprice.dto.outbound;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductCollectionCSVData {

    private String compCode;
    private String compDescription;
    private String ean;
    private double price;
    private String promoFlag;
    private LocalDateTime creationDate;
    private String tenant;
    private String storeCode;
    private String articleCode;
    private String uom;
    private String salesOrg;


}