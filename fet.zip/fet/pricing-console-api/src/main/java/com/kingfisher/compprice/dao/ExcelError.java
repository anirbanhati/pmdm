package com.kingfisher.compprice.dao;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class ExcelError implements Serializable {

    private static final long serialVersionUID = -1388303146070392224L;
    private String code;
    private String desc;
    private String cName;
    private String id;
    private String cValue;

}