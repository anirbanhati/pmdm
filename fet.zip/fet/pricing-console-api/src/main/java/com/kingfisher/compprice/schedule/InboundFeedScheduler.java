package com.kingfisher.compprice.schedule;

import com.kingfisher.compprice.helper.InboundFeedDownloadHelper;
import com.kingfisher.compprice.util.constants.FeedConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;

@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "enabled.scheduler", havingValue = "true")
public class InboundFeedScheduler {

    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketName;

    @Autowired // NOSONAR
    private final InboundFeedDownloadHelper downLoadHelper;


    @Scheduled(cron = "${inboundScheduleCron.inflationFeed}")
    @SchedulerLock(name = "inflationFeed")
    public void consumeInflationInboundFeed() {
        final long startingTime = System.currentTimeMillis();
        log.info("Inflation feed download process started:: {}", startingTime);
        downLoadHelper.processInboundFeedFromBucket(bucketName, FeedConstants.INFLATION_FEED_NAME);
        log.info("Inflation download feed process ended at :: {} ", System.currentTimeMillis() - startingTime);
    }

}