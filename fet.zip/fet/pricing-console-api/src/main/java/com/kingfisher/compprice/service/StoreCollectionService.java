package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.*;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.price.PriceUpdateRequest;
import com.kingfisher.compprice.dao.price.ProductPrice;
import com.kingfisher.compprice.dao.request.CompItemInfo;
import com.kingfisher.compprice.dao.request.ProductInfo;
import com.kingfisher.compprice.dao.request.StoreCollectionPricesRequest;
import com.kingfisher.compprice.dao.request.StoreCollectionUpdatesInfo;
import com.kingfisher.compprice.dao.response.*;
import com.kingfisher.compprice.dao.response.product.ScProductResponse;
import com.kingfisher.compprice.dao.response.search.PriceConversion;
import com.kingfisher.compprice.dao.search.CompItemCriteria;
import com.kingfisher.compprice.dao.search.SearchPaging;
import com.kingfisher.compprice.dao.search.StoreCollectionItemSearchCriteria;
import com.kingfisher.compprice.dto.AssignmentDTO;
import com.kingfisher.compprice.dto.CompetitorStoreDTO;
import com.kingfisher.compprice.dto.ProductDTO;
import com.kingfisher.compprice.enums.CollectionStatus;
import com.kingfisher.compprice.enums.CollectionType;
import com.kingfisher.compprice.enums.RoundingType;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.helper.ExcelDataRead;
import com.kingfisher.compprice.helper.ExcelFileHelper;
import com.kingfisher.compprice.helper.ProductInfoHelper;
import com.kingfisher.compprice.repository.StoreCollectionRepository;
import com.kingfisher.compprice.repository.StoreCollectionSearchRepository;
import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import com.kingfisher.compprice.tools.PriceTools;
import com.kingfisher.compprice.tools.PriceValidation;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.*;
import com.kingfisher.compprice.util.constants.Constants;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.BulkUploadExceptionConstant.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.CollectionListExceptions.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.ProductExceptions.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.UserExceptions.*;
import static com.kingfisher.compprice.util.constants.CacheConstants.*;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class StoreCollectionService {

    @Value("${aws.s3.bucket-name-outbound}")
    private String bucketName;

    @PersistenceContext
    private EntityManager entityManager;
    private final UserService userService;
    private final StoreService storeService;
    private final ExcelDataRead excelDataRead;
    private final StoreCollectionSearchRepository storeCollectionSearchRepository;
    private final StoreCollectionRepository storeCollectionRepository;
    private final BaseValidationFactory prdValidation;
    private final PriceValidation priceValidation;
    private final ProductInfoHelper productInfoHelper;
    private final ExcelFileHelper excelFileHelper;
    private final ProductService productsService;
    private final StoreProductService storeProductService;
    private final ProductListingService productListingService;
    private final AssignmentItemService assignmentItemService;
    private final ClusterPriceService clusterPriceService;
    private final ThirdPartyAPIService thirdPartyAPIService;
    private final CompetitorProductService competitorProductService;
    private final CompetitorPriceService competitorPriceService;
    private final RoundingPriceService roundingPriceService;
    private final PriceUpdateService priceUpdateService;
    private final StorePriceService storePriceService;
    private final StorePriceTools storePriceTools;
    private final ProductTools productTools;
    private final PriceTools priceTools;
    private final HelperService helperService;
    private final S3OutboundLoadService s3OutboundLoadService;
    private final CacheUtils cacheUtils;
    private final LogService logService;


    public Optional<StoreCollection> findSCollectionById(final Long id) {
        StopWatch stopWatch = logService.logStopWatchStart("findStoreCollectionById");

        Optional<StoreCollection> storeCollections = storeCollectionRepository.findById(id);
        logService.logStopWatchStop(stopWatch);
        return storeCollections;
    }

    /**
     * if store is not populated from header, need to set store to user
     * else store will populate from header
     */
    @Transactional
    public void updateStoreCollectionById(final StoreCollectionUpdatesInfo scUpdateInfo, final Long id, final boolean ignoreEx,
                                          final User user, final boolean prdValidationRequired) {
        StoreCollection storeCollection;
        cacheUtils.evictCacheByKey(STORE_COLLECTION_CACHE, id);
        if (!isDifferentStoreCollectionItem(scUpdateInfo, id)) {
            var storeCollectionOptional = findSCollectionById(id);
            if (storeCollectionOptional.isPresent()) {
                storeCollection = storeCollectionOptional.get();
                if (null == user.getStore()) {
                    user.setStore(storeService.getStoreByCode(storeCollection.getStoreCode()));
                }
                updateAssignedUser(scUpdateInfo.getAssignTo(), storeCollection, user);

                updateStoreCollectionStatus(scUpdateInfo, storeCollection);
                updateSCLastModifiedBy(scUpdateInfo.getLastModifiedBy(), storeCollection);
                if (null != scUpdateInfo.getName()) {
                    storeCollection.setName(scUpdateInfo.getName());
                }
                updateCompetitorStore(scUpdateInfo, storeCollection);
                updateProducts(scUpdateInfo, storeCollection, user, prdValidationRequired);
                storeCollectionRepository.save(storeCollection);
                if (prdValidationRequired) {
                    assignmentItemService.removeAssignment(scUpdateInfo, storeCollection);
                }
            }
        } else if (!ignoreEx) {
            throw new DetailsNotFoundException(CI_ITEM_EXIST_APP_EXP, CI_ITEM_EXIST_HTTP_STATUS, CI_ITEM_EXIST_DETAILS,
                    CI_ITEM_EXIST_ID, CI_ITEM_EXIST_POINTER, String.valueOf(id), CI_ITEM_EXIST_TITLE);
        }
    }

    @Transactional
    public StoreCollectionSearchResponse findStoreCollectionBySearchCriteria(final SearchPaging page, final CompItemCriteria criteria) {
        StoreCollectionSearchResponse response = new StoreCollectionSearchResponse();
        var storeCollections = storeCollectionSearchRepository.findFilteredStoreCollectionList(page, criteria);
        var listOfSearchItems = storeCollections.stream().map(result -> {
            StoreCollectionDetails res = new StoreCollectionDetails();
            res.setAssignTo(result.getAssignTo());
            res.setCategoryType(result.getCategoryType());
            res.setCompetitor(new CompetitorResponse(result.getCsName()));
            res.setCreatedBy(result.getCreatedBy());
            res.setCreationTime(result.getCreationTime());
            res.setExpDate(result.getExpDate());
            res.setId(result.getId());
            res.setLastModifiedBy(result.getLastModifiedBy());
            res.setName(result.getName());
            res.setNumOfItems(result.getNumOfItems());
            res.setStartDate(result.getStartDate());
            res.setStatus(result.getStatus());
            res.setStoreCode(result.getStoreCode());
            return res;
        }).collect(Collectors.toSet()).stream().sorted(Comparator.comparing(StoreCollectionDetails::getCreationTime).reversed()).toList();
        response.setSearch(listOfSearchItems);
        response.setTotal(CollectionUtils.isNotEmpty(listOfSearchItems) ? listOfSearchItems.size() : 0);
        return response;
    }

    public Status getStoreCollectionStatus() {
        Status statusResponse = new Status();
        Set<String> statuses = new HashSet<>();
        for (final CollectionStatus status : CollectionStatus.values()) {
            statuses.add(status.toString());
        }
        statusResponse.setcStatus(statuses);
        return statusResponse;
    }

    @Cacheable(value = STORE_COLLECTION_CACHE, key = "{#id}")
    @Transactional
    public StoreCollectionItemResponse findStoreCollectionById(final Long id) {
        var storeCollectionOptional = findSCollectionById(id);
        StoreCollectionItemResponse response = new StoreCollectionItemResponse();
        if (storeCollectionOptional.isPresent()) {
            StoreCollection storeCollection = storeCollectionOptional.get();
            storeCollection.getAssignment().removeIf(assignment -> null == assignment.getProduct());

            response.setId(storeCollection.getId());
            response.setStoreCode(storeCollection.getStoreCode());
            response.setCompetitor(new CompetitorStoreDTO(storeCollection.getCsName(), deriveCompShortName(storeCollection.getClCsCode())));
            response.setName(storeCollection.getName());
            response.setTenant(storeCollection.getTenant());
            response.setAssignTo(storeCollection.getAssignTo());
            response.setLastModifiedBy(storeCollection.getLastModifiedBy());
            response.setCategoryType(storeCollection.getCategoryType());
            response.setStatus(storeCollection.getStatus());
            response.setCreationTime(storeCollection.getCreationTime());
            response.setLastModifiedBy(storeCollection.getLastModifiedBy());
            response.setStartDate(storeCollection.getStartDate());
            response.setEndDate(storeCollection.getEndDate());
            response.setExpDate(storeCollection.getExpDate());
            response.setNumOfItems(storeCollection.getNumOfItems());

            List<AssignmentDTO> listOfAssDTOs = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(storeCollection.getAssignment())) {
                for (Assignment assignment : storeCollection.getAssignment()) {
                    Product product = assignment.getProduct();
                    AssignmentDTO assignmentDTO = getAssignmentDTO(assignment, product);
                    listOfAssDTOs.add(assignmentDTO);
                }
            }
            response.setAssignment(listOfAssDTOs);
        } else {
            throw new DetailsNotFoundException(CI_ITEM_NOT_FOUND_APP_EXP, CI_ITEM_NOT_FOUND_HTTP_STATUS,
                    CI_ITEM_NOT_FOUND_DETAILS, CI_ITEM_NOT_FOUND_ID, CI_ITEM_NOT_FOUND_POINTER, String.valueOf(id),
                    CI_ITEM_NOT_FOUND_TITLE);
        }
        return response;
    }

    private AssignmentDTO getAssignmentDTO(final Assignment assignment, final Product product) {
        AssignmentDTO assignmentDTO = new AssignmentDTO();

        assignmentDTO.setId(assignment.getId());
        assignmentDTO.setProduct(getProductDTO(product));
        assignmentDTO.setCollectedPrice(assignment.getCollectedPrice());
        assignmentDTO.setCollectedPackage(assignment.getCollectedPackage());
        assignmentDTO.setCollectedPkgUnit(assignment.getCollectedPkgUnit());
        assignmentDTO.setCollectedPkgValue(assignment.getCollectedPkgValue());
        assignmentDTO.setTenant(assignment.getTenant());
        assignmentDTO.setMasterDataMissing(assignment.isMasterDataMissing());
        assignmentDTO.setCollectedArticleCode(assignment.getCollectedArticleCode());
        assignmentDTO.setCollectedEan(assignment.getCollectedEan());
        assignmentDTO.setHasPromo(assignment.isHasPromo());
        assignmentDTO.setLinkArticle(assignment.isLinkArticle());
        assignmentDTO.setProductCollectionExtracted(assignment.isProductCollectionExtracted());
        assignmentDTO.setProductAssociationExtracted(assignment.isProductAssociationExtracted());
        assignmentDTO.setProductAssociationExtractedDate(assignment.getProductAssociationExtractedDate());
        assignmentDTO.setProductCollectionExtractedDate(assignment.getProductCollectionExtractedDate());
        assignmentDTO.setNotes(assignment.getNotes());
        assignmentDTO.setPromoInfo(assignment.getPromoInfo());
        assignmentDTO.setCollectedDescription(assignment.getCollectedDescription());

        return assignmentDTO;
    }

    private ProductDTO getProductDTO(final Product product) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(product.getProductId());
        productDTO.setProductCode(product.getProductCode());
        productDTO.setCategory(product.getCategory());
        productDTO.setAppType(product.getAppType());
        productDTO.setPackaging(product.getPackaging());
        productDTO.setBrickCode(product.getBrickCode());
        productDTO.setSubCategory(product.getSubCategory());
        productDTO.setSalesUnit(product.getSalesUnit());
        productDTO.setEan(product.getEan());
        productDTO.setBrickName(product.getBrickName());
        productDTO.setDescription(product.getDescription());
        productDTO.setPkg1(product.getPkg1());
        productDTO.setPkg2(product.getPkg2());
        productDTO.setUnit(product.getUnit());
        productDTO.setMap(product.getMap());
        productDTO.setPriceUom(product.getPriceUom());
        productDTO.setConversion(product.getConversion());
        productDTO.setUom(product.getUom());
        productDTO.setStandardPrice(product.getStandardPrice());
        productDTO.setSalesPrice(product.getSalesPrice());
        productDTO.setEffectivePrice(product.getEffectivePrice());
        productDTO.setCostPrice(product.getCostPrice());
        productDTO.setVatCategory(product.getVatCategory());
        productDTO.setLastUpdated(product.getLastUpdated());
        productDTO.setProductStatus(product.getProductStatus());
        return productDTO;
    }

    @Transactional
    public StoreCollectionPricesResponse getStoreCollectionPriceDetails(final StoreCollectionPricesRequest collectionPriceRequest, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getStoreCollectionPriceDetails");
        StoreCollectionPricesResponse response = new StoreCollectionPricesResponse();
        var assignments = assignmentItemService.getAssignmentsFromSCLists(collectionPriceRequest, user);

        if (CollectionUtils.isNotEmpty(assignments)) {
            var products = productsService.getProductsFromAssignments(assignments);
            var listOfEan = productTools.getListOfEanFromProducts(products);
            var cRounding = roundingPriceService.getRoundingConfigs(products);
            var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, listOfEan, user.getStore());
            var productStoreProductMap = storeProductService.getProductStoreProductMap(products, listOfEan, user);
            var validPrdListingMap = productListingService.validateProductListing(products, listOfEan, user.getStore());
            var eanWithCompNameCompProductMap = competitorProductService.getEanWithCompNameCompProductMap(listOfEan, collectionPriceRequest.getCollectionIds());
            var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
            MasterData masterData = new MasterData(Map.of(), eanStorePriceMap, productStoreProductMap, validPrdListingMap, Map.of(),
                    eanWithCompNameCompProductMap, eanClusterPriceMap, Map.of(), Map.of(), Map.of(), List.of());

            var productAssignmentsMap = assignmentItemService.getProductAssignmentsMap(assignments, user);
            var collectionProductList = prepareCollectionProductResponse(masterData, user, cRounding, productAssignmentsMap);
            response.setCollectionIds(collectionPriceRequest.getCollectionIds());
            response.setStoreCode(collectionPriceRequest.getStoreCode());
            response.setUserId(collectionPriceRequest.getUserId());
            response.setProductList(collectionProductList);
            response.setRollingDays(helperService.getRollingDaysForPVMax());
        }
        logService.logStopWatchStop(stopWatch);
        return response;
    }

    public List<CollectionProduct> prepareCollectionProductResponse(final MasterData masterData, final User user,
                                                                    final CategoryRoundingResponse cRounding,
                                                                    final Map<Product, List<Assignment>> productAssignmentsMap) {
        StopWatch stopWatch = logService.logStopWatchStart("prepareCollectionProductResponse");

        List<CollectionProduct> collectionProductList = new ArrayList<>();
        productAssignmentsMap.forEach((product, assignments) ->
                getCollectedProductResponse(collectionProductList, cRounding, user, product, assignments, masterData));
        logService.logStopWatchStop(stopWatch);
        return collectionProductList;
    }

    @Transactional
    public ByteArrayInputStream prepareFileForStoreCollections(final String id, final User user)
            throws NoDataException, IOException {
        StopWatch stopWatch = logService.logStopWatchStart("prepareFileForStoreCollections");
        var storeCollection = findSCollectionById(Long.parseLong(id));
        if (storeCollection.isPresent()) {
            ByteArrayInputStream file;
            if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
                if (userService.isHeadOfficeUser(user.getUserId())) {
                    file = prepareFileForHoCollectionListDownload(id);
                } else {
                    var listOfStoreCollectionSpreadSheetData = getStoreCollectionsSpreadsheetData(storeCollection.get(), user);
                    file = excelFileHelper.prepareFileDataForCollectionListForBdfr(listOfStoreCollectionSpreadSheetData, storeCollection.get());
                }
            } else {
                var listOfStoreCollectionSpreadSheetData = getStoreCollectionsSpreadsheetData(storeCollection.get(), user);
                file = excelFileHelper.prepareFileDataForCollectionListForCafr(listOfStoreCollectionSpreadSheetData);
            }
            logService.logStopWatchStop(stopWatch);
            return file;
        } else {
            throw new NoDataException();
        }
    }

    public String getStoreCollectionFileName(final String id) {
        return COLLECTION_LIST_FILENAME_PREFIX + id + EXCEL_FORMAT;
    }

    private ByteArrayInputStream prepareFileForHoCollectionListDownload(String id) throws IOException {
        StopWatch stopWatch = logService.logStopWatchStart("prepareFileForHoCollectionListDownload");
        String fileName = findKeyFromStoreCollection(id);
        final ByteArrayInputStream file =
                (ByteArrayInputStream) s3OutboundLoadService.fetchStoreCollectionFileFromS3Bucket(bucketName, fileName)
                        .getInputStream();
        logService.logStopWatchStop(stopWatch);
        return file;
    }

    private List<StoreCollectionSpreadsheetData> getStoreCollectionsSpreadsheetData(final StoreCollection storeCollection, final User user) {
        List<StoreCollectionSpreadsheetData> listOfData = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(storeCollection.getAssignment())) {
            for (final Assignment assignment : storeCollection.getAssignment()) {
                var product = assignment.getProduct();
                var sProd = storeProductService.getStoreProductByProductAndStore(product, user.getStore());
                var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
                var sPrice = storePriceTools.getActiveSPrice(product, sProd, user.getStore());
                var clusterPrice = clusterPriceService.findClusterPriceByClusterId(product, user);
                var stdNPrice = storePriceService.deriveStandardPrice(nPrice, sPrice, user, clusterPrice);
                var comp = storeService.getCompetitorStoreData(storeCollection);
                var cPrd = competitorProductService.getValidCompProds(product, comp);
                var compDesc = null != cPrd ? cPrd.getCompDescription() : EMPTY_STR;
                var data = StoreCollectionSpreadsheetData.builder().
                        category(product.getCategory()).
                        ean(product.getEan()).
                        description(product.getDescription()).
                        uom(product.getUom()).
                        packaging(getPropertyOrDefaultValue(product.getPkg1(), DECIMAL_3_ZEROS)).
                        nationalPrice(stdNPrice).
                        competitorName(null != comp ? comp.getLongName() : null).
                        competitorProductDescription(compDesc).
                        competitorStoreCode(null != comp ? comp.getCode() : null).
                        competitorProductCollectedEAN(assignment.getCollectedEan()).
                        competitorProductCollectedArticleCode(assignment.getCollectedArticleCode()).
                        competitorConversionUnit(product.getConversion()).
                        competitorQuantity(product.getUnit()).//need answer
                                collectedPkgValue(product.getPkg2()).
                        competitorPrice(assignment.getCollectedPrice()).
                        promoInfo(assignment.getPromoInfo()).
                        notes(assignment.getNotes()).
                        build();
                listOfData.add(data);
            }
        }
        return listOfData;
    }

    private boolean isDifferentStoreCollectionItem(final StoreCollectionUpdatesInfo scUpdateInfo, final Long id) {
        boolean isDifferent = false;
        if (null != scUpdateInfo.getName() && null != scUpdateInfo.getLongName()) {
            var storeCollections = storeCollectionRepository
                    .findByNameAndCreationTimeBetween(scUpdateInfo.getName(),
                            LocalDate.now().atStartOfDay(), LocalDate.now().atStartOfDay().plusDays(1).minusSeconds(1));
            storeCollections = storeCollections.stream().filter(sc -> {
                String csLongName = null != sc.getCsName() ? sc.getCsName() : EMPTY_STR;
                return scUpdateInfo.getLongName().equals(csLongName);
            }).toList();
            for (final StoreCollection cl : storeCollections) {
                if (!id.equals(cl.getId())) {
                    isDifferent = true;
                    break;
                }
            }
        }
        return isDifferent;
    }

    private List<Assignment> prepareUpdateAssignments(final StoreCollection storeCollection, final StoreCollectionUpdatesInfo scUpdateInfo,
                                                      final User user, final boolean prdValidationRequired) {
        List<Assignment> assignments = new ArrayList<>();
        boolean isHoUser = userService.isHeadOfficeUser(user.getUserId());

        var listOfEan = scUpdateInfo.getProducts().stream().map(ProductInfo::getEan).toList();
        var eanProductsMap = productsService.getEanProductMap(listOfEan, List.of(), user);
        var productStoreProductMap = storeProductService.getProductStoreProductMap(new ArrayList<>(), listOfEan, user);
        var validPrdListingMap = productListingService.validateProductListing(new ArrayList<>(), listOfEan, user.getStore());
        var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
        MasterData masterData = MasterData.builder().eanProductMap(eanProductsMap).productStoreProductMap(productStoreProductMap)
                .validPrdListingMap(validPrdListingMap).eanClusterPriceMap(eanClusterPriceMap).build();

        scUpdateInfo.getProducts().forEach(info -> prepareAssignments(storeCollection, user, assignments, info, prdValidationRequired, isHoUser, masterData));
        return assignments;
    }

    private void prepareAssignments(final StoreCollection storeCollection, final User user, final List<Assignment> assignments,
                                    final ProductInfo productInfo, final boolean prdValidationRequired, final boolean isHoUser,
                                    final MasterData masterData) {
        if (null != productInfo.getEan()) {
            var product = masterData.getEanProductMap().get(productInfo.getEan());
            if (null != product) {
                var assignment = assignmentItemService.getAssignmentsBySCAndProduct(storeCollection, product).orElse(null);
                if (prdValidationRequired) {
                    prepareAssignmentByPrdListingValidation(user, assignments, productInfo, isHoUser, product, assignment, masterData);
                } else {
                    prepareAssignmentDetails(user, assignments, productInfo, product, assignment);
                }
            } else {
                throw new DetailsNotFoundException(INVALID_EAN_APP_EXP, INVALID_EAN_HTTP_STATUS, INVALID_EAN_DETAILS,
                        INVALID_EAN_ID, INVALID_EAN_POINTER, productInfo.getEan(), INVALID_EAN_TITLE);
            }
        } else {
            Assignment newAssignment = new Assignment();
            assignmentItemService.saveProductDetails(productInfo, null, newAssignment, user);
            assignments.add(newAssignment);
        }
    }

    private void prepareAssignmentByPrdListingValidation(final User user, final List<Assignment> assignments, final ProductInfo productInfo,
                                                         final boolean isHoUser, final Product product, final Assignment assignment,
                                                         final MasterData masterData) {
        StoreProduct storeProduct = new StoreProduct();
        boolean isValidPrdList = true;
        if (!isHoUser) {
            storeProduct = masterData.getProductStoreProductMap().get(product);
            isValidPrdList = null != storeProduct && productTools.filterNonEligibleProductByStatus(product) &&
                    masterData.getValidPrdListingMap().getOrDefault(productInfo.getEan(), true);
        }
        if (null != storeProduct && isValidPrdList) {
            prepareAssignmentDetails(user, assignments, productInfo, product, assignment);
        }
    }

    private void prepareAssignmentDetails(final User user, final List<Assignment> assignments, final ProductInfo productInfo,
                                          final Product product, final Assignment assignment) {
        if (null != assignment) {
            assignmentItemService.saveProductDetails(productInfo, product, assignment, user);
            assignments.add(assignment);
        } else {
            Assignment newAssignment = new Assignment();
            assignmentItemService.saveProductDetails(productInfo, product, newAssignment, user);
            assignments.add(newAssignment);
        }
    }

    /**
     * Create collection list: Comp Store will be null if list is created by HO users
     * phase 2 and CompStore is mandatory when list is created by store user
     *
     * @param compItemInfo Collection list input
     * @param user         user
     * @return created collection list
     */
    @Transactional
    public String saveStoreCollectionItems(final CompItemInfo compItemInfo, final User user) {
        List<StoreCollection> storeCollections = new ArrayList<>();
        var compStoreNameList = compItemInfo.getCompStoreLongNames();
        if (CollectionUtils.isNotEmpty(compStoreNameList)) {
            List<StoreCollection> scListByNameAndCreationTime = storeCollectionRepository
                    .findByNameInAndCreationTimeBetweenAndCsNameIn(competitorPriceService.getScNamesBySector(compItemInfo, user),
                            LocalDate.now().atStartOfDay(), LocalDate.now().atStartOfDay().plusDays(1).minusSeconds(1), compStoreNameList);

            if (CollectionUtils.isEmpty(scListByNameAndCreationTime)) {
                for (final String competitorStoreName : compStoreNameList) {
                    final CompetitorStore competitorStore = storeService.getCsByStoreCodeAndLongName(competitorStoreName,
                            compItemInfo.getStoreId());
                    saveProdInStoreCollItems(compItemInfo, storeCollections, competitorStore, CollectionType.STORE.type(), user,
                            null);
                }
            } else {
                throw new DetailsNotFoundException(CI_ITEM_EXIST_APP_EXP, CI_ITEM_EXIST_HTTP_STATUS,
                        CI_ITEM_EXIST_DETAILS, CI_ITEM_EXIST_ID, CI_ITEM_EXIST_POINTER, compItemInfo.getName(),
                        CI_ITEM_EXIST_TITLE);
            }
        } else if (userService.isHeadOfficeUser(user.getUserId())) {
            createStoreCollectionForHOUsers(compItemInfo, storeCollections, user);
        }
        if (CollectionUtils.isNotEmpty(storeCollections)) {
            storeCollectionRepository.saveAllAndFlush(storeCollections);
        }
        return STATUS_OK;
    }

    private void createStoreCollectionForHOUsers(final CompItemInfo storeCollectionReq, final List<StoreCollection> storeCollections,
                                                 final User user) {
        if (CollectionUtils.isNotEmpty(storeCollectionReq.getStoreCodes())) {
            storeCollectionReq.getStoreCodes()
                    .forEach(storeCode -> createStoreCollectionForHO(storeCollectionReq, storeCollections, user, storeCode));
        } else {
            createStoreCollectionForHO(storeCollectionReq, storeCollections, user, null);
        }
    }

    private void createStoreCollectionForHO(final CompItemInfo storeCollectionReq, final List<StoreCollection> storeCollections,
                                            final User user, final String storeCode) {
        List<StoreCollection> clList = storeCollectionRepository.findByNameAndCreationTimeBetween(
                storeCollectionReq.getName(), LocalDate.now().atStartOfDay(),
                LocalDate.now().atStartOfDay().plusDays(1).minusSeconds(1));
        if (CollectionUtils.isEmpty(clList)) {
            saveProdInStoreCollItems(storeCollectionReq, storeCollections, null, CollectionType.CENTER.type(), user, storeCode);
        } else {
            throw new DetailsNotFoundException(CI_ITEM_EXIST_APP_EXP, CI_ITEM_EXIST_HTTP_STATUS,
                    CI_ITEM_EXIST_DETAILS, CI_ITEM_EXIST_ID, CI_ITEM_EXIST_POINTER, storeCollectionReq.getName(),
                    CI_ITEM_EXIST_TITLE);
        }
    }

    private void saveProdInStoreCollItems(final CompItemInfo storeCollectionReq, final List<StoreCollection> storeCollections,
                                          final CompetitorStore competitorStore, final String type, final User user, final String storeCode) {
        Map<String, List<Assignment>> scNameAssignmentsMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(storeCollectionReq.getProductList()) || CollectionUtils.isNotEmpty(storeCollectionReq.getProducts())) {
            scNameAssignmentsMap = createAssignmentItems(storeCollectionReq.getProducts(), storeCollectionReq, user);
        }
        if (userService.isUserExist(storeCollectionReq.getCreatedBy())) {
            saveStoreCollection(storeCollectionReq, competitorStore, scNameAssignmentsMap, type, storeCode, user, storeCollections);
        } else {
            throw new DetailsNotFoundException(USER_NOT_FOUND_APP_EXP, USER_NOT_FOUND_HTTP_STATUS,
                    USER_NOT_FOUND_DETAILS, USER_NOT_FOUND_ID, USER_NOT_FOUND_POINTER, storeCollectionReq.getCreatedBy(),
                    USER_NOT_FOUND_TITLE);
        }
    }

    private void saveStoreCollection(final CompItemInfo storeCollectionReq, final CompetitorStore competitorStore,
                                     final Map<String, List<Assignment>> scNameAssignmentsMap, final String cType,
                                     final String storeCode, final User user, List<StoreCollection> storeCollections) {
        if (MapUtils.isNotEmpty(scNameAssignmentsMap)) {
            scNameAssignmentsMap.forEach((scName, assignments) -> {
                StoreCollection scItem = new StoreCollection();
                if (CollectionUtils.isNotEmpty(assignments)) {
                    scItem.setAssignment(assignments);
                }
                scItem.setName(scName);
                scItem.setCategoryType(cType);
                scItem.setTenant(user.getTenant());
                scItem.setStatus(CollectionStatus.Created);
                scItem.setCreationTime(LocalDateTime.now());
                scItem.setLastModifiedTime(LocalDateTime.now());
                scItem.setCreatedBy(storeCollectionReq.getCreatedBy());
                scItem.setLastModifiedBy(storeCollectionReq.getCreatedBy());
                scItem.setHoClName(storeCollectionReq.getHoClName());
                scItem.setHoClId(storeCollectionReq.getHoClId());
                setHoStoreClone(storeCollectionReq, storeCollections);
                scItem.setStoreCode(null != storeCode ? storeCode : storeCollectionReq.getStoreId());
                if (null != competitorStore) {
                    scItem.setClCsCode(competitorStore.getCode());
                    scItem.setCsName(competitorStore.getLongName());
                }
                scItem.setExpDate(null != storeCollectionReq.getExpDate()
                        ? DateUtils.getFormattedDateWithFormatter(storeCollectionReq.getExpDate(), DateUtils.DATE_FORMAT_WITH_TIME)
                        : LocalDateTime.now().plusDays(90));
                storeCollections.add(scItem);
            });
        }
    }

    private void setHoStoreClone(CompItemInfo storeCollectionReq, List<StoreCollection> storeCollections) {
        if (null != storeCollectionReq.getHoClId()) {
            StoreCollection hoCollection = storeCollectionRepository.findById(storeCollectionReq.getHoClId()).orElse(null);
            if (null != hoCollection) {
                hoCollection.setHasStoreClone(true);
                hoCollection.setLastModifiedTime(LocalDateTime.now());
                storeCollections.add(hoCollection);
            }
        }
    }

    private void getCollectedProductResponse(final List<CollectionProduct> collectionProductList, final CategoryRoundingResponse cRounding,
                                             final User user, final Product product, final List<Assignment> assignments, final MasterData masterData) {
        StopWatch stopWatch = logService.logStopWatchStart("getCollectedProductResponse");

        CollectionProduct collectionProduct = new CollectionProduct();
        collectionProduct.setProduct(prepareScProductResponse(product, cRounding, user, masterData));
        collectionProduct.setAssignments(getCollectedItemsValidation(product, assignments, masterData));
        collectionProduct.setChainId(productTools.getChainIdFromProduct(product));
        collectionProductList.add(collectionProduct);
        logService.logStopWatchStop(stopWatch);
    }

    public ScProductResponse prepareScProductResponse(final Product product, final CategoryRoundingResponse cRounding,
                                                      final User user, final MasterData masterData) {
        StopWatch stopWatch = logService.logStopWatchStart("prepareScProductResponse");
        ScProductResponse scProductResponse = new ScProductResponse();
        scProductResponse.setEan(product.getEan());
        scProductResponse.setProductCode(product.getProductCode());
        scProductResponse.setSalesUnit(product.getSalesUnit());
        scProductResponse.setPkg2(product.getPkg2());
        scProductResponse.setDescription(product.getDescription());
        scProductResponse.setPackaging(product.getPackaging());

        var nPrice = storePriceService.findActiveNationalPriceFromProduct(product, user.getTenant());
        var storePrice = masterData.getEanStorePriceMap().get(product.getEan());
        var clusterPrice = masterData.getEanClusterPriceMap().get(product.getEan());
        var storeProduct = masterData.getProductStoreProductMap().getOrDefault(product, new StoreProduct());
        scProductResponse.setValidPrd(productTools.filterNonEligibleProductByStatus(product) && masterData.getValidPrdListingMap().getOrDefault(product.getEan(), true));
        scProductResponse.setPConversion(helperService.getConversionDetails(product, cRounding));
        scProductResponse.setCatType(cRounding.getRType().toString());
        scProductResponse.setStandardPrice(competitorPriceService.getStdPriceBasedOnRounding(storePrice, nPrice, product, cRounding, user.getTenant(), clusterPrice));
        scProductResponse.setPrdType(null != storeProduct.getPrdType() ? storeProduct.getPrdType().toString() : EMPTY_STR);
        scProductResponse.setShowDatePicker(storeProductService.isShowDatePicker(scProductResponse.getPrdType(), user));
        scProductResponse.setSPrice(storePrice);
        scProductResponse.setNPrice(nPrice);
        scProductResponse.setConversion(product.getConversion());
        scProductResponse.setPkg1(StringUtils.isNoneEmpty(product.getPkg1()) ? product.getPkg1() : DECIMAL_3_ZEROS);
        scProductResponse.setUnit(UOM_EA.equalsIgnoreCase(product.getUom()) ? UOM_PC : product.getUom());

        logService.logStopWatchStop(stopWatch);
        return scProductResponse;
    }

    private List<CollectionAssginment> getCollectedItemsValidation(final Product product, final List<Assignment> assignments, final MasterData masterData) {
        StopWatch stopWatch = logService.logStopWatchStart("getCollectedItemsValidation");
        List<CollectionAssginment> responseAssignments = new ArrayList<>();
        assignmentItemService.prepareCollectionAssignments(product, responseAssignments, assignments, masterData);
        logService.logStopWatchStop(stopWatch);
        return responseAssignments;
    }

    private void updateAssignedUser(final String userId, final StoreCollection storeCollection, final User user) {
        if (null != userId) {
            validateIfUpdateAllowedForCl(storeCollection);
            if ("None".equals(userId)) {
                storeCollection.setAssignTo(null);
                storeCollection.setStatus(CollectionStatus.Created);
                storeCollection.setLastModifiedTime(LocalDateTime.now());
            } else if (null != user && !user.getUserId().equals(storeCollection.getAssignTo())
                    && user.getStore().getStoreCode().equals(storeCollection.getStoreCode())) {
                storeCollection.setAssignTo(userId);
                storeCollection.setStatus(CollectionStatus.Assigned);
                storeCollection.setLastModifiedTime(LocalDateTime.now());
            }
        }
    }

    private void updateStoreCollectionStatus(final StoreCollectionUpdatesInfo scUpdateInfo, final StoreCollection storeCollection) {
        validateIfUpdateAllowedForCl(storeCollection);
        Optional.ofNullable(scUpdateInfo.getStatus()).ifPresent(status -> {
            storeCollection.setStatus(CollectionStatus.valueOf(status));
            storeCollection.setLastModifiedTime(LocalDateTime.now());
            if (CollectionStatus.Reported.toString().equals(status)) {
                storeCollection.setCollectedDate(LocalDateTime.now());
            }
        });
    }

    private void updateCompetitorStore(final StoreCollectionUpdatesInfo scUpdateInfo, final StoreCollection storeCollection) {
        validateIfUpdateAllowedForCl(storeCollection);
        if (null != scUpdateInfo.getLongName()) {
            var compStore = storeService.getCsByStoreCodeAndLongName(scUpdateInfo.getLongName(),
                    storeCollection.getStoreCode());
            if (null != compStore) {
                storeCollection.setClCsCode(compStore.getCode());
                storeCollection.setCsName(compStore.getLongName());
            }
        }
    }

    @Transactional
    public void updateStoreCollections(final Set<StoreCollectionUpdatesInfo> scUpdateInformation, final User user,
                                       final boolean prdValidationRequired) {
        for (final StoreCollectionUpdatesInfo scUpdateInfo : scUpdateInformation) {
            if (null != scUpdateInfo.getCollectionId()) {
                updateStoreCollectionById(scUpdateInfo, scUpdateInfo.getCollectionId(), true, user, prdValidationRequired);
            } else {
                throw new DetailsNotFoundException(CI_ITEM_ID_MISSING_APP_EXP, CI_ITEM_ID_MISSING_HTTP_STATUS,
                        CI_ITEM_ID_MISSING_DETAILS, CI_ITEM_ID_MISSING_ID, CI_ITEM_ID_MISSING_POINTER, EMPTY_STR,
                        CI_ITEM_ID_MISSING_TITLE);
            }
        }
    }

    private void updateSCLastModifiedBy(final String userId, final StoreCollection storeCollection) {
        validateIfUpdateAllowedForCl(storeCollection);
        if (null != userId && userService.isUserExist(userId)) {
            storeCollection.setLastModifiedBy(userId);
        }
    }

    private void updatePriceIfChainedProducts(final List<Product> productList, final Set<ProductPrice> prdPrice) {
        StopWatch stopWatch = logService.logStopWatchStart("updatePriceIfChainedProducts");

        Map<String, Double> productPricesWithChain = new HashMap<>();
        Map<String, String> chainIdForEanMap = productsService.getChainIdFromProductPrice(productList);
        getChainIdAndPriceMap(prdPrice, productPricesWithChain, chainIdForEanMap);

        log.info("::: eanWithChainIdMap => {}, chainIdWithPriceMap => {}, isEmpty => {}", chainIdForEanMap, productPricesWithChain, productPricesWithChain.isEmpty());
        setPricesForProducts(prdPrice, productPricesWithChain, chainIdForEanMap);
        logService.logStopWatchStop(stopWatch);
    }

    private void setPricesForProducts(Set<ProductPrice> prdPrice, Map<String, Double> productPricesWithChain, Map<String, String> chainIdForEanMap) {

        prdPrice.stream().filter(price -> StringUtils.isNotEmpty(chainIdForEanMap.get(price.getEan()))).forEach(price -> {
            if (price.isChainRequired() && StringUtils.isNotEmpty(chainIdForEanMap.get(price.getEan()))) {
                price.setPrice(productPricesWithChain.get(chainIdForEanMap.get(price.getEan())));
            } else {
                price.setPrice(!productPricesWithChain.isEmpty() && (null != productPricesWithChain.get(chainIdForEanMap.get(price.getEan())))
                        && (productPricesWithChain.get(chainIdForEanMap.get(price.getEan()))) < price.getPrice() ?
                        productPricesWithChain.get(chainIdForEanMap.get(price.getEan())) : price.getPrice());
            }
        });
    }

    private void getChainIdAndPriceMap(Set<ProductPrice> prdPrice, Map<String, Double> productPricesWithChain, Map<String, String> chainIdForEanMap) {
        prdPrice.stream().filter(price -> price.isChainRequired() &&
                StringUtils.isNotEmpty(chainIdForEanMap.get(price.getEan()))).forEach(price -> {
            if (productPricesWithChain.containsKey(chainIdForEanMap.get(price.getEan()))) {
                if (price.getPrice() != 0.0 && checkProductPriceWithChain(productPricesWithChain, chainIdForEanMap, price)) {
                    productPricesWithChain.put(chainIdForEanMap.get(price.getEan()), price.getPrice());
                }
            } else {
                productPricesWithChain.put(chainIdForEanMap.get(price.getEan()), price.getPrice());
            }
        });
    }

    private static boolean checkProductPriceWithChain(final Map<String, Double> productPricesWithChain, final Map<String, String> chainIdForEanMap, final ProductPrice price) {
        return (productPricesWithChain.get(chainIdForEanMap.get(price.getEan())) == 0.0) ||
                (productPricesWithChain.get(chainIdForEanMap.get(price.getEan())) > price.getPrice());
    }

    private void updateProducts(final StoreCollectionUpdatesInfo scUpdateInfo, final StoreCollection storeCollection,
                                final User user, final boolean prdValidationRequired) {
        if (null != scUpdateInfo.getProducts()) {
            List<Assignment> assignments = new ArrayList<>();
            if (!scUpdateInfo.getProducts().isEmpty()) {
                assignments = prepareUpdateAssignments(storeCollection, scUpdateInfo, user, prdValidationRequired);
            }
            storeCollection.setAssignment(assignments);
        }
    }

    @Transactional
    public List<StoreCollectionItemResponse> findScItemsByStatusAndUser(final CollectionStatus status, final String userId) {
        var storeCollections = storeCollectionRepository.findByStatusAndAssignToIgnoreCaseOrderByCreationTimeDesc(status, userId);
        log.info("findScItemsByStatusAndUser --> storeCollections.size::{}", storeCollections.size());
        var user = userService.findUserByUserId(userId);
        
        List<StoreCollectionItemResponse> responses = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(storeCollections)) {
            for (final StoreCollection sc : storeCollections) {
                user.setStore(storeService.getStoreByCode(sc.getStoreCode()));
                prepareStoreCollectionItemResponses(sc, user, responses);
            }
        }
        return responses;
    }

    private void prepareStoreCollectionItemResponses(final StoreCollection collection, final User user,
                                                     List<StoreCollectionItemResponse> responses) {
        var compShortName = deriveCompShortName(collection.getClCsCode());
        List<AssignmentDTO> assignments = new ArrayList<>();
        collection.getAssignment().stream()
                .filter(Objects::nonNull)
                .filter(assignment -> Objects.nonNull(assignment.getProduct()))
                .forEach(assignment -> {
                    ProductDTO productDTO = updateProductDTO(assignment.getProduct(), assignment, compShortName, user);
                    assignments.add(updateAssignmentDTO(assignment, productDTO));
                });

        responses.add(updateStoreCollectionItemResponse(collection, compShortName, assignments));
    }

    private ProductDTO updateProductDTO(final Product product, final Assignment assignment, final String compShortName,
                                        final User user) {
        CategoryRoundingResponse cRounding = new CategoryRoundingResponse();
        helperService.getConversionDetails(product, cRounding);

        ProductDTO productDTO = ProductDTO.builder().ean(product.getEan())
                .pkg1(product.getPkg1()).pkg2(product.getPkg2())
                .map(product.getMap()).conversion(product.getConversion())
                .vatCategory(product.getVatCategory())
                .lastUpdated(product.getLastUpdated())
                .productStatus(product.getProductStatus())
                .productCode(product.getProductCode())
                .category(product.getCategory())
                .brickCode(product.getBrickCode())
                .subCategory(product.getSubCategory())
                .salesUnit(product.getSalesUnit())
                .brickName(product.getBrickName())
                .description(product.getDescription())
                .comProduct(competitorProductService.filterCompProductByCompName(assignment, compShortName)).build();
        productInfoHelper.updateProductDetailsLatest(cRounding, user, product, productDTO);
        return productDTO;
    }

    private AssignmentDTO updateAssignmentDTO(final Assignment assignment, final ProductDTO productDTO) {
        return AssignmentDTO.builder()
                .id(assignment.getId()).product(productDTO).masterDataMissing(assignment.isMasterDataMissing())
                .collectedPrice(assignment.getCollectedPrice()).tenant(assignment.getTenant())
                .hasPromo(assignment.isHasPromo()).linkArticle(assignment.isLinkArticle())
                .productCollectionExtracted(assignment.isProductCollectionExtracted())
                .productAssociationExtracted(assignment.isProductAssociationExtracted()).build();
    }

    private StoreCollectionItemResponse updateStoreCollectionItemResponse(final StoreCollection sc, final String compShortName,
                                                                          final List<AssignmentDTO> assignments) {
        StoreCollectionItemResponse response = new StoreCollectionItemResponse();
        response.setId(sc.getId());
        response.setName(sc.getName());
        response.setCompetitor(new CompetitorStoreDTO(sc.getCsName(), compShortName));
        response.setStoreCode(sc.getStoreCode());
        response.setCreatedBy(sc.getCreatedBy());
        response.setTenant(sc.getTenant());
        response.setAssignTo(sc.getAssignTo());
        response.setLastModifiedBy(sc.getLastModifiedBy());
        response.setCategoryType(sc.getCategoryType());
        response.setStatus(sc.getStatus());
        response.setCreationTime(sc.getCreationTime());
        response.setLastModifiedTime(sc.getLastModifiedTime());
        response.setExpDate(sc.getExpDate());
        response.setNumOfItems(sc.getNumOfItems());
        response.setAssignment(assignments);
        return response;
    }

    private String deriveCompShortName(final String compCode) {
        return StringUtils.isNotEmpty(compCode) && compCode.contains(UNDER_SCORE) ? compCode.split(UNDER_SCORE)[1] : EMPTY_STR;
    }

    private void validateIfUpdateAllowedForCl(final StoreCollection storeCollection) {
        if (CollectionType.CENTER.type().equals(storeCollection.getCategoryType())) {
            throw new DetailsNotFoundException(CI_ITEM_UPDATE_NOT_PERMITTED_EXP,
                    CI_ITEM_UPDATE_NOT_PERMITTED_HTTP_STATUS, CI_ITEM_UPDATE_NOT_PERMITTED_DETAILS,
                    CI_ITEM_UPDATE_NOT_PERMITTED_ID, CI_ITEM_UPDATE_NOT_PERMITTED_POINTER,
                    String.valueOf(storeCollection.getId()), CI_ITEM_UPDATE_NOT_PERMITTED_TITLE);
        }
    }

    private Map<String, List<Assignment>> createAssignmentItems(final List<ProductInfo> productInfoList, final CompItemInfo collListInfo,
                                                                final User user) {
        List<Assignment> listOfAssignments = new ArrayList<>();
        Map<String, List<Assignment>> scNameWithAssignmentsMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(collListInfo.getProductList())) {
            // CPT Import CollectionList
            assignmentItemService.setAssignmentDetailsForStoreCollection(collListInfo.getProductList(), listOfAssignments, user);
            scNameWithAssignmentsMap.put(collListInfo.getName(), listOfAssignments);
        } else {
            // Manual CollectionList creation/Clone
            boolean isHoUser = userService.isHeadOfficeUser(user.getUserId());
            var listOfValidEan = isHoUser ? createAssignmentItemsForHo(productInfoList) :
                    createAssignmentItemsForStore(productInfoList, user);
            var productList = productTools.getProductsFromEans(listOfValidEan, user);

            scNameWithAssignmentsMap = assignmentItemService.getSectorScNameWithAssignmentsMap(collListInfo, user, listOfAssignments, productList);
        }
        return scNameWithAssignmentsMap;
    }

    private List<String> createAssignmentItemsForStore(final List<ProductInfo> productInfoList, final User user) {
        List<String> listOfValidEans = null;
        List<String> listOfInputEan = productInfoList.stream().map(ProductInfo::getEan).toList();
        var validPrdListingMap = productListingService.validateProductListing(new ArrayList<>(), listOfInputEan, user.getStore());
        if (MapUtils.isNotEmpty(validPrdListingMap)) {
            listOfValidEans = validPrdListingMap.entrySet().stream()
                    .filter(prdListMap -> Boolean.TRUE.equals(prdListMap.getValue()))
                    .map(Map.Entry::getKey)
                    .toList();
        }
        return listOfValidEans;
    }

    private List<String> createAssignmentItemsForHo(List<ProductInfo> productInfoList) {
        return productInfoList.stream().map(ProductInfo::getEan).toList();
    }

    @Transactional
    public ForeignProductSearchResponse searchForeignProducts(final StoreCollectionItemSearchCriteria filters) {
        return ForeignProductSearchResponse.builder().searchResponse(searchForeignProductsByFilters(filters)).build();
    }

    private Page<ForeignProduct> searchForeignProductsByFilters(final StoreCollectionItemSearchCriteria criteria) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Assignment> criteriaQuery = criteriaBuilder.createQuery(Assignment.class);

        final Root<Assignment> assignmentRoot = criteriaQuery.from(Assignment.class);
        final Subquery<StoreCollection> subQuery = criteriaQuery.subquery(StoreCollection.class);
        final Root<StoreCollection> clRoot = subQuery.from(StoreCollection.class);

        criteriaQuery.select(assignmentRoot).where(prepareFilter(criteria, assignmentRoot, subQuery, clRoot, criteriaBuilder));

        final long count = getResultCount(criteria, criteriaBuilder);

        final SearchPaging page = criteria.getPaging() != null ? criteria.getPaging() : new SearchPaging();
        productTools.setPageSizeAndNum(page, count);
        int pNum = page.getPageNum();
        int pSize = page.getPageSize();
        final TypedQuery<Assignment> typedQuery = entityManager.createQuery(criteriaQuery);
        typedQuery.setFirstResult((pNum - 1) * pSize);
        typedQuery.setMaxResults(pSize);
        Set<Assignment> assignments = typedQuery.getResultStream().collect(Collectors.toSet());
        final List<ForeignProduct> products = mapRepoItemToForeignProductResponse(assignments);

        return new PageImpl<>(products, PageRequest.of(pNum - 1, pSize, Sort.by(page.getSortDirection(), page.getSortBy())), count);
    }

    private Predicate prepareFilter(final StoreCollectionItemSearchCriteria criteria, final Root<Assignment> assignmentRoot,
                                    final Subquery<StoreCollection> subQuery, final Root<StoreCollection> clRoot, CriteriaBuilder criteriaBuilder) {

        final List<Predicate> listOfSubFilters = storeCollectionSearchRepository.prepareFilterList(criteria, clRoot, criteriaBuilder);
        final List<Predicate> listOfFilter = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(listOfSubFilters)) {
            subQuery.select(clRoot).distinct(true).where(criteriaBuilder.and(listOfSubFilters.toArray(new Predicate[0])));
            listOfFilter.add(criteriaBuilder.in(assignmentRoot.get(Constants.STORE_COLLECTION)).value(subQuery));
        }
        listOfFilter.add(criteriaBuilder.equal(assignmentRoot.get(Constants.MASTER_DATA_MISSING), true));
        return criteriaBuilder.and(listOfFilter.toArray(new Predicate[0]));
    }

    private long getResultCount(final StoreCollectionItemSearchCriteria criteria, CriteriaBuilder criteriaBuilder) {
        final CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        final Root<Assignment> assignmentRoot = criteriaQuery.from(Assignment.class);
        final Subquery<StoreCollection> subQuery = criteriaQuery.subquery(StoreCollection.class);
        final Root<StoreCollection> clRoot = subQuery.from(StoreCollection.class);
        criteriaQuery.select(criteriaBuilder.count(assignmentRoot)).where(prepareFilter(criteria, assignmentRoot, subQuery, clRoot, criteriaBuilder));
        return entityManager.createQuery(criteriaQuery).getSingleResult();
    }

    private List<ForeignProduct> mapRepoItemToForeignProductResponse(final Set<Assignment> assignments) {
        return assignments.stream().map(
                        item -> {
                            CompetitorStore comp = storeService.getCompetitorStoreData(item.getStoreCollection());
                            return ForeignProduct.builder()
                                    .cArticleCode(item.getCollectedArticleCode())
                                    .cEan(item.getCollectedEan())
                                    .cPrice(item.getCollectedPrice())
                                    .cListId(item.getStoreCollection().getId())
                                    .cListName(item.getStoreCollection().getName())
                                    .storeCode(item.getStoreCollection().getStoreCode())
                                    .csCode(null != comp ? comp.getCode() : null)
                                    .csName(null != comp ? comp.getName() : null)
                                    .tenant(item.getStoreCollection().getTenant())
                                    .assignedTo(item.getStoreCollection().getAssignTo())
                                    .createdBy(item.getStoreCollection().getCreatedBy())
                                    .creationTime(item.getStoreCollection().getCreationTime())
                                    .cDesc(item.getCollectedDescription())
                                    .cUOM(item.getCollectedPackage())
                                    .build();
                        })
                .toList();
    }

    @Transactional
    public EanListResponse importBulkUploadEanList(final InputStream fileStream, CompItemInfo collListInfo, User user) throws IOException {
        final EanListResponse response = new EanListResponse();
        final XSSFWorkbook workBook = SpreadsheetUtils.getInputStreamAsWorkBook(fileStream);
        final XSSFSheet sheet = workBook.getSheetAt(0);
        ExcelDataDetails dataDetails = excelDataRead.readSingleColumnByHeader(workBook, sheet, BULK_IMPORT_EAN, collListInfo, user);
        final List<ExcelValidation> excelData = dataDetails.getExcelData();
        final List<ExcelValidation> bulkUploadErrors = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(excelData)) {
            if (dataDetails.isHasError()) {
                excelData.stream().filter(ex -> ex.getErrorCount() > 0).forEach(bulkUploadErrors::add);
                response.setEanListErrors(bulkUploadErrors);
            } else {
                final long count = collListInfo.getProductList().size();
                saveStoreCollectionItems(collListInfo, user);
                log.info("Bulk upload::Total count: {}", count);
                response.setSuccessMsg("Ean list has successfully updated for " + count + " products");
            }
        } else {
            final Set<ExcelError> excelErrors = new HashSet<>();
            ExcelDataValidation.setErrorDetail(excelErrors, EMPTY_STR, BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_STATUS,
                    BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET, BULK_UPLOAD_DATA_VALIDATION_EMPTY_SHEET_ID, EMPTY_STR);
            final ExcelValidation emptyRowError = new ExcelValidation();
            emptyRowError.setErrors(excelErrors);
            bulkUploadErrors.add(emptyRowError);
            response.setEanListErrors(bulkUploadErrors);
        }
        return response;
    }

    public CompItemInfo prepareStoreCollectionInfo(String compStoreLongNames, String stores, String name, String expDate, User user) {
        CompItemInfo compItemInfo = new CompItemInfo();
        compItemInfo.setName(name);
        if (userService.isHeadOfficeUser(user.getUserId())) {
            compItemInfo.setStoreCodes(Arrays.stream(stores.split(",")).toList());
            compItemInfo.setExpDate(expDate);
            compItemInfo.setCreatedBy(user.getUserId());
        } else {
            compItemInfo.setCompStoreLongNames(Arrays.stream(compStoreLongNames.split(",")).toList());
            compItemInfo.setStoreId(user.getStore().getStoreCode());
            compItemInfo.setCreatedBy(user.getUserId());
        }
        return compItemInfo;
    }

    @Transactional
    public StoreCollectionPricesResponse getChainedProdsWithLowestPrice(PriceUpdateRequest pUpdateInfo, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("getChainedProdsWithLowestPrice");
        StoreCollectionPricesResponse priceResponses = new StoreCollectionPricesResponse();
        List<CollectionProduct> cProducts = new ArrayList<>();

        final Set<ProductPrice> prdPrice = pUpdateInfo.getPrdPrice();
        List<String> eanList = prdPrice.stream().map(ProductPrice::getEan).toList();
        List<Product> productList = productTools.findProductByListOfEanAndType(eanList, user);
        var eanProductMapWithoutChained = productsService.getEanProductMap(eanList, productList, user);

        var productsList = productsService.getChainedProductsList(productList);
        var listOfEan = productTools.getListOfEanFromProducts(productsList);
        var productStoreProductMap = storeProductService.getProductStoreProductMap(productsList, listOfEan, user);
        var validPrdListingMap = productListingService.validateProductListing(productsList, listOfEan, user.getStore());
        var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
        var productPriceUpdateMap = priceUpdateService.getProductPriceUpdateMap(productsList, user);
        var eanCostPriceMap = thirdPartyAPIService.getCostPriceDetails(productsList, user, true);

        MasterData masterData = new MasterData(Map.of(), Map.of(), productStoreProductMap, validPrdListingMap, Map.of(),
                Map.of(), eanClusterPriceMap, productPriceUpdateMap, Map.of(), eanCostPriceMap, productsList);

        //convert convertedPrice into PriceUom
        priceTools.getSuPriceFromCollectedPrice(prdPrice, eanClusterPriceMap, eanProductMapWithoutChained, user);
        //Set lowest price for collected chained articles
        updatePriceIfChainedProducts(productList, prdPrice);

        if (null != user.getStore()) {
            for (final ProductPrice price : prdPrice) {
                final String ean = price.getEan();
                Product product = eanProductMapWithoutChained.getOrDefault(ean, new Product());

                log.info("::::: Updating Price of Article ::::: EAN - {}", product.getEan());
                setPriceResponse(cProducts, price, product, prdPrice, masterData, user);
                setChainedProductDetails(user, cProducts, prdPrice, productList, price, masterData, product);
            }
            priceResponses.setCollectionIds(pUpdateInfo.getClIds());
            priceResponses.setUserId(user.getUserId());
            priceResponses.setStoreCode(user.getStore().getStoreCode());
            cProducts.sort(Comparator.comparing((CollectionProduct cp) -> Optional.ofNullable(cp.getChainId()).orElse(EMPTY_STR))
                    .thenComparing(cp -> cp.getProduct().getDescription()));
            priceResponses.setProductList(cProducts);
            priceResponses.setRollingDays(helperService.getRollingDaysForPVMax());
        }
        logService.logStopWatchStop(stopWatch);
        return priceResponses;
    }

    private void setChainedProductDetails(final User user, final List<CollectionProduct> cProducts, final Set<ProductPrice> prdPrice,
                                          final List<Product> productList, final ProductPrice price, final MasterData masterData,
                                          final Product product) {
        StopWatch stopWatch = logService.logStopWatchStart("setChainedProductDetails");
        if (price.isChainRequired()) {
            String chainId = productTools.getChainIdFromProduct(product);
            var filteredChainedProducts = productsService.findChainedProductsFiltered(chainId, user, false, productList);
            if (CollectionUtils.isNotEmpty(filteredChainedProducts)) {
                price.setCollectedPrice(0.0);
                filteredChainedProducts.stream()
                        .filter(chainedProduct -> {
                            log.info(":: Updating Price of Chained Article :: EAN - {}", chainedProduct.getEan());
                            return cProducts.stream().noneMatch(p -> p.getProduct().getEan().contains(chainedProduct.getEan()));
                        })
                        .forEach(chainedProduct -> setPriceResponse(cProducts, price, chainedProduct.getPrd(), prdPrice, masterData, user));
            }
        }
        logService.logStopWatchStop(stopWatch);
    }

    private void setPriceResponse(List<CollectionProduct> cProducts, ProductPrice price, final Product prd,
                                  Set<ProductPrice> prdPrices, final MasterData masterData, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("setPriceResponse");

        CollectionProduct cPrd = new CollectionProduct();
        CategoryRoundingResponse cRounding = new CategoryRoundingResponse();
        PriceConversion pConv;
        String catType;
        StoreProduct sProd;
        StorePrice sPrice;
        Double nPrice;
        List<CollectionAssginment> collectionAssignments;

        sProd = masterData.getProductStoreProductMap().getOrDefault(prd, new StoreProduct());
        if (price.getEan().equals(prd.getEan())) {
            pConv = price.getPConv();
            catType = price.getCatType();
            sPrice = price.getSPrice();
            nPrice = price.getNPrice();
            collectionAssignments = price.getAssignments();
        } else {
            ProductPrice price1 = prdPrices.stream().filter(pr -> pr.getEan().contains(prd.getEan())).findFirst().orElse(null);
            if (null != price1) {
                pConv = price1.getPConv();
                catType = price1.getCatType();
                sPrice = price1.getSPrice();
                nPrice = price1.getNPrice();
                collectionAssignments = price1.getAssignments();
            } else {
                pConv = helperService.getConversionDetails(prd, cRounding);
                catType = null != cRounding.getRType() ? cRounding.getRType().toString() : null;
                collectionAssignments = new ArrayList<>();
                nPrice = storePriceService.findActiveNationalPriceFromProduct(prd, user.getTenant());
                sPrice = null != prd.getProductId() ? storePriceTools.getActiveSPrice(prd, sProd, user.getStore()) : null;
            }
        }

        //Rounding logic
        priceTools.applyRounding(price.getPrice(), prd, cPrd, nPrice, catType, user.getTenant(), false);
        cPrd.setChainId(productTools.getChainIdFromProduct(prd));
        cPrd.setAssignments(collectionAssignments);
        cPrd.setCollectedPrice(price.getCollectedPrice());

        productInfoHelper.setDesiredPriceResponse(cPrd, prd, masterData);
        setClProductResponse(cPrd, prd, nPrice, pConv, catType, sPrice, masterData, user);

        cProducts.add(cPrd);
        logService.logStopWatchStop(stopWatch);
    }

    private void setClProductResponse(final CollectionProduct cPrd, final Product prd, final Double nPrice,
                                      final PriceConversion pConv, final String catType, final StorePrice sPrice,
                                      final MasterData masterData, final User user) {
        StopWatch stopWatch = logService.logStopWatchStart("setClProductResponse");

        var sProd = masterData.getProductStoreProductMap().get(prd);
        var clusterPrice = masterData.getEanClusterPriceMap().get(prd.getEan());
        var costPrice = Double.parseDouble(masterData.getEanCostPriceMap().getOrDefault(prd.getEan(), MAP_0));
        var costPriceVat = priceValidation.calculateCostPriceInclusiveOfVat(costPrice, prd, user);

        log.info("{} {} {} {} {} {}", StructuredArguments.keyValue("method", "setClProductResponse"),
                StructuredArguments.keyValue("ean", prd.getEan()), StructuredArguments.keyValue("nPrice", nPrice),
                StructuredArguments.keyValue("catType", catType), StructuredArguments.keyValue("costPrice", costPrice),
                StructuredArguments.keyValue("costPriceVat", costPriceVat));

        ScProductResponse scProductResponse = new ScProductResponse();
        scProductResponse.setEan(prd.getEan());
        scProductResponse.setProductCode(prd.getProductCode());
        scProductResponse.setDescription(prd.getDescription());
        scProductResponse.setStandardPrice(storePriceService.deriveStandardPrice(nPrice, sPrice, user, clusterPrice));
        scProductResponse.setConversion(prd.getConversion());
        scProductResponse.setCostPrice(costPrice);
        scProductResponse.setCostPriceVat(costPriceVat);
        scProductResponse.setUnit(UOM_EA.equalsIgnoreCase(prd.getUom()) ? UOM_PC : prd.getUom());
        scProductResponse.setPConversion(pConv);
        scProductResponse.setCatType(TENANT_CAFR.equals(user.getTenant()) ? String.valueOf(RoundingType.UL) : catType);
        scProductResponse.setPrdType(prdValidation.typeValidation((user.getTenant())).getPrdTypeFromStoreProduct(sProd).toString());
        scProductResponse.setShowDatePicker(storeProductService.isShowDatePicker(scProductResponse.getPrdType(), user));
        scProductResponse.setPackaging(prd.getPackaging());
        scProductResponse.setPkg1(prd.getPkg1());
        scProductResponse.setPkg2(prd.getPkg2());
        scProductResponse.setFixedPrice(PRICE_FLAG_YES.equals(null != sProd ? sProd.getFixedPrice() : EMPTY_STR));
        scProductResponse.setSPrice(sPrice);
        scProductResponse.setNPrice(nPrice);
        scProductResponse.setValidPrd(productTools.filterNonEligibleProductByStatus(prd) && masterData.getValidPrdListingMap().getOrDefault(prd.getEan(), true));
        cPrd.setProduct(scProductResponse);
        logService.logStopWatchStop(stopWatch);
    }

    private String getPropertyOrDefaultValue(final String input, final String defaultValue) {
        return StringUtils.isNotEmpty(input) ? input : defaultValue;
    }

    @Transactional
    public void saveKeyToStoreCollections(String fileName, List<StoreCollection> storeCollections) {
        storeCollections.forEach(collection -> collection.setKey(fileName));
        storeCollectionRepository.saveAll(storeCollections);
    }

    public String findKeyFromStoreCollection(final String id) {
        Optional<StoreCollection> storeCollectionOptional = storeCollectionRepository.findById(Long.valueOf(id));
        String fileName = EMPTY_STR;
        if (storeCollectionOptional.isPresent()) {
            fileName = storeCollectionOptional.get().getKey();
        }
        log.debug("Key for collection: {} --> {}", id, fileName);
        return fileName;
    }

    public List<StoreCollection> getCollectionsByCategoryType() {
        return storeCollectionRepository.findAllByCategoryType("Center");
    }

}