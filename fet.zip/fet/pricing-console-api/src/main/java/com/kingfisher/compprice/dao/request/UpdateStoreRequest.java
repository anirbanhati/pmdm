package com.kingfisher.compprice.dao.request;

import com.kingfisher.compprice.dao.entity.CompetitorStore;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateStoreRequest {

    @NotNull
    @Size(max = 40)
    @NotBlank
    private String storeCode;

    @NotNull
    @Size(max = 40)
    @NotBlank
    private String name;

    @NotNull
    @Size(max = 40)
    @NotBlank
    private String storeType;

    private List<CompetitorStore> competitors;

}