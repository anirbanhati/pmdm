package com.kingfisher.compprice.config;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JsonWebKey {
	@JsonAlias("kty")
	private String kty;

	@JsonAlias("use")
	private String use;

	@JsonAlias("kid")
	private String kid;

	@JsonAlias("n")
	private String n;

	@JsonAlias("e")
	private String e;

	@JsonAlias("x5t")
	private String x5t;

	@JsonAlias("issuer")
	private String issuer;

	@JsonAlias("x5c")
	private List<String> x5c;

	public String getKty() {
		return this.kty;
	}

	public void setKty(String kty) {
		this.kty = kty;
	}

	public String getUse() {
		return this.use;
	}

	public void setUse(String use) {
		this.use = use;
	}

	public String getKid() {
		return this.kid;
	}

	public void setKid(String kid) {
		this.kid = kid;
	}

	public String getN() {
		return this.n;
	}

	public void setN(String n) {
		this.n = n;
	}

	public String getE() {
		return this.e;
	}

	public void setE(String e) {
		this.e = e;
	}

	public String getX5t() {
		return this.x5t;
	}

	public void setX5t(String x5t) {
		this.x5t = x5t;
	}

	public String getIssuer() {
		return this.issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public List<String> getX5c() {
		return this.x5c;
	}

	public void setX5c(List<String> x5c) {
		this.x5c = x5c;
	}
}
