package com.kingfisher.compprice.tools;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.util.StopWatch;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PerformanceLogger {

    @Pointcut(value="execution(public * *(..))")
    public void anyPublicMethod() { }

    @Around("anyPublicMethod() && @annotation(PerformanceExecution)")
    public void userAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
        StopWatch stopWatch = new StopWatch(getClass().getSimpleName());
        try{
            stopWatch.start(joinPoint.getSignature().getName());
            joinPoint.proceed();
        } finally{
            stopWatch.stop();
            log.info("Execution time of {}.{} :: {} ms", className, methodName, stopWatch.getTotalTimeMillis());
            log.debug(stopWatch.prettyPrint());
        }
    }
}
