package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.ImportErrors;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ImportErrorsRepository extends JpaRepository<ImportErrors, Long> {

    Optional<ImportErrors> findByErrorKey(final String errorKey);

    List<ImportErrors> findAllByLastUpdatedBefore(final LocalDateTime effectiveDate);

}