package com.kingfisher.compprice.controller;

import com.google.gson.Gson;
import com.kingfisher.compprice.controller.swagger.ProductControllerSwagger;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.request.RoundingRequest;
import com.kingfisher.compprice.dao.response.ProductDetailsResponse;
import com.kingfisher.compprice.dao.response.ProductSearchResponse;
import com.kingfisher.compprice.dao.response.RoundingResponse;
import com.kingfisher.compprice.dao.response.search.ProductChainItem;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.ProductSearchPaging;
import com.kingfisher.compprice.service.CompetitorPriceService;
import com.kingfisher.compprice.service.ProductService;
import com.kingfisher.jsonapi.JsonApiResponse;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(PRODUCT_BASE_URL)
public class ProductController implements ProductControllerSwagger {

	private final CurrentUser cUser;
	private final ProductService productService;
	private final CompetitorPriceService compPriceService;

	Gson gson = new Gson();

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'DISPLAY_PRODUCT')")
	@Override
	@GetMapping(GET_PRODUCT_HIERARCHY_BY_TYPE)
	public MultiDataResponse<Category> getHierarchyByProductType(@NotNull @RequestParam(PRD_TYPE) final List<String> prdType) {
		log.info("Product: getHierarchyByProductType --> {}", gson.toJson(prdType));
		return JsonApiResponse
				.multiDataResponse(productService.getHierarchiesByPrdType(cUser.getUser().getStore(), cUser.getUser(), prdType));
	}

	@PreAuthorize("hasPermission(#id, 'PermissionName', 'DISPLAY_PRODUCT')")
	@Override
    @PostMapping(PRODUCT_SEARCH)
	public SingleDataResponse<ProductSearchResponse> searchProductsByCriteria(@RequestBody final ProductSearchCriteria searchCriteria) {
		log.info("Product: searchProductsByCriteria --> {}", gson.toJson(searchCriteria));
		final ProductSearchPaging paging = null != searchCriteria.getPaging() ? searchCriteria.getPaging() :
				new ProductSearchPaging();
		return JsonApiResponse.singleDataResponse(productService.productSearchByType(paging, searchCriteria, cUser));
	}

	@PostMapping(ROUNDED_OFF_PRODUCT_PRICE)
	public SingleDataResponse<RoundingResponse> roundedProduct(@RequestBody RoundingRequest request) {
		log.info("Product: roundedProduct --> {}", gson.toJson(request));
		return JsonApiResponse.singleDataResponse(compPriceService.findRoundedPrice(request, cUser.getUser()));
	}

	@Override
	@GetMapping(PRODUCT_CHAIN)
	public MultiDataResponse<ProductChainItem> getChainedProductsByChainId(@PathVariable final String chainId) {
		log.info("Product: getChainedProductsByChainId --> {}", chainId);
		return JsonApiResponse.multiDataResponse(productService.findChainedProducts(chainId, cUser.getUser()));
	}

	@Override
	@GetMapping
	public SingleDataResponse<ProductDetailsResponse> getProductDetailsByEanAndType(@NotNull @RequestParam(PRODUCT_EAN) final String ean,
																					@NotNull @RequestParam(PRD_TYPE) final String prdType) {
		log.info("Product: getProductDetailsByEanAndType --> {}, {}", ean, prdType);
		return JsonApiResponse.singleDataResponse(productService.getProductInfo(ean, prdType, cUser));
	}

}