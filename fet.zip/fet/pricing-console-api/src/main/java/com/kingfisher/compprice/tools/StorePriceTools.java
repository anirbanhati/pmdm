package com.kingfisher.compprice.tools;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.service.LogService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class StorePriceTools {

    @PersistenceContext
    private EntityManager entityManager;
    private final LogService logService;


    public StorePrice getActiveSPrice(final Product product, final StoreProduct storeProduct, final Store store) {
        StopWatch stopWatch = logService.logStopWatchStart("getActiveSPrice");
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        final CriteriaQuery<StorePrice> criteriaQuery = criteriaBuilder.createQuery(StorePrice.class);
        final Root<StorePrice> storePriceRoot = criteriaQuery.from(StorePrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(storePriceRoot.get(PRODUCT_EAN), product.getEan());
        final Predicate storePredicate = criteriaBuilder.equal(storePriceRoot.get(STORE), store);
        final Predicate startDatePredicate = criteriaBuilder.lessThanOrEqualTo
                (storePriceRoot.get(START_DATE).as(LocalDateTime.class), LocalDateTime.now());
        final Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo
                (storePriceRoot.get(END_DATE).as(LocalDate.class), LocalDate.now());
        criteriaQuery.where(prdPredicate, storePredicate, startDatePredicate, endDatePredicate);
        final TypedQuery<StorePrice> typedQuery = entityManager.createQuery(criteriaQuery);
        List<StorePrice> resultRow = typedQuery.getResultList();

        StorePrice sPrice;
        sPrice = CollectionUtils.isNotEmpty(resultRow) ? resultRow.stream()
                .filter(storePrice -> null != storeProduct.getId() && PRICE_FLAG_YES.equalsIgnoreCase(storeProduct.getLocalPricing()))
                .max(Comparator.comparing(StorePrice::getLastUpdateTime)).orElse(null) : null;
        logService.logStopWatchStop(stopWatch);
        return sPrice;
    }

    @Cacheable(value = STORE_PRICE_CACHE, key = "{#product.ean, #store.storeCode}")
    public StorePrice getActiveStorePrice(final Product product, final Store store) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<StorePrice> criteriaQuery = criteriaBuilder.createQuery(StorePrice.class);
        final Root<StorePrice> storePriceRoot = criteriaQuery.from(StorePrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(storePriceRoot.get(PRODUCT_EAN), product.getEan());
        final Predicate storePredicate = criteriaBuilder.equal(storePriceRoot.get(STORE), store);
        final Predicate startDatePredicate = criteriaBuilder.lessThanOrEqualTo
                (storePriceRoot.get(START_DATE).as(LocalDateTime.class), LocalDateTime.now());
        final Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo
                (storePriceRoot.get(END_DATE).as(LocalDate.class), LocalDate.now());
        criteriaQuery.where(prdPredicate, storePredicate, startDatePredicate, endDatePredicate);
        criteriaQuery.orderBy(criteriaBuilder.desc(storePriceRoot.get(LAST_UPDATE_TIME)));
        final TypedQuery<StorePrice> typedQuery = entityManager.createQuery(criteriaQuery);
        List<StorePrice> storePrices = typedQuery.getResultList();
        return CollectionUtils.isNotEmpty(storePrices) ? storePrices.stream().findFirst().orElse(null) : null;
    }

    public List<StorePrice> getStorePricesList(final Product product, final User user) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<StorePrice> criteriaQuery = criteriaBuilder.createQuery(StorePrice.class);
        final Root<StorePrice> storePriceRoot = criteriaQuery.from(StorePrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(storePriceRoot.get(PRODUCT_EAN), product.getEan());
        final Predicate storePredicate = criteriaBuilder.equal(storePriceRoot.get(STORE), user.getStore());
        final Predicate tenantPredicate = criteriaBuilder.equal(storePriceRoot.get(TENANT), user.getTenant());
        final Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo(storePriceRoot.get(END_DATE).as(LocalDateTime.class), LocalDateTime.now().minusDays(90));
        criteriaQuery.where(prdPredicate, storePredicate, tenantPredicate, endDatePredicate);
        criteriaQuery.orderBy(criteriaBuilder.asc(storePriceRoot.get(LAST_UPDATE_TIME)));
        final TypedQuery<StorePrice> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }

    public List<StorePrice> getStorePricesListForSalesHistory(final Product product, final User user) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<StorePrice> criteriaQuery = criteriaBuilder.createQuery(StorePrice.class);
        final Root<StorePrice> storePriceRoot = criteriaQuery.from(StorePrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(storePriceRoot.get(PRODUCT_EAN), product.getEan());
        final Predicate storePredicate = criteriaBuilder.equal(storePriceRoot.get(STORE), user.getStore());
        final Predicate tenantPredicate = criteriaBuilder.equal(storePriceRoot.get(TENANT), user.getTenant());
        final Predicate endDatePredicate = criteriaBuilder.between(storePriceRoot.get(END_DATE).as(LocalDateTime.class), LocalDateTime.now().minusDays(90), LocalDateTime.now().minusDays(1));
        criteriaQuery.where(prdPredicate, storePredicate, tenantPredicate, endDatePredicate);
        final TypedQuery<StorePrice> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }

    public List<StorePrice> getActiveOrFutureStorePrice(final String ean, final Store store, final String tenant) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<StorePrice> criteriaQuery = criteriaBuilder.createQuery(StorePrice.class);
        final Root<StorePrice> storePriceRoot = criteriaQuery.from(StorePrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(storePriceRoot.get(PRODUCT_EAN), ean);
        final Predicate storePredicate = criteriaBuilder.equal(storePriceRoot.get(STORE), store);
        final Predicate tenantPredicate = criteriaBuilder.equal(storePriceRoot.get(TENANT), tenant);
        final Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo
                (storePriceRoot.get(END_DATE).as(LocalDateTime.class), LocalDate.now().atStartOfDay());
        criteriaQuery.where(prdPredicate, storePredicate, tenantPredicate, endDatePredicate);
        final TypedQuery<StorePrice> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }

    public List<NationalPrice> getActiveOrFutureNationalPrice(final Product product, final String tenant) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<NationalPrice> criteriaQuery = criteriaBuilder.createQuery(NationalPrice.class);
        final Root<NationalPrice> nationalPriceRoot = criteriaQuery.from(NationalPrice.class);
        final Predicate prdPredicate = criteriaBuilder.equal(nationalPriceRoot.get(PRODUCT), product);
        final Predicate tenantPredicate = criteriaBuilder.equal(nationalPriceRoot.get(TENANT), tenant);
        final Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo
                (nationalPriceRoot.get(END_DATE).as(LocalDateTime.class), LocalDate.now().atStartOfDay());
        criteriaQuery.where(prdPredicate, tenantPredicate, endDatePredicate);
        final TypedQuery<NationalPrice> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }

    public List<ClusterPrice> getActiveOrFutureClusterPrice(final String  ean, final String tenant, String clusterID) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<ClusterPrice> criteriaQuery = criteriaBuilder.createQuery(ClusterPrice.class);
        final Root<ClusterPrice> root = criteriaQuery.from(ClusterPrice.class);
        final Predicate productPredicate = criteriaBuilder.equal(root.get(PRODUCT_EAN), ean);
        final Predicate tenantPredicate = criteriaBuilder.equal(root.get(TENANT), tenant);
        final Predicate clusterIdPredicate = criteriaBuilder.equal(root.get(CLUSTER_ID),clusterID);
        final Predicate startDatePredicate = criteriaBuilder.greaterThanOrEqualTo(root.get(END_DATE), LocalDateTime.now());
        criteriaQuery.where(productPredicate, tenantPredicate, startDatePredicate, clusterIdPredicate);
        final TypedQuery<ClusterPrice> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }

}