package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.MapPrice;
import com.kingfisher.compprice.repository.MapPriceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.kingfisher.compprice.util.constants.Constants.MAP_0;

@Slf4j
@RequiredArgsConstructor
@Service
public class MapStoreDataService {

    private final MapPriceRepository mapRepo;
    private final LogService logService;


    @Async
    public void storeDataInDB(Map<String, String> costDataMap, String storeCode, List<String> listOfEan) {
        StopWatch stopWatch = logService.logStopWatchStart("storeDataInDB");

        log.debug("Store map data in DB ::::");
        List<MapPrice> mapPrices = new ArrayList<>();
        listOfEan.forEach(ean -> {
            MapPrice mapPrice = new MapPrice();
            mapPrice.setEan(ean);
            mapPrice.setStoreCode(storeCode);
            mapPrice.setCostPrice(Double.parseDouble(costDataMap.getOrDefault(ean, MAP_0)));
            mapPrices.add(mapPrice);
        });
        mapRepo.saveAll(mapPrices);
        logService.logStopWatchStop(stopWatch);
    }

    public Map<String, String> getEanCostPriceMap(List<MapPrice> mapList) {
        StopWatch stopWatch = logService.logStopWatchStart("getEanCostPriceMap");

        Map<String, String> costDataMap = new HashMap<>();
        mapList.forEach(map -> costDataMap.put(map.getEan(), String.valueOf(map.getCostPrice())));

        logService.logStopWatchStop(stopWatch);
        return costDataMap;
    }

}