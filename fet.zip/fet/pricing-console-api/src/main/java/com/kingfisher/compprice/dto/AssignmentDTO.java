package com.kingfisher.compprice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssignmentDTO implements Serializable {
    private static final long serialVersionUID = -5860315638885177020L;

    private long id;
    private ProductDTO product;
    @JsonProperty("cPrice")
    private double collectedPrice;
    @JsonProperty("cPkg")
    private String collectedPackage;
    @JsonProperty("cPkgUnit")
    private String collectedPkgUnit;
    @JsonProperty("cPkgValue")
    private String collectedPkgValue;
    @JsonProperty("tenant")
    private String tenant;
    private boolean masterDataMissing;
    @JsonProperty("cCode")
    private String collectedArticleCode;
    @JsonProperty("cEan")
    private String collectedEan;
    @Builder.Default
    @JsonProperty("hasPromo")
    private boolean hasPromo = false;
    @JsonProperty("isLinked")
    @Builder.Default
    private boolean linkArticle = false;
    @JsonProperty("productCollectionExtracted")
    private boolean productCollectionExtracted;
    @JsonProperty("productAssociationExtracted")
    private boolean productAssociationExtracted;
    @JsonProperty("productAssociationExtractedDate")
    private LocalDateTime productAssociationExtractedDate;
    @JsonProperty("productCollectionExtractedDate")
    private LocalDateTime productCollectionExtractedDate;
    private String notes;
    @JsonProperty("promoInfo")
    private String promoInfo;
    @JsonProperty("cDesc")
    private String collectedDescription;

}