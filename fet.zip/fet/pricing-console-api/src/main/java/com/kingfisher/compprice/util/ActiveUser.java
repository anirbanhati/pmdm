package com.kingfisher.compprice.util;

import com.kingfisher.compprice.dao.entity.FeaturesPermissions;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.entity.UserCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

/**
 * This class implements UserDetails interface and overrides the getAuthorities()
 * method. By overriding it adds role or permission to the authorities Collection, so that
 * when the authorization occurs it can match against these authorities
 */
@Slf4j
public class ActiveUser implements UserDetails {
    private static final long serialVersionUID = 5961497080670956513L;

    private final User user;


    public ActiveUser(final User user) {
        log.debug("Initialized User in MyUserPrincipal with userId: {}", user.getUserId());
        this.user = user;
    }

    @Override
    public String getUsername() {
        return user.getUserId();
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        final List<GrantedAuthority> authorities = new ArrayList<>();
        final Optional<UserCode> userCodeOptional = Optional.ofNullable(user.getUserCode());
        if (userCodeOptional.isPresent()) {
            final Set<FeaturesPermissions> userPermissions = userCodeOptional.get().getFeaturePermissions();
            userPermissions.forEach(permission -> authorities.add(new SimpleGrantedAuthority(permission.getFeaturesPermissionsName())));
        }
        return authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

}