package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StoreCompetitorStoreMap;
import com.kingfisher.compprice.dto.StoreAssociationInfo;
import com.kingfisher.compprice.dto.StoreAssociations;
import com.kingfisher.compprice.repository.CompetitorStoreRepository;
import com.kingfisher.compprice.repository.StoreCompetitorStoreRepository;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.STORE_ASSOCIATION_MESSAGE_SERVICE;
import static com.kingfisher.compprice.util.constants.Constants.UNDER_SCORE;

@Service
@RequiredArgsConstructor
@Slf4j
public class StoreAssociationMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final MessageServicesHelper servicesHelper;
    private final StoreCompetitorStoreRepository storeCompetitorStoreRepository;
    private final CompetitorStoreRepository compStoreRepo;


    @Override
    public ProcessedByType getProcessedBy() {
        return STORE_ASSOCIATION_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Store Association Feed :: {}", message);
        }
        try {
            log.info("Start processing message :: {} {}", this.getClass().getSimpleName(), " :: processMessage()");
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message :: {} {}", this.getClass().getSimpleName(), " :: processMessage()");
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata) throws JAXBException {
        StoreAssociations feed = getStoreAssociationFeed(messageMetadata);
        deleteAllExistingRecords();
        Optional.ofNullable(feed).ifPresent(sf -> sf.getStoreAssociationList().forEach(this::insertStoreAssociationFeedIntoRepository));
    }

    public String getCompName(final StoreAssociationInfo storeAssociationInfo) {
        return StringUtils.isNotEmpty(storeAssociationInfo.getCompCode()) && storeAssociationInfo.getCompCode().contains(UNDER_SCORE) ? storeAssociationInfo.getCompCode().split(UNDER_SCORE)[1] : Constants.EMPTY_STR;
    }

    private void deleteAllExistingRecords() {
        storeCompetitorStoreRepository.deleteAllInBatch();
        compStoreRepo.deleteAllInBatch();
    }

    private StoreAssociations getStoreAssociationFeed(String message) throws JAXBException {
        StoreAssociations feed = null;
        final String methodName = "getStoreAssociationFeed()";
        log.debug("Entering :: {} {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(StoreAssociations.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            feed = (StoreAssociations) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting :: {} {}", this.getClass().getSimpleName(), methodName);
        return feed;
    }

    @Transactional
    public void insertStoreAssociationFeedIntoRepository(StoreAssociationInfo storeAssociationInfo) {
        Store storeData = servicesHelper.findStoreByStoreCode(storeAssociationInfo.getStoreCode());
        if (Optional.ofNullable(storeData).isPresent()) {
            refreshRepositoryForStoreAssocFeed(storeAssociationInfo, storeData);
        } else {
            log.info("Invalid Store Code in Store Association feed :: {}", storeAssociationInfo.getStoreCode());
        }
    }

    private void refreshRepositoryForStoreAssocFeed(StoreAssociationInfo storeAssociationInfo, Store store) {
        Optional<CompetitorStore> competitorStore = compStoreRepo.findByCode(storeAssociationInfo.getCompCode());
        if (competitorStore.isPresent()) {
            updateStoreAssociation(competitorStore.get(), storeAssociationInfo, store);
            compStoreRepo.save(competitorStore.get());
        } else {
            CompetitorStore compStore = new CompetitorStore();
            compStore.setLongName(storeAssociationInfo.getCompDescription());
            compStore.setName(getCompName(storeAssociationInfo));
            StoreCompetitorStoreMap storeCompetitorStoreMap = new StoreCompetitorStoreMap();
            storeCompetitorStoreMap.setStore(store);
            storeCompetitorStoreMap.setCompetitorStore(compStore);
            storeCompetitorStoreMap.setActiveFlag(storeAssociationInfo.getActiveFlag());
            storeCompetitorStoreMap.setModTime(LocalDateTime.now());
            compStore.getStoreCompetitorStoreMaps().add(storeCompetitorStoreMap);
            compStore.setCode(storeAssociationInfo.getCompCode());
            compStore.setLastUpdated(LocalDateTime.now());
            compStore.setCsCode(storeAssociationInfo.getCompCode().split(UNDER_SCORE)[0]);
            compStoreRepo.save(compStore);
            storeCompetitorStoreRepository.save(storeCompetitorStoreMap);
        }
    }

    private void updateStoreAssociation(CompetitorStore association, StoreAssociationInfo storeAssociationInfo, Store store) {
        association.setLongName(storeAssociationInfo.getCompDescription());
        association.setName(getCompName(storeAssociationInfo));
        association.setLastUpdated(LocalDateTime.now());
        var scs = storeCompetitorStoreRepository.findByStoreAndCompetitorStore(store, association).orElse(null);
        if (Optional.ofNullable(scs).isPresent()) {
            scs.setModTime(LocalDateTime.now());
            scs.setActiveFlag(storeAssociationInfo.getActiveFlag());
            storeCompetitorStoreRepository.save(scs);
        } else {
            StoreCompetitorStoreMap storeCompetitorStoreMap = new StoreCompetitorStoreMap();
            storeCompetitorStoreMap.setStore(store);
            storeCompetitorStoreMap.setCompetitorStore(association);
            storeCompetitorStoreMap.setModTime(LocalDateTime.now());
            storeCompetitorStoreMap.setActiveFlag(storeAssociationInfo.getActiveFlag());
            Set<StoreCompetitorStoreMap> storeCompStoreMappingSet = storeCompetitorStoreRepository.findByCompetitorStore(association);
            storeCompStoreMappingSet.add(storeCompetitorStoreMap);
            association.setStoreCompetitorStoreMaps(storeCompStoreMappingSet);
        }
    }

}