package com.kingfisher.compprice.dao.response.map;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Getter
@Setter
public class MapMeta {

	private List<Object> warnings;

}