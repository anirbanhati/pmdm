package com.kingfisher.compprice.tools;

import com.kingfisher.compprice.dao.MasterData;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.service.ProductTools;
import com.kingfisher.compprice.util.BaseValidationFactory;
import com.kingfisher.compprice.dao.ExcelValidation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.kingfisher.compprice.exception.ExceptionConstants.StagePriceExceptions.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.StorePriceExceptions.*;
import static com.kingfisher.compprice.util.constants.Constants.PIPE_SEPARATOR;
import static com.kingfisher.compprice.util.constants.Constants.TENANT_BDFR;

@Component
@RequiredArgsConstructor
@Slf4j
public class PriceValidation {

    private final BaseValidationFactory stageValidation;
    private final ProductTools productTools;


    public void isValidPrice(final Product product, StoreProduct storeProduct, final Double stdPrice,
                             final double costPrice, final User user, double price) {
        double maxDecreasePrice;
        double maxIncreasePrice;

        log.info("{} {} {} {}",
                StructuredArguments.keyValue("ean", product.getEan()),
                StructuredArguments.keyValue("price", price),
                StructuredArguments.keyValue("costPrice", costPrice),
                StructuredArguments.keyValue("method", "isValidPrice"));
        if (costPrice <= 0) {
            throw new DetailsNotFoundException(STG_PRODUCT_COST_PRICE_NOT_FOUND_APP_EXP,
                    STG_PRODUCT_COST_PRICE_NOT_FOUND_HTTP_STATUS, STG_PRODUCT_COST_PRICE_NOT_FOUND_DETAILS,
                    STG_PRODUCT_COST_PRICE_NOT_FOUND_ID, STG_PRODUCT_COST_PRICE_NOT_FOUND_POINTER, product.getEan() +
                    PIPE_SEPARATOR + user.getStore().getStoreCode(), STG_PRODUCT_COST_PRICE_NOT_FOUND_TITLE);
        }
        if (null != storeProduct) {
            maxDecreasePrice = storeProduct.getMaxDecrease();
            maxIncreasePrice = storeProduct.getMaxIncrease();
        } else {
            throw new DetailsNotFoundException(STORE_PRICE_NOT_FOUND_APP_EXP,
                    STORE_PRICE_NOT_FOUND_HTTP_STATUS, STORE_PRICE_NOT_FOUND_DETAILS,
                    STORE_PRICE_NOT_FOUND_ID, STORE_PRICE_CODE_NOT_FOUND_POINTER, product.getEan() + PIPE_SEPARATOR
                    + user.getStore().getStoreCode(), STORE_PRICE_NOT_FOUND_TITLE);
        }
        stageValidation.validation(user.getTenant()).isValidPriceToStage(product, price,
                calculateMinimalPrice(stdPrice, maxDecreasePrice),
                calculateMaxPrice(stdPrice, maxIncreasePrice, user.getTenant()));
    }

    public double calculateMinimalPrice(final double standardPrice, final Double maxDecrease) {
        return standardPrice - (standardPrice * (Optional.ofNullable(maxDecrease).orElse(0.0)));
    }

    public double calculateMaxPrice(final double standardPrice, final Double maxIncrease, final String tenant) {
        return tenant.equals(TENANT_BDFR) ?
                standardPrice + (standardPrice * (Optional.ofNullable(maxIncrease).orElse(0.0))) :
                standardPrice;
    }

    public boolean isLocalStorePriceStopped(final Product product, final MasterData masterData, ExcelValidation excelData) {
        StageProduct stageProduct = masterData.getProductStageProductMap().get(product);
        excelData.setStgPrd(stageProduct);
        return null!=stageProduct && stageProduct.isPriceStopped();
    }

    public double calculateCostPriceInclusiveOfVat(final double costPrice, final Product product, final User user) {
        final double vat = productTools.getVATByJurisdictionIdAndClassificationCode(product.getVatCategory(), user);
        return costPrice * vat;
    }

}