package com.kingfisher.compprice.dao;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DesiredPrice implements Serializable {
	private static final long serialVersionUID = 3178946878196632268L;

	private String ean;
	private double price;
	private String modifiedBy;
	private LocalDateTime modifiedTime;
	private LocalDateTime startDate;
	private LocalDateTime endDate;

}