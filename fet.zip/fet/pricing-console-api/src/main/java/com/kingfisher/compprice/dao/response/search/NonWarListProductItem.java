package com.kingfisher.compprice.dao.response.search;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.response.StockInfo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NonWarListProductItem extends ProductItem {

	private static final long serialVersionUID = -2128368670647915317L;
	private LocalDateTime oorDate;
	@JsonProperty("recom")
	private Recommandation recommadation;
	private StockInfo stockInfo;
	
}
