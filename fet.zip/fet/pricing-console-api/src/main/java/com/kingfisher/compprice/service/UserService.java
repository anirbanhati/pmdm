package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.FeaturesPermissions;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.dao.entity.UserCode;
import com.kingfisher.compprice.dao.request.PermissionRequest;
import com.kingfisher.compprice.dao.request.UserCodeRequest;
import com.kingfisher.compprice.dao.request.UserCodeUpdateRequest;
import com.kingfisher.compprice.dao.request.UserRequest;
import com.kingfisher.compprice.dao.response.Roles;
import com.kingfisher.compprice.dao.response.UserWithPermissionsResponse;
import com.kingfisher.compprice.dao.response.user.UserRoleResponse;
import com.kingfisher.compprice.enums.Role;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.UserException;
import com.kingfisher.compprice.helper.ExcelDataRead;
import com.kingfisher.compprice.repository.FeaturesPermissionsRepository;
import com.kingfisher.compprice.repository.UserCodeRepository;
import com.kingfisher.compprice.repository.UserRepository;
import com.kingfisher.compprice.util.ActiveUser;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.exception.ExceptionConstants.CollectionListExceptions.*;
import static com.kingfisher.compprice.exception.ExceptionConstants.UserExceptions.*;
import static com.kingfisher.compprice.util.constants.CacheConstants.USER_PERMISSION_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;
import static com.kingfisher.compprice.util.constants.Constants.TENANT_CAFR;

@Service
@AllArgsConstructor
@Slf4j
public class UserService implements UserDetailsService {

    protected static final String HEAD_OFFICE_USERS = "Head Office users";
    protected static final String LASTNAME = "Last Name";
    protected static final String FIRSTNAME = "First Name";
    protected static final String STORE = "Store";
    protected static final String USER_ID = "ID";

    private UserRepository userRepository;
    private UserCodeRepository userCodeRepository;
    private FeaturesPermissionsRepository featuresPermissionsRepository;
    private StoreService storeService;


    @Override
    public UserDetails loadUserByUsername(final String username) {
        Optional<User> user = userRepository.findTopByUserIdIgnoreCaseOrderByIdDesc(username);
        if (user.isEmpty()) {
            throw new UsernameNotFoundException(username);
        }
        log.debug("Exiting loadUserByUsername() method, user: {} is present", username);
        return new ActiveUser(user.get());
    }

    @Transactional
    public User createNewUser(final UserRequest userRequest) {
        if (StringUtils.isBlank(userRequest.getUserId())) {
            throw new UserException(USER_ID_EMPTY_APP_EXP, USER_ID_EMPTY_HTTP_STATUS, USER_ID_EMPTY_DETAILS,
                    USER_ID_EMPTY_ID, USER_ID_EMPTY_POINTER, EMPTY_STR, USER_ID_EMPTY_TITLE);
        }

        if (!isUserExist(userRequest.getUserId())) {
            User user = new User();
            user = updateAndSaveUserInfo(userRequest, user);
            return user;
        } else {
            throw new UserException(USER_EXISTS_APP_EXP, USER_EXISTS_HTTP_STATUS,
                    "User Already exist: " + userRequest.getUserId(), USER_EXISTS_ID, USER_EXISTS_POINTER,
                    userRequest.getUserId(), USER_EXISTS_TITLE);
        }
    }

    @Transactional
    public void deleteUser(final String userId) {
        userRepository.deleteById(findUserByUserId(userId).getId());
    }

    public List<User> findAllUsers() {
        return userRepository.findAllByOrderByUserIdAsc();
    }

    public List<User> findUserByStoreCode(final String storeCode) {
        final Store store = storeService.getStoreByCode(storeCode);
        return userRepository.findByStoreOrderByUserIdAsc(store);
    }

    public List<UserRoleResponse> findAllUsersByRole(final String roleName) {
        final List<User> allUser = userRepository.findAllByRoleOrderByIdAsc(Role.valueOf(roleName));
        return allUser.stream()
                .map(user -> UserRoleResponse.builder()
                        .id(user.getId())
                        .userId(user.getUserId())
                        .build()
                ).toList();
    }

    public User findUserByUserId(final String userId) {
        return userRepository.findTopByUserIdIgnoreCaseOrderByIdDesc(userId)
                .orElseThrow(() -> new DetailsNotFoundException(USER_NOT_FOUND_APP_EXP, USER_NOT_FOUND_HTTP_STATUS,
                        USER_NOT_FOUND_DETAILS, USER_NOT_FOUND_ID, USER_NOT_FOUND_POINTER, userId,
                        USER_NOT_FOUND_TITLE));
    }

    public Roles fetchRoles() {
        final Roles response = new Roles();
        final List<String> roles = new ArrayList<>();
        for (final Role role : Role.values()) {
            roles.add(role.toString());
        }
        response.setListOfRole(roles);
        return response;
    }

    public boolean isHeadOfficeUser(final String userId) {
        final User user = findUserByUserId(userId);
        return Role.HeadOffice.equals(user.getRole()) || HEAD_OFFICE_USERS.equalsIgnoreCase(
                user.getUserCode().getWorkGroupDesc());
    }

    public boolean isUserExist(final String userId) {
        return userRepository.findTopByUserIdIgnoreCaseOrderByIdDesc(userId).isPresent();
    }

    private User updateAndSaveUserInfo(final UserRequest userRequest, User user) {
        user.setUserId(userRequest.getUserId().trim());
        user.setFirstName(userRequest.getFirstName());
        user.setLastName(userRequest.getLastName());
        user.setFullName(userRequest.getFullName());
        user.setTenant(userRequest.getTenant());
        user.setRole(userRequest.getRole());
        user.setWorkerId(userRequest.getWorkerId());
        user.setSubArea(userRequest.getSubArea());
        user.setLoginId(userRequest.getLoginId());
        user.setEmailAddress(userRequest.getEmailAddress());
        user.setWorkerStatusCode(userRequest.getWorkerStatusCode());
        user.setLastUpdateTime(LocalDateTime.now());
        if (null != userRequest.getStoreCode()) {
            user.setStore(storeService.getStoreByCode(userRequest.getStoreCode()));
        }

        user = userRepository.save(user);
        return user;
    }

    @Transactional
    public User updateUser(final String userId, final UserRequest userRequest) {
        User userToUpdate = findUserByUserId(userId);
        updateAndSaveUserInfo(userRequest, userToUpdate);
        return userToUpdate;
    }

    public void importUsersList(final InputStream fileStream) throws IOException {
        final XSSFWorkbook workBook = getInputStreamAsWorkBook(fileStream);
        final XSSFSheet sheet = workBook.getSheetAt(0);
        saveUsersList(readUserDataFromExcel(workBook, sheet));
    }

    private void saveUsersList(final Map<String, Map<String, Object>> dataMap) {
        final List<User> users = new ArrayList<>();
        for (final Map.Entry<String, Map<String, Object>> entry : dataMap.entrySet()) {
            final Map<String, Object> userDataMap = entry.getValue();
            final User user = new User();
            user.setUserId(userDataMap.get(USER_ID).toString());
            user.setFirstName(userDataMap.get(FIRSTNAME).toString());
            user.setLastName(userDataMap.get(LASTNAME).toString());
            final String store = userDataMap.get(STORE).toString();
            String storeCode = store;
            log.info("User is creating with user: {} and storeCode: {}", user.getUserId(), storeCode);
            if (store.contains(".")) {
                storeCode = store.substring(0, store.indexOf("."));
            }
            user.setStore(storeService.getStoreByCode(storeCode));
            user.setRole(Role.Store);
            user.setTenant(TENANT_CAFR);
            users.add(user);
        }
        userRepository.saveAll(users);
    }

    private static XSSFWorkbook getInputStreamAsWorkBook(final InputStream inputStream) throws IOException {
        XSSFWorkbook workBook;
        workBook = new XSSFWorkbook(inputStream);
        return workBook;
    }

    private Map<String, Map<String, Object>> readUserDataFromExcel(final XSSFWorkbook workBook, final XSSFSheet sheet) {
        final List<String> headerColumnList = new ArrayList<>(
                Arrays.asList(USER_ID, LASTNAME, FIRSTNAME, STORE));
        return ExcelDataRead.readDataFromExcel(workBook, sheet, headerColumnList);
    }

    @Transactional
    public List<FeaturesPermissions> storeFeatures(final List<PermissionRequest> requests) {
        List<FeaturesPermissions> featuresPermissions = requests.stream()
                .map(req -> {
                    final FeaturesPermissions featurePermission = new FeaturesPermissions();
                    featurePermission.setFeaturesPermissionsName(req.getFeaturesPermissionsName());
                    featurePermission.setFunctionDescription(req.getFunctionDescription());
                    featurePermission.setUserCode(null);
                    return featurePermission;
                })
                .toList();
        return featuresPermissionsRepository.saveAll(featuresPermissions);
    }

    @Transactional
    public List<UserCode> createAndMapFeaturesPermissionsService(final List<UserCodeRequest> requests) {
        final List<UserCode> userCodes = new ArrayList<>();
        for (final UserCodeRequest req : requests) {
            final Optional<UserCode> userCodeObj = userCodeRepository.findByWorkGroupCode(req.getWorkGroupCode());
            final UserCode userCode;
            final Set<FeaturesPermissions> featurePermissions = req.getPermissionName().stream().map(
                    name -> featuresPermissionsRepository.findByFeaturesPermissionsName(name)).collect(Collectors.toSet());
            if (userCodeObj.isPresent()) {
                userCode = userCodeObj.get();
                final Set<FeaturesPermissions> existingFeaturePermissions = new HashSet<>(userCode.getFeaturePermissions());
                existingFeaturePermissions.addAll(featurePermissions);
                userCode.setFeaturePermissions(existingFeaturePermissions);
            } else {
                userCode = new UserCode();
                userCode.setSalesOrg(req.getSalesOrg());
                userCode.setWorkGroupCode(req.getWorkGroupCode());
                userCode.setWorkGroupDesc(req.getWorkGroupDesc());
                userCode.setFeaturePermissions(featurePermissions);
            }
            userCodes.add(userCode);
        }
        return userCodeRepository.saveAll(userCodes);
    }

    public void updatePermissionOfWorkgroupCodeService(final long workGroupCode, final UserCodeUpdateRequest updateReq) {
        final UserCode userCode = userCodeRepository.findByWorkGroupCode(workGroupCode)
                .orElseThrow(() -> new DetailsNotFoundException(USER_NOT_FOUND_APP_EXP, USER_NOT_FOUND_HTTP_STATUS,
                        USER_NOT_FOUND_DETAILS, USER_NOT_FOUND_ID, USER_NOT_FOUND_POINTER, "UserCode",
                        USER_NOT_FOUND_TITLE));
        final Set<FeaturesPermissions> featurePermissions = updateReq.getPermissionName().stream().map(
                name -> featuresPermissionsRepository.findByFeaturesPermissionsName(name)).collect(Collectors.toSet());
        userCode.setFeaturePermissions(featurePermissions);
        userCodeRepository.save(userCode);
    }

    @Cacheable(value = USER_PERMISSION_CACHE, key = "#userId")
    public UserWithPermissionsResponse getUserWithPermissionsService(final String userId) {
        final UserWithPermissionsResponse userWithPermissionsResponse = new UserWithPermissionsResponse();
        final User user = userRepository.findTopByUserIdIgnoreCaseOrderByIdDesc(userId)
                .orElseThrow(() -> new DetailsNotFoundException(USER_NOT_FOUND_APP_EXP, USER_NOT_FOUND_HTTP_STATUS,
                        USER_NOT_FOUND_DETAILS, USER_NOT_FOUND_ID, USER_NOT_FOUND_POINTER, userId,
                        USER_NOT_FOUND_TITLE));
        try {
            BeanUtils.copyProperties(userWithPermissionsResponse, user);
            userWithPermissionsResponse.setStoreId(
                    userWithPermissionsResponse.getStore() != null && userWithPermissionsResponse.getStore().getStoreId() != null ?
                            userWithPermissionsResponse.getStore().getStoreId() : null);
            userWithPermissionsResponse.setStoreCode(
                    userWithPermissionsResponse.getStore() != null && userWithPermissionsResponse.getStore().getStoreId() != null ?
                            storeService.getStoreById(userWithPermissionsResponse.getStore().getStoreId()).getStoreCode() : null);

            final UserCode userCode = user.getUserCode();
            if (userCode != null) {
                userWithPermissionsResponse.setPermissions(userCode.getFeaturePermissions());
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new DetailsNotFoundException(CI_ITEM_INTERNAL_ERROR_APP_EXP,
                    CI_ITEM_INTERNAL_ERROR_HTTP_STATUS, CI_ITEM_INTERNAL_ERROR_DETAILS,
                    CI_ITEM_INTERNAL_ERROR_ID, CI_ITEM_INTERNAL_ERROR_POINTER, String.valueOf(user.getId()),
                    CI_ITEM_INTERNAL_ERROR_TITLE);
        }
        return userWithPermissionsResponse;
    }

    public List<User> findUsersAssignedToByStoreCode(String storeCode) {
        final Store store = storeService.getStoreByCode(storeCode);
        final List<User> users = userRepository.findByStoreOrderByUserIdAsc(store);
        return users.stream()
                .filter(user -> {
                            if (null != user.getUserCode()) {
                                return user.getUserCode()
                                        .getFeaturePermissions()
                                        .stream()
                                        .anyMatch(name -> name.getFeaturesPermissionsName().equalsIgnoreCase("COLLECT_PRICE"));
                            }
                            return false;
                        }
                )
                .toList();
    }

    public void deleteAllFeaturesPermissionsService() {
        List<UserCode> userCodes = userCodeRepository.findAll();
        userCodes.forEach(usr -> usr.setFeaturePermissions(null));
        userCodeRepository.saveAll(userCodes);
        List<FeaturesPermissions> featuresPermissions = featuresPermissionsRepository.findAll();
        featuresPermissions.forEach(fp -> fp.setUserCode(null));
        featuresPermissionsRepository.saveAll(featuresPermissions);
        featuresPermissionsRepository.deleteAll();
    }

}