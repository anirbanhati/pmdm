package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.Constants.*;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Getter
@Setter
@Table(name = "lsp_product")
public class Product implements Serializable {

    private static final long serialVersionUID = 403510387769949805L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    @JsonIgnore
    private Long productId;

    @Column(name = COL_PRODUCT_CODE)
    @JsonProperty("code")
    private String productCode;

    @Column(name = PRODUCT_CATEGORY)
    @JsonProperty("cat")
    private String category;

    @Column(name = "app_type")
    private String appType;

    @Column(name = "packaging")
    @JsonProperty("pkg")
    private String packaging;

    @Column(name = "brick_code")
    @JsonProperty("brickCode")
    private String brickCode;

    @Column(name = "sub_category")
    @JsonProperty("subCat")
    private String subCategory;

    @Column(name = SALES_UNIT)
    @JsonProperty("sUnit")
    private String salesUnit;

    @Column(name = P_EAN)
    private String ean;

    @Column(name = "brick_name")
    @JsonProperty("bName")
    private String brickName;

    @Column(name = DESCRIPTION)
    @JsonProperty("desc")
    private String description;

    @Column(name = PACKAGING_1)
    private String pkg1;

    @Column(name = "packaging2")
    private String pkg2;

    @Column(name = "unit")
    private String unit;

    @Column(name = "map")
    private double map;

    @Column(name = "price_uom")
    private Double priceUom;

    @Column(name = CONVERSION)
    private Double conversion;

    @Column(name = UOM)
    @JsonProperty(UOM)
    private String uom;

    @Column(name = "standard_price")
    @JsonProperty("stdPrice")
    private Double standardPrice;

    @Column(name = "sales_price")
    @JsonProperty("sPrice")
    private Double salesPrice;

    @Column(name = "effective_price")
    @JsonIgnore
    private double effectivePrice;

    @Column(name = "cost_price")
    private Double costPrice;

    @Column(name = "vat_category")
    private String vatCategory;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Column(name = "productStatus")
    private Double productStatus;

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private final Set<Assignment> assignment = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<PriceUpdate> pUpdate = new HashSet<>();

    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE}, mappedBy = "products")
    @JsonIgnore
    private Set<WarlistInfo> warListInfos = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<StageProduct> stageProduct = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<Vendor> vendor = new HashSet<>();

    @OneToMany(mappedBy = "comProd", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<CompetitorProduct> comProduct = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<StoreProduct> storeProduct = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<CostPrice> costPrices = new HashSet<>();

    @JsonIgnore
    @OneToOne(mappedBy = "product", cascade = CascadeType.ALL)
    private ProductChainingInfo productChainingInfo;

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<NationalPrice> nationalPrices = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<Provisions> provisions = new HashSet<>();

    @Transient
    private String legalUnit;


    public void setComProduct(final Set<CompetitorProduct> comProduct) {
        for (final CompetitorProduct cProd : comProduct) {
            cProd.setComProd(this);
        }
        this.comProduct = comProduct;
    }

    public String getProductCode() {
        return Integer.valueOf(productCode).toString();
    }

}