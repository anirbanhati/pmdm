package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.response.search.StorePriceResponse;
import com.kingfisher.compprice.repository.NationalPriceRepository;
import com.kingfisher.compprice.repository.StorePriceRepository;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.compprice.util.DecimalUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.kingfisher.compprice.util.constants.CacheConstants.N_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.DecimalUtils.ROUND_OF_2;

@Service
@RequiredArgsConstructor
@Slf4j
public class StorePriceService {

	private final StorePriceRepository storePriceRepo;
	private final NationalPriceRepository nationalPriceRepository;
	private final LogService logService;


	private List<StorePrice> findStorePricesByListOfEanAndStore(final List<String> listOfEan, final Store store) {
		return storePriceRepo.findByStoreAndEanIn(store, listOfEan);
	}

	public StorePriceResponse setStorePrice(final StorePrice storePrice, final Double price) {
		StorePriceResponse response = null;
		if (Optional.ofNullable(storePrice).isPresent()) {
			response = new StorePriceResponse();
			response.setPrice(DecimalUtils.roundOf(price, ROUND_OF_2));
			response.setRefPrice(DecimalUtils.roundOf(storePrice.getRefPrice(), ROUND_OF_2));
			response.setSDate(storePrice.getStartDate());
			response.setEDate(storePrice.getEndDate());
		}
		return response;
	}

	@Cacheable(value = STORE_PRICE_CACHE, key = "{#product.ean, #store.storeCode}")
	public StorePrice findActiveStorePriceByProduct(final Product product, final Store store) {
		StorePrice activeStorePrice = null;
		if (null != product) {
			StopWatch stopWatch = logService.logStopWatchStart("findActiveStorePriceByProduct");
			log.debug("{} {} {}",
					StructuredArguments.keyValue("method", "findActiveStorePriceByProduct"),
					StructuredArguments.keyValue("ean", product.getEan()),
					StructuredArguments.keyValue("storeCode", store.getStoreCode()));

			Set<StorePrice> storePrices = storePriceRepo.findByEan(product.getEan());
			activeStorePrice = storePrices.stream()
					.filter(storePrice -> null != storePrice.getStore() && storePrice.getStore().getStoreId().equals(store.getStoreId())
							&& DateUtils.isInBetween(storePrice.getStartDate(), storePrice.getEndDate().plusDays(1), LocalDateTime.now()))
					.max(Comparator.comparing(StorePrice::getLastUpdateTime))
					.orElse(null);
			logService.logStopWatchStop(stopWatch);
		}
		return activeStorePrice;
	}

	public Double deriveStandardPrice(final Double nPrice, final StorePrice storePrice, final User user, final Double clusterPrice) {
		double stdPrice = 0.0;
		if (TENANT_CAFR.equalsIgnoreCase(user.getTenant())) {
			double storeRefPrice = null != storePrice && null != storePrice.getRefPrice() ? storePrice.getRefPrice() : 0.0;
			stdPrice = Optional.ofNullable(clusterPrice).orElse(storeRefPrice);
		} else if (TENANT_BDFR.equalsIgnoreCase(user.getTenant())) {
			if (VKP0.equalsIgnoreCase(Optional.ofNullable(Optional.ofNullable(storePrice).orElse(new StorePrice()).getPriceTypeFlag()).orElse(EMPTY_STR))) {
				stdPrice = Optional.ofNullable(clusterPrice).orElse(Optional.ofNullable(nPrice).orElse(0.0));
			} else {
				stdPrice = Optional.ofNullable(nPrice).orElse(0.0);
			}
		}
		return stdPrice;
	}

	public Double getStorePriceWithCluster(final Double nPrice, final StorePrice storePrice, final User user, final Double clusterPrice) {
		Double price = 0.0;
		String priceType = EMPTY_STR;
		double refPrice = 0.0;
		if (null != storePrice) {
			price = Optional.ofNullable(storePrice.getPrice()).orElse(0.0);
			priceType = Optional.ofNullable(storePrice.getPriceTypeFlag()).orElse(EMPTY_STR);
			refPrice = Optional.ofNullable(storePrice.getRefPrice()).orElse(0.0);
		}

		if (TENANT_CAFR.equalsIgnoreCase(user.getTenant())) {
			if (null != clusterPrice && VKP0.equalsIgnoreCase(priceType) && price.equals(refPrice)) {
				price = clusterPrice;
			}
		} else {
			if (null != clusterPrice && VKP0.equalsIgnoreCase(priceType) && price.equals(nPrice)) {
				return clusterPrice;
			}
		}
		return price;
	}

	@Cacheable(value = N_PRICE_CACHE, key = "{#product.ean, #product.salesUnit}")
	public Double findActiveNationalPriceFromProduct(final Product product, final String tenant) {
		if (TENANT_BDFR.equals(tenant)) {
			StopWatch stopWatch = logService.logStopWatchStart("findActiveNationalPriceFromProduct");
			Set<NationalPrice> nationalPrice = null!=product ? product.getNationalPrices() : new HashSet<>();
			NationalPrice price = CollectionUtils.isNotEmpty(nationalPrice) ? (nationalPrice.stream()
					.filter(nPrice -> DateUtils.isInBetween(nPrice.getStartDate(), nPrice.getEndDate().plusDays(1), LocalDateTime.now()))
					.max(Comparator.comparing(NationalPrice::getLastUpdateTime))
					.orElse(null)): null;
			double stdPrice = price != null ? price.getPrice() : 0.0;
			log.debug("Entered findActiveNationalPriceFromProduct: Tenant {}, nPrice {}", tenant, stdPrice);
			logService.logStopWatchStop(stopWatch);
			return stdPrice;
		}
		return 0.0;
	}

	@Cacheable(value = N_PRICE_CACHE, key = "{#product.ean, #product.salesUnit}")
	public Double findActiveNationalPriceByProduct(final Product product, final String tenant) {
		Double price = 0.0;
		if (TENANT_BDFR.equals(tenant) && null != product) {
			List<NationalPrice> nationalPrice = nationalPriceRepository.findByProduct_EanAndProduct_SalesUnitAndTenant(product.getEan(), product.getSalesUnit(), tenant);
			if (CollectionUtils.isNotEmpty(nationalPrice)) {
				price = nationalPrice.stream()
						.filter(nPrice -> DateUtils.isInBetween(nPrice.getStartDate(), nPrice.getEndDate().plusDays(1), LocalDateTime.now()))
						.max(Comparator.comparing(NationalPrice::getLastUpdateTime))
						.map(NationalPrice::getPrice)
						.orElse(0.0);
				log.debug("Entered findActiveNationalPriceByProductRepo: Ean {}, salesUnit {}, nPrice {}", product.getEan(), product.getSalesUnit(), price);
			}
		}
		return price;
	}

	@Cacheable(value = N_PRICE_CACHE, key = "{#ean, #salesUnit}")
	public double findActiveNationalPriceByEan(final String ean, final String salesUnit) {
		double price = 0.0;
		List<NationalPrice> nationalPrice = nationalPriceRepository.findByProduct_EanAndProduct_SalesUnit(ean, salesUnit);
		if (CollectionUtils.isNotEmpty(nationalPrice)) {
			price = nationalPrice.stream()
					.filter(nPrice -> DateUtils.isInBetween(nPrice.getStartDate(), nPrice.getEndDate().plusDays(1), LocalDateTime.now()))
					.max(Comparator.comparing(NationalPrice::getLastUpdateTime))
					.map(NationalPrice::getPrice)
					.orElse(0.0);
			log.debug("Entered findActiveNationalPriceByEan: Ean {}, salesUnit {}, nPrice {}", ean, salesUnit, price);
		}
		return price;
	}

	@Cacheable(value = STORE_PRICE_CACHE, key = "{#ean, #storeCode}")
	public StorePrice findActiveStorePriceByEanFromRepo(final String ean, final String storeCode) {
		log.debug("Entered findActiveStorePriceByEanFromRepo: ean {}, storeCode {}", ean, storeCode);
		List<StorePrice> storePrices = storePriceRepo.findByStore_StoreCodeAndEan(storeCode, ean);
		if (CollectionUtils.isNotEmpty(storePrices)) {
			return storePrices.stream()
					.filter(sPrice -> DateUtils.isInBetween(sPrice.getStartDate(), sPrice.getEndDate().plusDays(1), LocalDateTime.now()))
					.max(Comparator.comparing(StorePrice::getLastUpdateTime))
					.orElse(new StorePrice());
		} else { return new StorePrice(); }
	}

	public String getPriceType(final String sType) {
		if (VKP0.equalsIgnoreCase(sType)) {
			return "Prix Standard";
		} else if (VKA0.equalsIgnoreCase(sType)) {
			return "Prix Promo";
		} else {
			return "Prix déréférencé";
		}
	}

	public Map<String, StorePrice> getEanStorePriceMap(final List<Product> products, List<String> listOfEan, final Store store) {
		StopWatch stopWatch = logService.logStopWatchStart("getEanStorePriceMap");
		Map<String, StorePrice> eanStorePriceMap = new HashMap<>();

		if (CollectionUtils.isEmpty(listOfEan)) {
			listOfEan = products.stream().map(Product::getEan).toList();
		}

		var storePrices = findStorePricesByListOfEanAndStore(listOfEan, store);
		if (CollectionUtils.isNotEmpty(storePrices)) {
			getEanStorePriceMapFromStorePrices(eanStorePriceMap, storePrices);
		}
		logService.logStopWatchStop(stopWatch);
		return eanStorePriceMap;
	}

	public Map<Product, StorePrice> getProductStorePriceMap(final List<Product> products, final Store store) {
		StopWatch stopWatch = logService.logStopWatchStart("getProductStorePriceMap");
		Map<Product, StorePrice> productStorePriceMap = new HashMap<>();
		var eanStorePriceMap = getEanStorePriceMap(products, List.of(), store);
		products.stream()
				.filter(product -> eanStorePriceMap.containsKey(product.getEan()))
				.forEach(product -> productStorePriceMap.put(product, eanStorePriceMap.get(product.getEan())));
		logService.logStopWatchStop(stopWatch);
		return productStorePriceMap;
	}

	private void getEanStorePriceMapFromStorePrices(Map<String, StorePrice> eanStorePriceMap, final List<StorePrice> listOfStorePrices) {
		Map<String, List<StorePrice>> eanStorePricesMap = listOfStorePrices.stream().collect(Collectors.groupingBy(StorePrice::getEan));
		eanStorePricesMap.forEach((ean, storePrices) -> {
			var storePriceOptional = storePrices.stream()
					.filter(storePrice -> DateUtils.isInBetween(storePrice.getStartDate(), storePrice.getEndDate().plusDays(1), LocalDateTime.now()))
					.filter(storePrice -> storePrice.getPrice() > 0)
					.max(Comparator.comparing(StorePrice::getLastUpdateTime));
			storePriceOptional.ifPresent(storePrice -> eanStorePriceMap.put(ean, storePrice));
		});
	}

}