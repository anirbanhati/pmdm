package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Inflation;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.repository.InflationRepository;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class InflationMessageService {

    private final InflationRepository inflationRepository;
    private final StoreService storeService;


    public void createInflationData(List<String[]> inflationDataList) {
        inflationDataList.forEach(this::saveInflationData);
    }

    private void saveInflationData(String[] modifiedInflationData) {
        if (StringUtils.isNotEmpty(modifiedInflationData[0]) && StringUtils.isNotEmpty(modifiedInflationData[1])) {
            Store store = storeService.getStoreByCode(modifiedInflationData[0]);
            Inflation inflation = new Inflation();
            if (null != store) {
                inflation.setStore(store);
                inflation.setArticleNumber(modifiedInflationData[1]);
                if (StringUtils.isNotEmpty(modifiedInflationData[3])) {
                    String startDate = modifiedInflationData[3].substring(0, 4) + "-" + modifiedInflationData[3].substring(4, 6) + "-" + modifiedInflationData[3].substring(6, 8);
                    inflation.setStartDate(DateUtils.formattedDate(startDate));
                }
                if (StringUtils.isNotEmpty(modifiedInflationData[4])) {
                    inflation.setStoreAcquisitionCost(Double.valueOf(modifiedInflationData[4]));
                }
                inflation.setCurrency(modifiedInflationData[5]);
                inflation.setLastUpdatedDate((LocalDateTime.now()));
                inflationRepository.save(inflation);
            } else {
                log.info("Store Code Not Available In DB :: {}", modifiedInflationData[0]);
            }
        } else {
            log.info("Empty Store Code Provided In The File");
        }
    }

}