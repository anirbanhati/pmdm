package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.configuration.ChangeRequestConfiguration;
import com.kingfisher.compprice.dao.*;
import com.kingfisher.compprice.dao.entity.*;
import com.kingfisher.compprice.dao.response.CategoryRoundingResponse;
import com.kingfisher.compprice.exception.DetailsNotFoundException;
import com.kingfisher.compprice.exception.ExceptionConstants.ExcelImportExceptions;
import com.kingfisher.compprice.repository.ImportErrorsRepository;
import com.kingfisher.compprice.service.*;
import com.kingfisher.compprice.dao.ExcelError;
import com.kingfisher.compprice.dao.ExcelValidation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.Map.Entry;

import static com.kingfisher.compprice.util.constants.Constants.*;
import static com.kingfisher.compprice.util.constants.FeedConstants.FORWARD_SLASH;

@Component
@RequiredArgsConstructor
@Slf4j
public class PriceExcelPrepHelper {

	public static final String CONSTANT_1 = "Article non ouvert à la modification de prix";
	public static final String POUR_L_EAN = "Pour l'EAN ";
	private static final String[] HEADERS = { "Code article", "Libellé", "Magasin", "Nom du relevé",
			"Magasin concurrent", "Date relevé", "EAN concurrent", "Code article concurrent", "Commentaire", "Promo",
			"Conditionnement", "Conditionnement relevé", "Prix standard", "Unité légale",
			"Prix relevé en unité de vente", "Prix local créé", "Date début" };
	private static final String[] DELTA_HEADERS = { "EAN", "Prix", "Date de début", "Date de fin" };
	private static final String[] IMPORT_ERRORS_HEADERS = { "Numéro de ligne du fichier", "EAN", "les erreurs" };
	private static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
	private static final String DATE_FORMAT_MMDDHHMM = "MM-dd HH:mm";
	private static final String LSP_IMPORT_ERRORS_SHEET = "Lsp Import Errors";

	private final ImportErrorsRepository importErrorsRepository;
	private final StoreCollectionService scService;
	private final StoreService storeService;
	private final PriceUpdateService priceUpdateService;
	private final AssignmentItemService assignmentItemService;
	private final StorePriceService storePriceService;
	private final StoreProductService storeProductService;
	private final ClusterPriceService clusterPriceService;
	private final ProductTools productTools;
	private final ProductListingService productListingService;
	private final CompetitorProductService competitorProductService;
	private final ChangeRequestConfiguration crConfig;


	@Transactional
	public Map<String, List<ExcelData>> getPriceUpdateData(final User user) {
		return excelDataForPriceUpdate(priceUpdateService.getPriceUpdates(user.getTenant()), user);
	}

	@Transactional
	public Map<String, List<ExcelData>> getPriceUpdateDataForStore(final User user, final String storeCode) {
		return excelDataForPriceUpdate(priceUpdateService.getPriceUpdatesByStore(user.getTenant(),
				storeService.getStoreByCode(storeCode)), user);
	}

	private Map<String, List<ExcelData>> excelDataForPriceUpdate(final Set<PriceUpdate> priceUpdates, final User user) {
		log.info("Total price update records (Before):: {}", priceUpdates.size());
		final List<CollectionProduct> cProducts = new ArrayList<>();
		CategoryRoundingResponse cRounding = new CategoryRoundingResponse();
		Set<StoreCollection> scSet = new HashSet<>();
		priceUpdates.forEach(priceUpdate -> scSet.addAll(priceUpdate.getStoreCollection()));
		List<Long> collectionIds = scSet.stream().map(StoreCollection::getId).toList();

		var products = priceUpdates.stream().map(PriceUpdate::getProduct).toList();
		var listOfEan = productTools.getListOfEanFromProducts(products);
		var eanStorePriceMap = storePriceService.getEanStorePriceMap(products, listOfEan, user.getStore());
		var productStoreProductMap = storeProductService.getProductStoreProductMap(products, listOfEan, user);
		var validPrdListingMap = productListingService.validateProductListing(products, listOfEan, user.getStore());
		var eanClusterPriceMap = clusterPriceService.getEanClusterPriceMap(listOfEan, user);
		var eanWithCompNameCompProductMap = competitorProductService.getEanWithCompNameCompProductMap(listOfEan, collectionIds);
		MasterData masterData = MasterData.builder().
				eanStorePriceMap(eanStorePriceMap).productStoreProductMap(productStoreProductMap).validPrdListingMap(validPrdListingMap).
				eanwithCompNameCompProductMap(eanWithCompNameCompProductMap).eanClusterPriceMap(eanClusterPriceMap).build();

		for (final PriceUpdate pUpdate : priceUpdates) {
			final DesiredPrice priceDetails = new DesiredPrice();
			priceDetails.setPrice(pUpdate.getPrice());
			priceDetails.setStartDate(pUpdate.getStartDate());
			final Set<StoreCollection> storeCollections = pUpdate.getStoreCollection();

			if (CollectionUtils.isNotEmpty(storeCollections)) {
				final Product product = pUpdate.getProduct();
				final CollectionProduct cProduct = new CollectionProduct();
				cProduct.setAssignments(assignmentItemService.getCollectedItems(masterData, storeCollections, product, user));
				cProduct.setProduct(scService.prepareScProductResponse(product, cRounding, user, masterData));
				cProduct.setPrice(priceDetails);
				cProducts.add(cProduct);
			}
		}
		log.info("Total price updates records (After):: {}", cProducts.size());
		return this.prepareListForExport(cProducts);
	}

	private Map<String, List<ExcelData>> prepareListForExport(List<CollectionProduct> cProducts) {
		final Map<String, List<ExcelData>> eanExcelDataMap = new TreeMap<>();
		for (final CollectionProduct cProduct : cProducts) {
			if (!eanExcelDataMap.containsKey(cProduct.getProduct().getProductCode())) {
				final List<ExcelData> excelData = new ArrayList<>();
				for (final CollectionAssginment data : cProduct.getAssignments()) {
					final ExcelData excel = this.prepareExcelObjects(cProduct, data);
					excelData.add(excel);
					eanExcelDataMap.put(cProduct.getProduct().getProductCode(), excelData);
				}
			} else {
				final List<ExcelData> excelDataList = eanExcelDataMap.get(cProduct.getProduct().getProductCode());
				for (final CollectionAssginment data : cProduct.getAssignments()) {
					final ExcelData excel = this.prepareExcelObjects(cProduct, data);
					excelDataList.add(excel);
					eanExcelDataMap.put(cProduct.getProduct().getProductCode(), excelDataList);
				}
			}
		}
		return eanExcelDataMap;
	}

	private ExcelData prepareExcelObjects(final CollectionProduct cProduct, final CollectionAssginment data) {
		final ExcelData excel = new ExcelData();
		excel.setProductCode(cProduct.getProduct().getProductCode());
		excel.setProductDesc(cProduct.getProduct().getDescription());
		excel.setStoreCode(data.getStoreCode());
		excel.setClName(data.getName());
		excel.setCompName(data.getCompititorName());
		excel.setCreationTime(data.getCreationTime());
		excel.setCEan(data.getEan());
		excel.setCArticleCode(data.getArticleCode());
		excel.setNotes(data.getNotes());
		excel.setHasPromo(data.isHasPromo() ? "vrai" : "faux");
		excel.setPkg(cProduct.getProduct().getPackaging());
		excel.setCPkg(data.getPkg());
		excel.setStdPrice(StringUtils.replace(Double.toString(cProduct.getProduct().getStandardPrice()), DOT_SEPARATOR, COMMA_SEPARATOR));
		excel.setUnit(cProduct.getProduct().getUnit());
		excel.setCPrice(StringUtils.replace(Double.toString(data.getPrice()), DOT_SEPARATOR, COMMA_SEPARATOR));
		excel.setDPrice(StringUtils.replace(Double.toString(cProduct.getPrice().getPrice()), DOT_SEPARATOR, COMMA_SEPARATOR));
		excel.setDStartDate(this.getFormattedDateTime(cProduct.getPrice().getStartDate()));
		return excel;
	}

	@Transactional
	public ByteArrayInputStream prepareFileData(final String tenant, final String ref, final String storeCode) {
		final List<PriceUpdate> priceUpdates = priceUpdateService.getDeltaPriceUpdates(tenant, ref);
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			final Sheet sheet = workbook.createSheet("store data");

			final Row headerRowRef = sheet.createRow(0);
			headerRowRef.createCell(0).setCellValue("Référence fichier");
			headerRowRef.createCell(1).setCellValue(storeCode + UNDER_SCORE + this.getFormattedDateTimeForSave());

			sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 3));
			// Header
			final Row headerRow = sheet.createRow(1);
			for (int col = 0; col < DELTA_HEADERS.length; col++) {
				final Cell cell = headerRow.createCell(col);
				cell.setCellValue(DELTA_HEADERS[col]);
			}
			int rowIdx = 2;
			for (final PriceUpdate csvData : priceUpdates) {
				final Row row = sheet.createRow(rowIdx);
				row.createCell(0).setCellValue(csvData.getProduct().getEan());
				row.createCell(1).setCellValue(StringUtils.replace(Double.toString(csvData.getPrice()), DOT_SEPARATOR, COMMA_SEPARATOR));
				row.createCell(2).setCellValue(this.getDateFromDateTime(csvData.getStartDate()));
				row.createCell(3).setCellValue(this.getDateFromDateTime(csvData.getEndDate()));
				rowIdx++;
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (final IOException e) {
			throw new DetailsNotFoundException(ExcelImportExceptions.EXCEL_IMPORT_APP_EXP,
					ExcelImportExceptions.EXCEL_IMPORT_HTTP_STATUS, ExcelImportExceptions.EXCEL_IMPORT_DETAILS,
					"Ref export", ExcelImportExceptions.EXCEL_IMPORT_POINTER, "Export",
					ExcelImportExceptions.EXCEL_IMPORT_TITLE);
		}
	}

	public ByteArrayInputStream prepareFileDataForBulk(Map<String, List<ExcelData>> excelData) {

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			final Sheet sheet = workbook.createSheet("All data");
			final Row headerRow = sheet.createRow(0);
			for (int col = 0; col < HEADERS.length; col++) {
				final Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERS[col]);
			}
			int rowIdx = 1;

			for (final Entry<String, List<ExcelData>> entry : excelData.entrySet()) {
				final List<ExcelData> listOfData = entry.getValue();
				listOfData.sort(Comparator.comparing(ExcelData::getCreationTime).reversed()
						.thenComparing(ExcelData::getStoreCode)
						.thenComparing(ExcelData::getCompName, String.CASE_INSENSITIVE_ORDER));

				if (CollectionUtils.isNotEmpty(listOfData)) {
					for (final ExcelData data : listOfData) {
						final Row row = sheet.createRow(rowIdx);
						row.createCell(0).setCellValue(data.getProductCode());
						row.createCell(1).setCellValue(data.getProductDesc());
						row.createCell(2).setCellValue(data.getStoreCode());
						row.createCell(3).setCellValue(data.getClName());
						row.createCell(4).setCellValue(data.getCompName());
						row.createCell(5).setCellValue(getFormattedDateTime(data.getCreationTime()));
						row.createCell(6).setCellValue(data.getCEan());
						row.createCell(7).setCellValue(data.getCArticleCode());
						row.createCell(8).setCellValue(data.getNotes());
						row.createCell(9).setCellValue(data.getHasPromo());
						row.createCell(10).setCellValue(data.getPkg());
						row.createCell(11).setCellValue(data.getCPkg());
						row.createCell(12).setCellValue(data.getStdPrice());
						row.createCell(13).setCellValue(data.getUnit());
						row.createCell(14).setCellValue(data.getCPrice());
						row.createCell(15).setCellValue(data.getDPrice());
						row.createCell(16).setCellValue(data.getDStartDate());
						rowIdx++;
					}
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (final IOException e) {
			throw new DetailsNotFoundException(ExcelImportExceptions.EXCEL_IMPORT_APP_EXP,
					ExcelImportExceptions.EXCEL_IMPORT_HTTP_STATUS, ExcelImportExceptions.EXCEL_IMPORT_DETAILS,
					"bulk export", ExcelImportExceptions.EXCEL_IMPORT_POINTER, EXPORT,
					ExcelImportExceptions.EXCEL_IMPORT_TITLE);
		}
	}

	private String getFormattedDateTime(LocalDateTime dateTime) {
		final SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
		return formatter.format(Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant()));
	}

	private String getDateFromDateTime(final LocalDateTime dateTime) {
		final SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
		final String format = formatter.format(Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant()));
		return StringUtils.replace(format, FORWARD_SLASH, DOT_SEPARATOR);
	}

	private String getFormattedDateTimeForSave() {
		final SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_MMDDHHMM);
		log.info("Export time is : {}", LocalDateTime.now().plusHours(2).atZone(ZoneId.systemDefault()).toInstant());
		final String formattedDate = formatter
				.format(Date.from(LocalDateTime.now().plusHours(2).atZone(ZoneId.systemDefault()).toInstant()));
		return formattedDate.replace(HYPHEN_SEPARATOR, EMPTY_STR).replace(" ", UNDER_SCORE).replace(COLON_SEPARATOR, EMPTY_STR);
	}

	public ByteArrayInputStream prepareImportErrorsFile(final String errorKey) {
		ImportErrors importErrors = importErrorsRepository.findByErrorKey(errorKey).orElse(null);
		try (SXSSFWorkbook workbook = new SXSSFWorkbook(102); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			final SXSSFSheet sheet = workbook.createSheet(LSP_IMPORT_ERRORS_SHEET);
			setColumnHeaders(sheet);
			setColumnWidthForImport(sheet);
			setErrorMessages(importErrors, workbook, sheet);
			log.info("prepareImportErrorsFile:: Total number of cell styles:: {}", workbook.getNumCellStyles());
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (final IOException e) {
			log.error("prepareImportErrorsFile --> {}", e.getMessage());
			throw new DetailsNotFoundException(ExcelImportExceptions.EXCEL_IMPORT_APP_EXP,
					ExcelImportExceptions.EXCEL_IMPORT_HTTP_STATUS, ExcelImportExceptions.EXCEL_IMPORT_DETAILS,
					ExcelImportExceptions.EXCEL_IMPORT_ID, ExcelImportExceptions.EXCEL_IMPORT_KEY_POINTER,
					errorKey, ExcelImportExceptions.EXCEL_IMPORT_TITLE);
		}
	}

	private void setColumnHeaders(final SXSSFSheet sheet) {
		final Row headerRow = sheet.createRow(0);
		for (int column = 0; column < IMPORT_ERRORS_HEADERS.length; column++) {
			final Cell cell = headerRow.createCell(column);
			cell.setCellValue(IMPORT_ERRORS_HEADERS[column]);
		}
	}

	private void setErrorMessages(final ImportErrors importErrors, final SXSSFWorkbook workbook, final SXSSFSheet sheet) throws IOException {
		final CellStyle style = createStyleForImportErrors(workbook);
		if (null != importErrors) {
			int rowNo = 1;
			for (final ExcelValidation excelError : importErrors.getErrorJson().getPricelistErrors()) {
				final Row row = sheet.createRow(rowNo++);

				List<String> errorMessages = excelError.getErrors().stream()
						.map(error -> getErrorMessages(excelError.getEan(), error.getCValue(), error)).toList();
				row.setHeightInPoints(15f * errorMessages.size());

				final Cell cell0 = row.createCell(0);
				cell0.setCellValue(String.valueOf(excelError.getRowNum()));
				final Cell cell1 = row.createCell(1);
				cell1.setCellValue(excelError.getEan());
				final Cell cell2 = row.createCell(2);
				cell2.setCellValue(String.join(NEW_LINE_SEPARATOR, errorMessages));

				setStyleForImportErrors(cell0, cell1, cell2, style);

				if (rowNo % 101 == 0) {
					sheet.flushRows(102);
				}
			}
		}
	}

	private CellStyle createStyleForImportErrors(final SXSSFWorkbook workbook) {
		final CellStyle style = workbook.createCellStyle();
		style.setVerticalAlignment(VerticalAlignment.TOP);
		style.setWrapText(true);
		return style;
	}

	private void setColumnWidthForImport(final SXSSFSheet sheet) {
		sheet.setColumnWidth(0, 7000);
		sheet.setColumnWidth(1, 4500);
		sheet.setColumnWidth(2, 20000);
	}

	private void setStyleForImportErrors(final Cell cell0, final Cell cell1, final Cell cell2, final CellStyle style) {
		cell0.setCellStyle(style);
		cell1.setCellStyle(style);
		cell2.setCellStyle(style);
	}

	private String getErrorMessages(final String ean, final String cValue, final ExcelError error) {
		Map<String, String> errorIdWithErrorMsgMap = new HashMap<>();

		errorIdWithErrorMsgMap.put("LSP_BU_DE_02", "Type d’article invalide");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_03", "L’EAN n’est pas défini comme un EAN de vente");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_04", "EAN non renseigné");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_05", "EAN invalide");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_06", "Prix de vente non renseigné");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_08", "Date non renseignée");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_09", "Date invalide");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_10", "L’EAN n’est pas défini comme un EAN de vente");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_14", "La date de fin doit être supérieure à la date de début");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_17", "En-tête invalide");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_20", "L'article ne fait partie de la liste de guerre, il n'est pas modifiable");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_21", "La date de fin doit être comprise entre la date de début et la date de début + 60 si le product type est PVMax/PVLocal");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_22", "Les articles PV Max ne doivent pas être modifiables dans le module LSP");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_27", "PV Max, modification du prix impossible");
		errorIdWithErrorMsgMap.put("LSP_BU_DE_29", "Fixation de prix impossible, article inactif (40,99)");

		if (crConfig.isErrorMsg()) {
			errorIdWithErrorMsgMap.put("LSP_BU_DE_01", "EAN inconnu");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_07", "Format de prix invalide");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_11", "Le prix ne peut pas être supérieur au prix standard national");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_12", "Le prix ne peut pas être inférieur à " + cValue + "€ ni supérieur au prix standard national");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_13", "La date d’application du prix doit être dans le futur (à minima J+1)");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_15", "Le prix ne peut être appliqué que 45 jours maximum. Merci de modifier la date de fin");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_16", "Le fichier est vide");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_18", "Ce produit ne s'applique pas aux prix des magasins locaux");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_19", "Ce produit a un prix fixe, le prix ne peut pas être modifié");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_23", "PRMP absent, le prix ne peut pas être modifié");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_24", "Fixation de prix impossible, article inactif");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_30", "Fixation de prix impossible, article inactif");
		} else {
			errorIdWithErrorMsgMap.put("LSP_BU_DE_01", CONSTANT_1);
			errorIdWithErrorMsgMap.put("LSP_BU_DE_07", "Format de prix incorrect");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_11", POUR_L_EAN + ean + ", le prix ne peut pas être supérieur à xx.xx€ (prix national)");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_12", POUR_L_EAN + ean + ", le prix ne peut pas être inférieur à " + cValue + "€, prix minimal autorisé");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_13", "La date d’application du prix doit être à minima J+1");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_15", "La durée ne doit pas dépasser 45 jours");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_16", "Le fichier à charger est vide");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_18", CONSTANT_1);
			errorIdWithErrorMsgMap.put("LSP_BU_DE_19", "Prix non modifiable, promotion en cours ou à venir");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_23", POUR_L_EAN + ean + ", le prix de vente TTC ne peut pas être inférieur au PRMP+TVA, sauf validation par le DM ou le CGM dans l’outil");
			errorIdWithErrorMsgMap.put("LSP_BU_DE_24", CONSTANT_1);
			errorIdWithErrorMsgMap.put("LSP_BU_DE_30", "Statut article inactif, fixation de prix impossible");
		}

		return errorIdWithErrorMsgMap.getOrDefault(error.getId(), EMPTY_STR);
	}

}