package com.kingfisher.compprice.dao.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

import static com.kingfisher.compprice.util.constants.Constants.COL_PRODUCT_CODE;

@Getter
@Setter
@Entity
@Table(name="lsp_product_listing")
public class ProductListing implements Serializable {

	private static final long serialVersionUID = 4389954043505371226L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

	@Column(name = "ean", nullable = false)
	private String ean;

	@Column(name= "last_updated")
	private LocalDateTime lastUpdated;

	@Column(name = COL_PRODUCT_CODE, nullable = false)
	private String productCode;

	@Column(name = "start_date")
	private LocalDateTime startDate;

	@Column(name = "end_date")
	private LocalDateTime endDate;

}