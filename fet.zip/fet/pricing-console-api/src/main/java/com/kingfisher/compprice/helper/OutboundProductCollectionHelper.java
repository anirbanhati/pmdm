package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.entity.Assignment;
import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dto.outbound.ProductCollectionCSVData;
import com.kingfisher.compprice.enums.PriceValidationStatus;
import com.kingfisher.compprice.repository.AssignmentRepository;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

import static com.kingfisher.compprice.util.constants.Constants.EMPTY_STR;
import static com.opencsv.ICSVWriter.DEFAULT_SEPARATOR;

@Slf4j
@RequiredArgsConstructor
@Component
public class OutboundProductCollectionHelper {

    private static final String FILE_PREFIX = "productCollection";
    private static final String[] OUTBOUND_PROD_COLLECTION_HEADERS = new String[]{"COMP_CODE", "COMP_DESCRIPTION", "EAN",
            "PRICE", "FLAG_PROMO", "DATE_CREATION", "SALES_ORG", "STORE_CODE", "ARTICLE_CODE", "UOM"};


    private final AssignmentRepository assignmentRepository;
    private final MessageServiceTools messageServiceTools;
    private final StoreService storeService;

    public Map<File,String> getOutboundProductCollectionFileForBucketUpload() throws IOException {
        final List<ProductCollectionCSVData> csvDataList = prepareFileData(getProductCollectionForOutboundFeed());
        return CollectionUtils.isNotEmpty(csvDataList) ? getPrdCollOutboundCSVFileForUpload(csvDataList) : null;
    }

    private List<Assignment> getProductCollectionForOutboundFeed() {
        List<Assignment> assignments = assignmentRepository.findByMasterDataMissingAndProductCollectionExtracted(true,false);
        if (CollectionUtils.isNotEmpty(assignments)) {
        log.info("Total valid records fetched for processing (Collection) ::{}", assignments.size());
            assignments.forEach(assignment -> {
                log.info("Updating the status for record (Collection) ::{} to ::{}", assignment.getId(), PriceValidationStatus.EXTRACTED);
                assignment.setProductCollectionExtracted(true);
                assignment.setProductCollectionExtractedDate(LocalDateTime.now());
            });
            assignmentRepository.saveAll(assignments);
        }
        else
            log.info("No valid record found for processing product collection details to be extracted");
        return assignments;
    }

    public List<ProductCollectionCSVData> prepareFileData(final List<Assignment> assignments) {
        final List<ProductCollectionCSVData> productCollectionCSVData = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(assignments)) {
            assignments.forEach(assignment -> productCollectionCSVData.add(getProdCollectionCSVData(assignment)));
        }
        return productCollectionCSVData;
    }

    private ProductCollectionCSVData getProdCollectionCSVData(final Assignment assignment) {
        final CompetitorStore compStore = storeService.getCompetitorStoreData(assignment.getStoreCollection());
        String compCode = null;
        String compDescription = null;
        if (null != compStore) {
            compCode = compStore.getCode();
            compDescription = compStore.getLongName();
        }
        final String storeCode = Optional.ofNullable(assignment.getStoreCollection()).isPresent() ? assignment.getStoreCollection().getStoreCode() : EMPTY_STR;
        final Product product = Optional.ofNullable(assignment.getProduct()).orElse(new Product());
        return new ProductCollectionCSVData(compCode, compDescription, assignment.getCollectedEan(),
                assignment.getCollectedPrice(), String.valueOf(assignment.isHasPromo() ? 1 : 0), LocalDateTime.now(),
                assignment.getTenant(), storeCode, Optional.ofNullable(product.getProductCode()).orElse(EMPTY_STR),
                assignment.getCollectedPkgUnit(), Optional.ofNullable(product.getSalesUnit()).orElse(EMPTY_STR));
    }

    private Map<File, String> getPrdCollOutboundCSVFileForUpload(final List<ProductCollectionCSVData> productCollectionData) throws IOException {
        Map<File, String> fileTenantMap = new HashMap<>();
        final String salesOrg = messageServiceTools.getSalesOrgFromTenant(productCollectionData.get(0).getTenant());
        if (StringUtils.isNotEmpty(productCollectionData.get(0).getTenant()) && StringUtils.isNotEmpty(salesOrg)) {
            final List<String[]> csvData = prepareOutBoundFeedDataForCSVFile(productCollectionData);
            final File tempFileToUpload = messageServiceTools.getFileToUpload(csvData, FILE_PREFIX, salesOrg, DEFAULT_SEPARATOR);
            fileTenantMap.put(tempFileToUpload, productCollectionData.get(0).getTenant());
        }
        return fileTenantMap;
    }

    private List<String[]> prepareOutBoundFeedDataForCSVFile(final List<ProductCollectionCSVData> productCollectionCSVData) {
        final List<String[]> records = new ArrayList<>();
        records.add(OUTBOUND_PROD_COLLECTION_HEADERS);
        productCollectionCSVData.forEach(outboundData -> records.add(new String[]{outboundData.getCompCode(),
                outboundData.getCompDescription(), outboundData.getEan(), String.valueOf(outboundData.getPrice()),
                outboundData.getPromoFlag(), DateUtils.getValidDateFormatForOutbound(outboundData.getCreationDate()),
                outboundData.getSalesOrg(), outboundData.getStoreCode(), outboundData.getArticleCode(), outboundData.getUom()})
        );
        return records;
    }

}