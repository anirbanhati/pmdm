package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "StoreAssociation")
@XmlAccessorType(XmlAccessType.FIELD)
public class StoreAssociationInfo {

    @XmlElement(name = "compCode")
    String compCode;

    @XmlElement(name = "compDescription")
    String compDescription;

    @XmlElement(name = "storeCode")
    String storeCode;

    @XmlElement(name = "storeDescription")
    String storeDescription;

    @XmlElement(name = "activeFlag")
    String activeFlag;

    public String getCompCode() {
        return compCode;
    }

    public void setCompCode(String compCode) {
        this.compCode = compCode;
    }

    public String getCompDescription() {
        return compDescription;
    }

    public void setCompDescription(String compDescription) {
        this.compDescription = compDescription;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getStoreDescription() {
        return storeDescription;
    }

    public void setStoreDescription(String storeDescription) {
        this.storeDescription = storeDescription;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }
}
