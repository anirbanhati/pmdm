package com.kingfisher.compprice.service;

import com.kingfisher.compprice.dao.entity.CostPrice;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.repository.CostPriceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CostPriceService {

    private final CostPriceRepository costPriceRepository;


    public double getCostPrice(final Store store, final Product product, final String salesOrg) {
        final Optional<CostPrice> costPrices = costPriceRepository.findByStoreAndProductAndSalesOrg(store, product,
                salesOrg);
        return costPrices.map(CostPrice::getCPrice).orElse(0.0);
    }

}