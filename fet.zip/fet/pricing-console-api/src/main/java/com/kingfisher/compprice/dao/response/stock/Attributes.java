package com.kingfisher.compprice.dao.response.stock;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class Attributes {

    String ean;
    String source;
    int stockValue;
    String locationId;
    boolean ranged;

}