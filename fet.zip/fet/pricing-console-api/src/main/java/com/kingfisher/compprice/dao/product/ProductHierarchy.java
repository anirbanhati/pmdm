package com.kingfisher.compprice.dao.product;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductHierarchy {

    private String cat;
    private String sCat;
    private String brick;
    private String bCode;

}
