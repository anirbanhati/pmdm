package com.kingfisher.compprice.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ProductTaxClassifications")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductTaxClassifications {

    @XmlElement(name = "ProductTaxClassification")
    private List<ProductTaxClassification> productTaxClassification;

    public List<ProductTaxClassification> getProductTaxClassification() {
        return productTaxClassification;
    }

    public void setProductTaxClassification(List<ProductTaxClassification> productTaxClassifications) {
        this.productTaxClassification = productTaxClassifications;
    }



}
