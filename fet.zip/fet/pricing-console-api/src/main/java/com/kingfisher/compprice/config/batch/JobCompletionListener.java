package com.kingfisher.compprice.config.batch;

import com.kingfisher.compprice.service.outbound.S3OutboundLoadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import java.io.File;

import static com.kingfisher.compprice.util.constants.Constants.OUTPUT_FILE_NAME;

@Slf4j
@RequiredArgsConstructor
public class JobCompletionListener implements JobExecutionListener {

    private final S3OutboundLoadService s3OutboundLoadService;


    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.debug(":Batch: JobCompletionListener: Before Job");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        String outPutFileName = jobExecution.getJobParameters().getString(OUTPUT_FILE_NAME);

        if (BatchStatus.COMPLETED.equals(jobExecution.getStatus())) {
            assert outPutFileName != null;
            s3OutboundLoadService.uploadFileToS3Bucket(new File(outPutFileName));
            log.info(":Batch: JobExecution status--> {} & File Uploaded for filName --> {}", jobExecution.getStatus(), outPutFileName);
        } else {
            log.info(":Batch: JobExecution status--> {} :::", jobExecution.getStatus());
        }
    }

}