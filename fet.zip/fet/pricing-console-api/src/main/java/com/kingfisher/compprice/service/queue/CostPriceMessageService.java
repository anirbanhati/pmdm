package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.CostPrice;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dto.StoreCostPrices;
import com.kingfisher.compprice.dto.StoreCostPricesInfo;
import com.kingfisher.compprice.repository.CostPriceRepository;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.COST_PRICE_SERVICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class CostPriceMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final CostPriceRepository costPriceRepository;
    private final MessageServicesHelper messageServicesHelper;


    @Override
    public ProcessedByType getProcessedBy() {
        return COST_PRICE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        if (isLoggingEnabled) {
            log.info("Cost Price Feed :: {}", message);
        }
        final String methodName = "processMessage";
        try {
            log.info("Start processing message {}::{}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message {}::{}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata)
            throws JAXBException {
        StoreCostPrices costPriceFeed = getCostPriceFeed(messageMetadata);
        Optional.ofNullable(costPriceFeed).ifPresent(cpf -> cpf.getStorePricesInfoList().forEach(this::saveCostPriceFeedToRepository));
    }

    private StoreCostPrices getCostPriceFeed(String message) throws JAXBException {
        final String methodName = "getCostPriceFeed()";
        StoreCostPrices costPrices = null;
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(StoreCostPrices.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            costPrices = (StoreCostPrices) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting ::{} :: method name ::{} ", this.getClass().getSimpleName(), methodName);
        return costPrices;

    }

    @Transactional
    public void saveCostPriceFeedToRepository(StoreCostPricesInfo storePricesInfo) {
        final String methodName = "saveCostPriceFeedToRepository()";
        log.debug("Entering ::{} :: Method:: {}", this.getClass().getSimpleName(), methodName);
        addOrUpdateCostPriceFeedDetailsIntoRepository(storePricesInfo);
        log.debug("Exiting ::{} :: Method:: {}", this.getClass().getSimpleName(), methodName);

    }

    private void addOrUpdateCostPriceFeedDetailsIntoRepository(StoreCostPricesInfo costPricesInfo) {
        Product savedProduct = messageServicesHelper.getProductByEanAndSalesUnit(costPricesInfo.getEan(), costPricesInfo.getSalesOrg());
        Store storeData = messageServicesHelper.findStoreByStoreCode(costPricesInfo.getStoreCode());
        Product product = Optional.ofNullable(savedProduct).isPresent() ? savedProduct : messageServicesHelper.createProduct
                (costPricesInfo.getEan(), costPricesInfo.getArticleNumber(), costPricesInfo.getSalesOrg());
        if (Optional.ofNullable(storeData).isPresent()) {
            addStorePriceCostDetailsInRepository(costPricesInfo, storeData, product);
        } else {
            log.info("Invalid StoreCode in Store Cost price  feed :: {}", costPricesInfo.getStoreCode());
        }
    }

    private void addStorePriceCostDetailsInRepository(StoreCostPricesInfo costPricesInfo, Store store, Product product) {
        CostPrice existingCostPrice = getExistingCostPrice(product, store, costPricesInfo.getSalesOrg());
        if (Optional.ofNullable(existingCostPrice).isPresent()) {
            updateCostPriceDetailsInRepository(existingCostPrice, costPricesInfo);
        } else {
            saveCostPriceDetailsInRepository(costPricesInfo, product, store);
        }
    }

    private void updateCostPriceDetailsInRepository(CostPrice costPrice, StoreCostPricesInfo costPricesInfo) {
        costPrice.setCPrice(costPricesInfo.getCostPrice());
        costPrice.setVendor(costPricesInfo.getVendor());
        costPrice.setLastUpdated(LocalDateTime.now());
        costPriceRepository.save(costPrice);
    }

    private CostPrice getExistingCostPrice(Product product, Store store, String salesOrg) {
        Optional<CostPrice> storeCostPrice = costPriceRepository.findByStoreAndProductAndSalesOrg(store, product, salesOrg);
        return storeCostPrice.orElse(null);
    }

    private void saveCostPriceDetailsInRepository(StoreCostPricesInfo storePricesInfo, Product product, Store store) {
        CostPrice costPrice = new CostPrice();
        costPrice.setProduct(product);
        costPrice.setStore(store);
        costPrice.setLastUpdated(LocalDateTime.now());
        costPrice.setSalesOrg(storePricesInfo.getSalesOrg());
        costPrice.setVendor(storePricesInfo.getVendor());
        costPrice.setCPrice(storePricesInfo.getCostPrice());
        costPriceRepository.save(costPrice);
    }

}