package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StoreProduct;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRODUCT_CACHE;

@Repository
public interface StoreProductRepository extends JpaRepository<StoreProduct, Long> {

    Set<StoreProduct> findByStoreAndProduct(final Store store, final Product product);

    Set<StoreProduct> findByProduct(final Product product);

    List<StoreProduct> findByPrdTypeIsNull();

    @Cacheable(value = STORE_PRODUCT_CACHE, key = "{#product.ean, #store.storeCode}")
    StoreProduct findTopByStoreAndProduct(final Store store, final Product product);

    Set<StoreProduct> findByStoreAndProduct_EanIn(final Store store, final List<String> listOfEan);

}