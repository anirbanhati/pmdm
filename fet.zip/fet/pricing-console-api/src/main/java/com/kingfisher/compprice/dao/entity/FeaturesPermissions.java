package com.kingfisher.compprice.dao.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import static com.kingfisher.compprice.util.constants.Constants.DESCRIPTION;

@Entity
@Table(name = "features_permissions")
@Getter
@Setter
public class FeaturesPermissions implements Serializable {

    private static final long serialVersionUID = -7486757682914227976L;
    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "features_permissions_id", unique = true, nullable = false)
    private long id;

    @JsonProperty("desc")
    @Column(name = DESCRIPTION)
    private String functionDescription;

    @JsonProperty("name")
    @Column(name = "features_permissions_name")
    private String featuresPermissionsName;

    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST,
            CascadeType.MERGE}, mappedBy = "featurePermissions")
    @JsonIgnore
    private Set<UserCode> userCode = new HashSet<>();

}