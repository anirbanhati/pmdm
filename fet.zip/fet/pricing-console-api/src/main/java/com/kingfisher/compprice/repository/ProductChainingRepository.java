package com.kingfisher.compprice.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.ProductChainingInfo;

@Repository
public interface ProductChainingRepository extends JpaRepository<ProductChainingInfo,Long> {

	Optional<ProductChainingInfo> findByProduct(final Product product);

	Optional<Set<ProductChainingInfo>> findByGroupingCodeAndDeleteFlagNotIn(final String gCode, final List<String> deleteFlag);

}