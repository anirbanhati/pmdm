package com.kingfisher.compprice.dao.product;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
public class SubCategory implements Serializable {

	private static final long serialVersionUID = -1596379055716860726L;

	private String name;
	private List<Brick> bricks;
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final SubCategory other = (SubCategory) obj;
		if (this.bricks == null) {
			if (other.bricks != null) {
				return false;
			}
		} else if (!this.bricks.equals(other.bricks)) {
			return false;
		}
		if (this.name == null) {
            return other.name == null;
		} else
            return this.name.equals(other.name);
    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.bricks == null) ? 0 : this.bricks.hashCode());
		result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
		return result;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Brick> getBricks() {
		this.bricks.sort(Comparator.comparing(Brick::getName, String.CASE_INSENSITIVE_ORDER));
		return this.bricks;
	}
	public void setBricks(List<Brick> bricks) {
		this.bricks = bricks;
	}

	public void addBrick(Brick brick){
		if(this.bricks==null){
			this.bricks=new ArrayList<>();
		}
		this.bricks.add(brick);
	}

	public Boolean brickByNameIsPresent(String brickName){
		if(this.bricks!=null){
		return 	this.bricks.stream().anyMatch(e-> e.getName().equalsIgnoreCase(brickName));
	}else{
			return false;
		}
	}
	public Boolean brickByCodeIsPresent(String brickCode){
		if(this.bricks!=null){
			return 	this.bricks.stream().anyMatch(e-> e.getName().equalsIgnoreCase(brickCode));
		}else{
			return false;
		}
	}
}
