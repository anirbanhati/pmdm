package com.kingfisher.compprice.controller;

import com.kingfisher.compprice.controller.swagger.EvictCacheControllerSwagger;
import com.kingfisher.compprice.schedule.CacheEvictScheduler;
import com.kingfisher.compprice.service.CacheService;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RestController
@RequestMapping(CACHE_BASE_URL)
@RequiredArgsConstructor
@Hidden
public class EvictCacheController implements EvictCacheControllerSwagger {

    private final CacheService cacheService;
    private final CacheEvictScheduler cacheEvictScheduler;


    @Override
    @DeleteMapping(URI_CACHE_NAME)
    public ResponseEntity<String> clearCache(@PathVariable(CACHE_NAME) final String cacheName) {
        log.info("EvictCache: clearCache --> {}", cacheName);
        cacheService.clearCacheByName(cacheName);
        return new ResponseEntity<>(cacheName + " cleared.", HttpStatus.OK);
    }

    @Override
    @DeleteMapping
    public ResponseEntity<String> clearCacheByNameAndKeys(@NotNull @RequestParam(CACHE_NAME) final String cacheName,
                                                          @NotNull @RequestParam final String key1,
                                                          @RequestParam(required = false) final String key2) {
        log.info("EvictCache: clearCacheByNameAndKeys --> {}, {}, {}", cacheName, key1, key2);
        cacheService.clearCacheByKeys(cacheName, key1, key2);
        return new ResponseEntity<>(cacheName + " cleared by Key: " + key1 + ", " + key2, HttpStatus.OK);
    }

    @Override
    @DeleteMapping(path = ALL)
    public ResponseEntity<String> clearAllCache() {
        log.info("EvictCache: clearAllCache");
        cacheEvictScheduler.evictAllCacheValues();
        return new ResponseEntity<>("All cache has been evicted", HttpStatus.OK);
    }

}