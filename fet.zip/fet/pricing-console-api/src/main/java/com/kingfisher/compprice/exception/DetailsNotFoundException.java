package com.kingfisher.compprice.exception;

public class DetailsNotFoundException extends ApplicationException{



	/**
	 *
	 */
	private static final long serialVersionUID = 2199133725521830428L;

	public DetailsNotFoundException(final String applicationErrorCode, final String httpStatusCode, final String detail,
			final String id, final String pointer, final String parameter, final String title) {
		super(applicationErrorCode, httpStatusCode, detail, id, pointer, parameter, title);
	}

}
