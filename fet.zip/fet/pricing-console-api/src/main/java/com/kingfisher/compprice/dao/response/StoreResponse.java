package com.kingfisher.compprice.dao.response;

import com.kingfisher.jsonapi.Resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StoreResponse implements Resource{

	/**
	 *
	 */
	private static final long serialVersionUID = -957628511677307479L;
	private String code;
	private String name;
	private String storeType;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}