package com.kingfisher.compprice.service.queue;

import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dto.PriceInfo;
import com.kingfisher.compprice.dto.Prices;
import com.kingfisher.compprice.repository.StorePriceRepository;
import com.kingfisher.compprice.service.CacheService;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.CacheUtils;
import com.kingfisher.compprice.util.DateUtils;
import com.kingfisher.mq.MqMetricHandler;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

import static com.kingfisher.compprice.service.queue.MessageService.ProcessedByType.PRICE_MESSAGE_SERVICE;
import static com.kingfisher.compprice.util.constants.CacheConstants.N_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.CacheConstants.STORE_PRICE_CACHE;
import static com.kingfisher.compprice.util.constants.Constants.NATIONAL_PRICE;

@Service
@RequiredArgsConstructor
@Slf4j
public class PriceMessageService implements MessageService {

    @Value("${enabled.logging}")
    private boolean isLoggingEnabled;
    @Value("${enabled.fullfeed}")
    private boolean isFullFeedEnabled;

    private static final ReentrantLock lock = new ReentrantLock();

    private final StorePriceRepository storePriceRepository;
    private final MessageServicesHelper servicesHelper;
    private final MessageServiceTools messageServiceTools;
    private final StorePriceTools storePriceTools;
    private final NationalPriceMessageServiceHelper nationalPriceMessageServiceHelper;
    private final CacheUtils cacheUtils;
    private final CacheService cacheService;


    @Override
    public ProcessedByType getProcessedBy() {
        return PRICE_MESSAGE_SERVICE;
    }

    @Override
    public void processMessage(String message, MqMetricHandler metricHandler) {
        lock.lock();
        final String methodName = "processMessage";
        if (isLoggingEnabled) {
            log.info("Price Feed :: {}", message);
        }
        try {
            log.info("Start processing message ::{} :: {}", this.getClass().getSimpleName(), methodName);
            doProcessMessage(message);
            metricHandler.recordSuccess();
            log.info("Finished processing message:: {} :: {}", this.getClass().getSimpleName(), methodName);
        } catch (Exception ex) {
            log.error("Error while processing message ", ex);
            metricHandler.recordError();
        } finally {
            lock.unlock();
        }
    }

    private void doProcessMessage(String messageMetadata) throws JAXBException {
        PriceInfo priceInfo = getPriceFeed(messageMetadata);
        Map<String, String> invalidStoresMap = new HashMap<>();
        if (Optional.ofNullable(priceInfo).isPresent()) {
            savePriceFeedToRepository(priceInfo, invalidStoresMap); //NOSONAR
            log.info("Invalid records skipped  :: {} ", invalidStoresMap);
        }
    }

    private PriceInfo getPriceFeed(String message) throws JAXBException {
        PriceInfo priceFeed = null;
        final String methodName = "getPriceFeed";
        log.debug("Entering :: {} :: {}", this.getClass().getSimpleName(), methodName);
        if (Optional.ofNullable(message).isPresent()) {
            StringReader sr = new StringReader(message);
            JAXBContext jaxbContext = JAXBContext.newInstance(PriceInfo.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            priceFeed = (PriceInfo) unmarshaller.unmarshal(sr);
        }
        log.debug("Exiting :: {} :: {}", this.getClass().getSimpleName(), methodName);
        return priceFeed;
    }

    @Transactional
    public void savePriceFeedToRepository(PriceInfo priceInfo, Map<String, String> invalidStores) {
        final String methodName = "savePriceFeedToRepository";
        log.debug("Entering :: {} Method:: {}", this.getClass().getSimpleName(), methodName);
        if (NATIONAL_PRICE.equalsIgnoreCase(priceInfo.getStoreID())) {
            log.debug("National price found to be processed {}", priceInfo.getStoreID());
            nationalPriceMessageServiceHelper.refreshNationalPriceFeedDetails(priceInfo);

        } else if (StringUtils.isNotEmpty(priceInfo.getStoreID())) {
            Store storeData = servicesHelper.findStoreByStoreCode(priceInfo.getStoreID());
            if (servicesHelper.isSalesOrgValid(priceInfo.getBannerID()) && Optional.ofNullable(storeData).isPresent()) {
                refreshPriceDetails(priceInfo, storeData);
                cacheService.clearCacheList(priceInfo.getPrices(), priceInfo.getStoreID());
            } else {
                log.info("Invalid Sales org for price feed");
                invalidStores.put(priceInfo.getStoreID(), "Invalid store for price feed");
            }
        } else {
            log.info("Blank StoreID in Feed");
        }
        log.debug("Exiting :: {} Method:: {}", this.getClass().getSimpleName(), methodName);
    }

    private void refreshPriceDetails(PriceInfo priceInfo, Store store) {
        priceInfo.getPrices().forEach(price -> {
            createPriceDetails(priceInfo, store, price);
            cacheUtils.evictCacheByKey(STORE_PRICE_CACHE, List.of(price.getEan(), priceInfo.getStoreID()));
        });
    }

    private void createPriceDetails(PriceInfo priceInfo, Store store, Prices price) {
        if (isPriceFeedDetailsValid(price)) {
            createPriceDetailsForProduct(priceInfo, store, price);
        } else {
            log.info("Skipping the feed details {} :: Ean or article not present :: {} :: {}", "refreshPriceDetails", price.getArticleNumber(), price.getEan());
        }
    }

    private void createPriceDetailsForProduct(PriceInfo priceInfo, Store store, Prices price) {
        if (isLoggingEnabled) {
            log.debug("Refreshing store price details :: ean {}", price.getEan());
        }
        refreshPriceDetails(priceInfo, store, price);
    }

    private boolean isPriceFeedDetailsValid(Prices price) {
        log.debug("Inside isPriceFeedDetailsValid() :: ean={}", price.getEan());
        return StringUtils.isNotEmpty(price.getEan()) && StringUtils.isNotEmpty(price.getArticleNumber());
    }

    private void refreshPriceDetails(PriceInfo priceInfo, Store store, Prices price) {
        if (isFullFeedEnabled) {
            log.info("Is full load enabled for price feed :: {}", isFullFeedEnabled);
            addNewPriceDetails(priceInfo, store, price);
        } else {
            refreshPriceDetailsWithDeltaFeed(priceInfo, store, price);
        }
    }

    private void refreshPriceDetailsWithDeltaFeed(PriceInfo priceInfo, Store store, Prices price) {
        List<StorePrice> storePrices = storePriceTools.getActiveOrFutureStorePrice(price.getEan(), store, messageServiceTools.getTenantFromSalesOrg(priceInfo.getBannerID()));
        Optional<StorePrice> priceWithSameStartDate = getPriceWithSameStartDate(storePrices, price.getStartDate());
        if (priceWithSameStartDate.isPresent()) {
            log.debug("Store Price Found :: ean {}", price.getEan());
            updatePriceDetails(priceInfo, price, priceWithSameStartDate.get());
        } else {
            addNewPriceDetails(priceInfo, store, price);
        }
    }

    private Optional<StorePrice> getPriceWithSameStartDate(List<StorePrice> storePrices, String startDate) {
        for (StorePrice price : storePrices) {
            if (DateUtils.isEqual(price.getStartDate(), servicesHelper.getLocalDateTime(startDate))) {
                return Optional.of(price);
            }
        }
        return Optional.empty();
    }

    public void updatePriceDetails(PriceInfo priceInfo, Prices price, StorePrice storePrice) {
        populateStorePriceDetails(priceInfo, price, storePrice);
        storePriceRepository.save(storePrice);
        cacheUtils.evictCacheByKey(STORE_PRICE_CACHE, List.of(price.getEan(), priceInfo.getStoreID()));
        cacheUtils.evictCacheByKey(N_PRICE_CACHE, List.of(price.getEan(), priceInfo.getBannerID()));
        log.debug("Evicted Price cache(2) for EAN: {}, Store: {}", price.getEan(), priceInfo.getStoreID());
    }

    private void addNewPriceDetails(PriceInfo priceInfo, Store store, Prices price) {
        log.debug("Store Price Not Found, adding new price details :: ean {}", price.getEan());
        StorePrice newStorePrice = new StorePrice();
        populateStorePriceDetails(priceInfo, price, newStorePrice);
        newStorePrice.setStore(store);
        newStorePrice.setEan(price.getEan());
        storePriceRepository.save(newStorePrice);
    }

    private void populateStorePriceDetails(PriceInfo priceInfo, Prices price, StorePrice storePrice) {
        storePrice.setBannerId(priceInfo.getBannerID());
        storePrice.setCurrency(priceInfo.getCurrency());
        storePrice.setLocale(priceInfo.getLocale());
        storePrice.setLastUpdateTime(LocalDateTime.now());
        storePrice.setPriceTypeFlag(price.getPriceTypeFlag());
        storePrice.setTenant(messageServiceTools.getTenantFromSalesOrg(priceInfo.getBannerID()));
        if (StringUtils.isNotEmpty(price.getStartDate())) {
            storePrice.setStartDate(servicesHelper.getLocalDateTime(price.getStartDate()));
        }
        if (StringUtils.isNotEmpty(price.getEndDate())) {
            storePrice.setEndDate(servicesHelper.getLocalDateTime(price.getEndDate()));
        }
        storePrice.setRefPrice(price.getCurrentReferencePrice());
        storePrice.setPrice(price.getCurrentStorePrice());
    }

}