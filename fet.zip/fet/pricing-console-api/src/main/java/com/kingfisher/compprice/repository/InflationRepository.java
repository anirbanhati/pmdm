package com.kingfisher.compprice.repository;

import com.kingfisher.compprice.dao.entity.Inflation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InflationRepository extends JpaRepository<Inflation,Long> {

}