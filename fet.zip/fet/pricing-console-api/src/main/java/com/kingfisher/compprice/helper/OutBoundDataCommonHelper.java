package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.util.constants.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Stream;

@Component
@RequiredArgsConstructor
@Slf4j
public class OutBoundDataCommonHelper {

    private final OutboundProductAssocCSVHelper outboundProductAssocCSVHelper;
    private final OutboundProductCollectionHelper outboundProductCollectionHelper;
    private final OutboundPriceCSVHelper outboundPriceCSVHelper;


    public Map<File, String> getOutboundFile(String fileType) throws IOException {
        Map<File, String> fileTenantMap;
        if (Constants.PROD_COLL_OUTBOUND_TYPE.equalsIgnoreCase(fileType)) {
            fileTenantMap = outboundProductCollectionHelper.getOutboundProductCollectionFileForBucketUpload();
        } else if (Constants.PRICE_OUTBOUND_TYPE.equalsIgnoreCase(fileType)) {
            fileTenantMap = outboundPriceCSVHelper.getOutboundPriceFileForBucketUpload();
        } else if (Constants.PROD_ASSOC_OUTBOUND_TYPE.equalsIgnoreCase(fileType)) {
            fileTenantMap = outboundProductAssocCSVHelper.getOutboundProductAssocFileForBucketUpload();
        } else
            fileTenantMap = null;
        return fileTenantMap;
    }

    public String getFileNameBasedOnTenant(final String fileType, final String tenant, final String fileName) {
        final String outboundFolderName = Stream.of(Constants.PROD_ASSOC_OUTBOUND_TYPE, Constants.PROD_COLL_OUTBOUND_TYPE).anyMatch(fileType::equalsIgnoreCase) ? Constants.PRODUCT : Constants.PRICE_OUTBOUND_TYPE;
        return outboundFolderName + "/" + tenant + "/" + fileName;
    }

}