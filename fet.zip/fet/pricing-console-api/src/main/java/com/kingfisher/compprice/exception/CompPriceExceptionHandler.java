package com.kingfisher.compprice.exception;

import com.kingfisher.jsonapi.Meta;
import com.kingfisher.jsonapi.error.Error;
import com.kingfisher.jsonapi.error.ErrorResponse;
import com.kingfisher.jsonapi.error.ErrorSource;
import org.apache.poi.openxml4j.exceptions.NotOfficeXmlFileException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.Objects;

import static com.kingfisher.compprice.exception.ExceptionConstants.WarListExceptions.*;

@ControllerAdvice
public class CompPriceExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String NA = "NA";
	private static final String STATUS_403 = "403";
	private static final String STATUS_500 = "500";
	private static final String TIMESTAMP = "timestamp";
	private static final String EXCEPTION = "Exception";
	private static final String UNSUPPORTED_MEDIA_TYPE_STR = "UNSUPPORTED_MEDIA_TYPE";


	@ExceptionHandler(ApplicationException.class)
	public final ResponseEntity<Object> handleAllException(final ApplicationException e) {
		final var errorToReturn = e.build();
		return getErrorResponseResponseEntity(e, errorToReturn);
	}

	@ExceptionHandler(NotOfficeXmlFileException.class)
	public final ResponseEntity<Object> handleNotOfficeXmlFileException(final Exception e) {
		final Error errorToReturn = Error.builder().applicationErrorCode(WAR_PRODUCT_INVALID_INPUT_APP_EXP)
				.httpStatusCode(WAR_PRODUCT_INVALID_INPUT_HTTP_STATUS).detail(WAR_PRODUCT_INVALID_INPUT_DETAILS)
				.source(new ErrorSource(WAR_PRODUCT_INVALID_INPUT_POINTER, NA)).title(WAR_PRODUCT_INVALID_INPUT_TITLE)
				.build();
		return getErrorResponseResponseEntity(e, errorToReturn);
	}

	@ExceptionHandler(AccessDeniedException.class)
	public final ResponseEntity<Object> handleUserAccess(final AccessDeniedException e) {
		final Error errorToReturn = Error.builder().applicationErrorCode(EXCEPTION).httpStatusCode(STATUS_403)
				.detail(e.getMessage()).id(e.toString()).source(new ErrorSource(NA, NA))
				.title(e.getClass().getName()).build();
		return getErrorResponseResponseEntity(e, errorToReturn);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllException(final Exception e) {
		final Error errorToReturn = Error.builder().applicationErrorCode(EXCEPTION).httpStatusCode(STATUS_500)
				.detail(e.getMessage()).id(e.toString()).source(new ErrorSource(NA, NA))
				.title(e.getClass().getName()).build();
		return getErrorResponseResponseEntity(e, errorToReturn);
	}

	@ExceptionHandler(UserException.class)
	public final ResponseEntity<Object> handleUserExceptionException(final UserException e) {
		final var error = e.build();
		logger.error("User Service Exception ==>  Detail : " + error.getDetail(), e);
		return ResponseEntity.status(Objects.requireNonNull(HttpStatus.resolve(Integer.parseInt(error.getHttpStatusCode())))).body(prepareErrorResponse(error));
	}

	private ResponseEntity<Object> getErrorResponseResponseEntity(final Exception e, final Error errorToReturn) {
		logger.error("Exception ==> Detail : " + errorToReturn.getDetail(), e);
		return ResponseEntity.status(Objects.requireNonNull(HttpStatus.resolve(Integer.parseInt(errorToReturn.getHttpStatusCode()))))
				.body(prepareErrorResponse(errorToReturn));
	}


	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(final HttpMediaTypeNotSupportedException ex) {
		final Error errorToReturn = Error.builder().applicationErrorCode(UNSUPPORTED_MEDIA_TYPE_STR)
				.httpStatusCode(HttpStatus.UNSUPPORTED_MEDIA_TYPE.toString())
				.detail(ex.getContentType() + " media type is not supported. we only support ").id(ex.toString())
				.source(new ErrorSource(NA, NA)).title(ex.getClass().getName()).build();
		logger.error("HttpMediaTypeNotSupported ==> Detail : " + errorToReturn.getDetail(), ex);
		return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(prepareErrorResponse(errorToReturn));
	}

	private static ErrorResponse<Error> prepareErrorResponse(Error error) {
		final Meta metaData = new Meta();
		Meta.ofEntry(TIMESTAMP, LocalDateTime.now());
		return (new ErrorResponse<>(error)).withMeta(metaData);
	}

}