package com.kingfisher.compprice.dao.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kingfisher.compprice.dao.response.search.PriceHistory;
import com.kingfisher.compprice.dao.response.search.ProductResponse;
import com.kingfisher.compprice.dao.response.search.Recommandation;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductItemDetails extends ProductResponse {

	private static final long serialVersionUID = 4255937958949447388L;

	private StockInfo stockInfo;
	@JsonProperty("hisPrices")
	private List<PriceHistory> historyPrices;
	private String vendor;
	private String oorDate;
	private ProductMarging margin;
	private Recommandation recom;
	private List<CompetitorInfo> compInfos;

}