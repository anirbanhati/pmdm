package com.kingfisher.compprice.dao.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

import static com.kingfisher.compprice.util.constants.Constants.STATUS;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StoreCollectionUpdatesInfo {

    /**
     *
     */
    @JsonProperty("id")
    private Long collectionId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("assignTo")
    private String assignTo;

    @JsonProperty("modBy")
    private String lastModifiedBy;

    @JsonProperty("csLongName")
    private String longName;

    @JsonProperty(STATUS)
    private String status;

    @JsonProperty("products")
    private List<ProductInfo> products;

}