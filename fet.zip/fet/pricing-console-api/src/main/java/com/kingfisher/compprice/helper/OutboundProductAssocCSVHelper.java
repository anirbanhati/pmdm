package com.kingfisher.compprice.helper;

import com.kingfisher.compprice.dao.entity.Assignment;
import com.kingfisher.compprice.dao.entity.CompetitorStore;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.StorePrice;
import com.kingfisher.compprice.dto.outbound.ProductAssocCSVData;
import com.kingfisher.compprice.enums.PriceValidationStatus;
import com.kingfisher.compprice.repository.AssignmentRepository;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.compprice.service.queue.MessageServicesHelper;
import com.kingfisher.compprice.tools.MessageServiceTools;
import com.kingfisher.compprice.tools.StorePriceTools;
import com.kingfisher.compprice.util.DateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.kingfisher.compprice.util.constants.Constants.*;

@Slf4j
@RequiredArgsConstructor
@Component
public class OutboundProductAssocCSVHelper {

    private final AssignmentRepository assignmentRepository;
    private final MessageServicesHelper messageServicesHelper;
    private final MessageServiceTools messageServiceTools;
    private final StorePriceTools storePriceTools;
    private final StoreService storeService;


    public Map<File, String> getOutboundProductAssocFileForBucketUpload() throws IOException {
        final List<ProductAssocCSVData> productAssocCSVData = prepareFileData(getProductAssociationsForOutboundFeed());
        return messageServicesHelper.getOutboundCSVFileForUpload(productAssocCSVData);
    }

    public List<Assignment> getProductAssociationsForOutboundFeed() {
        List<Assignment> listOfAssignments = assignmentRepository.findByCollectedEanNotNullOrCollectedArticleCodeNotNull();
        List<Assignment> assignments = listOfAssignments.stream()
                .filter(assignment -> StringUtils.isNotBlank(assignment.getCollectedEan()) || StringUtils.isNotBlank(assignment.getCollectedArticleCode()))
                .filter(assignment -> null == assignment.getProduct()
                        || !assignment.getProduct().getEan().contains(Optional.ofNullable(assignment.getCollectedEan()).orElse(EMPTY_STR)))
                .toList();

        log.info("Records fetched: Before --> {}, After --> {}", listOfAssignments.size(), assignments.size());
        if (CollectionUtils.isNotEmpty(assignments)) {
            assignments.forEach(assignment -> {
                log.debug("Updating the status for record (PrdAssoc) ::{} to ::{}", assignment.getId(), PriceValidationStatus.EXTRACTED);
                assignment.setProductAssociationExtracted(true);
                assignment.setProductAssociationExtractedDate(LocalDateTime.now());
            });
            assignmentRepository.saveAll(assignments);
        }
        return assignments;
    }

    public List<ProductAssocCSVData> prepareFileData(final List<Assignment> assignments) {
        final List<ProductAssocCSVData> productAssocCSVData = new ArrayList<>();
        assignments.forEach(assignment -> productAssocCSVData.add(getProdAssocCSVData(assignment)));
        return productAssocCSVData;
    }

    public ProductAssocCSVData getProdAssocCSVData(final Assignment assignment) {
        final ProductAssocCSVData assocData = new ProductAssocCSVData();

        Optional.ofNullable(assignment.getStoreCollection()).ifPresent(sc -> {
            assocData.setStoreCode(Optional.ofNullable(sc.getStoreCode()).orElse(EMPTY_STR));
            Optional.ofNullable(sc.getCollectedDate())
                    .ifPresent(collectedDate -> assocData.setCreationDate(
                            DateUtils.getDateAsString(collectedDate, DATE_FORMAT_EXCEL)
                    ));
        });
        Store store = storeService.getStoreByCode(assocData.getStoreCode());
        if (null != assignment.getProduct()) {
            assocData.setArticleNumber(assignment.getProduct().getProductCode());
            assocData.setArticleName(StringUtils.replace(assignment.getProduct().getDescription(), COMMA_SEPARATOR, DOT_SEPARATOR));
            StorePrice storePrice = storePriceTools.getActiveStorePrice(assignment.getProduct(), store);
            assocData.setPriceSu(null != storePrice ? storePrice.getPrice() : 0.0);
            assocData.setPackaging1(assignment.getProduct().getPkg1());
            assocData.setPackaging2(assignment.getProduct().getPkg2());
            assocData.setCoeff(messageServiceTools.getCoefValue(assignment.getProduct().getPkg1(), assignment.getCollectedPkgValue(),
                    assignment.getCollectedPkgUnit(), assignment.getProduct().getPkg2()));
        } else {
            assocData.setCoeff(DEFAULT_VALUE_1);
        }
        assocData.setCompArticleNumber(assignment.getCollectedArticleCode());
        assocData.setCompEan(assignment.getCollectedEan());
        assocData.setCompPkgUnit(StringUtils.isNotEmpty(assignment.getCollectedPkgUnit()) ?
                assignment.getCollectedPkgUnit().replace(COMMA_SEPARATOR, DOT_SEPARATOR) : EMPTY_STR);
        CompetitorStore comp = storeService.getCompetitorStoreData(assignment.getStoreCollection());
        assocData.setCompCode(null != comp ? comp.getCode() : null);
        assocData.setCompName(null != comp ? comp.getName() : null);
        assocData.setCompLongName(null != comp ? comp.getLongName() : null);
        assocData.setCompPriceSu(assignment.getCollectedPrice());
        assocData.setComments(assignment.getNotes());
        assocData.setTenant(assignment.getTenant());
        return assocData;
    }

}