package com.kingfisher.compprice.dao;

import java.io.Serializable;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kingfisher.compprice.dao.entity.Product;
import com.kingfisher.compprice.dao.entity.StageProduct;
import com.kingfisher.compprice.dao.request.StageDataRequest;

import lombok.*;

@ToString
@Getter
@Setter
public class ExcelValidation implements Serializable {

	private static final long serialVersionUID = -6640065517952977028L;

	private String ean;
	private int rowNum;
	private int errorCount;
	private Set<ExcelError> errors;

	@JsonIgnore
	private Product product;
	@JsonIgnore
	private StageProduct stgPrd;
	@JsonIgnore
	private StageDataRequest request;
	@JsonIgnore
	private String sDate;
	@JsonIgnore
	private String prdType;
	@JsonIgnore
	private double storePrice;
	@JsonIgnore
	private double stdPrice;
	@JsonIgnore
	private double maxDecrease;
	@JsonIgnore
	private double maxIncrease;

}