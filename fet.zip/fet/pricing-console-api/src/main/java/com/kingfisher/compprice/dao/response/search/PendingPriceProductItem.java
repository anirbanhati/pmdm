package com.kingfisher.compprice.dao.response.search;

import com.kingfisher.jsonapi.Resource;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PendingPriceProductItem implements Resource {
	private static final long serialVersionUID = 8478268437334127682L;

	private String ean;
	private String desc;
	private String cat;
	private String sCat;
	private String bName;
	private String pCode;
	private String pkg2;
	private String costPrice;
	private String stdPrice;
	private String storeAppPrice;
	private String type;
	private String dPrice;
	private String sDate;
	private String eDate;
	private long reqId;
	private String status;

	@Override
	public String getJsonApiDataId() {
		return null;
	}

	@Override
	public String getJsonApiDataType() {
		return null;
	}

}