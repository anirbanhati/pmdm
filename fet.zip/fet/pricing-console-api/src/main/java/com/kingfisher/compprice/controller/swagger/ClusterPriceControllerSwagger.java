package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.entity.ClusterStoreMapping;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Tag(name = Constants.TAG_CLUSTER_PRICE)
public interface ClusterPriceControllerSwagger {

    @Operation(description = "Save cluster store details")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    MultiDataResponse<ClusterStoreMapping> saveClusterStoresData(@RequestBody final List<ClusterStoreMapping> clusterStoreList) throws JSONException;

    @Operation(description = "Get cluster store by code")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    SingleDataResponse<ClusterStoreMapping> getClusterByCode(@PathVariable final String code);

    @Operation(description = "Get cluster store mapping details")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    MultiDataResponse<ClusterStoreMapping> getClusterStoreData();

    @Operation(description = "Delete cluster stores")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> deleteClusterStoreByCode(@PathVariable final String code);

    @Operation(description = "Delete all cluster stores")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description  = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "400", description  = Constants.RESPONSE_MESSAGE_400),
            @ApiResponse(responseCode = "401", description  = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description  = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description  = Constants.RESPONSE_MESSAGE_404),
            @ApiResponse(responseCode = "409", description  = Constants.RESPONSE_MESSAGE_409) })
    ResponseEntity<String> deleteAllClusterStore();

}