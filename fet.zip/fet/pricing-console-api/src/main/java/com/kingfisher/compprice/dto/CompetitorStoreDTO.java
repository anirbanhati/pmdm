package com.kingfisher.compprice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompetitorStoreDTO implements Serializable {
    private static final long serialVersionUID = -6399723648296833544L;

    @JsonProperty("longname")
    private String longName;

    @JsonProperty("name")
    private String name;

}