package com.kingfisher.compprice.filter;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.kingfisher.compprice.configuration.FunctionalityConfiguration;
import com.kingfisher.compprice.dao.CurrentUser;
import com.kingfisher.compprice.dao.entity.Store;
import com.kingfisher.compprice.dao.entity.User;
import com.kingfisher.compprice.exception.CustomParseException;
import com.kingfisher.compprice.service.StoreService;
import com.kingfisher.compprice.service.UserService;
import com.kingfisher.compprice.util.constants.Constants;
import com.nimbusds.jwt.JWTParser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.Base64;

import static com.kingfisher.compprice.util.constants.Constants.AUTHORIZATION;
import static com.kingfisher.compprice.util.constants.Constants.BASIC;

@Component
@RequiredArgsConstructor
@Slf4j
public class UserDetailsFilter extends OncePerRequestFilter {

	public static final String USER_SEPARATOR = "@";
	public static final String TOKEN_SEPARATOR = " ";
	public static final String PREF_NAME_SEPARATOR = "preferred_username";

	private final CurrentUser currentUser;
	private final UserService userService;
	private final StoreService storeService;
	private final FunctionalityConfiguration funConfig;



	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws ServletException, IOException {
        final String authToken = request.getHeader(AUTHORIZATION);
        try {
            if (StringUtils.isNotEmpty(authToken)) {
                String userId;
                final String[] token = authToken.split(TOKEN_SEPARATOR);
				if (funConfig.isLocal() && BASIC.equalsIgnoreCase(token[0])) {
					log.debug("::: Filter by Local Authorization :::");
					userId = new String(Base64.getDecoder().decode(token[1]));
				} else {
					log.debug("::: Filter by Env Authorization :::");
					final JsonElement claimsData = JsonParser.parseString(String.valueOf(JWTParser.parse(token[1]).getJWTClaimsSet()));
					final String preUserName = claimsData.getAsJsonObject().get(PREF_NAME_SEPARATOR).getAsString();
					userId = preUserName.split(USER_SEPARATOR)[0];
				}

				currentUser.setUserId(userId);
				populateCurrentUserWithStoreCodeFetchedFromRequestHeader(request, userId);
				UserDetails userDetails = this.userService.loadUserByUsername(userId);
				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
			filterChain.doFilter(request, response);
		} catch (ParseException e) {
			log.error("Error parsing JWT token", e);
			throw new CustomParseException("Error parsing JWT token", e);
        } finally {
			this.currentUser.clear();
		}
	}

	private void populateCurrentUserWithStoreCodeFetchedFromRequestHeader(final HttpServletRequest request, final String userId) {
		final String storeCode = request.getHeader(Constants.STORE_HEADER);
		if (StringUtils.isNotEmpty(storeCode)) {
			populateUserWithStoreCode(userId, storeCode, true);
		} else {
			populateUserWithStoreCode(userId, storeCode, false);
			log.info("Could not fetch the store code from Request header");
		}
	}

	private void populateUserWithStoreCode(final String userId, final String storeCode, final boolean isStoreAvailable) {
		User user = userService.findUserByUserId(userId);
		if (isStoreAvailable) {
			final Store store = storeService.getStoreByCode(storeCode);
			user.setStore(store);
		}
		this.currentUser.setUser(user);
		log.info("Authenticated user: {}, storeCode: {}", userId, storeCode);
	}

}