package com.kingfisher.compprice.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name="map_store_competitorstore_v2")
public class StoreCompetitorStoreMap implements Serializable {
	private static final long serialVersionUID = 9140191303631330130L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "store_id", nullable = false)
	private Store store;

	@Column(name= "last_updated")
	private LocalDateTime modTime;

	@JsonIgnore
	@ManyToOne (fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "cs_id", nullable = false)
	private CompetitorStore competitorStore;

	@Column(name = "active_flag")
	private String activeFlag;

}