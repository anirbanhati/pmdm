package com.kingfisher.compprice.controller.swagger;

import com.kingfisher.compprice.dao.product.Category;
import com.kingfisher.compprice.dao.search.ProductSearchCriteria;
import com.kingfisher.compprice.dao.search.SearchProduct;
import com.kingfisher.compprice.util.constants.Constants;
import com.kingfisher.jsonapi.MultiDataResponse;
import com.kingfisher.jsonapi.SingleDataResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import static com.kingfisher.compprice.util.constants.Constants.ID;

@Tag(name = Constants.TAG_WAR_LIST)
public interface WarlistControllerSwagger {

    @Operation(description = "Get Category", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    MultiDataResponse<Category> getProductsFilterOption(@PathVariable(ID) String id);

    @Operation(description = "Product Search", requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)))
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = Constants.RESPONSE_MESSAGE_200),
            @ApiResponse(responseCode = "401", description = Constants.RESPONSE_MESSAGE_401),
            @ApiResponse(responseCode = "403", description = Constants.RESPONSE_MESSAGE_403),
            @ApiResponse(responseCode = "404", description = Constants.RESPONSE_MESSAGE_404) })
    SingleDataResponse<SearchProduct> productSearch(@RequestBody ProductSearchCriteria searchCriteria);

}