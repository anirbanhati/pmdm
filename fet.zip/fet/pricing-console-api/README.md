# Competitor Price & FET
#
- Competitor Price: This service is used to prepare price collection list and save collected price from Competitor 
- FET: This service is used to set and local store prices
***

## Development

### Test stack

- Open JDK 11 : `sudo apt-get install openjdk-11-jdk`
- Docker-Compose : `sudo apt  install docker-compose`
- Gradle


## Data Setup

Get postGres image ```docker pull postgres:12-alpine```

Run postGres ```docker run -e '\''POSTGRES_PASSWORD=session'\'' -p 5432:5432 --name postgre -d postgres:12-alpine```

Download [PGAdmin4 client](https://www.pgadmin.org/download) for data manipulation - [Ubuntu Setup](https://www.pgadmin.org/download/pgadmin-4-apt/)

Schema [schema.sql](/src/main/resources/database/schema.sql)

## Project Setup

Clone ```git clone https://gitlab.kfplc.com/kitslocalstorepriceapp/competitorprice-api.git -b dev_pricing_console```

Build and Test > ```gradle clean build```

## Documentation

Api-docs [localhost](http://localhost:3000/v2/api-docs)

Swagger-UI [localhost](http://localhost:3000/swagger-ui.html)

## Running the application stand-alone

Start the server > ```gradle bootRun```

## Run application with docker

Build the image with latest code > ```docker-compose build```

Start DB and application > ```docker-compose up```

## For Franchisee CR: 

Refer branch: Franchisee_CR
https://gitlab.kfplc.com/kitslocalstorepriceapp/pricing-console-api/-/tree/Franchisee_CR?ref_type=heads

