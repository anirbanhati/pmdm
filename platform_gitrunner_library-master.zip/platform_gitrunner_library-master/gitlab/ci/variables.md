# Variables to include in your Gitlab CI

[variables.gitlab-ci.yaml](../defaults/variables.gitlab-ci.yml)

## Descriptions

| Variable name | description |
| - | - |
| `RUBY_VERSION` | The supported version of ruby in our templates |
| `RUBY_IMAGE` | The supported ruby docker image derived from the ruby version |
