# Gitlab CI/CD templates and how to use them

## Defaults for including

| Template Include | Description |
| - | - |
| [`defaults/rules.yaml`](./docs/rules.md) | A collection of all the rules that you can have in your jobs. |
| [`defaults/shared-scripts.yaml`](./docs/shared-script.md) | Collection of common shell functions for use in the scripting part of your jobs |
| [`defaults/variables.yaml`](./docs/variables.md) | Global variables file to ensure consistent supported versions across templates |
| [`defaults/workflow.yaml`](./docs/workflow.md) | Workflow to control when pipelines are created. |

## Jobs templates

| Template Include | Description |
| - | - |
| [`templates/yaml`](./docs/yaml.md) | Job for testing yaml code with `yamllint` |
| [`templates/shell`](./docs/shell.md) | Job for testing bash(shell) code with `shellcheck` |
| [`templates/microservices/*`](./docs/microservice.md) | Jobs for working with microservices |
| [`templates/terraform`](./docs/terraform.md) | terraform jobs templates to use it within other jobs |
| [`templates/docker`](./docs/docker.md) | docker related jobs |
| [`templates/kubernetes`](./docs/kubernetes.md) | kubernetes related jobs |
| [`templates/semantic-release`](./docs/seamntic-release.md) | release related jobs |
| [`templates/sonarqube`](./docs/sonarqube.md) | sonarqube related jobs |
| [`templates/ruby`](./docs/ruby.md) | ruby related jobs |
