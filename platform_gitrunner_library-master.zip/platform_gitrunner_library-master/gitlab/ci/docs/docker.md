# Jobs for Docker

## Variables defined

| Variable name | Default | Description |
| - | - | - |
| `DOCKERFILE_PATH` | "Dockerfile" | Path to Dockerfile |
| `DOCKERFILE_LINT_DISABLE` | "" | If you need to disable Dockerfile linting with the hadolint |

> `hadolint` configured with environment variables, you could change setting for it within `dockerfile-lint` job. Check [hadolint docs](https://github.com/hadolint/hadolint#configure) for more info
