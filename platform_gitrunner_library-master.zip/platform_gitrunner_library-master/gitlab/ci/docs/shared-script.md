# Shared scripts

[shared-scripts.gitlab-ci.yml](../defaults/shared-scripts.gitlab-ci.yml)

## Functions list

| Function name | Args on input | Description |
| -- | -- | -- |
| `user_cluster_name()` |  | We used this function in jenkins urls to avoid condition because we have user name and domain for main cluster without numbers |
| `show_team_info` |  | Show info about the team running this script |
