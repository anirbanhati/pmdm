# Rules to include in your Gitlab CI

[rules.gitlab-ci.yaml](../defaults/rules.gitlab-ci.yml)

## Descriptions

| Rule name | description |
| - | - |
| `.yaml-lint:rules` | Rules for including primarily with yaml-lint job |
| `.shell-lint:rules` | Rules for including primarily with shell-lint job |
| `.dockerfile-lint:rules` | Rules for including primarily with dockerfile-lint job |
| `.ruby-lint:rules` | Rules for including primarily with ruby-lint job |
| `.kubernetes-job:rules` | Rules for including primarily with kubernetes job |
| `.semantic-release:rules` | Rules for including primarily with semantic-release job |
| `.microservice-job:rules` | to include in microservices job, like serverless or db |
