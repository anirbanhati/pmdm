# Gitlab job for bash scripts

[`shell.gitlab-ci.yml`](../templates/shell.gitlab-ci.yml)


## Variables defined
| Variable name | Default | Description |
| - | - | - |
| `SCRIPT_PATH` | "" | Either the path to the script file or the folder containing the script files. By default this is set to the root folder. |
| `SHELLCHECK_OPTS` | "" | Options for shellcheck. Example `-e SC2059 -e SC2034 -e SC1090` |
