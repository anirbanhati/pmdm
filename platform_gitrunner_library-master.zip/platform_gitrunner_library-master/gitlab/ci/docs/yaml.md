# Gitlab job for yaml files

[`yaml.gitlab-ci.yml`](../templates/yaml.gitlab-ci.yml)


## Variables defined
| Variable name | Default | Description |
| - | - | - |
| `YAML_FOLDER` | "" | Where to look for yaml files. By default this is recursively set to the root folder |
