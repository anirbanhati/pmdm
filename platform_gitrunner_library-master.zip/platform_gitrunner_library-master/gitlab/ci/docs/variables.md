# Variables

Variables can be set at various scopes to override the default values.

[variables.gitlab-ci.yml](../defaults/variables.gitlab-ci.yml)
