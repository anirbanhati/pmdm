# Jobs for Kubernetes

## Variables defined
| Variable name | Default | Description |
| - | - | - |
| `CLUSTER_NAME` | "" | The cluster for which to render templates for |
| `CLUSTER_YAML` | "clusters.yaml" | The cluster metadata file |
| `TEMPLATE_SCRIPT` | "template.rb" | The localtion of the cluster rendering script |
