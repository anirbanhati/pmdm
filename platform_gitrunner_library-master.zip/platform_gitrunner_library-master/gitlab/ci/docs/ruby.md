# Jobs for Ruby

## Variables defined
| Variable name | Default | Description |
| - | - | - |
