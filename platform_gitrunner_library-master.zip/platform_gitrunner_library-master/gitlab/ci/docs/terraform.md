# Jobs for Terraform

## Variables defined
| Variable name | Default | Description |
| - | - | - |
| `REVIEW_ENV_ENABLED` | `false ` | Enable review environment for pipeline or not |
| `TERRAFORM_VERSION` | `1.5.7` | Version of terraform to use. Defined in `default/variables` |
| `TERRAFORM_DEFAULT_IMAGE` | "hashicorp/terraform:${TERRAFORM_VERSION}" | Image used for all terraform's jobs. Defined in `default/variables` |
| `TFLINT_VERSION` | `v0.47.0.0` | Version of `tflint` used for terraform files linting. Defined in `default/variables` |
| `TFLINT_IMAGE` |  `ghcr.io/terraform-linters/tflint-bundle:${TFLINT_VERSION}` | Image used for `tflint`. Defined in `default/variables` |
| `AWS_DEFAULT_REGION` | `eu-west-1` | Default region to use with terraform modules. Defined in `default/variables` |
| `TF_PLAN_CACHE` | `plan.cache` | File name for terraform plan output |
| `TF_PLAN_JSON` | `plan.json` | File name for converted terraform plan cache. Used for visualise output in merge requests |
| `TF_INIT_ARGS` | "" | Any additional arguments for init command, like `-no-color` or `-input=true`. All arguments have to be in one variable |
