# Jobs for microservice

1. [`microservice/db.gitlab-ci.yml`](../templates/microservices/db.gitlab-ci.yml)
2. [`microservice/db-qa.gitlab-ci.yml`](../templates/microservices/db-qa.gitlab-ci.yml)
3. WIP: [`microservice/serverless.gitlab-ci.yml`](../templates/microservices/serverless.gitlab-ci.yml)
4. WIP: [`microservice/serverless.gitlab-ci.yml`](../templates/microservices/serverless-qa.gitlab-ci.yml)

## Variables defined

| Variable name | Default | Description |
| - | - | - |
| `RUBY_VERSION` | `3.2.2` | Version of Ruby to use during template rendering |
| `SCHEMA_VERSION` | `0.1` | Microservices API version |
| `MANIFEST_BUILD` | `build/db/${DB_TYPE}` | Where rendered Terraform files go |
| `MANIFEST_FILE` | `api/${SCHEMA_VERSION}/tests/${DB_TYPE}/${DB_VERSION}.yaml` | Manifest file used to render Terraform files |
| `MANIFEST_SCHEMA` | `api/${SCHEMA_VERSION}/schema/schema_${DB_TYPE}.yaml` | Manifest schema to validate manifest file |
| `DB_TYPE` | "" | Type of DB to use (mysql, postresql, documentdb, etc) |
| `CLUSTER_NAME` | "" | Name of the Kubernetes cluster. Is using for naming and secret fetching |
| `DOMAIN` | "" | Name of the _team_ where microservices will be using |
