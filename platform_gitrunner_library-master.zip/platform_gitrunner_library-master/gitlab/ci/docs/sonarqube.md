# Jobs for Sonarqube

## Configuration

Please ensure you have placed a sonar.properties file at the root of your repository, you will need to set the following as environment variables -

* CI_TEAM (optional) - The friendly-name of the team committing the code
* SONAR_HOST_URL - The URL of your sonarqube host
* SONAR_TOKEN - The authenticating token to publish code to the sonarqube host

Example sonar.properties configuration -

```
sonar.projectKey=${env.CI_TEAM}-${env.CI_PROJECT_NAME}
sonar.projectName=${env.CI_TEAM}-${env.CI_PROJECT_NAME}
sonar.qualitygate.wait=true
sonar.qualitygate.timeout=1800
```
