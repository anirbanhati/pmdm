# Jobs for Semantic Release

## Variables defined
| Variable name | Default | Description |
| - | - | - |
