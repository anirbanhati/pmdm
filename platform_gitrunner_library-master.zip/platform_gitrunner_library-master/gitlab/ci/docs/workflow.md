# Workflow for creating a pipeline

The workflow keyword is evaluated before jobs. For example, if a job is configured to run for tags, but the workflow prevents tag pipelines, the job never runs.

[workflow.gitlab-ci.yml](../defaults/workflow.gitlab-ci.yml)

## Workflow description

WIP:

1. Create a pipeline on *branches* for MR only. Do not create if there is an open merge request.
```yaml
if: $CI_PIPELINE_SOURCE == "merge_request_event"
if: $CI_COMMIT_BRANCH && $CI_OPEN_MERGE_REQUESTS
when: never
```
2. Create a pipeline every time on default branch ( usually `master`)
```yaml
if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
```

3. Force creating a pipeline ignoring the previous rules. Just pass any value to `FORCE_GITLAB_CI` variable during manualy pipeline creation.
```yaml
if: '$FORCE_GITLAB_CI'
```
