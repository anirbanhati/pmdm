# DPS Platform gitlab runner Library

Library of shared tasks to use in gitlab runners which call remote jenkins jobs

Please see details https://wiki.kfplc.com/display/DPS/Deploying+by+Gitlab+Runners of how it is used

## Pre-commit hooks configuration
Git hook scripts are useful for identifying simple issues before submission to code review.
Current repo with pre-hooks for some basic testing. __As it is not enforced, it is up to you to install it or not__.

1. Installation
    1. Using pip: `pip install pre-commit`
    1. Using homebrew: `brew install pre-commit`
2. Usage
    1. Run command `pre-commit install` in the root of the repository.
    1. Run command `pre-commit run` or `pre-commit run -a` to verify that hooks was installed.
    1. Now on every commit `pre-commit run` command will be evaluated and fail if something is wrong.

To read more about this tool you could check official documentation on [pre-commit.com](https://pre-commit.com/#usage)
