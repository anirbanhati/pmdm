# [1.16.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.15.0...v1.16.0) (2026-08-03)


### Bug Fixes

* **CEN-1542:** revert:downgreade the AWS TF provider verion as bug introduced ([3314479](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3314479a65a7ba7bd7a19e73d31f7eb80425ddcb))


### Features

* **CEN-1478:** add NodeJS support for Lambda Layer creation ([bc4d0a2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/bc4d0a2c3e8d155f3a8dbd47d6dbad0c4373badc))
* **CEN-1542:** temp downgrade the AWS TF provider version as bug introduced in v6.57.0 ([8f08df7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8f08df7883149ab581af5e64acc3d654c29942b7))
* **non-prod:** CSU-2869 adding prdsl-qa to migrated namespaces ([69b8f22](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/69b8f22e413b053178a95b7c09d244e5f3f3e482))
* **non-prod:** CSU-2885 adding apm2 to migrated teams ([44f9c27](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/44f9c27e3cba069b3d6cda285c61d1f741b93c3a))
* **non-prod:** CSU-2928 adding prdsl-qa and spy-qa ([71c6bf1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/71c6bf1ab7be9e601f2bd830275adf59d069544c))

# [1.15.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.14.0...v1.15.0) (2026-07-22)


### Bug Fixes

* **CEN-1459:** reverting to the master ([55e8aa3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/55e8aa31860efa35c9b374628816e4efd2bbda82))


### Features

* **CEN-1482:** Update PDB for k8s deployments ([c88a469](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c88a4696ee8675e4993356a2336ef2c0b026fc78))
* **non-prod:** CSU-2869 adding bdecom to migrated teams ([935ff6b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/935ff6b56d343311cb9a12d49604c846a86e41b4))

# [1.14.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.13.0...v1.14.0) (2026-06-30)


### Bug Fixes

* **CEN-1387:** added frequencr response type to sqs trigger ([cd76a49](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/cd76a49602bc466a1a437901487e1a84bc1f60a6))
* **CEN-1459:** added batch size ([ae57524](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ae57524345b179d5188d65183990077f54a2ddb5))


### Features

* **CCO-1912:** revert master branch on non-prod (microservice_serverless) ([4c7c4d4](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4c7c4d4103219e207d85b13de9c5d85a886595fc))
* **CCO-1912:** test CCO-1912 branch on non-prod (microservice_serverless) ([4654273](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4654273ca516ff977993323272d0a610bf33d163))
* **CEN-1100:** test CEN-1100 branch on non-prod (microservice) ([5704839](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/570483922aaabba2d91851d678b5d27368e01ce7))
* **CEN-1192:** Update charge_code for k8s deployment ([78b07fc](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/78b07fc5a2cfcf3c9edd783370a036f0c7b84ee2))
* **CEN-1387:** testing the sqs ([de97f22](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/de97f2211c6c6710a670c67a8630f3052f3930b1))
* **CEN-1414:** remove CEN-1414 branch from non-prod (microservice_db) ([2883384](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2883384871139e37b89c6ff16f2625a79d3fec32))
* **CEN-1414:** test CEN-1414 branch on non-prod (microservice_db) ([6e39184](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6e3918495627616ee8f2048981190dbcc5eeb4ba))
* **CEN-775:** revert master branch on microservice_db non-prod ([72b0c08](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/72b0c08087ec5f377330e84ce2eff6d4aa801f06))
* **CEN-775:** test KMS multi-region key encryption for DynamoDB ([5ae8e00](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/5ae8e00df81ddbab7d03374006ae77fee4c92bdc))
* **CSU-2752:** revert master branch on non-prod (microservice) ([ec6cadd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ec6cadd412c69f8db619033dfe282d14ed342b80))
* **CSU-2752:** test CSU-2752 branch on non-prod (microservice) ([10fc3a8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/10fc3a830ed8d6a164df11a3d638a9f2baf3bf7c))
* **non-prod/prod:** CSU-2623 gcms team onboarding ([33cbf4a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/33cbf4aa340c894be662131fd22043ce5b1948ff))
* **prod/non-prod:** CSU-2739 onboarding MBFFR ([4b349c4](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4b349c40b6638afd466692f16a905f342ed3dda0))

# [1.13.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.12.0...v1.13.0) (2026-05-14)


### Bug Fixes

* **CEN-1178:** test fix for 'unbound variable' error in redis deployments ([efd3749](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/efd374970eb63ac51662490825f0c871e6ddb769))
* **CEN-1242:** increase memory size to 8 for testing ([fd7d33e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/fd7d33e6174c1bfd5c5b205aa0cb673cbc2fd297))
* **CEN-1242:** increase memory size to 8 for testing ([0051a2d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0051a2d0b8b0b18f13db8ae2360d4a74fd1f44ab))
* CSU-2470 add new ffx namespace ([416b1a0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/416b1a0f7a853e003244a19af3258470a3415473))
* **prod/non-prod:** CSU-2342 removed content type from mandated var for s3 upload ([671b853](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/671b8530c3905ea32d15c3624eafdfae4011f067))
* test setting content type for s3 upload ([5d77ee7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/5d77ee7cf5caf40f5091495c1e73f4ad47b16c2b))


### Features

* CCO-1684 Test the changes in microservice repo related to Traefik IngressRoutes match filed changes (Host method) ([5337f1a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/5337f1addbabe08209825d79a8b6c7178e3f3383))
* **CEN-1177a:** address trivy issue ([658c436](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/658c436d5577fa922c930f536623f69709024448))
* **CEN-1192:** change charge code pattern ([23e79de](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/23e79de5431a9e59839d76fecd33940b2bc179fd))
* **CEN-1192:** Update logic for chargeCode ([c90af04](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c90af043cd39e3a5edaad87b37a818610d71c37c))
* **CEN-1202:** end testing for microservice serverless using CEN-1202 ([7717da5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/7717da5d80e7a5516ee67f08470d0d9803e030e5))
* **CEN-1202:** use CEN-1202 for micro_serverless for non-prod testing ([715888e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/715888e10dc51c9333f6fe943c2158a041b51387))
* **CEN-1213:** temporarily disabed trivy scan method ([c42fc5b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c42fc5b06e6058a95f4be5c5449577331002c264))
* **CEN-1300:** change back the branch for microservice_db ([7646293](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/76462939b19cc557436cd40e873adcd497737d63))
* **CEN-1300:** start testing CEN-1300 for microservice db ([7368209](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/7368209ef0c5aaa7e4ed01b240ed11517a0d2eed))
* **CEN-1331:** set the vault-sync-enforcer to get fail status ([76afa30](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/76afa30b83732f78d04e4f93500ee42c9cbb9397))
* **CEN-954:** Upgrade terraform version for database ([53d6be9](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/53d6be95a75e0fe4e57afc86a61e77644da764a8))
* **CEN-964:** test microservice_db and microservice_transfer use s3 lock ([d0ab7b7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d0ab7b71d172d61523c68c19bd9add6c3c82ef0e))
* **CEN-964:** Use S3 lockfile instead of DynamoDB for terraform state locking ([ae4eb52](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ae4eb52277b7456f92b82004b61cad09df80e1aa))
* CSU-2517 test new branch for k8s ([710ecea](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/710eceabc14483cadd2d73009edeb34daf1fe7de))
* **prod/non-prod:** Adding new teams to use gitlab pipelines ([ab64510](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ab64510a69c3a1025eb2db22aec7ad2cc0b547ee))
* **prod/non-prod:** CSU-2571 onboard bdecom team ([15275b6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/15275b60ad9bc93f8dfa37db4c2069aafd0ac392))
* **prod:** CSU-2517 merge changed and point k8s to master ([b1bf307](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b1bf307dc7005b7d3cc8573cc04b2ad6bba15d4e))
* revert the MICROSERVICE_K8S_TEST_BRANCH to default ([e1e557f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e1e557f7d43dd69f46894ee14128ab47c64e075f))

# [1.12.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.11.0...v1.12.0) (2026-03-03)


### Bug Fixes

* **CEN-1014:** Test enforcing DataDog tags on non-prod tier (microservice) ([6c0f812](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6c0f812c77c468c4292b24196b9d9a21e24ee380))
* **CEN-1022:** back option to restart pods through rollout restart ([3ed6110](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3ed6110548abb94e5a84e0b838e58ce95bb908de))
* **CEN-1043:** fixed issue with recent changes ([9d720fb](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9d720fb465ba42e38c85ddd215a83d718463aa5c))
* **CEN-1081a:** fix terraform script for mysql replica ([d1ccdb8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d1ccdb8cbe9dea1ead717ddb357d4e1faaeec9f1))
* **CEN-697f:** fixed handling when community_image is null ([6b6e003](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6b6e00357b2ed1a776eb5d1fda37921119f2b2f4))
* **CEN-755:** reverting it master ([e094c55](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e094c55abc8847e225783d551071b1bab309593a))
* **CEN-755:** updated terraform version for microservice_serverless ([189ebc6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/189ebc6b0a96b5249fe90766b6848e894c66d5ac))
* **CEN-776:** set charge_code as not mandatory ([ccd352f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ccd352fc1810171c48d6fbe60031371448449aea))
* **CEN-829:** set back to 'master' branch on microservice non-prod ([c8c7a25](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c8c7a252ba3106e79005d4784352a6c6f48681a7))
* **CEN-829:** test 'CEN-829' branch on non-prod (microservice) ([98cebf0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/98cebf025ca222d268c0a6c48d0e771e1a56d760))
* **CEN-829:** test 'CEN-829' branch on on-prod (microservice) ([a9452e5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a9452e50516ac2b237d1af61acfbc523a02d68a3))
* **CEN-849:**  switiched all the teams gitlab prod for db ([1893304](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1893304e6943ff88365a74878160c920e9fff502))
* **CEN-849:** switiching  some teams to prod ([485b5c3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/485b5c33260e45c782bd03724a16872c3edbdb21))
* **CEN-871:** Fix deploy errors when deployment is new ([ee254b8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ee254b823ece6a384d7efb154b0beb23b76b6de7))
* **CEN-980:** updated terraform version ([18efde3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/18efde3cae8c7bf95f57f1438c4002cd4c22b417))
* **CEN-980:** updated terraform version ([d9e96a7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d9e96a783c97b25aa26a257872a8c54c92d83a8c))
* CSU-2316 added cufu-om to the migrated teams ([fe747bf](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/fe747bf957685bbecd02279377ff0585da813deb))


### Features

* **CCO-976:** update Traefik IngressRoute API version and name ([b5a3446](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b5a34467288282498d103deed30572ea59403076))
* **CEN-1047:** restore 'master' branch on microservice_db (non-prod) ([3571337](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/35713377df2b04c1ee0947635b9db94abfa1cc7e))
* **CEN-1047:** Test 'CEN-1047' branch on non-prod (microservice_db) ([c6016fa](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c6016fab97a1d44bf941195ff4826369857ea476))
* **CEN-1050/CEN-1136:** Make dt_* labels optional and  remove manifest... ([8e61031](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8e6103186c04c9cd76b945d19a531fdab92814ee))
* **CEN-1050/CEN-1136:** Make dt_* labels optional and  remove manifest... ([0b53213](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0b53213d57a158611105ba25405030ed4996faa8))
* **CEN-1050:** Make dt_* labels  optional ([d6a0ef4](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d6a0ef406d52894ac6ae46404632c92c6ac3b2e4))
* **CEN-1052:** Return branch to master for CR ([0564365](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0564365688b9ad7ea925727193b4dd0be1448ada))
* **CEN-1052:** testing regex issue ([df0e11c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/df0e11c83d6c795528475073a1c773ec0dc94054))
* **CEN-1069:** Propagate Lambda "DD_TAGS" env variable to logs via AWS tags ([2ae3e00](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2ae3e001566613ffac99be98dd770c48272c7a30))
* **CEN-1069:** Propagate Lambda DD_TAGS env variable to logs via AWS tags ([6caf8bc](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6caf8bc5e2c21b473ae027fcaaa81d1a2f3673ea))
* **CEN-1071:** add verbosity to the pipeline ([572992f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/572992f0982b61631497d15f0925c1c4429f78a4))
* **CEN-1146:** change db ref ([34d75f9](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/34d75f9f677df7c186443f0c5e7529da80ca9cda))
* **CEN-1146:** schema add redis_7.1 ([7ac383a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/7ac383a6bb6367bce6d467309378c1f03fa28e18))
* **CEN-1177:** Address Trivy Vulnerability Issue ([c538b20](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c538b20301a3f9019052bf012493df68c690a3e5))
* **CEN-680:** test 'CEN-680' on non-prod (microservice) ([4559330](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4559330f67706f03ce51aaf07f64c800a571117c))
* **CEN-776:** change ref test branches ([6aaccc2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6aaccc2e92246be548895961d23c6e701a59f68a))
* **CEN-797:** Adjusted ROD teamplate fields to make more informative ([f2eef56](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f2eef56def9c18ec8df39a701078571e8deb7134))
* **CEN-871:** Return branch ref to master for microservice repo after tests ([4a1acda](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4a1acda13a76d721271ec49f1dd95cd16bbae5b5))
* **CEN-891:** test 'CEN-891' on non-prod + fix for SED issue (microservice) ([14b8cf8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/14b8cf86c3a249aa8a823dc106797abdbcef93f1))
* **CEN-908:** Return branch to 'master' for microservice_db non-prod ([6f9f3a1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6f9f3a1c9f9466f49b028400638d4971fd66e11b))
* **CEN-908:** test 'CEN-908' branch on non-prod (microservice_db) ([360383c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/360383cae7b2fcd9ef01f1528e222aaf5747b14e))
* **CEN-924:** updated docker executor to align with recent docker breaking changes (v.29) ([fa3a212](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/fa3a212519841445da7b7f8ba54828988fc69cc2))
* **CEN-937:** implement automatic lambda layers splitting by size ([926b897](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/926b8972b1b19a08d2e83335ea9123e6b6c2e63e))
* **CEN-937:** Set 'master' branch for non-prod in microservice_serverless ([1aab115](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1aab1150be21929e4ce601a7652170579d6ac2be))
* **CEN-964:** Update TF state to use S3 lock feature (ECR/Serverless) ([eba6fc7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/eba6fc7fcf30325fdd4d57b2f9e79e090d3f80a9))
* **CEN-964:** Update TF state to use S3 lock feature for ECR and Serverless apis ([3f989c2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3f989c238b0ed6c71dab0e6963bc68053fdd7992))
* **CEN-974:** enable db type postgres_18 ([18e99db](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/18e99dbed23ff857e70a9a3eafcbedfcabacfcc6))
* **CEN-974:** enable db type postgres_18 ([44cc544](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/44cc5446bcaeb9e2e7d620708e65b34d920840bc))
* **CEN-975:** Updated token for gitlab registry ([d1348c7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d1348c7a2c6edc47c2d17ee288ebeac999061f60))
* **CEN-996:** change back to master for microservice db ([214b105](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/214b105efd35222e42263fca8ed44ece2ef92168))
* **CEN-996:** test 'CEN-966' branch on non-prod (microservice_db) ([6d13455](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6d134554ce0a85a53af59d9681e65d167f1ba64b))
* **CEN-996:** Test 'CEN-996' branch on non-prod (microservice_db) ([353e5bf](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/353e5bfbae30d534661553a0d1ffb2a58ec1122a))
* **non-prod/prod:** CCO-1519 Remove redundand commands ([0cde711](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0cde711cd677ca91f4eed083eb8f678802438bdb))
* **prod/non-prod:** CSU-1937 bot team onboarding ([a6ba9b0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a6ba9b0098936f669fb275e03f4f6ad50452c056))
* **prod/non-prod:** CSU-2023 add new team names ([cef7a6d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/cef7a6dca7fcda8cc8e4d623d4308ac6f450287a))
* **prod:** CSU-1907 enable qe360 team ([04e9f4a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/04e9f4afdd2a0579c9eb9a80425d2f7930c5e593))

# [1.11.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.10.0...v1.11.0) (2025-11-05)


### Bug Fixes

* **prod/non-prod:** CSU-1925 adding dcol namespaces to gitlab migration list ([9aae1f2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9aae1f20e78487b67ecfa66dfcd170d0aed5f5f4))


### Features

* **CEN-697:** added possibility to change version in manifest and continue deployment without it ([ba88f04](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ba88f0438ccd00048656d4fb39a785f72416b118))
* **CEN-813:** Set default value for point_in_time_recovery as true ([69f64c2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/69f64c2619126271d30bea17ff1163d9c48d23cf))
* **CEN-850f:** switched all prod namespaces to gitlab for microservice_serverless ([b4938cc](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b4938cc70ddfe9caf6cb3e1b525bdd175d763626))
* **CEN-850:** switched some of namespaces in prod to gitlab for microservice_serverless ([87c8f81](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/87c8f81a81e83d68a77f68c777e4ea4698a582f5))
* **CEN-870:** remove 'CEN-870' branch from non-prod (microservice) ([ec1f256](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ec1f256715363cb2938cea889f241007c7223d53))

# [1.10.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.9.0...v1.10.0) (2025-10-24)


### Bug Fixes

* **CEN-679:** fixed rules to make possible to run deploy jobs when mr is open ([4a0219a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4a0219a1557440bfcca3970e550e0d387debc0ba))
* **CEN-800f:** fixed issue with undeploy serverless ref branch ([bb57647](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/bb5764742754263660071c3505b15afda8853ecb))
* **CEN-836:** restore 'master' branch on non-prod (microservice) ([a3bbc06](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a3bbc062aa23e16a8ab0d55842f28d5889040b83))
* **CEN-836:** test 'CEN-836' branch on non-prod (microservice) ([0b3a6aa](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0b3a6aa5cdac5e67aec0b957c0b46cad2199c97c))
* **CEN-841:** timeout for deploy has been increased to an hour ([5b75583](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/5b755831edd297fe4601f1102997de3e47794ea9))
* **CEN-870:** test 'CEN-870' feature branch on non-prod (microservice). ([2bb40dd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2bb40dd4cd4254d8ba2f107a5d0ce7a7f7e6aa79))


### Features

* **CEN-578:** switch back to 'master' branch for microservice ([e39aeb5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e39aeb5193c6f39c91dedc504750edb19340adb3))
* **CEN-578:** test CEN-578 feature branch on non-prod (microservice) ([4c3baed](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4c3baed24b6fb4a1423affd665c721bf075074fd))
* **CEN-680:** test CEN-680 feature branch on non-prod (microservice) ([8dc58c3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8dc58c3fe9344c4249f3e4cafa88ad16bc55f34c))
* **CEN-742:** non-prod - Enable Redis from snapshot restore with KMS encryption ([884a613](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/884a61398d35c21d19eef0ea24cf9937503f69ac))
* **CEN-742:** set microservice_db non-prod branch from 'CEN-742' to 'master' ([988fb6e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/988fb6e167b193af2e6b48c07da33032d8ccc6ac))
* **CEN-756:** added 12 prod namespace to migrate to gitlab in microservice deploy ([eebfe7e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/eebfe7e7326acfbbf2ba51ffe5d3570a2b7a0c1b))
* **CEN-756n:** added list of namespaces to swtich from jenkins to gitlab ([88e108d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/88e108dec8b0d9d7ed5f31c26f0dbcdaaa87e1d5))
* **CEN-771:** extended list of migrated teams to gitlab for non-prod ([a0ca559](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a0ca559e4a3e8c496416278ac843295a71dff554))
* **CEN-791:** add new var for kafka trigger maximum_batching_window_in_seconds ([15a1785](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/15a1785a1ea00f1e6b50efd28033f55399cae510))
* **CEN-791:** add new variable maximum_batching_window_in_second to kafka_trigger ([57c4b58](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/57c4b58a1a2d96a74504e8a50d9d74809d6a3a64))
* **CEN-793:** added functionality to change s3 bucket name regarding aws changes ([81abe2f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/81abe2f36a691fe79d4aaf39fa5f1d0618509347))
* **CEN-793:** switch back to master branch for microservice_serverless ([1d2a80f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1d2a80f5b7622d87a513cdf9f90e27c37410f2a8))
* **CEN-800:** bring switch to test branch to one method for all microservice apis ([39731da](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/39731dad7856545ab5059dec72c5ec0376f51739))
* **CEN-812:** switch back to 'master' branch for microservice. ([03bcca7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/03bcca7b376276d32a1468888e793075c0c723af))
* **CEN-812:** test CEN-812 feature branch on non-prod (microservice) ([f5c0748](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f5c074848bb63e95d510e22075fad85c7ca25ec4))
* **CEN-846:** test for populating version dd tag for custom instrumentation path ([4d2d58e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4d2d58ee3086049e4644a51e46bf2b7da38fd612))

# [1.9.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.8.0...v1.9.0) (2025-09-18)


### Bug Fixes

* **CEN-723:** apply test branch on nonprod env ([9559a69](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9559a6945b17629a0d0ed29b542fee7be343ad60))


### Features

* **CEN-741a:** changed branch to master for microservice_db ([0819b7b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0819b7b36fa59bb733244ea76b4d2fcfe4cb3cee))
* **CEN-785:** added new team to migrated list ([95a4524](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/95a4524d0a43376827e9ec3037150146f35ec510))

# [1.8.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.7.0...v1.8.0) (2025-09-08)


### Features

* **CEN-688:** change branch from CEN-688 to master on non-prod ([e4c78d1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e4c78d11342a33a539a3dd52502693b5f74a784d))
* **CEN-691:** change branch from CEN-691 to master on non-prod (microservice repo) ([f6272fe](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f6272fe2c8f22480246082d405a599fddc2b779b))
* **CEN-741:** changed variable name for database test branch ([292f2e8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/292f2e837afdce666ad058bb04dc13c77d18a87b))

# [1.7.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.6.1...v1.7.0) (2025-08-20)


### Bug Fixes

* **CEN-607:** commented out rule to allow auto deploy from custom branch for microserivce_db ([e77162a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e77162a6602d00b41e99fb56641db172ed4740e0))
* **CEN-721:** add VAULT_ADDR var to rendering job ([5842ef3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/5842ef3c93dc12d03e2330f0dd55bd64e77fd462))


### Features

* **CEN-559:** add new params to Jenkins trigger ([8354b5e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8354b5e2ba94004020138c1f9ff487f56d55905e))
* **CEN-559:** comment out testing branch ([354fe7d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/354fe7d655502cd4daa7e5ccd2e7fdd8bba815d4))
* **CEN-607:** change branch to master ([301c78b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/301c78b638531d0703ddc10460ff31995548041d))
* **CEN-688:** test lambda instrumentation with datadog under non-prod ([31ec210](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/31ec2102a8732f33f7aa87abb17d7d4c9010c811))
* **CEN-691:** Non-prod - Assign single-replica deployments to base-static nodepool for stability ([fde4438](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/fde4438f23dd803a29a05301516696b51ccef76c))

## [1.6.1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.6.0...v1.6.1) (2025-07-28)


### Bug Fixes

* add ignore case option for location grep ([f2afbf1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f2afbf1bef82d311c037824b67f4817ec053894a))
* **CSU-1484:** add ignore case option for location filter ([d3dab09](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d3dab09ca32a75cde5bff980b8a1ab0b90d38872))

# [1.6.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.5.0...v1.6.0) (2025-07-28)


### Bug Fixes

* **CEN-577:** changed branch for microservice_serverless for non-prod from CEN-577 to master ([4eb4ef5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4eb4ef53fb97ec89b5b13b5337353b44461b7abd))
* **CEN-577:** fix for lambda provisioned concurrency (non-prod only) ([09be171](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/09be17113934fa4a7f982cceb37c2beb2f8eaf35))
* **CEN-625:** changed the branch to master ([19259f5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/19259f5f4922494ae0da6be6c2fed52d68899c08))
* **CEN-639:** non-prod - fix for Lambda alias weights issue with provisioned concurrency ([730f7b3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/730f7b31343037471711ba91e95982471642a240))
* **CEN-653:** fix check for CREATE_LAYER ([f35bd79](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f35bd79339bc08dc864f247081ab838b03a4c108))
* **CEN-672:** update curl commands in remote jobs ([1b6670a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1b6670ac1d77d9d5ab7183fedefa40a05b2b585c))
* CSU-1484 added -i option for deploy job ([c21cfc1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c21cfc15d07344d26a27f230409a6808417638f6))


### Features

* **CEN-523:** add support for custom lambda layer deployment ([68c127e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/68c127e73661d710ce0ebd4eabd6f3a04948303f))
* **CEN-559:** add new configurable parameters to microservice k8s deployment ([4a66dcd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4a66dcd371d89ea8462df285b81fc9fe398c136b))
* **CEN-559:** hotfix in new parameter ([cdbed44](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/cdbed443a4dc1400fba28125e323f0ff917f1f87))
* **CEN-607:** add new configurable parameters to microservce_db deployment ([4b223fa](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4b223faa2fa7698cecbdafd3aa5999920471adaf))
* **CEN-625:** set temp branch for serverless non-prod to validate deprecation warn fix ([b30a06a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b30a06a4dc4cd97e23d9942957dd0cf537414692))

# [1.5.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.4.0...v1.5.0) (2025-06-26)


### Bug Fixes

* **CEN-364b:** move custom variables into job definitions ([da684a6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/da684a63741efc7946eb68feb2393b1212784667))
* **CEN-424:** Fix k8s deployment pipeline issues as a post migration ([750fe73](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/750fe7357fce5f65fd6e14ab07ee6519c67099d9))
* **CEN-450:** added prod related chan api namespaces to the migrated scope ([9aab743](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9aab7435e3dcf62d4aebb97e3109e9c64c33be98))
* **CEN-535:** modified the backup script ([bbf6aad](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/bbf6aadda5212dfcd86f0dc53a5866bc765e3d20))
* **CEN-535:** time out for db backup increased at runner level ([2e433c4](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2e433c44d2e53100fa8a295ef7e1325a12870703))
* **CEN-540:** changed branch for microservice_serverless for non-prod from CEN-353 to CEN-540 ([6c830c0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6c830c0e53ed681e01f2fc973365ad43d75c7778))
* CSU-1340 allow cufu to run migration for ffx redis ([a35d42e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a35d42eed920a24919d76c776f017ba689d45603))


### Features

* **CEN-382:** add ability to push docker images with custom tags ([0c13eb0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0c13eb049de2d35092345cfae3c60db4f7259791))
* **CEN-405:** added container proxy support under build image ([9af6c4f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9af6c4fcec4993cd40c4fbc5e5d8fd1a1c030039))

# [1.4.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.3.0...v1.4.0) (2025-04-25)


### Bug Fixes

* added dev package install to fix rubocop ([14670fe](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/14670fef28c5ebd55209fd6b098433446e4fe1fd))
* added new team names ([c92c418](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c92c418b1812d3f79e61e3aa7a40992771f90f9e))
* **CEN-106f:** removed feature team from migrate db list ([079982c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/079982c6d8909d33596aca59a97b69b591e55a67))
* **CEN-106h:** added rule for rod jobs ([ca04c19](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ca04c195f564c1c29071bc48bd79f80b3808992d))
* **CEN-107f:** changed branch for gitlab pipeline trigger ([3fa9d62](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3fa9d62e6c556f3f10d90d42f7e7e474c4e62717))
* **CEN-107h:** fixed issue when cluster set as a domain ([c357fd1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c357fd154232d53fd490179a510c5b11ffbb87f2))
* **CEN-121:** update default branch vol2 ([6f7ebc9](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6f7ebc9c944c086aa0e36435f7cb302d7bd1386f))
* **CEN-152r:** rotation gitlab registry token ([2a35fc2](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2a35fc2a9ca46e465d00ca06478ee91222499e7c))
* **CEN-231:** replace access token ([71da886](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/71da88614e8d7ed70785e5bf4741c592ae5ad393))
* **CEN-336a:** escape catching error when status is absent or api unavailable for deployment of database ([75537dd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/75537dd41eeaa550d0c56366194eaba786ebd5ec))
* **CEN-336f:** fixed issue with deployment of new database ([2772d39](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2772d396dd18c93c27ee3336734d1c28d67b3b3d))
* **CEN-336:** fixed issue with deployment of new database ([00a49ee](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/00a49eee9ffb9366fc5e125f820fb412c70d1dbf))
* **CEN-339:** update on-demand job ([6723a0c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6723a0cfab69d5710b0bf6212a7866a1ef726703))
* **CEN-342:** remove before_script from remote job ([91853e1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/91853e1e00968a87f5ae3a82852f625e88d50b12))
* **CEN-343:** removing before_script blocks ([c92dc82](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c92dc82adf2dc011049f68fc150441992df99396))
* **CEN-352:** hotfix for variable overwriting issue ([8637a4a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8637a4ab0bc0ffd2e8dc3b039ea860baab2c3f15))
* **CEN-387b:** rollback for k8s deploy regarding issue with add stable tag after deploy to image ([1f2e984](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1f2e9849e2aff5aaffbb3fd63c7c8844a08c98f3))
* **CEN-387r:** added wcms2 namespaces for non-prod to migrated list ([080e803](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/080e8038680035298c282c8648c8ce519182a673))
* **non-pord:** CCO-194 - Fix of terraform_plan stage needed in checks on digital_platform MRs" ([394f218](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/394f2184390f1a9cf2328ae13cf174eb7705032f))
* reverting fft to Jenkins pipeline for db ([69e492b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/69e492be5490ba8706d50268c9a0ee260a222b86))


### Features

* **CEN-105f:** Increased timeout for k8s deployment and changed project ID var key ([1a58e43](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1a58e43f2e97fc6e48ed78328dd15e1293a11db1))
* **CEN-105fix:** Fixed issue within overridden vars under deployment pipeline ([4385199](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4385199f11b9638f4c8a6941608316ae02455947))
* **CEN-105:** migrated kubernetes deployment job to gitlab CI ([3bf668c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3bf668c358bb91d2429a786df0a7e42cf6dfc79f))
* **CEN-106n:** extended gitlab pipeline for microservice_db and added method to trigger gitlab pipeline for db deploy ([b5b8ebe](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b5b8ebe906f417bf20b7c95e826981ac4b0810e3))
* **CEN-106:** Removed leading zeros from rod business timeframe borders ([05780f6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/05780f6143f506cf22506455ebe0c189ae6882f5))
* **CEN-107:** Added templates for terraform microservices jobs and changed serverless deploy to make possible ([9d63470](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/9d6347093e34f98df269c9e75b243ef0ae68fffd))
* **CEN-107t:** added chan, cufu and fft some namespaces to migrated list for serverless ([727dd85](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/727dd8529c7a24d8886785261133c13eed961ef5))
* **CEN-118:** migrate deploy cronjob, remove cronjob and deploy child job pipelines to gitlab ([453306d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/453306d7b9737530c742a6b3419bffd207c28ebd))
* **CEN-119f:** changed branch for microservice_ecr trigger ([04a7df6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/04a7df6cbffbf63d2a3807069b5ee5976c54fe67))
* **CEN-119:** migrate deployecr to gitlab ([79371f0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/79371f0d474089d8935df917c40bff8e380ec35b))
* **CEN-119s:** added fft, cufu and chan to migrated list of gitlab ([294586c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/294586c7768b1d2225e26b79f81cf5c49c703a53))
* **CEN-121:** migrate deployingress & remove-ingress Jenkins jobs to GitLab ([874c1ab](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/874c1abb31c08024609a4d61e72f925a74d826cb))
* **CEN-122:** fetching cluster name from config map cluster-info ([eb12702](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/eb12702199fe93e605aca566da6723e053af2034))
* **CEN-122:** trigger new scaling pipeline ([125a35f](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/125a35f34b7a7ef7d60ae8e134cc2d231a2a9d2f))
* **CEN-122:** update error message ([25c5ec1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/25c5ec18f76701b25fae5ca96892a41519376e30))
* **CEN-122:** update target branch ([4fe7354](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4fe7354cfba3a5949d20309d9f82170fdb4186ef))
* **CEN-138:** added files for transfer user job ([7c2928e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/7c2928e76f01cf3173974aa338dda00452186d0e))
* **CEN-138:** added master branch to transfer user job ([c53c628](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c53c6287769dc38658c6268c4a6f86e6630bed76))
* **CEN-142:** migrate restart-pods Jenkins job to gitlab CI ([60f1a45](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/60f1a456c658703f55ef9f571eda9fc7559cb35d))
* **CEN-149:** Added specific pipeline rules for microservice_db pipeline ([e9f0c85](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e9f0c852f60330e5281784ccc67c077686c42505))
* **CEN-149:** changed rod ci definition ([4c7ac4c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4c7ac4cb043f2131ad6f839325ceb9ee79ef3b08))
* **CEN-152:** changed name of secrets for gitlab token ([c943064](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c943064bcd88cc8eed0d3705b67261b726219f81))
* **CEN-197:** added manual step for failure validation branch and promote to prod ([1fed62c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1fed62c0097f1e0dda260c2c58a66abd14ce401b))
* **CEN-222:** added possibility to execute k8s job on-demand via pipeline ([269212e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/269212eba5dc3ff8ff7816223d6f77361e8a62bf))
* **CEN-222b:** Added exception for k8s ns validation ([3c2fe31](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3c2fe31acdf957fab25e61275d4a8179a3f7c0de))
* **CEN-237:** added code for s3 upload ([e395db1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e395db1945d18c2d09ecc2974364e0564ce3c31b))
* **CEN-242:** added adhoc backup job ([b160a11](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b160a1154ef984fbd5f86b477fb28f6999505c96))
* **CEN-242:** changed branch to main ([025a4c8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/025a4c8810cb37927ef8e251c92a70c755e40bce))
* **CEN-242:** changed branch to master ([0dc02ad](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/0dc02adf86031833db98e482da93c55e9f22d510))
* **CEN-244:** added aditional job to show which variables was passed to job from triggered pipeline ([1a34aec](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1a34aec40e1819903a31a20d21472720b9c6359f))
* **CEN-338:** added redis backup and cache clear script ([b3658e8](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b3658e836d2cc311eec685bdbfa7e05459e9b198))
* **CEN-352:** fix versions bug ([666a773](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/666a7739c828f5cdd51383bd3d954f7e684a8031))
* **CEN-352:** migrate build remote jobs to kaniko ([192683b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/192683b99de0a01b90090a548c95e3ccc94218aa))
* **cen-365a:** add libaries needed by microservice_db ([072cd4b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/072cd4b9805f19f715d5feb1485683d3fe2ce799))
* **CEN-365:** add aws-sdk-rds gem installation to CI templates ([75e510e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/75e510e4f2bac1174b6fc85a73e3a0f97848893f))
* **CEN-365:** remove gem installations ([d878c44](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/d878c448842597bfc1b09cc8fd3a57e08a63501c))
* **CEN-368:** add error handling ([8d02596](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8d02596bf186fdb320d769ff40d1dbe795a485ef))
* **CEN-368:** revert changes to docker build from kaniko ([b78d73d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b78d73ddeeea34a82b239c73981c8a70c3e5e9e7))
* **CEN-376:** added remotejob for vault-sync ([fa616e0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/fa616e0ba62c763e5176b6d65c9712083fc89669))
* **CEN-387:** added gapi-prod and wcms2 to switch from jenkins to gitlab for k8s deploy and dbdeploy and serverless ([cff08cf](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/cff08cf164a3237f93a39087efa7087bb81aacee))
* **CEN-387:** added gapi-qa and gapi-stage to switch from jenkins to gitlab for k8s deploy and dbdeploy ([1ea8a83](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1ea8a832ff6bce67cf7bd4eb14f652d5e6bb26e1))
* **CEN-393f:** Temporarily removed chan/dcom ns from k8s migrated ([4920022](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/49200223a356006f8f9590f11eb0d7d5f3f45fed))
* **CEN-393:** switched non-prod namespaces from jenkins to gitlab for serverless, k8s and db deployment ([e513b36](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/e513b36a88e9c8435469438d4cdb783ee6afe6c3))
* **CEN-393:** Temporarily rolled back non-prod namespaces from k8s migrated list ([1d453c7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1d453c731be94361a3ed6c3b4aa4139663ae7505))
* **CEN-54:** added cluster 2 in the condition for running selenosis app on an2 cluster ([f3192f3](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f3192f3a871a74943d83d753112965cd294e3528))
* **CEN-89:** adjusted pipeline steps as part of rod implementation workflow ([dd11606](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/dd11606b1b8dcbf8ede72097e6715b715f0f8980))
* **CSU-425:** Fix remote job status ([2ea794c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2ea794cf245ea041c3cb7e2c5db07e3f13403a23))

# [1.3.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.2.0...v1.3.0) (2024-08-29)


### Bug Fixes

* **DPS-10216:** mistype in path ([3b201d1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3b201d102ab0918ee3a865d54ec09e11dc7e6ff2))
* **DPS-11085:** testing rules update for microservice ([8a565d1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8a565d1305d39959bd5cd3542b07f5bf47ba5a9d))
* **DPS-9764:** fix rule for "as" env plan job ([07758fd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/07758fd9facde6bc23d63ab6988b35490f13b434))
* **DPS-9764:** update rules for terraform ([a22057d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a22057d3a6c6e75cf05663bd2bc60375a33981ca))
* **prod/non-prod:** [DPS-11074] - Fixed manifest creation location for gitrunner library ([8b09e5e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8b09e5e581e500e9602dffea5ca35cf8376cb4fe))


### Features

* **CEN-TEMP:** added dvx team to platform_gitrunner_library ([6323cf7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/6323cf714520d872f41358a3606fba33073930ef))
* **DPS-10017:** add terraform module pipeline ([ccecd84](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ccecd840e3b5a443751c3dca7849b208233888a2))
* **DPS-10956:** rules for cluster list update ([4b82efd](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/4b82efd2ff3966c4cee02c07558bbd14a43374b6))
* **DPS-11077:** added deploy ecr job template and template for ecr manifest ([c7e900c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/c7e900cae12cfb1b241c4e3cd3cdad1166ca62ac))
* **DPS-11104:** Add capability to set namespace-scoped variables for database deployments ([210bc30](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/210bc3072c6ac11e9d92cd6d59b3b3cd0b5412b0))
* **DPS-9216:** update db testing pipeline ([3affa49](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3affa490aff11d25cd97ae7e27a9bba5f2bc2618))
* **DPS-9764:** adjust terraform template to work with digital platform ([7f20832](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/7f20832d048f7ef1d1113dcbfaed99d52cd59ddd))
* **DPS-9764:** remove resource_group since it not working ([3cc9f54](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3cc9f54fccdf8fbe3c341df98e32c9b087c1556f))
* **non-prod-prod:** Added function to scan docker images for vulnerabilities ([642a3d7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/642a3d70a78bb93c004e0e4895a72660ea105937))
* **non-prod-prod:** Push latest tag only for the master branch ([a7f9944](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a7f99447ccb13f6f75f16d7f0b993ddcf2b0b777))
* **non-prod-prod:** Update docker container builder image ([54c9374](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/54c9374e98ada11985c1dd9c28b2221736dc467d))
* **non-prod-prod:** update gitlab runner docker image ([058bac7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/058bac7e9b8339b4b4abdc87e31e6a538dad3966))
* **non-prod-prod:** update kubectl version from 1.23 to 1.28 ([3a0c233](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3a0c233342a8d750f8ffa46e3d5f06d55decfd8a))
* **non-prod/prod:** [DPS-12061] optimized git clone by adding sparse-checkout ([8e8924a](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8e8924a1b6c653bb497341ff17db4337bdc9063c))
* **non-prod/prod:** DPS-10474 move mktp to migrated teams list ([f248582](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/f24858286764db6303cff8b00e304e312279d49c))
* **non-prod/prod:** DPS-11466 [ZS] Introducing library method for restart pod on-demand ([054ba1e](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/054ba1e3655b6463acf95ddb7bdefdb5b2065e91))
* **non-prod/prod:** DPS-11504 Adding vault-sync job for gitlab runner library ([de1747c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/de1747cd42ddc7ab7e086607ee94a804cbeee865))
* **non-prod/prod:** DPS-9425f move gapi to migrated teams list ([3d6ccda](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3d6ccda6348dbb55bf1dc181d25f63b60652e349))
* **non-prod/prod:** DPS-9695 - Removed DOCKER_AUTH ([2d4a358](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2d4a358a11b6a80a2148732632b9653c36621001))
* **non-prod:** DPS-10017 add module release ([1c520f7](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1c520f71b742f8b57c9c72b808bf6a9963b0d237))
* **non-prod:** DPS-10017 improve module testing speed ([8592f49](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8592f4965966a66acfb578b67bfe1aab779528a5))
* **non-prod:** DPS-11386 added finops_billing_code && servicenow_application_id into deploydb for tests databases. ([b72d86c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/b72d86ceab614ef2d1e324690929bc8e8b96fa8f))
* **non-prod:** DPS-9763 remove terraform init stage ([1a8bf7b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/1a8bf7bd729abc05f2f6625928377a82d3809d00))
* **non-prod:** DPS-9763 update rules for gitlab flow ([cd46974](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/cd46974fdfb3324204a36114923ce06964a2a813))
* **nonm-prod/prod:** DPS-10858 - Added prdsl to migrated list ([875435b](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/875435bc634dd48076a37e89ffadd3ff0314ec0f))
* **nonprod/prod:** [DPS-10936] Update default values after terraform version update in digital_platform ([a02a966](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/a02a9668f17f9bb0c9a51251faa25f01db7f1f01))
* **prod:** [DPS-9419p][YS] moved dcol and dcom to migrated teams list ([8032aa9](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/8032aa9dfa02709026b12d600e1b1d71ac236e8e))
* **qa:** [DPS-10104] Add Kubernetes unit testing template ([156b50c](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/156b50c94acbac0b6a1f0229d9c05d695ab72552))

# [1.2.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.1.1...v1.2.0) (2023-09-12)


### Features

* **DPS-9763:** add terraform jobs and fixing some minor formatting issues ([85ae020](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/85ae020928e2ae261ae52c90b25cb7b15edf0806))
* **non-prod:** DPS-9763 update terraform templates ([ee3105d](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/ee3105d336ea829f56771827647260f74fa52a6c))

## [1.1.1](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.1.0...v1.1.1) (2023-08-24)


### Bug Fixes

* **DPS-9060:** change email for release-bot ([2dd6e40](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/2dd6e40e84c198e16c62f5e09e730136084b39fb))

# [1.1.0](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/compare/v1.0.0...v1.1.0) (2023-08-22)


### Features

* **DPS-9888:** Refactor kubernetes-rendering to allow for matrix based inputs ([3cb4aa6](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/3cb4aa61d8c83a26122cc0100567243d12637ea4))

# 1.0.0 (2023-08-16)


### Features

* **ci:** [DPS-9776] Add E2E template for kubernetes module CI ([97befb5](https://gitlab.kfplc.com/digital_platform_services/gp/platform_gitrunner_library/commit/97befb541bf272c0e6c02dfd4be24396ef5433e2))
