#!/usr/bin/env bash

set -Eeuo pipefail
shopt -s nullglob dotglob

progname=$(basename $0)

err() {
  echo "[$(date +'%Y-%m-%dT %H:%M:%S%zZ')] ($progname): ERROR: $@" >&2
  exit 1
}

status() {
  echo "[$(date +'%Y-%m-%dT %H:%M:%S%zZ')] ($progname): $@"
}

cleanup() {
  find . -name \*.pw\* -delete
  find . -name \*.hw\* -delete
  shopt -u nullglob dotglob
}

finish() {
  local exit_status="${1:-$?}"
  if [[ "$exit_status" -eq 0 ]]; then
    status "Done"
  else
    err "Exit code: ${exit_status}"
  fi
  cleanup
  exit $exit_status
}

usage() {
  cat <<EOL
    Helper script for packer.
    Usage: $0 [ -s <suffix> -t <template> ]

      -s    The suffix to use for naming the AMI
      -t    The template name to use which will either be a HCL or JSON file formay

    Needs a set of env variables in file: $HOME/$project.env if building an AMI
EOL
exit 1
}

import_env() {
  local project=$1
  status "Importing env..."
  if [ -f $HOME/$project.env ]; then
    status "Found file: $HOME/$project.env"
    # can't only source it as TF/AWS tools expect these as environment variables
    source $HOME/$project.env
    export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-eu-west-1}"
    status "Imported file: $project.env"
  else
    status "No $HOME/$project.env file found"
    status "Create this file to add environment variables to the terraform run"
  fi
}

build() {
  local suffix="$1-$(date +%d-%m-%Y-%H-%M)"
  status "Building.. suffix=$suffix"
  import_env $2
  local template=$3

  packer init .
  packer build -var "suffix=$suffix" $template | tee build.log

  local amiId=$(grep 'eu-west-1:' build.log | cut -d ' ' -f 2)
  printf "$amiId" > ami.properties
}

trap finish SIGHUP SIGINT SIGQUIT SIGTERM ERR

if [ "$#" -lt 2 ]; then
  usage
fi

while getopts ":s:t:" opt; do
  case "$opt" in
    s)
      SUFFIX=$OPTARG
    ;;
    t)
      TEMPLATE=$OPTARG
    ;;
    :)
      err "Option -$OPTARG requires an argument."
      exit 1
    ;;
    *)
      usage
    ;;
  esac
done

PROJECT=${PROJECT:-group_platform}
build $SUFFIX $PROJECT $TEMPLATE
finish
