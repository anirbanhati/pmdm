package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean

@JsonIgnoreProperties(ignoreUnknown = true)
@DynamoDbBean
data class TechnicalAttributes(
    @JsonProperty("technical") var technical: List<Technical> = emptyList(),
    @JsonProperty("dimension") var dimension: List<Technical> = emptyList(),
)
