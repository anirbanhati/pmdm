package com.kingfisher.marketplace.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.carreirBookingAPI.CarrierBookingAPIConfigProperties
import com.kingfisher.marketplace.constant.Constant
import com.kingfisher.marketplace.constant.Constant.Companion.NOT_APPLICABLE
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CarrierBookingException
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingLineItem
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingRecipient
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingRequest
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingResponse
import com.kingfisher.marketplace.service.ReturnBusinessService.Companion.logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpHeaders.AUTHORIZATION
import org.springframework.http.HttpHeaders.CONTENT_TYPE
import org.springframework.http.HttpMethod
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.web.client.HttpStatusCodeException
import org.springframework.web.client.RestTemplate
import java.time.LocalDateTime
import java.time.ZoneOffset
@Service
class CarrierBookingAPIService
@Autowired
constructor(
    private var restTemplate: RestTemplate,
    private var miraklAPIService: MiraklAPIService,
    private var sellerService: SellerApiService,
    private var carrierBookingAPIConfigProperties: CarrierBookingAPIConfigProperties,
    private var objectMapper: ObjectMapper
) {
    fun invokeCarrierBookingAPI(
        returnLines: List<ReturnLine>,
        dPDReturnLines: MutableList<CarrierBookingLineItem>,
        tenant: String,
    ): ResponseEntity<CarrierBookingResponse> {
        val headers = HttpHeaders()
        val carrierBookingRequest = CarrierBookingRequest()
        carrierBookingRequest.lineItems = dPDReturnLines as ArrayList<CarrierBookingLineItem>
        val firstReturnLine = returnLines.listIterator().next()
        buildCarrierBookingRequestBody(carrierBookingRequest, firstReturnLine)
        populateSellerInStoreReturnAddress(
            if (firstReturnLine.shopId.isBlank() || firstReturnLine.shopId == NOT_APPLICABLE) {
                miraklAPIService.getMiraklOrderDetailsByOrderId(
                    firstReturnLine.logisticalOrderId, tenant
                ).shopId
            } else {
                firstReturnLine.shopId
            },
            carrierBookingRequest,
            tenant,
        )
        logger().info("carrierBooking API request json : {}", objectMapper.writeValueAsString(carrierBookingRequest))
        headers.set(AUTHORIZATION, carrierBookingAPIConfigProperties.carrierBookingAPIKey)
        headers.set(CONTENT_TYPE, Constant.CONTENT_TYPE_APPLICATION_VND_API_JSON)
        val entity = HttpEntity(carrierBookingRequest, headers)
        val response: ResponseEntity<CarrierBookingResponse>
        try {
            response = restTemplate.exchange(
                carrierBookingAPIConfigProperties.carrierBookingURL,
                HttpMethod.POST,
                entity,
                CarrierBookingResponse::class.java,
                tenant
            )
        } catch (ex: HttpStatusCodeException) {
            logger().error("Failed to book carrier for return order ${returnLines[0].returnOrderNumber} : ${ex.message}")
            throw CarrierBookingException(
                ex.statusCode,
                ex.message.toString()
            )
        }
        return response
    }

    private fun buildCarrierBookingRequestBody(
        carrierBookingRequest: CarrierBookingRequest,
        returnLine: ReturnLine,
    ) {
        carrierBookingRequest.atpDate = LocalDateTime.parse(returnLine.returnDate).atOffset(ZoneOffset.UTC).toString()
        carrierBookingRequest.countryCode = returnLine.countryCode
        carrierBookingRequest.sapOrderID = returnLine.returnOrderNumber.toString() + '-' + returnLine.logisticalOrderId.split('-')[1]
        carrierBookingRequest.atgOrderID = returnLine.returnOrderNumber.toString() + '-' + returnLine.logisticalOrderId.split('-')[1]
        carrierBookingRequest.sourceId = returnLine.storeId
        carrierBookingRequest.logisticOrderID = returnLine.logisticalOrderId
        carrierBookingRequest.deliveryType = carrierBookingAPIConfigProperties.deliveryType
        carrierBookingRequest.deliveryPriority = carrierBookingAPIConfigProperties.deliveryPriority
        carrierBookingRequest.bookingType = carrierBookingAPIConfigProperties.bookingType
        carrierBookingRequest.fulfilmentType = carrierBookingAPIConfigProperties.fulfilmentType
        carrierBookingRequest.deliveryGroupID = carrierBookingAPIConfigProperties.deliveryGroupID
        carrierBookingRequest.sumConsignmentWeight = carrierBookingAPIConfigProperties.sumConsignmentWeight
        carrierBookingRequest.sumConsignmentVolume = carrierBookingAPIConfigProperties.sumConsignmentVolume
        carrierBookingRequest.maxConsignmentHeight = carrierBookingAPIConfigProperties.maxConsignmentHeight
        carrierBookingRequest.maxConsignmentLength = carrierBookingAPIConfigProperties.maxConsignmentLength
        carrierBookingRequest.maxConsignmentWidth = carrierBookingAPIConfigProperties.maxConsignmentWidth
        carrierBookingRequest.maxConsignmentWeight = carrierBookingAPIConfigProperties.maxConsignmentWeight
    }

    fun populateSellerInStoreReturnAddress(
        shopId: String,
        carrierBookingRequest: CarrierBookingRequest,
        tenant: String,
    ) {
        val carrierBookingRecipient = CarrierBookingRecipient()
        val sellerAddress = sellerService.fetchSeller(shopId, tenant)

        logger().info("Seller API response  json: $sellerAddress")
        val contactInformation = sellerAddress.body!!.data.attributes.contactInformation
        val inStoreReturnDetails = sellerAddress.body!!.data.attributes.inStoreReturnDetails
        carrierBookingRecipient.countryCode = carrierBookingAPIConfigProperties.defaultCountryCodeForRecipient
        carrierBookingRecipient.addressLine1 = inStoreReturnDetails.addressLine1
        carrierBookingRecipient.addressLine2 = if (inStoreReturnDetails.addressLine2.isNullOrEmpty()) inStoreReturnDetails.addressLine1 else inStoreReturnDetails.addressLine2
        carrierBookingRecipient.city = inStoreReturnDetails.city
        carrierBookingRecipient.name = if (inStoreReturnDetails.departmentName.isNullOrEmpty())sellerAddress.body!!.data.attributes.sellerName!! else inStoreReturnDetails.departmentName
        carrierBookingRecipient.postCode = inStoreReturnDetails.zipCode
        carrierBookingRecipient.email = contactInformation.email
        carrierBookingRecipient.contactPhone = contactInformation.phone
        carrierBookingRequest.recipient = carrierBookingRecipient
    }
}
