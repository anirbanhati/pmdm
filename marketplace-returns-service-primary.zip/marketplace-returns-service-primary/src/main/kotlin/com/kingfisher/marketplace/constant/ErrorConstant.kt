package com.kingfisher.marketplace.constant

class ErrorConstant {
    companion object {
        const val RETURN_ORDER_NOT_FOUND = "RETURN_ORDER_NOT_FOUND"
        const val DATE_TO_IS_BEFORE_DATE_FROM = "ERROR_DATE_TO_IS_BEFORE_DATE_FROM"
    }
}
