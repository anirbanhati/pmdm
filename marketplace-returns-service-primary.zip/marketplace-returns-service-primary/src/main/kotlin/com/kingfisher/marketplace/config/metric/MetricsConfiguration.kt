package com.kingfisher.marketplace.config.metric

import io.micrometer.core.instrument.config.MeterFilter
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
@EnableConfigurationProperties(MetricProperties::class)
class MetricsConfiguration {

    @Bean
    fun nameFilter(props: MetricProperties): MeterFilter {
        return MeterFilter.denyUnless { id ->
            props.allowed.any { prefix -> id.name.startsWith(prefix) }
        }
    }
}
