package com.kingfisher.marketplace.model

data class ConfirmReturnResponse(var data: ConfirmReturnResponseData = ConfirmReturnResponseData())
