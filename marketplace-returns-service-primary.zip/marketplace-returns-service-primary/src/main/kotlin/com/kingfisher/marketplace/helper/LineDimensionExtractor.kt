package com.kingfisher.marketplace.helper

import com.kingfisher.marketplace.config.cms.CmsApiConfigProperties
import com.kingfisher.marketplace.config.mirakl.MiraklClientConfig.Companion.logger
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import org.springframework.stereotype.Component
import kotlin.math.roundToInt

/**
 * Extracts physical dimensions (height, length, width in cm) and weight (in kg)
 * from a TechnicalAttributes object.
 *
 * Supported input units:
 *   - Dimensions: mm, cm, m  → output: cm (Int)
 *   - Weight:     g, kg      → output: kg (Double)
 *
 * Falls back to the values configured in CmsApiConfigProperties when an
 * attribute is missing, has an unrecognised unit, or cannot be parsed.
 */
@Component
class LineDimensionExtractor(
    private val cmsApiConfigProperties: CmsApiConfigProperties
) {

    data class LineDimensions(
        val height: Int,
        val length: Int,
        val width: Int,
        val weight: Double
    )

    fun extract(
        technicalAttributes: TechnicalAttributes,
        returnOrderNumber: Long,
        lineNumber: Long
    ): LineDimensions {
        val allAttributes = technicalAttributes.technical + technicalAttributes.dimension

        fun findAttribute(groupName: String): Pair<String?, String?> {
            val attr = allAttributes.firstOrNull { it.groupName.equals(groupName, ignoreCase = true) }
            return Pair(attr?.value, attr?.uom)
        }

        val (heightVal, heightSourceUnit) = findAttribute("Product_height")
        val (lengthVal, lengthSourceUnit) = findAttribute("Product_length")
        val (widthVal, widthSourceUnit) = findAttribute("Product_width")
        val (weightVal, weightSourceUnit) = findAttribute("Product_weight")

        val height = toCm(heightVal?.toDoubleOrNull(), heightSourceUnit, returnOrderNumber, lineNumber)
            ?: fallback(returnOrderNumber, lineNumber, "height", cmsApiConfigProperties.height, "cm")
        val length = toCm(lengthVal?.toDoubleOrNull(), lengthSourceUnit, returnOrderNumber, lineNumber)
            ?: fallback(returnOrderNumber, lineNumber, "length", cmsApiConfigProperties.length, "cm")
        val width = toCm(widthVal?.toDoubleOrNull(), widthSourceUnit, returnOrderNumber, lineNumber)
            ?: fallback(returnOrderNumber, lineNumber, "width", cmsApiConfigProperties.width, "cm")
        val weight = toKg(weightVal?.toDoubleOrNull(), weightSourceUnit, returnOrderNumber, lineNumber)
            ?: fallback(returnOrderNumber, lineNumber, "weight", cmsApiConfigProperties.weight, "kg")

        return LineDimensions(height = height, length = length, width = width, weight = weight)
    }

    /** Converts a dimension value to cm. Supported input units: mm, cm, m. */
    private fun toCm(value: Double?, sourceUnit: String?, returnOrderNumber: Long, lineNumber: Long): Int? {
        if (value == null) return null
        return when (sourceUnit?.lowercase()) {
            "cm" -> value.roundToInt()
            "mm" -> (value / 10.0).roundToInt()
            "m" -> (value * 100.0).roundToInt()
            else -> {
                logger().warn(
                    "Unknown dimension uom='$sourceUnit' for order=$returnOrderNumber line=$lineNumber, treating value as cm"
                )
                value.roundToInt()
            }
        }
    }

    /** Converts a weight value to kg. Supported input units: g, kg. */
    private fun toKg(value: Double?, sourceUnit: String?, returnOrderNumber: Long, lineNumber: Long): Double? {
        if (value == null) return null
        return when (sourceUnit?.lowercase()) {
            "kg" -> value
            "g" -> value / 1000.0 // preserves full precision, e.g. 1999g → 1.999kg
            else -> {
                logger().warn(
                    "Unknown weight uom='$sourceUnit' for order=$returnOrderNumber line=$lineNumber, treating value as kg"
                )
                value
            }
        }
    }

    private fun <T> fallback(
        returnOrderNumber: Long,
        lineNumber: Long,
        dimension: String,
        defaultValue: T,
        unit: String
    ): T {
        logger().warn(
            "Missing or invalid $dimension for order=$returnOrderNumber line=$lineNumber, using default $dimension=$defaultValue $unit"
        )
        return defaultValue
    }
}
