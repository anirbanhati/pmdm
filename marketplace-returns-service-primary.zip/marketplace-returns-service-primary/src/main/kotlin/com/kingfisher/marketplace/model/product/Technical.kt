package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean

@JsonIgnoreProperties(ignoreUnknown = true)
@DynamoDbBean
data class Technical(
    @JsonProperty("dataType") var dataType: String = "",
    @JsonProperty("groupName") var groupName: String = "",
    @JsonProperty("localisedName") var localisedName: String = "",
    @JsonProperty("uom") var uom: String = "",
    @JsonProperty("value") var value: String = "",
)
