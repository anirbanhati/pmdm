package com.kingfisher.marketplace.controller

import ReturnLineResponse
import com.kingfisher.marketplace.constant.SwaggerExamples.CARRIER_BOOKING_EXCEPTION_RESPONSE
import com.kingfisher.marketplace.constant.SwaggerExamples.CONFIRM_RETURN_REQUEST_BODY_FOR_DPD
import com.kingfisher.marketplace.constant.SwaggerExamples.CONFIRM_RETURN_REQUEST_BODY_FOR_IFORCE
import com.kingfisher.marketplace.constant.SwaggerExamples.CONFIRM_RETURN_RESPONSE
import com.kingfisher.marketplace.constant.SwaggerExamples.EMPTY_RETURN_LINE_RESPONSE
import com.kingfisher.marketplace.constant.SwaggerExamples.ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_AND_STATUS_COMBINATION_NOT_ALLOWED_TO_UPDATE
import com.kingfisher.marketplace.constant.SwaggerExamples.ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_NOT_ALLOWED_TO_UPDATE
import com.kingfisher.marketplace.constant.SwaggerExamples.ERROR_RESPONSE_FOR_RETURN_LINE_STATUS_NOT_ALLOWED_TO_UPDATE
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_COUNT
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_COUNT_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_DATE_FROM
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_DATE_FROM_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_DATE_TO
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_DATE_TO_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_LAST_UPDATED
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_LINE_NUMBER
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_NEXT_CURSOR
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_NEXT_CURSOR_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_RETURN_LAST_UPDATED_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_RETURN_LINE_NUMBER
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_RETURN_LINE_NUMBER_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_RETURN_ORDER_NUMBER
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_STORE_ID
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_STORE_ID_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_TENANT
import com.kingfisher.marketplace.constant.SwaggerExamples.PARAMETER_TENANT_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.RETURN_LINES
import com.kingfisher.marketplace.constant.SwaggerExamples.RETURN_NOT_FOUND_ERROR_DESCRIPTION
import com.kingfisher.marketplace.constant.SwaggerExamples.RETURN_NOT_FOUND_ERROR_RESPONSE
import com.kingfisher.marketplace.constant.SwaggerExamples.RETURN_ORDER_IS_NOT_PRESENT_IN_DB
import com.kingfisher.marketplace.constant.SwaggerExamples.SUCCESSFUL_RETURN_LINE_RESPONSE
import com.kingfisher.marketplace.constant.SwaggerExamples.UPDATE_RETURN_LINE_REQUEST_BODY
import com.kingfisher.marketplace.constant.SwaggerExamples.UPDATE_ROUTE_DPD_REQUEST_BODY
import com.kingfisher.marketplace.constant.SwaggerExamples.UPDATE_ROUTE_IFORCE_REQUEST_BODY
import com.kingfisher.marketplace.constant.SwaggerExamples.UPDATE_ROUTE_SPLIT_QUANTITY_REQUEST_BODY
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.model.ConfirmReturnRequest
import com.kingfisher.marketplace.model.ConfirmReturnResponse
import com.kingfisher.marketplace.model.UpdateRouteRequest
import com.kingfisher.marketplace.model.errors.ErrorResponseWrapper
import com.kingfisher.marketplace.model.manualUpdate.UpdateReturnLineRequest
import com.kingfisher.marketplace.model.FetchOrdersResponse
import io.swagger.v3.oas.annotations.Hidden
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.ExampleObject
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import jakarta.validation.Valid
import jakarta.validation.constraints.Pattern
import jakarta.validation.constraints.Size
import jakarta.validation.constraints.Max
import jakarta.validation.constraints.Min
import org.springframework.format.annotation.DateTimeFormat
import org.springframework.format.annotation.DateTimeFormat.ISO.DATE_TIME
import org.springframework.http.MediaType.APPLICATION_JSON_VALUE
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestParam
import java.time.LocalDateTime

@Suppress("TooManyFunctions")
interface ControllerSwagger {

    @Hidden
    fun fetchAllOrders(): List<ReturnLine>

    @Operation(
        summary = "Fetch return lines using cursor-based pagination.",
        parameters = [
            Parameter(
                name = PARAMETER_TENANT,
                example = "BQUK",
                description = PARAMETER_TENANT_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_COUNT,
                example = "1000",
                description = PARAMETER_COUNT_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_NEXT_CURSOR,
                example = "eyJyZXR1cm5fb3JkZXJfbnVtYmVyIjoxMjM0NSwibGluZV9udW1iZXIiOjF9",
                description = PARAMETER_NEXT_CURSOR_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Paged return lines.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = FetchOrdersResponse::class)
                    )
                ]
            )
        ]
    )
    fun fetchOrders(
        @RequestParam tenant: Tenant,
        @RequestParam
        @Min(1)
        @Max(20000)
        count: Int,
        @RequestParam(required = false)
        nextCursor: String?
    ): ResponseEntity<FetchOrdersResponse>

    @Operation(
        summary = "Fetch all return lines present in DB placed from given store with given tenant filtered by time-range within retention period (in days) for confirmed lines.",
        parameters = [
            Parameter(
                name = PARAMETER_DATE_TO,
                example = "2024-09-26T20:28:00.00",
                description = PARAMETER_DATE_TO_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_DATE_FROM,
                example = "2024-09-26T20:27:00.00",
                description = PARAMETER_DATE_FROM_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_STORE_ID,
                example = "1017",
                description = PARAMETER_STORE_ID_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_TENANT,
                example = "BQUK",
                description = PARAMETER_TENANT_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Return line response with filtered return line data.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = List::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Return line response with filtered return line data.",
                                value = SUCCESSFUL_RETURN_LINE_RESPONSE
                            ),
                            ExampleObject(
                                name = "Empty return lines",
                                description = "Return line response with empty return line data.",
                                value = EMPTY_RETURN_LINE_RESPONSE
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
        @PathVariable tenant: Tenant,
        @PathVariable @Size(
            min = 4,
            max = 4,
            message = "The Store Id should be of 4 digits"
        ) @Pattern(regexp = "^[0-9]{4}\$") storeId: String,
        @RequestParam(required = true) @DateTimeFormat(iso = DATE_TIME) dateFrom: LocalDateTime,
        @RequestParam(required = true) @DateTimeFormat(iso = DATE_TIME) dateTo: LocalDateTime,
    ): ReturnLineResponse?

    @Operation(
        summary = "Fetch all return lines present in DB with given return number.",
        parameters = [
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "4002",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Return line response containing return lines with given return number.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ReturnLineResponse::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Return line response with return line data for given return number.",
                                value = SUCCESSFUL_RETURN_LINE_RESPONSE
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "404",
                description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            ),
                        ],
                    ),
                ]
            )
        ]
    )
    fun fetchAllLineDetailsAssociatedWithReturnOrder(
        @PathVariable returnOrderNumber: Long
    ): ResponseEntity<ReturnLineResponse>

    @Operation(
        summary = "Return PSO XML is to be pushed to create new return lines.",
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Return line created successfully."
            )
        ]
    )
    fun loadReturnOrders(
        @RequestBody returnOrderPSO: String,
    )

    @Operation(
        summary = "Updating last updated dated for return lines. This property of the Return line was a newer addition, so this endpoint is used to update latestUpdated field for old return lines.",
        parameters = [
            Parameter(
                name = PARAMETER_TENANT,
                example = "BQUK",
                description = PARAMETER_TENANT_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "4000",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_RETURN_LINE_NUMBER,
                example = "1",
                description = PARAMETER_RETURN_LINE_NUMBER_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_LAST_UPDATED,
                example = "2024-09-26T20:27:00.00",
                description = PARAMETER_RETURN_LAST_UPDATED_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Last updated date updated successfully.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ConfirmReturnResponse::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Updated return line data response.",
                                value = CONFIRM_RETURN_RESPONSE
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "404", description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_ORDER_IS_NOT_PRESENT_IN_DB,
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun updateLastUpdated(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @PathVariable returnLineNumber: Long,
        @PathVariable lastUpdated: LocalDateTime,
    ): ConfirmReturnResponse?

    @Operation(
        summary = "Request to update return line route for given quantity. It can be full quantity iForce or DPD or split quantity between iForce and DPD route. For DPD carrier booking is also done, if that fails the whole transaction is rolled back.",
        parameters = [
            Parameter(
                name = PARAMETER_TENANT,
                example = "BQUK",
                description = PARAMETER_TENANT_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "4000",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            )
        ],
        requestBody = io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Request to update return line route.",
            content = [
                Content(
                    mediaType = APPLICATION_JSON_VALUE,
                    schema = Schema(implementation = UpdateReturnLineRequest::class),
                    examples = [
                        ExampleObject(
                            name = "Update line 1 for iForce",
                            description = "For a line having route not decided, will be updated to iForce",
                            value = UPDATE_ROUTE_IFORCE_REQUEST_BODY
                        ),
                        ExampleObject(
                            name = "Update line 1 for DPD",
                            description = "For a line having route not decided, will be updated to DPD",
                            value = UPDATE_ROUTE_DPD_REQUEST_BODY
                        ),
                        ExampleObject(
                            name = "Update line 1 with split quantity.",
                            description = "For a line having route not decided, will be updated some for DPD rest for iForce.",
                            value = UPDATE_ROUTE_SPLIT_QUANTITY_REQUEST_BODY
                        )
                    ]
                )
            ]
        ),
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Update order line route successfully.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ReturnLineResponse::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Return line response with return line data for given return number.",
                                value = SUCCESSFUL_RETURN_LINE_RESPONSE
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "404", description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_ORDER_IS_NOT_PRESENT_IN_DB,
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "424",
                description = "Full operation rolled back due to carrier booking failure for DPD route.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = "Failed to book carrier",
                                value = CARRIER_BOOKING_EXCEPTION_RESPONSE,
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun updateRoute(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @Valid @RequestBody updateRouteRequest: UpdateRouteRequest
    ): ResponseEntity<ReturnLineResponse?>

    @Operation(
        summary = "Request to confirm return and print label for DPD. For line it marks the status as LABEL_PRINTING_REQUESTED.",
        parameters = [
            Parameter(
                name = PARAMETER_TENANT,
                example = "BQUK",
                description = PARAMETER_TENANT_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "4000",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_LINE_NUMBER,
                example = "1",
                description = PARAMETER_RETURN_LINE_NUMBER_DESCRIPTION
            )
        ],
        requestBody = io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Request to update return line route.",
            content = [
                Content(
                    mediaType = APPLICATION_JSON_VALUE,
                    schema = Schema(implementation = ConfirmReturnRequest::class),
                    examples = [
                        ExampleObject(
                            name = "Confirm line 1 for iForce",
                            description = "For a line with route iForce, label attached",
                            value = CONFIRM_RETURN_REQUEST_BODY_FOR_IFORCE
                        ),
                        ExampleObject(
                            name = "Confirm line 1 for DPD",
                            description = "For a line with route DPD, label printing requested",
                            value = CONFIRM_RETURN_REQUEST_BODY_FOR_DPD
                        ),
                    ]
                )
            ]
        ),
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Label printing requested successfully.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ConfirmReturnResponse::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Updated return line data response.",
                                value = CONFIRM_RETURN_RESPONSE
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "404", description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_ORDER_IS_NOT_PRESENT_IN_DB,
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun confirmReturn(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @PathVariable lineNumber: Long,
        @Valid @RequestBody confirmReturnRequest: ConfirmReturnRequest,
    ): ConfirmReturnResponse?

    @Operation(
        summary = "Update return line details manually. When route is TBC, and carrier booking is failed for any reason, then it is done manually. Then to update in DB, this endpoint is used.",
        requestBody = io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Request to update return line route and/or status manually. It is used to update those lines for which, carrier booking is done manually or need to be cancelled for any reason. Allowed combinations of route and status are (TBC, CANCELLED), (DPD,COLLECTION_BOOKED), (DPD, LABEL_PRINTING_REQUESTED). Only lines for which route is not determined i.e. TBC are allowed to update manually.",
            content = [
                Content(
                    mediaType = APPLICATION_JSON_VALUE,
                    schema = Schema(implementation = UpdateReturnLineRequest::class),
                    examples = [
                        ExampleObject(
                            name = "Update line 1 or return order number 400",
                            description = "In this case, line 1 of return order 400 is saved as route TBC and now we want to update it with route DPD and status COLLECTION_BOOKED",
                            value = UPDATE_RETURN_LINE_REQUEST_BODY
                        )
                    ]
                )
            ]
        ),
        responses = [
            ApiResponse(
                responseCode = "200",
                description = "Update order line route and/or status successfully.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ReturnLineResponse::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_LINES,
                                description = "Return line response with return line data for given return number.",
                                value = SUCCESSFUL_RETURN_LINE_RESPONSE
                            )
                        ]
                    )
                ]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Unable to update line details due to any error.",
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = "Line route is not TBC",
                                value = ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_NOT_ALLOWED_TO_UPDATE,
                            ),
                            ExampleObject(
                                name = "Line already cancelled",
                                value = ERROR_RESPONSE_FOR_RETURN_LINE_STATUS_NOT_ALLOWED_TO_UPDATE,
                            ),
                            ExampleObject(
                                name = "Invalid status for given route, for example status COLLECTION_BOOKED with route TBC.",
                                value = ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_AND_STATUS_COMBINATION_NOT_ALLOWED_TO_UPDATE,
                            )
                        ],
                    ),
                ]
            ),
            ApiResponse(
                responseCode = "404", description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_ORDER_IS_NOT_PRESENT_IN_DB,
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun updateLine(@RequestBody updateReturnLineRequest: UpdateReturnLineRequest): ResponseEntity<ReturnLineResponse>

    @Operation(
        summary = "Delete return line record with given return order number and line number.",
        parameters = [
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "400",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            ),
            Parameter(
                name = PARAMETER_LINE_NUMBER,
                example = "1",
                description = PARAMETER_RETURN_LINE_NUMBER_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "204",
                description = "Line deleted successfully if present in DB"
            )
        ]
    )
    fun deleteReturnLine(
        @PathVariable returnOrderNumber: Long,
        @PathVariable lineNumber: Long
    ): ResponseEntity<Unit>

    @Operation(
        summary = "Delete all return line record with given return order number.",
        parameters = [
            Parameter(
                name = PARAMETER_RETURN_ORDER_NUMBER,
                example = "400",
                description = PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION
            )
        ],
        responses = [
            ApiResponse(
                responseCode = "204",
                description = "All lines related to this return are deleted successfully"
            ),
            ApiResponse(
                responseCode = "404",
                description = RETURN_NOT_FOUND_ERROR_DESCRIPTION,
                content = [
                    Content(
                        mediaType = APPLICATION_JSON_VALUE,
                        schema = Schema(implementation = ErrorResponseWrapper::class),
                        examples = [
                            ExampleObject(
                                name = RETURN_ORDER_IS_NOT_PRESENT_IN_DB,
                                value = RETURN_NOT_FOUND_ERROR_RESPONSE,
                            )
                        ]
                    )
                ]
            )
        ]
    )
    fun deleteReturnOrder(
        @PathVariable returnOrderNumber: Long
    ): ResponseEntity<Unit>
}
