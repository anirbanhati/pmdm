package com.kingfisher.marketplace.model.errors

data class Error(
    var field: String?,
    var rejectedValue: Any?,
    var errorMessage: String?
)
