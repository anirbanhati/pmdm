package com.kingfisher.marketplace.model

import com.kingfisher.marketplace.entity.ReturnLine
import java.util.Collections.emptyList

data class ReturnDataAttributes(
    var lines: List<ReturnLine> = emptyList(),
)
