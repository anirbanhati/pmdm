package com.kingfisher.marketplace.exception.handler

import com.kingfisher.marketplace.utils.Logging
import org.springframework.kafka.support.serializer.FailedDeserializationInfo

class PickEventDeserializationInfo(
    failedDeserializationInfo: FailedDeserializationInfo
) : Logging {

    private val failedDeserializationInformation: FailedDeserializationInfo = failedDeserializationInfo

    init {
        logger().error(
            "Failed to Deserialize Pick: {} from topic: {} with exception: {}",
            failedDeserializationInformation.headers,
            failedDeserializationInformation.topic,
            failedDeserializationInformation.exception.cause,
            failedDeserializationInformation.exception
        )
    }
}
