package com.kingfisher.marketplace.transformer

import ReturnLineResponse
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.model.ConfirmReturnResponse
import com.kingfisher.marketplace.model.ConfirmReturnResponseAttributes
import com.kingfisher.marketplace.model.ConfirmReturnResponseData
import com.kingfisher.marketplace.model.ReturnData
import com.kingfisher.marketplace.model.ReturnDataAttributes
import org.springframework.context.annotation.Configuration

@Configuration
class ApiModelTransfomer {
    fun transformToReturnLineResponse(returnLines: List<ReturnLine>): ReturnLineResponse {
        val returnData = ReturnData()
        returnData.attributes =
            ReturnDataAttributes(returnLines)
        val returnLineResponse = ReturnLineResponse()
        returnLineResponse.data = returnData
        return returnLineResponse
    }

    fun transformToReturnLineResponse(returnLine: ReturnLine): ConfirmReturnResponse? {
        val confirmReturnResponseData = ConfirmReturnResponseData()
        confirmReturnResponseData.attributes =
            ConfirmReturnResponseAttributes(returnLine)
        val confirmReturnResponse = ConfirmReturnResponse()
        confirmReturnResponse.data = confirmReturnResponseData
        return confirmReturnResponse
    }
}
