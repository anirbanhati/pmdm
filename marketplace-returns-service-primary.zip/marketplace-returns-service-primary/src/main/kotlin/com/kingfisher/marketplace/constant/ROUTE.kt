package com.kingfisher.marketplace.constant

enum class ROUTE(val value: String) {
    IFORCE("iForce"),
    DPD("DPD"),
    TBC("TBC"),
    SHIPMENT_NOT_INITIATED("SHIPMENT_NOT_INITIATED");

    companion object {
        fun fromValue(value: String): ROUTE? {
            return values().find { it.value == value }
        }
    }
}
