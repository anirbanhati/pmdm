package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext

interface TenantRouteProvider {

    fun provide(orderInfo: SalesOrderInfo): TenantRouteContext
}
