package com.kingfisher.marketplace.config.productApi.configProperties

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.product-api")
data class ProductApiConfigProperties(
    var productApiUrl: String,
)
