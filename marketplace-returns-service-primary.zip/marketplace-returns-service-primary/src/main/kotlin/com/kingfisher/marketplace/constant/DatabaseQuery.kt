package com.kingfisher.marketplace.constant

class DatabaseQuery {
    companion object {
        internal const val LAST_UPDATED_FOR_NON_CONFIRMED_LINES = ":retentionPeriodInDaysForNonConfirmedLines"
        internal const val LAST_UPDATED_FOR_CONFIRMED_LINES = ":retentionPeriodInDaysForConfirmedLines"
        internal const val QUERY_VALUE_TENANT = ":tenant"
        internal const val QUERY_STATUS_AWAITING_LABEL_PRINTING = ":statusAwaitingLabelPrinting"
        internal const val QUERY_STATUS_AWAITING_STORE_CONFIRMATION = ":statusAwaitingStoreConfirmation"
        internal const val QUERY_STATUS_LABEL_PRINTING_REQUESTED = ":statusLabelPrintingRequested"
        internal const val QUERY_STATUS_COLLECTION_BOOKED = ":statusCollectionBooked"
    }
}
