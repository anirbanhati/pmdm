package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.PROCESS_KAFKA_PICK_EVENT
import com.kingfisher.marketplace.metrics.PROCESS_KAFKA_PICK_EVENT_COLLECTED
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.utils.Logging
import com.kingfisher.orderManagement.avro.ShippingMethodType
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import com.kingfisher.inStoreFulfilment.avro.Pick as InstorePick
import com.kingfisher.orderManagement.avro.Pick as OrderPick

@Service
class PickEventService
@Autowired constructor(
    private val returnLineRepository: ReturnLineRepository,
    private val productApiQueryService: ProductApiQueryService,
    private val returnLineService: ReturnLineService,
    private val configProperties: ConfigProperties,
    private val customMetrics: CustomMetrics
) {

    fun processPickEvent(pick: OrderPick) {
        val timer = customMetrics.startTimer()
        val pickEventPayload = pick.payload
        if (shouldProcessEvent(pickEventPayload.shippingMethodType, pick.eventType)) {
            logger().info("Received Order Pick Event message: $pick and corresponding order ID is: ${pick.payload.orderId}")
            val returnLines: MutableList<ReturnLine> = mutableListOf()
            val eans = pickEventPayload.pickLine.joinToString(",") { pickLine -> pickLine.ean }
            val tenant = pickEventPayload.site.tenant.toString()
            val productApiResponseMap = productApiQueryService.fetchProduct(eans, tenant)
            for (pickedLine in pickEventPayload.pickLine) {
                val returnLine = returnLineService.createNewReturnLine(
                    pickedLine,
                    pickEventPayload,
                    pick.eventType,
                    pick.metadata.createdOn,
                    productApiResponseMap,
                    tenant
                )
                returnLines.add(returnLine)
            }

            if (returnLines.isNotEmpty()) {
                returnLineRepository.save(returnLines)
            }
            customMetrics.reportTimer(PROCESS_KAFKA_PICK_EVENT, timer)
        }
    }

    fun processPickCollectedEvent(instorePick: InstorePick) {
        val timer = customMetrics.startTimer()
        val pickEventPayload = instorePick.payload
        if (shouldProcessPickCollectedEvent(instorePick.eventType)) {
            logger().info("Received Instore Pick Event message: $instorePick and corresponding order ID is: ${instorePick.payload.orderId}")
            val updatedReturnLines: MutableList<ReturnLine> = mutableListOf()
            val existingRecord = (pickEventPayload.orderId + pickEventPayload.aggregateId.takeLast(2))
            val returnLines = returnLineRepository.fetchItemsByHashKey(existingRecord.toLong())
            if (returnLines.isNotEmpty()) {
                returnLines.forEach { returnLine ->
                    returnLine.status = configProperties.eventTypeToStatusMapping[instorePick.eventType].toString()
                }
                updatedReturnLines.addAll(returnLines)
            }
            if (updatedReturnLines.isNotEmpty()) {
                returnLineRepository.save(updatedReturnLines)
            }
            customMetrics.reportTimer(PROCESS_KAFKA_PICK_EVENT_COLLECTED, timer)
        }
    }

    private fun shouldProcessEvent(shippingMethodType: ShippingMethodType?, eventType: String?): Boolean {
        return (configProperties.pickEventShippingMethodTypesToProcess.contains(shippingMethodType.toString()) && configProperties.pickExpiryEventTypesToProcess.contains(
            eventType
        ))
    }

    private fun shouldProcessPickCollectedEvent(eventType: String?): Boolean {
        return (configProperties.eventTypesToUpdateStatusOfExistingRecords.contains(
            eventType
        ))
    }

    companion object : Logging
}
