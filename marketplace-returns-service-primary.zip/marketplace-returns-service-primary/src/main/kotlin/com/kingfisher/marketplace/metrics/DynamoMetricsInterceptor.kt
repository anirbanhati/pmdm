package com.kingfisher.marketplace.metrics

import com.kingfisher.marketplace.metrics.MetricsTags.DYNAMO_OPERATION
import com.kingfisher.marketplace.metrics.MetricsTags.FAILURE
import com.kingfisher.marketplace.metrics.MetricsTags.RESULT
import com.kingfisher.marketplace.metrics.MetricsTags.SUCCESS
import io.micrometer.core.instrument.MeterRegistry
import io.micrometer.core.instrument.Tag
import io.micrometer.core.instrument.Tags
import org.springframework.stereotype.Component
import software.amazon.awssdk.core.interceptor.Context
import software.amazon.awssdk.core.interceptor.ExecutionAttribute
import software.amazon.awssdk.core.interceptor.ExecutionAttributes
import software.amazon.awssdk.core.interceptor.ExecutionInterceptor
import software.amazon.awssdk.core.interceptor.SdkExecutionAttribute
import java.util.concurrent.TimeUnit

@Component
class DynamoMetricsInterceptor(
    private val meterRegistry: MeterRegistry
) : ExecutionInterceptor {

    companion object {
        val START_TIME: ExecutionAttribute<Long> = ExecutionAttribute("startTime")
        const val DYNAMO_METRIC_NAME: String = "return.dynamo.execution"
    }

    override fun beforeExecution(context: Context.BeforeExecution, executionAttributes: ExecutionAttributes) {
        executionAttributes.putAttribute(START_TIME, System.nanoTime())
    }

    override fun afterExecution(
        context: Context.AfterExecution,
        attrs: ExecutionAttributes
    ) {
        record(attrs, SUCCESS)
    }

    override fun onExecutionFailure(context: Context.FailedExecution?, attributes: ExecutionAttributes?) {
        record(attributes, FAILURE)
    }

    private fun record(attrs: ExecutionAttributes?, result: String) {
        val start = attrs?.getAttribute(START_TIME) ?: return
        val duration = System.nanoTime() - start
        val operation = attrs.getAttribute(SdkExecutionAttribute.OPERATION_NAME)

        meterRegistry.timer(DYNAMO_METRIC_NAME,
            Tags.of(
            Tag.of(RESULT, result),
                Tag.of(DYNAMO_OPERATION, operation)
            )
        ).record(duration, TimeUnit.NANOSECONDS)
    }
}
