package com.kingfisher.marketplace.exception

class DateFormatException(val rejectedValue: String?) : RuntimeException()
