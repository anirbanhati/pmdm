package com.kingfisher.marketplace.model.carrierBooking

data class OrderMastersResponse(
    var consignmentCode: String,
    var deliveryDate: String,
)
