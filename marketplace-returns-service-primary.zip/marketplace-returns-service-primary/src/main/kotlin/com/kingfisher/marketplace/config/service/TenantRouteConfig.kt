package com.kingfisher.marketplace.config.service

import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.service.tenant.BQRouteProvider
import com.kingfisher.marketplace.service.tenant.CAPLRouteProvider
import com.kingfisher.marketplace.service.tenant.TenantRouteProvider
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class TenantRouteConfig {

    @Bean
    fun tenantToProviderMap(
        caplRouteProvider: CAPLRouteProvider,
        bqRouteProvider: BQRouteProvider
    ): Map<String, TenantRouteProvider> {
        return mapOf(
            Tenant.BQUK.name to bqRouteProvider,
            Tenant.CAPL.name to caplRouteProvider
        )
    }
}
