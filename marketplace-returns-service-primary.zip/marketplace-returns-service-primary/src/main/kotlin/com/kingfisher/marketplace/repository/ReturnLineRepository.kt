package com.kingfisher.marketplace.repository

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.config.dynamodb.configProperties.DynamoDBConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.LAST_UPDATED_FOR_CONFIRMED_LINES
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.LAST_UPDATED_FOR_NON_CONFIRMED_LINES
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.QUERY_STATUS_AWAITING_LABEL_PRINTING
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.QUERY_STATUS_AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.QUERY_STATUS_COLLECTION_BOOKED
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.QUERY_STATUS_LABEL_PRINTING_REQUESTED
import com.kingfisher.marketplace.constant.DatabaseQuery.Companion.QUERY_VALUE_TENANT
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.model.FetchOrdersResponse
import com.kingfisher.marketplace.utils.CursorUtils
import com.kingfisher.marketplace.utils.DateTimeUtils
import com.kingfisher.marketplace.utils.Logging
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import software.amazon.awssdk.enhanced.dynamodb.*
import software.amazon.awssdk.enhanced.dynamodb.model.*
import software.amazon.awssdk.services.dynamodb.model.AttributeValue
import software.amazon.awssdk.services.dynamodb.model.AttributeValue.fromN
import software.amazon.awssdk.services.dynamodb.model.AttributeValue.fromS
import software.amazon.awssdk.enhanced.dynamodb.Expression
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest
import java.time.LocalDateTime

internal const val MAX_WRITE_SIZE = 25

@Service
class ReturnLineRepository
@Autowired constructor(
    private val configProperties: ConfigProperties,
    private val dynamoDbEnhancedClient: DynamoDbEnhancedClient,
    dynamoDBConfigProperties: DynamoDBConfigProperties
) {
    private val table: DynamoDbTable<ReturnLine> =
        dynamoDbEnhancedClient.table(
            dynamoDBConfigProperties.tableName,
            TableSchema.fromClass(ReturnLine::class.java),
        )

    fun fetchAllLines(): List<ReturnLine> {
        return this.table.scan(
            ScanEnhancedRequest.builder().consistentRead(true).build(),
        ).items().sortedBy {
            it.returnOrderNumber
            it.ean
            it.storeId
            it.lineNumber
        }
    }

    fun fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
        tenant: String,
        storeId: String,
        dateFrom: Number,
        dateTo: Number
    ): List<ReturnLine>? {
        val expressionValue = mutableMapOf<String, AttributeValue>()
        expressionValue[QUERY_VALUE_TENANT] = fromS(tenant)
        expressionValue[LAST_UPDATED_FOR_NON_CONFIRMED_LINES] = fromN(
            (DateTimeUtils.fetchTimeInMs(
                LocalDateTime.now().minusDays(configProperties.retentionPeriodInDaysForNonConfirmedLines)
            )).toString()
        )
        expressionValue[LAST_UPDATED_FOR_CONFIRMED_LINES] = fromN(
            (DateTimeUtils.fetchTimeInMs(
                LocalDateTime.now().minusDays(configProperties.retentionPeriodInDaysForConfirmedLines)
            )).toString()
        )
        expressionValue[QUERY_STATUS_AWAITING_LABEL_PRINTING] = fromS(Status.AWAITING_LABEL_PRINTING.name)
        expressionValue[QUERY_STATUS_AWAITING_STORE_CONFIRMATION] = fromS(Status.AWAITING_STORE_CONFIRMATION.name)
        expressionValue[QUERY_STATUS_LABEL_PRINTING_REQUESTED] = fromS(Status.LABEL_PRINTING_REQUESTED.name)
        expressionValue[QUERY_STATUS_COLLECTION_BOOKED] = fromS(Status.COLLECTION_BOOKED.name)
        return table.index(GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX)
            .query(
                QueryEnhancedRequest.builder()
                    .queryConditional(
                        QueryConditional.sortBetween(
                            Key.builder().partitionValue(storeId).sortValue(dateFrom).build(),
                            Key.builder().partitionValue(storeId).sortValue(dateTo).build(),
                        ),
                    )
                    .filterExpression(
                        Expression.builder()
                            .expression(configProperties.fetchReturnLinesQuery)
                            .expressionValues(expressionValue)
                            .build(),
                    ).build(),
            )
            .flatMap { it.items() }
            .toList()
    }

    fun deleteReturnLine(
        returnOrderId: Long,
        lineNumber: Long
    ) {
        table.deleteItem(
            DeleteItemEnhancedRequest.builder()
                .key(Key.builder().partitionValue(returnOrderId).sortValue(lineNumber).build()).build()
        )
    }

    fun saveOrUpdateReturnLineDetails(returnLine: ReturnLine) {
        table.putItem(returnLine)
    }

    fun save(returnLines: List<ReturnLine>) {
        val batches = returnLines.chunked(MAX_WRITE_SIZE).map { chunk ->
            val batch = WriteBatch.builder(ReturnLine::class.java).mappedTableResource(this.table)
            chunk.forEach(batch::addPutItem)
            batch.build()
        }
        val batchWriteItemEnhancedRequest =
            BatchWriteItemEnhancedRequest.builder()
                .writeBatches(batches)
                .build()

        dynamoDbEnhancedClient.batchWriteItem(batchWriteItemEnhancedRequest)
    }

    fun fetchItemsByHashKey(returnOrderNumber: Long): List<ReturnLine> {
        logger().info("Going to fetch return lines with order number $returnOrderNumber")
        return table.query(
            QueryEnhancedRequest.builder().queryConditional(
                QueryConditional.keyEqualTo(Key.builder().partitionValue(returnOrderNumber).build()),
            ).build()
        )
            .items()
            .toList()
    }

    fun fetchReturnItem(returnOrderNumber: Long, returnLineNumber: Long): ReturnLine? {
        return table.getItem {
            it.key(
                Key.builder()
                    .partitionValue(returnOrderNumber)
                    .sortValue(returnLineNumber)
                    .build()
            )
        }
    }

    fun fetchOrders(
        tenant: String,
        count: Int,
        nextCursor: String?
    ): FetchOrdersResponse {
        logger().info("Fetching orders for tenant={}, requestedCount={}, nextCursor={}",
            tenant, count, nextCursor)
        val tenantExpressionValues =
            mapOf(":tenant" to AttributeValue.fromS(tenant))

        val filterExpression = Expression.builder()
            .expression("tenant = :tenant")
            .expressionValues(tenantExpressionValues)
            .build()

        var exclusiveStartKey = CursorUtils.decode(nextCursor)

        logger().info("Decoded ExclusiveStartKey={}", exclusiveStartKey)

        val orders = mutableListOf<ReturnLine>()
        var lastEvaluatedKey: Map<String, AttributeValue>? = null
        do {
            val scanRequestBuilder = ScanEnhancedRequest.builder()
                .filterExpression(filterExpression)

            exclusiveStartKey?.let {
                scanRequestBuilder.exclusiveStartKey(it)
            }

            val page = table.scan(scanRequestBuilder.build())
                .stream()
                .findFirst()
                .orElseThrow()
            val pageItems = page.items()
            val remaining = count - orders.size
            val itemsToAdd = pageItems.take(remaining)

            orders.addAll(itemsToAdd)

            lastEvaluatedKey =
                if (remaining < pageItems.size) {
                    itemsToAdd.lastOrNull()?.let { lastItem ->
                        mapOf(
                            "return_order_number" to AttributeValue.fromN(
                                lastItem.returnOrderNumber.toString()
                            ),
                            "line_number" to AttributeValue.fromN(
                                lastItem.lineNumber.toString()
                            )
                        )
                    }
                } else {
                    page.lastEvaluatedKey()
                }

            exclusiveStartKey = lastEvaluatedKey
        } while (orders.size < count && !lastEvaluatedKey.isNullOrEmpty())

        val cursor = CursorUtils.encode(lastEvaluatedKey)
        logger().info("Returning {} orders for tenant={}, hasNextCursor={}",
            orders.size, tenant, cursor != null)

        return FetchOrdersResponse(
            orders = orders,
            nextCursor = cursor
        )
    }

    companion object : Logging
}
