package com.kingfisher.marketplace.config

import org.springframework.security.oauth2.core.OAuth2Error
import org.springframework.security.oauth2.core.OAuth2TokenValidator
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult
import org.springframework.security.oauth2.jwt.Jwt

/**
 * Validates the audience claim of an incoming Entra ID JWT.
 * Spring Security does not check the audience by default, so this validator is delegated to alongside
 * the default issuer/expiry validators (see [SecurityConfig.jwtDecoder]). Access is rejected unless the
 * token's audience contains [expectedAudience].
 */
class AudienceValidator(
    private val expectedAudience: String,
) : OAuth2TokenValidator<Jwt> {

    override fun validate(token: Jwt): OAuth2TokenValidatorResult {
        return if (token.audience.contains(expectedAudience)) {
            OAuth2TokenValidatorResult.success()
        } else {
            OAuth2TokenValidatorResult.failure(
                OAuth2Error("invalid_token", "The required audience $expectedAudience is missing", null)
            )
        }
    }
}
