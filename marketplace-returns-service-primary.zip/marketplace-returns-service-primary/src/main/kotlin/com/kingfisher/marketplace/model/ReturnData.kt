package com.kingfisher.marketplace.model

data class ReturnData(
    var type: String = "returnLines",
    var attributes: ReturnDataAttributes = ReturnDataAttributes(),
)
