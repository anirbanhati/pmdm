package com.kingfisher.marketplace.constant

private const val RETURN_LINE = """{
											"returnOrderNumber": 4002,
											"lineNumber": 1,
											"originalOrderLineNumber": 1,
											"tenant": "BQUK",
											"route": "TBC",
											"status": "AWAITING_STORE_CONFIRMATION",
											"ean": "4444444444444",
											"quantity": 13,
											"unitPrice": 0.9,
											"returnDate": "2024-09-26T20:27:03.01",
											"returnDateInMilliSecond": 1727362623010,
											"lastUpdated": "2025-09-26T18:45:03.027347800",
											"lastUpdatedInMilliSecond": 1758892503027,
											"refundCreated": true,
											"cancellationCreated": false,
											"totalPrice": 11.7,
											"storeId": "1017",
											"createdBy": "service",
											"actionedBy": "NA",
											"returnReasonCode": "04",
											"reasonForIForce": "",
											"storeAddress": "NA",
											"offerId": "3213",
											"shopId": "2013",
											"logisticalOrderId": "1000000004-B",
											"recipientAddress": "NA",
											"customerId": "0060110125",
											"labelPrintingRequestedBy": "",
											"technicalAttributes": {
											"technical": [
												{
												"dataType": "Decimal",
												"groupName": "Product_weight",
												"localisedName": "Product weight",
												"uom": "g",
												"value": "155"
												}
											],
											"dimension": []
											},
											"countryCode": "GB",
											"consignmentCode": "",
											"parcelTrackingInfo": [],
											"productName": "Test product 4444444444444",
											"primaryImageUrl": "https://test.scene7.com/is/image/Test/4444444444444_01c_MP",
											"collectionDate": "",
											"isUpdatedManually": false,
											"returnType": "RETURN_TO_STORE",
											"currencyIsoCode": "GBP"
										}"""

object SwaggerExamples {
    const val PARAMETER_RETURN_ORDER_NUMBER = "returnOrderNumber"
    const val PARAMETER_TENANT = "tenant"
    const val PARAMETER_STORE_ID = "storeId"
    const val PARAMETER_DATE_FROM = "dateFrom"
    const val PARAMETER_DATE_TO = "dateTo"
    const val PARAMETER_RETURN_LINE_NUMBER = "returnLineNumber"
    const val PARAMETER_LINE_NUMBER = "lineNumber"
    const val PARAMETER_LAST_UPDATED = "lastUpdated"
    const val RETURN_LINES = "Return Lines"
    const val LIST_OF_RETURN_LINES_STORED_IN_DATABASE = "List of return lines stored in database."
    const val PARAMETER_DATE_TO_DESCRIPTION =
        "Last updated should be earlier than dateTo and dateTo should be after dateFrom, otherwise will DateFormatException will be thrown."
    const val PARAMETER_DATE_FROM_DESCRIPTION = "Last updated should be after than dateFrom."
    const val PARAMETER_STORE_ID_DESCRIPTION =
        "The Store Id from where return order is placed. It should be of 4 digits"
    const val PARAMETER_TENANT_DESCRIPTION = "Return order for which tenant (e.g. BQUK, CAFR)"
    const val PARAMETER_RETURN_ORDER_NUMBER_DESCRIPTION = "ATG Return order number."
    const val PARAMETER_RETURN_LINE_NUMBER_DESCRIPTION = "Return line number."
    const val PARAMETER_RETURN_LAST_UPDATED_DESCRIPTION = "Return line last updated time."
    const val UPDATE_ROUTE_IFORCE_REQUEST_BODY = """
                                {
									"data": {
										"type": "updateRoute",
										"attributes": {
											"userId": "SMukherjee",
											"lines": [
												{
													"lineNumber": 1,
													"ean": "4444444444444",
													"quantity": 5,
													"reason": "Too Large",
													"route": "iForce"
												}
											]
										}
									}
								}
                            """
    const val UPDATE_ROUTE_DPD_REQUEST_BODY = """
                                {
									"data": {
										"type": "updateRoute",
										"attributes": {
											"userId": "SMukherjee",
											"lines": [
												{
													"lineNumber": 1,
													"ean": "4444444444444",
													"quantity": 3,
													"route": "DPD",
													"parcelTrackingInfo": [
														{
															"quantity": 3,
															"externalParcelIdentifier": "4444444444444-001-PRC-001"
														}
													]
												}
											]
										}
									}
								}
                            """
    const val UPDATE_ROUTE_SPLIT_QUANTITY_REQUEST_BODY = """
                                {
									"data": {
										"type": "updateRoute",
										"attributes": {
											"userId": "SMukherjee",
											"lines": [
                                                {
													"lineNumber": 1,
													"ean": "4444444444444",
													"quantity": 2,
													"reason": "Too Large",
													"route": "iForce"
												},
												{
													"lineNumber": 1,
													"ean": "4444444444444",
													"quantity": 3,
													"route": "DPD",
													"parcelTrackingInfo": [
														{
															"quantity": 3,
															"externalParcelIdentifier": "4444444444444-001-PRC-001"
														}
													]
												}
											]
										}
									}
								}
                            """
    const val RETURN_NOT_FOUND_ERROR_DESCRIPTION = "No return lines found for this return order"
    const val RETURN_ORDER_IS_NOT_PRESENT_IN_DB = "Return order is not present in DB"
    const val RETURN_NOT_FOUND_ERROR_RESPONSE = """
                                {
                                    "status": 404,
                                    "errors": [
                                        {
                                            "field": "RETURN_ORDER_ID",
                                            "rejectedValue": "No order line found with return order number 4000",
                                            "errorMessage": "RETURN_ORDER_NOT_FOUND"
                                        }
                                    ]
                                }
                            """
    const val RETURN_LINE_LIST = """
                                    [
										$RETURN_LINE
									]
                                """
    const val SUCCESSFUL_RETURN_LINE_RESPONSE = """
									{
										"data": {
											"type": "returnLines",
											"attributes": {
												"lines": [
													$RETURN_LINE
												]
											}
										}
									}
                                """
    const val CONFIRM_RETURN_RESPONSE = """
									{
										"data": {
											"type": "returnLines",
											"attributes": {
												"line": $RETURN_LINE
											}
										}
									}
                                """
    const val EMPTY_RETURN_LINE_RESPONSE = """
									{
										"data": {
											"type": "returnLines",
											"attributes": {
												"lines": []
											}
										}
									}
                                """
    const val CARRIER_BOOKING_EXCEPTION_RESPONSE = """
                                {
                                    "status": 424,
                                    "errors": [
                                        {
                                            "field": "CARRIER_BOOKING_EXCEPTION",
                                            "rejectedValue": null,
                                            "errorMessage" : "No delivery option found returned by CMS, booking is not possible"
                                        }
                                    ]
                                }
                            """
    const val CONFIRM_RETURN_REQUEST_BODY_FOR_IFORCE = """
								{
									"data": {
										"type": "iForceLabelAttached",
										"attributes": {
											"userId": "SMukherjee"
										}
									}
								}
                            """
    const val CONFIRM_RETURN_REQUEST_BODY_FOR_DPD = """
								{
									"data": {
										"type": "labelPrintingRequested",
										"attributes": {
											"userId": "SMukherjee",
											"parcelTrackingInfo": [
												{
													"quantity": 2,
													"externalParcelIdentifier": "1000000000-A-001-PRC-001"
												}
											]
										}
									}
								}
                            """
    const val UPDATE_RETURN_LINE_REQUEST_BODY = """
                                {
                                    "returnOrderNumber": 400,
                                    "lineNumber": 1,
                                    "status": "COLLECTION_BOOKED",
                                    "route": "DPD"
                                }
                            """
    const val ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_NOT_ALLOWED_TO_UPDATE = """
                                {
                                    "status": 400,
                                    "errors": [
                                        {
                                            "field": "ILLEGAL_UPDATE_EXCEPTION",
                                            "rejectedValue": "DPD",
                                            "errorMessage": "Not possible to update order 400 line 1 as route is already IFORCE"
                                        }
                                    ]
                                }
                            """
    const val ERROR_RESPONSE_FOR_RETURN_LINE_STATUS_NOT_ALLOWED_TO_UPDATE = """
                                {
                                    "status": 400,
                                    "errors": [
                                        {
                                            "field": "ILLEGAL_UPDATE_EXCEPTION",
                                            "rejectedValue": "COLLECTION_BOOKED",
                                            "errorMessage": "Not possible to update order 400 line 1 as status is already CANCELLED"
                                        }
                                    ]
                                }
                            """
    const val ERROR_RESPONSE_FOR_RETURN_LINE_ROUTE_AND_STATUS_COMBINATION_NOT_ALLOWED_TO_UPDATE = """
                                {
                                    "status": 400,
                                    "errors": [
                                        {
                                            "field": "ILLEGAL_UPDATE_EXCEPTION",
                                            "rejectedValue": "TBC",
                                            "errorMessage": "Not possible to update order 400 line 1 as TBC is not available to be updated"
                                        }
                                    ]
                                }
                            """
    const val PARAMETER_COUNT = "count"
    const val PARAMETER_NEXT_CURSOR = "nextCursor"
    const val PARAMETER_COUNT_DESCRIPTION = "Maximum number of return lines to return."
    const val PARAMETER_NEXT_CURSOR_DESCRIPTION = "Cursor returned from the previous request. Omit for the first page."
}
