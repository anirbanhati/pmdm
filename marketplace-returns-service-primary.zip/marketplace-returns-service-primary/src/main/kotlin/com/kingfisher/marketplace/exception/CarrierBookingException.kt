package com.kingfisher.marketplace.exception

import org.springframework.http.HttpStatusCode

class CarrierBookingException(val statusCode: HttpStatusCode, val errorMessage: String) : RuntimeException()
