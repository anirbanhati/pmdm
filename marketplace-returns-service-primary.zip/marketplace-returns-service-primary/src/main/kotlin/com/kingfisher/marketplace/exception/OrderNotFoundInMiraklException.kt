package com.kingfisher.marketplace.exception

class OrderNotFoundInMiraklException(message: String) : RuntimeException(message)
