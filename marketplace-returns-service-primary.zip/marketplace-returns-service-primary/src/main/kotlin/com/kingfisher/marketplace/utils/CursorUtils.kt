package com.kingfisher.marketplace.utils

import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.kingfisher.marketplace.exception.InvalidNextCursorException
import software.amazon.awssdk.services.dynamodb.model.AttributeValue
import java.util.Base64

object CursorUtils {

    private const val RETURN_ORDER_NUMBER = "return_order_number"
    private const val LINE_NUMBER = "line_number"

    private val objectMapper = jacksonObjectMapper()

    fun encode(lastEvaluatedKey: Map<String, AttributeValue>?): String? {
        if (lastEvaluatedKey.isNullOrEmpty()) {
            return null
        }

        val map = lastEvaluatedKey.mapValues { it.value.n() }

        val json = objectMapper.writeValueAsString(map)

        return Base64.getEncoder().encodeToString(json.toByteArray())
    }

    fun decode(cursor: String?): Map<String, AttributeValue>? {
        if (cursor.isNullOrBlank()) {
            return null
        }
        try {
            val json = String(Base64.getDecoder().decode(cursor))

            val values: Map<String, String> = objectMapper.readValue(json)

            validateCursor(values)

            return values.mapValues {
                AttributeValue.fromN(it.value)
            }
        } catch (e: IllegalArgumentException) {
            throw InvalidNextCursorException()
        } catch (e: JsonProcessingException) {
            throw InvalidNextCursorException()
        }
    }

    private fun validateCursor(values: Map<String, String>) {
        val requiredKeys = setOf(
            RETURN_ORDER_NUMBER,
            LINE_NUMBER
        )

        if (values.keys != requiredKeys ||
            values.values.any { it.isBlank() } ||
            values.values.any { it.toLongOrNull() == null }
        ) {
            throw InvalidNextCursorException()
        }
    }
}
