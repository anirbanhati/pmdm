import com.kingfisher.marketplace.model.ReturnData

data class ReturnLineResponse(
    var data: ReturnData = ReturnData(),
)
