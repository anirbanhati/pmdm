package com.kingfisher.marketplace.utils

import org.slf4j.Logger
import org.slf4j.LoggerFactory

interface Logging {
    fun logger(): Logger = LoggerFactory.getLogger(this.javaClass)
}
