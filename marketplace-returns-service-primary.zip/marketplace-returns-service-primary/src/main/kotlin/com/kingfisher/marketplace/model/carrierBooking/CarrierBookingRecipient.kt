package com.kingfisher.marketplace.model.carrierBooking

data class CarrierBookingRecipient(
    var countryCode: String? = null,
    var postCode: String? = null,
    var city: String? = null,
    var name: String? = null,
    var email: String? = null,
    var mobilePhone: String? = null,
    var contactPhone: String? = null,
    var addressLine1: String? = null,
    var addressLine2: String? = null,
)
