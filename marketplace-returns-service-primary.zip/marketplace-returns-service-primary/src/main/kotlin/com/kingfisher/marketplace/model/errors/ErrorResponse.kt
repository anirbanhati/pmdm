package com.kingfisher.marketplace.model.errors

data class ErrorResponse(
    val message: String
)
