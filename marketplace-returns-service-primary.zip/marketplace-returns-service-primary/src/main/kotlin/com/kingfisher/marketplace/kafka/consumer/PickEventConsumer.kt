package com.kingfisher.marketplace.kafka.consumer

import com.kingfisher.marketplace.service.PickEventService
import com.kingfisher.marketplace.utils.Logging
import org.apache.kafka.clients.consumer.ConsumerRecords
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.kafka.support.Acknowledgment
import org.springframework.stereotype.Component
import com.kingfisher.inStoreFulfilment.avro.Pick as InstorePick
import com.kingfisher.orderManagement.avro.Pick as OrderPick

@Component
class PickEventConsumer @Autowired constructor(
    private val pickEventService: PickEventService
) : Logging {
    @KafkaListener(
        topics = ["#{'\${mktp-returns-service.topics}'.split(',')}"],
    )
    fun consumeMessageForPickExpiredEvents(
        consumerRecords: ConsumerRecords<String, OrderPick>,
        acknowledgment: Acknowledgment
    ) {
        for (record in consumerRecords) {
            acknowledgment.acknowledge()
            logger().info("Received Pick Event message: ${record.value()}")
            pickEventService.processPickEvent(record.value())
        }
    }

    @KafkaListener(
        topics = ["#{'\${mktp-returns-service.topicForPickCollectedEvent}'}"],
    )
    fun consumeMessageForPickCollectedEvents(
        consumerRecords: ConsumerRecords<String, InstorePick>,
        acknowledgment: Acknowledgment
    ) {
        for (record in consumerRecords) {
            acknowledgment.acknowledge()
            pickEventService.processPickCollectedEvent(record.value())
        }
    }
}
