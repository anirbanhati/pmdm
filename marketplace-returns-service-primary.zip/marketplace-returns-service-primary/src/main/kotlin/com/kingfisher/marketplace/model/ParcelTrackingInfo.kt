package com.kingfisher.marketplace.model

import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.Positive
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean

@DynamoDbBean
data class ParcelTrackingInfo(
    @field:Positive(message = "Quantity must be greater than 0")
    var quantity: Long = 0,
    @field:NotBlank(message = "External parcel tracking identifier cannot be blank")
    var externalParcelIdentifier: String = "",
    var trackingNumber: String = "",
)
