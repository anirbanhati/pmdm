package com.kingfisher.marketplace.model.cms.request

data class OrderLine(
    val lineNumber: Long,
    val productCode: String,
    val quantity: Long,
    val height: Int,
    val length: Int,
    val width: Int,
    val weight: Double,
    val name: String
)
