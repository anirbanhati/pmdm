package com.kingfisher.marketplace.service

import ReturnLineResponse
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.PARCEL_TRACKING_NUMBER
import com.kingfisher.marketplace.constant.ROUTE.*
import com.kingfisher.marketplace.constant.Status.*
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.REFUND_FAILED_FOR_DPD
import com.kingfisher.marketplace.metrics.RETURN_DPD_CONFIRMED
import com.kingfisher.marketplace.metrics.RETURN_I_FORCE_CONFIRMED
import com.kingfisher.marketplace.model.ConfirmReturnRequest
import com.kingfisher.marketplace.model.ConfirmReturnResponse
import com.kingfisher.marketplace.model.FetchOrdersResponse
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import com.kingfisher.marketplace.utils.DateTimeUtils.Companion.fetchTimeInMs
import com.kingfisher.marketplace.utils.Logging
import com.mirakl.client.core.exception.MiraklException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDateTime
import java.time.LocalDateTime.now

@Service
class ReturnBusinessService
@Autowired constructor(
    private val returnLineRepository: ReturnLineRepository,
    private val dataTransformer: ApiModelTransfomer,
    private val miraklAPIService: MiraklAPIService,
    private val sellerContentBuilder: SellerContentBuilder,
    private val configProperties: ConfigProperties,
    private val customMetrics: CustomMetrics
) {
    fun fetchAllReturnLines(): List<ReturnLine> = this.returnLineRepository.fetchAllLines()

    fun fetchOrders(
        tenant: Tenant,
        count: Int,
        nextCursor: String?
    ): FetchOrdersResponse {
        return returnLineRepository.fetchOrders(
            tenant = tenant.name,
            count = count,
            nextCursor = nextCursor
        )
    }

    fun fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
        tenant: String,
        storeId: String,
        dateFrom: LocalDateTime,
        dateTo: LocalDateTime,
    ): ReturnLineResponse? {
        return returnLineRepository.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
            tenant,
            storeId,
            fetchTimeInMs(dateFrom),
            fetchTimeInMs(dateTo),
        )?.let {
            dataTransformer.transformToReturnLineResponse(it)
        }
    }

    fun updateLastUpdated(
        returnOrderNumber: Long,
        returnLineNumber: Long,
        lastUpdated: LocalDateTime,
    ): ConfirmReturnResponse? {
        when (val returnLine = this.returnLineRepository.fetchReturnItem(returnOrderNumber, returnLineNumber)) {
            (null) -> {
                throw OrderNotFoundException(returnOrderNumber.toString())
            }

            else -> {
                returnLine.lastUpdated = lastUpdated.toString()
                returnLine.lastUpdatedInMilliSecond = fetchTimeInMs(lastUpdated).toLong()
                returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)
                return dataTransformer.transformToReturnLineResponse(returnLine)
            }
        }
    }

    fun confirmReturn(
        returnOrderNumber: Long,
        returnLineNumber: Long,
        confirmReturnRequest: ConfirmReturnRequest,
    ): ConfirmReturnResponse? {
        when (val returnLine = this.returnLineRepository.fetchReturnItem(returnOrderNumber, returnLineNumber)) {
            (null) -> {
                throw OrderNotFoundException(returnOrderNumber.toString())
            }

            else -> {
                returnLine.status = LABEL_PRINTING_REQUESTED.name
                returnLine.lastUpdatedInMilliSecond = fetchTimeInMs(now()).toLong()
                returnLine.lastUpdated = now().toString()
                returnLine.labelPrintingRequestedBy = confirmReturnRequest.data.attributes.userId
                returnLine.parcelTrackingInfo = confirmReturnRequest.data.attributes.parcelTrackingInfo
                when (returnLine.route) {
                    DPD.value -> confirmDPDLine(returnLine)
                }
                if (!returnLine.refundCreated) {
                    customMetrics.incrementCounter(REFUND_FAILED_FOR_DPD)
                }
                returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)
                when (returnLine.route) {
                    IFORCE.value -> customMetrics.incrementCounter(RETURN_I_FORCE_CONFIRMED)
                    DPD.value -> customMetrics.incrementCounter(RETURN_DPD_CONFIRMED)
                }
                return dataTransformer.transformToReturnLineResponse(returnLine)
            }
        }
    }

    private fun confirmDPDLine(returnLine: ReturnLine) {
        try {
            if (!returnLine.refundCreated) {
                miraklAPIService.createRefund(
                    returnLine.totalPrice,
                    returnLine.quantity,
                    returnLine.logisticalOrderId,
                    returnLine.originalOrderLineNumber,
                    returnLine.returnReasonCode,
                    returnLine.currencyIsoCode,
                    returnLine.tenant
                )
                returnLine.refundCreated = true
            }
            for (parcelInfo in returnLine.parcelTrackingInfo) {
                val sellerNotificationContent = sellerContentBuilder.buildSellerNotificationContent(
                    returnLine.route, returnLine.returnType, returnLine.productName, returnLine.ean,
                    parcelInfo.quantity,
                    returnLine.returnReasonCode,
                    MIRAKL_REFUND_REASON_CODE_PREFIX,
                    Tenant.BQUK.name,
                    returnLine.reasonForIForce,
                    buildParcelTrackingUrl(
                        parcelInfo.trackingNumber,
                        returnLine.route
                    )

                )
                miraklAPIService.notifySeller(
                    returnLine.logisticalOrderId,
                    sellerNotificationContent,
                    tenant = returnLine.tenant
                )
            }
        } catch (e: MiraklException) {
            logger().error("Error while creating refund or notify seller for line ${returnLine.originalOrderLineNumber} of order ${returnLine.logisticalOrderId} due to exception $e")
        }
    }

    private fun buildParcelTrackingUrl(parcelTrackingNumber: String, route: String): String {
        return configProperties.parcelTrackingUrlPattern.get(route)!!.replace(
            PARCEL_TRACKING_NUMBER,
            parcelTrackingNumber,
        )
    }

    fun deleteReturnLine(
        returnOrderNumber: Long,
        lineNumber: Long,
    ) {
        this.returnLineRepository.deleteReturnLine(returnOrderNumber, lineNumber)
    }

    fun deleteAllLineAssociatedWithReturnOrder(returnOrderNumber: Long) {
        val returnLines = this.returnLineRepository.fetchItemsByHashKey(returnOrderNumber)
        if (returnLines.isNotEmpty()) {
            returnLines.forEach { line -> deleteReturnLine(line.returnOrderNumber, line.lineNumber) }
        } else {
            throw OrderNotFoundException("No order line found with return order number $returnOrderNumber")
        }
    }

    fun fetchAllLineDetailsAssociatedWithReturnOrder(returnOrderNumber: Long): ReturnLineResponse {
        val returnLines = this.returnLineRepository.fetchItemsByHashKey(returnOrderNumber)
        if (returnLines.isNotEmpty()) {
            return this.dataTransformer.transformToReturnLineResponse(returnLines)
        } else {
            throw OrderNotFoundException("No order line found with return order number $returnOrderNumber")
        }
    }

    companion object : Logging
}
