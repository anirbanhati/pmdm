package com.kingfisher.marketplace.model.sellerAddress

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
data class InStoreReturnDetails(
    var departmentName: String? = null,
    var address: String? = null,
    var addressLine1: String? = null,
    var addressLine2: String? = null,
    var city: String? = null,
    var state: String? = null,
    var country: String? = null,
    var zipCode: String? = null,
    // CAPL Mappings
    var street: String? = null,
    var houseNumber: String? = null,
    var flatNumber: String? = null,
    var mobileNumber: String? = null,
    var mobileNumberPrefix: String? = null
)
