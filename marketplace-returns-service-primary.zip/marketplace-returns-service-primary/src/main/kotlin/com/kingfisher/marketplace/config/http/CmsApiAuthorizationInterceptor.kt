package com.kingfisher.marketplace.config.http

import com.kingfisher.marketplace.constant.Constant
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.utils.Logging
import org.springframework.http.HttpHeaders.ACCEPT
import org.springframework.http.HttpHeaders.CONTENT_TYPE
import org.springframework.http.HttpRequest
import org.springframework.http.client.ClientHttpRequestExecution
import org.springframework.http.client.ClientHttpRequestInterceptor
import org.springframework.http.client.ClientHttpResponse
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager
import org.springframework.security.oauth2.core.OAuth2AuthorizationException

/**
 * Adds a Bearer token, Content-Type and Accept headers to every CMS API request.
 */
class CmsApiAuthorizationInterceptor(
    private val authorizedClientManager: OAuth2AuthorizedClientManager
) : ClientHttpRequestInterceptor, Logging {

    override fun intercept(
        request: HttpRequest,
        body: ByteArray,
        execution: ClientHttpRequestExecution
    ): ClientHttpResponse {
        request.headers.setBearerAuth(fetchAccessToken())
        request.headers.set(CONTENT_TYPE, Constant.CONTENT_TYPE_APPLICATION_VND_API_JSON)
        request.headers.set(ACCEPT, Constant.CONTENT_TYPE_APPLICATION_VND_API_JSON)
        return execution.execute(request, body)
    }

    private fun fetchAccessToken(): String {
        val authorizeRequest = OAuth2AuthorizeRequest
            .withClientRegistrationId(CMS_REGISTRATION_ID)
            .principal(CMS_REGISTRATION_ID)
            .build()

        val authorizedClient = try {
            authorizedClientManager.authorize(authorizeRequest)
        } catch (ex: OAuth2AuthorizationException) {
            logger().error("Failed to obtain Entra access token for CMS API: ${ex.error}", ex)
            throw CmsApiException(
                "Failed to obtain access token for cms: ${ex.error.errorCode ?: "unknown"}"
            )
        } catch (ex: Exception) {
            logger().error("Unexpected error obtaining Entra access token for CMS API", ex)
            throw CmsApiException("Unexpected error obtaining access token for cms: ${ex.message}")
        }

        return authorizedClient?.accessToken?.tokenValue ?: run {
            logger().error("Entra returned no authorized client for cms")
            throw CmsApiException("No access token available for client registration cms")
        }
    }

    companion object {
        const val CMS_REGISTRATION_ID = "cms"
    }
}
