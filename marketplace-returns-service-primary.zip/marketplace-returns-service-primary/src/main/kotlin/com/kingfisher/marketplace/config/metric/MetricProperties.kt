package com.kingfisher.marketplace.config.metric

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.metrics")
data class MetricProperties(
    val allowed: List<String> = emptyList()
)
