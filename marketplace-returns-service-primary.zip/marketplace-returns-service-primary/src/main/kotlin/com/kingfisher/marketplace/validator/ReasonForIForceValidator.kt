package com.kingfisher.marketplace.validator

import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.model.UpdateReturnRequestLine
import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext

class ReasonForIForceValidator : ConstraintValidator<ValidReasonForIForce, UpdateReturnRequestLine> {
    override fun isValid(updateReturnLine: UpdateReturnRequestLine, context: ConstraintValidatorContext?): Boolean {
        var result = true
        if (updateReturnLine.route == IFORCE.value) {
            result = !updateReturnLine.reason.isNullOrEmpty()
        }
        return result
    }
}
