package com.kingfisher.marketplace.kafka.consumer

import com.kingfisher.marketplace.model.kafka.DeliveryNotification
import com.kingfisher.marketplace.service.DeliveryNotificationService
import com.kingfisher.marketplace.utils.Logging
import org.apache.kafka.clients.consumer.ConsumerRecords
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Profile
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.kafka.support.Acknowledgment
import org.springframework.stereotype.Service

@Profile("local")
@Service
class DeliveryNotificationConsumer @Autowired constructor(
    private val deliveryNotificationService: DeliveryNotificationService
) {

    @KafkaListener(
        containerFactory = "deliveryNotificationContainerFactory",
        topics = ["#{'\${mktp-returns-service.deliveryNotificationTopic}'}"],
        )
    fun consumeDeliveryNotification(
        consumerRecords: ConsumerRecords<String, DeliveryNotification>,
        acknowledgment: Acknowledgment
    ) {
        for (record in consumerRecords) {
            acknowledgment.acknowledge()
            logger().info("Received record ${record.value()}")
            deliveryNotificationService.processDeliveryNotification(record.value())
        }
    }
    companion object : Logging
}
