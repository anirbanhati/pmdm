package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class ProductMediaObject(
    @JsonProperty("contentUrl") var contentUrl: String = "",
    @JsonProperty("description") var description: String = "",
)
