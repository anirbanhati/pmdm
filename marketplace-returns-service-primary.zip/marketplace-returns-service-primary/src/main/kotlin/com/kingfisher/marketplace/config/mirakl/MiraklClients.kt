package com.kingfisher.marketplace.config.mirakl

import com.mirakl.client.mmp.operator.core.MiraklMarketplacePlatformOperatorApiClient

class MiraklClients(
    private val clients: Map<String, MiraklMarketplacePlatformOperatorApiClient>
) {
    fun getClient(tenantId: String): MiraklMarketplacePlatformOperatorApiClient {
        return clients[tenantId]
            ?: throw IllegalArgumentException("No Mirakl client configured for tenant: $tenantId")
    }
}
