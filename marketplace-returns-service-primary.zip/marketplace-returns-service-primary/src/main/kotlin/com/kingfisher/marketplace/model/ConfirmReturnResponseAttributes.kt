package com.kingfisher.marketplace.model

import com.kingfisher.marketplace.entity.ReturnLine

data class ConfirmReturnResponseAttributes(
    val line: ReturnLine = ReturnLine(),
)
