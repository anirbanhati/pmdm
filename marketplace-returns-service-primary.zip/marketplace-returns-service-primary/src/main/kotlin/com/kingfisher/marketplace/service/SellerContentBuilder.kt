package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.LEADING_ZERO_IN_REASON_CODE
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.utils.FileUtils.fetchFileContent
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

const val PARAMETER_PRODUCT_NAME_STRING: String = "{productName}"
const val PARAMETER_EAN_STRING: String = "{ean}"
const val PARAMETER_QTY_STRING: String = "{qty}"
const val PARAMETER_REASON_STRING: String = "{reason}"
const val PARAMETER_TRACKING_LINK: String = "{trackingLink}"
const val PARAMETER_IFORCE_REASON_MESSAGE: String = "{iForceReasonMessage}"
const val PARAMETER_ORDER_NUMBER: String = "{orderNumber}"

@Service
class SellerContentBuilder
@Autowired constructor(
    private val configProperties: ConfigProperties
) {

    private fun String.replaceIf(
        condition: Boolean,
        oldValue: String,
        newValue: String
    ): String = if (condition) replace(oldValue, newValue) else this

    fun buildSellerNotificationContent(
        route: String,
        returnType: String,
        name: String,
        ean: String,
        quantity: Long,
        reasonCode: String,
        reasonCodePrefix: String,
        tenant: String,
        reasonForIForce: String? = null,
        trackingLink: String? = null,
        orderNumber: String? = null
    ): String {
        return fetchFileContent(determineNotificationTemplateKey(route, returnType, tenant)).replace(
            PARAMETER_PRODUCT_NAME_STRING,
            name
        ).replace(
            PARAMETER_EAN_STRING,
            ean,
        ).replace(
            PARAMETER_QTY_STRING, quantity.toString()
        ).replace(
            PARAMETER_REASON_STRING,
            determineReasonCode(reasonCodePrefix, reasonCode, tenant)
        ).replace(
            PARAMETER_TRACKING_LINK,
            trackingLink ?: ""
        ).replaceIf(
            Tenant.BQUK.name == tenant,
            PARAMETER_IFORCE_REASON_MESSAGE,
            configProperties.iForceReasonMessageBasedOnReasonForIForce[reasonForIForce] ?: ""
        ).replaceIf(
            Tenant.CAPL.name == tenant,
            PARAMETER_ORDER_NUMBER,
            orderNumber ?: ""
        )
    }

    private fun determineNotificationTemplateKey(route: String, returnType: String, tenant: String): String {
        val templates: Map<String, String> = configProperties.routeToSellerNotificationTemplate[tenant]!!
        return templates.getOrDefault(("${route}_$returnType"), templates.getValue(route))
    }

    private fun determineReasonCode(reasonCodePrefix: String, reasonCode: String, tenant: String): String {
        val reasonCodes = configProperties.reasonCodeMap[tenant]!!
        return reasonCodes.getValue(reasonCodePrefix + '_' + reasonCode.removePrefix(LEADING_ZERO_IN_REASON_CODE))
    }
}
