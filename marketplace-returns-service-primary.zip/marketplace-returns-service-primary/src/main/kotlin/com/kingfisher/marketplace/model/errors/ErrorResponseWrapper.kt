package com.kingfisher.marketplace.model.errors

data class ErrorResponseWrapper(
    var status: Int,
    var errors: List<Error>?
)
