package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.mirakl.MiraklClients
import com.kingfisher.marketplace.constant.Constant
import com.kingfisher.marketplace.constant.Constant.Companion.LEADING_ZERO_IN_REASON_CODE
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_CANCEL_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.exception.OrderNotFoundInMiraklException
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode
import com.mirakl.client.mmp.domain.order.MiraklOrder
import com.mirakl.client.mmp.operator.domain.order.cancelation.MiraklCreateCancelation
import com.mirakl.client.mmp.operator.domain.order.refund.MiraklOperatorCreateRefund
import com.mirakl.client.mmp.operator.request.order.cancelation.MiraklCreateCancelationsRequest
import com.mirakl.client.mmp.operator.request.order.message.MiraklCreateOrderThreadRequest
import com.mirakl.client.mmp.operator.request.order.refund.MiraklOperatorCreateRefundRequest
import com.mirakl.client.mmp.request.order.MiraklGetOrdersRequest
import com.mirakl.client.mmp.request.order.message.MiraklCreateOrderThread
import com.mirakl.client.mmp.request.order.message.MiraklThreadTopic
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.io.File
import java.math.BigDecimal

@Service
class MiraklAPIService
@Autowired
constructor(
    private val miraklClients: MiraklClients
) {

    fun createRefund(
        totalPrice: BigDecimal,
        quantity: Long,
        logisticalOrderId: String,
        lineNumber: Long,
        reasonCode: String,
        currencyIsoCode: String,
        tenant: String
    ) {
        val refund = MiraklOperatorCreateRefund()
        refund.amount = totalPrice
        refund.quantity = quantity.toInt()
        refund.currencyIsoCode = currencyIsoCode.takeIf { it.isNotBlank() }
            .let { runCatching { MiraklIsoCurrencyCode.valueOf(it.toString()) }.getOrNull() }
            ?: getMiraklOrderDetailsByOrderId(logisticalOrderId, tenant).currencyIsoCode
        refund.orderLineId = logisticalOrderId.split('-')[0] + '-' + lineNumber
        refund.shippingAmount = BigDecimal.valueOf(0)
        refund.reasonCode =
            MIRAKL_REFUND_REASON_CODE_PREFIX + '_' + reasonCode.removePrefix(LEADING_ZERO_IN_REASON_CODE)
        miraklClients.getClient(tenant)
            .requestRefundOrder(MiraklOperatorCreateRefundRequest(mutableListOf(refund)))
    }

    fun createCancellation(
        totalPrice: BigDecimal,
        quantity: Long,
        logisticalOrderId: String,
        lineNumber: Long,
        reasonCode: String,
        currencyIsoCode: String,
        tenant: String
    ) {
        val cancellation = MiraklCreateCancelation()
        cancellation.amount = totalPrice
        cancellation.quantity = quantity.toInt()
        cancellation.currencyIsoCode = currencyIsoCode.takeIf { it.isNotBlank() }
            .let { runCatching { MiraklIsoCurrencyCode.valueOf(it.toString()) }.getOrNull() }
            ?: getMiraklOrderDetailsByOrderId(logisticalOrderId, tenant).currencyIsoCode
        cancellation.orderLineId = logisticalOrderId.split('-')[0] + '-' + lineNumber
        cancellation.shippingAmount = BigDecimal.ZERO
        cancellation.reasonCode =
            MIRAKL_CANCEL_REASON_CODE_PREFIX + '_' + reasonCode.removePrefix(LEADING_ZERO_IN_REASON_CODE)
        miraklClients.getClient(tenant)
            .cancelOrderLines(MiraklCreateCancelationsRequest(mutableListOf(cancellation)))
    }

    fun notifySeller(
        logisticalOrderId: String,
        message: String,
        tenant: String
    ) {
        val thread = MiraklCreateOrderThread()
        val topic = MiraklThreadTopic()
        val attachments = mutableListOf<File>()
        topic.type = Constant.TOPIC_TYPE
        topic.value = Constant.TOPIC_VALUE
        thread.body = message
        thread.topic = topic
        thread.to = listOf(Constant.THREAD_TO)
        val request = MiraklCreateOrderThreadRequest(logisticalOrderId, thread, attachments)
        miraklClients.getClient(tenant).createOrderThread(request)
    }

    fun getMiraklOrderDetailsByOrderId(orderId: String, tenant: String): MiraklOrder {
        val request = MiraklGetOrdersRequest()
        request.orderIds = listOf(orderId)
        return miraklClients.getClient(tenant).getOrders(request).orders.stream().findFirst()
            .orElseThrow { OrderNotFoundInMiraklException("Order not found in Mirakl with id $orderId") }
    }
}
