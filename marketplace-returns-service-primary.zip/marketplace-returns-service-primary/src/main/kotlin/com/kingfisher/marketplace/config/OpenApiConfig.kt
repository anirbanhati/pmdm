package com.kingfisher.marketplace.config

import io.swagger.v3.oas.models.Components
import io.swagger.v3.oas.models.OpenAPI
import io.swagger.v3.oas.models.security.OAuthFlow
import io.swagger.v3.oas.models.security.OAuthFlows
import io.swagger.v3.oas.models.security.Scopes
import io.swagger.v3.oas.models.security.SecurityRequirement
import io.swagger.v3.oas.models.security.SecurityScheme
import org.springdoc.core.customizers.OpenApiCustomizer
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

/**
 * Configures Swagger UI so the "Authorize" button performs an Entra ID authorization-code (PKCE) login,
 * letting developers call the secured `/v2` endpoints from the docs. Tenant and audience are taken from
 * [ApiSecurityProperties] so the docs work per environment.
 */
@Configuration
class OpenApiConfig(
    private val apiSecurityProperties: ApiSecurityProperties,
) {

    @Bean
    fun openAPI(): OpenAPI {
        val tenantId = apiSecurityProperties.tenantId
        val scope = "api://${apiSecurityProperties.audience}/access_as_user"

        val scopes = Scopes().addString(scope, "Access API as user")

        val oauthFlow = OAuthFlow()
            .authorizationUrl("https://login.microsoftonline.com/$tenantId/oauth2/v2.0/authorize")
            .tokenUrl("https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token")
            .scopes(scopes)

        val oauthFlows = OAuthFlows().authorizationCode(oauthFlow)

        val securityScheme = SecurityScheme()
            .type(SecurityScheme.Type.OAUTH2)
            .flows(oauthFlows)

        return OpenAPI()
            .components(Components().addSecuritySchemes("oauth2", securityScheme))
    }

    /**
     * Applies the `oauth2` security requirement to `/v2` operations only
     * TODO remove once V1 is removed
     */
    @Bean
    fun v2SecurityCustomizer(): OpenApiCustomizer = OpenApiCustomizer { openApi ->
        openApi.paths
            .filterKeys { it.startsWith("/v2") }
            .forEach { (_, pathItem) ->
                pathItem.readOperations().forEach { operation ->
                    operation.addSecurityItem(SecurityRequirement().addList("oauth2"))
                }
            }
    }
}
