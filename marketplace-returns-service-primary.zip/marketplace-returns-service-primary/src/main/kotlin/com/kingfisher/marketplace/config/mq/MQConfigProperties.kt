package com.kingfisher.marketplace.config.mq

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.ibm.mq")
data class MQConfigProperties(
    var host: String,
    var password: String?,
    var port: String,
    var queueManager: String?,
    var channel: String,
    var user: String,
    var queueName: String,
)
