package com.kingfisher.marketplace.config.mirakl

import com.kingfisher.marketplace.config.mirakl.configProperties.MiraklConfigProperties
import com.kingfisher.marketplace.config.mirakl.configProperties.MiraklTenantProperties
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.utils.Logging
import com.mirakl.client.core.security.MiraklClientCredentialFlow
import com.mirakl.client.mmp.operator.core.MiraklMarketplacePlatformOperatorApiClient
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

const val ERROR_MSG_FAILED_TO_INITIALIZE_MIRAKL_CREDENTIAL = "Failed to initialize Mirakl credential"

private const val ERROR_MSG_CLIENT_ID_REQUIRED_FOR_OAUTH2 = "CLIENT_ID required for OAuth2"

private const val ERROR_MSG_CLIENT_SECRET_REQUIRED_FOR_OAUTH2 = "CLIENT_SECRET required for OAuth2"

private const val ERROR_MSG_AUTH_URL_REQUIRED_FOR_OAUTH2 = "AUTH_URL required for OAuth2"

private const val ERROR_MSG_ERROR_INITIALIZING_MIRAKL_CREDENTIAL = "Error initializing Mirakl credential"

@Configuration
class MiraklClientConfig(
    private val miraklConfigProperties: MiraklConfigProperties,
) {
    companion object : Logging

    @Bean
    fun miraklClientFactory(
        @Qualifier("bqMiraklClient") bqClient: MiraklMarketplacePlatformOperatorApiClient,
        @Qualifier("caplMiraklClient") caplClient: MiraklMarketplacePlatformOperatorApiClient,
    ): MiraklClients = MiraklClients(mapOf(Tenant.BQUK.name to bqClient, Tenant.CAPL.name to caplClient))

    @Bean
    fun bqMiraklClient(): MiraklMarketplacePlatformOperatorApiClient {
        val tenant = Tenant.BQUK.name
        return buildClient(tenant, miraklConfigProperties.tenants[tenant]!!)
    }

    @Bean
    fun caplMiraklClient(): MiraklMarketplacePlatformOperatorApiClient {
        val tenant = Tenant.CAPL.name
        return buildClient(tenant, miraklConfigProperties.tenants[tenant]!!)
    }

    private fun buildClient(
        tenantId: String,
        props: MiraklTenantProperties
    ): MiraklMarketplacePlatformOperatorApiClient {
        return try {
            logger().info("Initializing OAuth2 for tenant: $tenantId")
            require(props.clientId.isNotBlank()) { ERROR_MSG_CLIENT_ID_REQUIRED_FOR_OAUTH2 }
            require(props.clientSecret.isNotBlank()) { ERROR_MSG_CLIENT_SECRET_REQUIRED_FOR_OAUTH2 }
            require(miraklConfigProperties.authUrl.isNotBlank()) { ERROR_MSG_AUTH_URL_REQUIRED_FOR_OAUTH2 }

            val credential = MiraklClientCredentialFlow(
                props.clientId,
                props.clientSecret,
                miraklConfigProperties.authUrl
            )
            CustomMiraklClient(credential, props.url, tenantId)
        } catch (e: Exception) {
            logger().error("$ERROR_MSG_ERROR_INITIALIZING_MIRAKL_CREDENTIAL for tenant: $tenantId", e)
            throw RuntimeException(ERROR_MSG_FAILED_TO_INITIALIZE_MIRAKL_CREDENTIAL, e)
        }
    }
}
