package com.kingfisher.marketplace.config.mirakl

import com.mirakl.client.core.internal.MiraklClientConfigWrapper
import com.mirakl.client.core.security.Credential
import com.mirakl.client.mmp.operator.core.MiraklMarketplacePlatformOperatorApiClient

open class CustomMiraklClient(
    credential: Credential,
    url: String,
    val tenant: String,
) : MiraklMarketplacePlatformOperatorApiClient(url, credential) {
    override fun configure(clientConfigWrapper: MiraklClientConfigWrapper) {
        super.configure(clientConfigWrapper)
        clientConfigWrapper.requestConfigBuilder
            .setConnectTimeout(2000)
            .setSocketTimeout(10000)
    }
}
