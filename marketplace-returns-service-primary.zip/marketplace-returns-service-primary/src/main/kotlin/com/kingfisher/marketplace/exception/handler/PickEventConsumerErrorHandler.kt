package com.kingfisher.marketplace.exception.handler

import com.kingfisher.marketplace.utils.Logging
import java.util.function.Function
import org.apache.kafka.clients.consumer.Consumer
import org.springframework.kafka.listener.ConsumerAwareListenerErrorHandler
import org.springframework.kafka.listener.ListenerExecutionFailedException
import org.springframework.kafka.support.serializer.FailedDeserializationInfo
import org.springframework.messaging.Message
import org.springframework.stereotype.Service

@Service
class PickEventConsumerErrorHandler : Function<FailedDeserializationInfo, PickEventDeserializationInfo>,
    ConsumerAwareListenerErrorHandler, Logging {

    // handles deserialization exception
    override fun apply(t: FailedDeserializationInfo): PickEventDeserializationInfo {
        return PickEventDeserializationInfo(t)
    }

    // handles other exceptions
    override fun handleError(
        message: Message<*>,
        exception: ListenerExecutionFailedException,
        consumer: Consumer<*, *>
    ): Any {
        val pickList = message.payload
        logger().error(
            "Failed to consume pick: {} with exception: {}",
            pickList.toString(),
            exception.cause,
            exception
        )
        return Any()
    }
}
