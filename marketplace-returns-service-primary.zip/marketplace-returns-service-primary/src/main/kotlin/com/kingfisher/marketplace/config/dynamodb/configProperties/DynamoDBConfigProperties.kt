package com.kingfisher.marketplace.config.dynamodb.configProperties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Configuration

@Configuration
@ConfigurationProperties(prefix = "mktp-returns-service.dynamodb")
data class DynamoDBConfigProperties(
    var region: String?,
    var tableName: String?,
    var accessKey: String?,
    var secretKey: String?,
    var url: String?,
)
