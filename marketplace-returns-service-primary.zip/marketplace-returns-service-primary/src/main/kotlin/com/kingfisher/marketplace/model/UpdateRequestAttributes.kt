package com.kingfisher.marketplace.model

import jakarta.validation.Valid
import jakarta.validation.constraints.NotBlank

data class UpdateRequestAttributes(
    @field:NotBlank(message = "user id can not be blank") val userId: String,
    @field:Valid
    val lines: List<UpdateReturnRequestLine>,
)
