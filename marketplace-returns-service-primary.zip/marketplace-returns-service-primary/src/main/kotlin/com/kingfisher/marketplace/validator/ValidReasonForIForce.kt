package com.kingfisher.marketplace.validator

import jakarta.validation.Constraint
import jakarta.validation.Payload
import kotlin.annotation.AnnotationRetention.RUNTIME
import kotlin.annotation.AnnotationTarget.CLASS
import kotlin.annotation.AnnotationTarget.TYPE
import kotlin.reflect.KClass

@Target(TYPE, CLASS)
@Retention(RUNTIME)
@Constraint(validatedBy = [ReasonForIForceValidator::class])
annotation class ValidReasonForIForce(
    val message: String = "Invalid value",
    val groups: Array<KClass<*>> = [],
    val payload: Array<KClass<out Payload>> = []
)
