package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class ProductAPIResponse(
    @JsonProperty("data") val data: List<ProductData>,
)
