package com.kingfisher.marketplace.model

import jakarta.validation.Valid

data class UpdateRouteRequest(
    @field:Valid val data: UpdateRequestData,
)
