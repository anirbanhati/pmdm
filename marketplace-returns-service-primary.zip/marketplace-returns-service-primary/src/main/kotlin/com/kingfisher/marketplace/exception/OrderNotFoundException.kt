package com.kingfisher.marketplace.exception

class OrderNotFoundException(val rejectedValue: String?) : RuntimeException()
