package com.kingfisher.marketplace.jms

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.COMMA_SEPARATOR
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.PRODUCT_MEDIA_OBJECT_DESCRIPTION_PRIMARY_IMAGE
import com.kingfisher.marketplace.constant.ReturnType.RETURN_TO_STORE
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.mapper.ReturnLineMapper
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.MetricsTags.FAILURE
import com.kingfisher.marketplace.metrics.MetricsTags.SUCCESS
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.service.MiraklAPIService
import com.kingfisher.marketplace.service.PostRefundHandler
import com.kingfisher.marketplace.service.ProductApiQueryService
import com.kingfisher.marketplace.service.ReturnLineService
import com.kingfisher.marketplace.service.SellerContentBuilder
import com.kingfisher.marketplace.service.tenant.TenantRouteHandler
import com.kingfisher.marketplace.utils.DateTimeUtils.Companion.fetchTimeInMs
import com.kingfisher.marketplace.utils.Logging
import com.kingfisher.www.oagis._9.ProcessSalesOrderDocument
import com.kingfisher.www.oagis._9.SalesOrderType
import org.apache.axiom.om.OMXMLBuilderFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.jms.annotation.JmsListener
import org.springframework.stereotype.Service
import java.io.StringReader
import java.time.LocalDateTime.now
import javax.xml.stream.XMLInputFactory

@Service
class ReturnOrderJmsListener
@Autowired constructor(
    private val sellerContentBuilder: SellerContentBuilder,
    private val productApiQueryService: ProductApiQueryService,
    private val miraklAPIService: MiraklAPIService,
    private val configProperties: ConfigProperties,
    private val customMetrics: CustomMetrics,
    private val returnLineMapper: ReturnLineMapper,
    private val returnLineService: ReturnLineService,
    private val tenantRouteHandler: TenantRouteHandler,
    private val postRefundHandler: PostRefundHandler
) {

    @JmsListener(destination = "\${mktp-returns-service.ibm.mq.queueName}", concurrency = "1-10")
    fun processReturnOrder(returnOrderPSO: String) {
        val timer = customMetrics.startTimer()
        val returnLines: MutableList<ReturnLine> = mutableListOf()
        val salesOrder = extractSalesOrder(returnOrderPSO)
        val orderId = salesOrder.orderId()
        val originalOrderId = salesOrder.originalOrderId()
        val notes = salesOrder.notes()
        logger().info("Received Return Order ID : $orderId")
        val tenant = configProperties.brandTenantMap.getValue(salesOrder.tenant())
        val eligibleOrderLines = salesOrder.eligibleOrderLines(configProperties.eligibleCategoryCodes)
        val eans = eligibleOrderLines.joinToString(COMMA_SEPARATOR) { it.ean() }
        try {
            val productApiResponseMap = productApiQueryService.fetchProduct(eans, tenant)
            val createdBy = salesOrder.createdBy()
            for (lineType in eligibleOrderLines) {
                val logisticalOrderId = lineType.logisticalOrderId()
                val originalOrderLineNumber = lineType.originalOrderLineNumber()
                val returnCreationDate = salesOrder.returnCreationDate()
                val lineNumber = lineType.lineNumber()
                val ean = lineType.ean()
                val quantity = lineType.quantity()
                val totalPrice = lineType.totalPrice()
                val reasonCode: String = lineType.reasonCode()
                val storeId: String = salesOrder.storeId()

                val productApiResponseAttributes: Attributes = productApiResponseMap.getValue(ean)
                val technicalAttributes = productApiResponseAttributes.technicalAttributes
                val name = productApiResponseAttributes.name
                val primaryImageUrl = productApiResponseAttributes.productMediaObjects
                    .filter { it.description == PRODUCT_MEDIA_OBJECT_DESCRIPTION_PRIMARY_IMAGE }
                    .map { it.contentUrl }
                    .first()
                val order = miraklAPIService.getMiraklOrderDetailsByOrderId(logisticalOrderId, tenant)
                val currencyIsoCode = order.currencyIsoCode.name
                val context = tenantRouteHandler.retrieveContext(
                    tenant,
                    SalesOrderInfo(totalPrice, productApiResponseMap.getValue(ean), storeId)
                )
                var sellerNotificationContent = buildSellerNotificationContent(
                    context,
                    tenant,
                    name,
                    ean,
                    quantity,
                    reasonCode
                )

                val refundCreated = returnLineService.isRefundCreatedInMiraklAndSellerNotified(
                    totalPrice,
                    quantity,
                    logisticalOrderId,
                    originalOrderLineNumber,
                    reasonCode,
                    sellerNotificationContent,
                    currencyIsoCode,
                    tenant
                )

                val nowDateTime = now()
                returnLines.add(
                    returnLineMapper.toEntity(
                        orderId,
                        logisticalOrderId,
                        reasonCode,
                        returnCreationDate,
                        salesOrder.returnCreationDateInMs(),
                        fetchTimeInMs(nowDateTime).toLong(),
                        nowDateTime.toString(),
                        context.status,
                        tenant,
                        ean,
                        lineNumber.toLong(),
                        originalOrderLineNumber,
                        quantity,
                        lineType.unitPrice(),
                        totalPrice,
                        context.route,
                        storeId,
                        lineType.offerId(),
                        context.reasonForIForce,
                        salesOrder.customerId(),
                        technicalAttributes,
                        refundCreated,
                        false,
                        createdBy,
                        name,
                        primaryImageUrl,
                        salesOrder.countryCode(),
                        order.shopId,
                        RETURN_TO_STORE.name,
                        currencyIsoCode,
                        originalOrderId,
                        notes
                    ),
                )
                customMetrics.recordJmsLineResult(if (refundCreated) SUCCESS else FAILURE, tenant)
            }
            postRefundHandler.handle(tenant, returnLines)
        } catch (ex: Exception) {
            logger().error("Exception during refund for order=$orderId msg=${ex.message}", ex)
            customMetrics.recordJmsResult(timer, FAILURE, tenant)
            return
        }
        customMetrics.recordJmsResult(timer, SUCCESS, tenant)
    }

    private fun buildSellerNotificationContent(
        context: TenantRouteContext,
        tenant: String,
        name: String,
        ean: String,
        quantity: Long,
        reasonCode: String
    ): String {
        return if (Tenant.BQUK.name == tenant) {
            sellerContentBuilder.buildSellerNotificationContent(
                context.route, RETURN_TO_STORE.name, name, ean,
                quantity,
                reasonCode,
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                tenant,
                context.reasonForIForce
            )
        } else {
            ""
        }
    }

    private fun extractSoapBodyContent(xmlString: String): String {
        val sReader = StringReader(xmlString)
        val factory = XMLInputFactory.newInstance()
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false)
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false)
        return OMXMLBuilderFactory.createStAXOMBuilder(factory.createXMLStreamReader(sReader)).documentElement.firstElement.firstElement.toString()
    }

    private fun extractSalesOrder(xmlString: String): SalesOrderType {
        var content = extractSoapBodyContent(xmlString)
        val psoDocument: ProcessSalesOrderDocument = ProcessSalesOrderDocument.Factory.parse(content)
        return psoDocument.processSalesOrder.dataArea.salesOrderArray[0]
    }

    companion object : Logging
}
