package com.kingfisher.marketplace.config

import jakarta.servlet.DispatcherType
import org.apache.hc.core5.http.HttpStatus
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import org.springframework.http.MediaType
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.JwtValidators
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter
import org.springframework.security.web.AuthenticationEntryPoint
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.access.AccessDeniedHandler

/**
 * Secures the API with OAuth2 against Microsoft Entra ID.
 *
 * `/v1` remains open for backward compatibility; `/v2` requires a valid Entra ID JWT whose caller is a
 * member of the configured Azure AD group ([ApiSecurityProperties.requiredGroupId]). The incoming token's
 * audience is validated by [AudienceValidator] because Spring does not check it by default.
 */
@Configuration
@EnableWebSecurity
@EnableConfigurationProperties(ApiSecurityProperties::class)
class SecurityConfig(
    private val apiSecurityProperties: ApiSecurityProperties,
    @Value("\${spring.security.oauth2.resourceserver.jwt.issuer-uri}") private val issuerUri: String,
) {

    @Bean
    @Profile("!noAuth")
    fun filterChain(http: HttpSecurity, jwtAuthenticationConverter: JwtAuthenticationConverter): SecurityFilterChain {
        http
            .csrf { it.disable() }
            .authorizeHttpRequests {
                it.dispatcherTypeMatchers(DispatcherType.ERROR, DispatcherType.ASYNC).permitAll()
                it.requestMatchers(
                    "/swagger-ui/**",
                    "/swagger-ui.html",
                    "/v3/api-docs/**",
                    "/v1/**",
                    "/actuator/**",
                    // default exception handlers behaves like POST /error
                    // allow access without token
                    "/error"
                ).permitAll()
                it.requestMatchers("/v2/**").hasRole("app-access")
                it.anyRequest().authenticated()
            }
            .oauth2ResourceServer { resourceServer ->
                resourceServer.jwt { it.jwtAuthenticationConverter(jwtAuthenticationConverter) }
                resourceServer.authenticationEntryPoint(authenticationEntryPoint())
                resourceServer.accessDeniedHandler(accessDeniedHandler())
            }
            .exceptionHandling {
                it.authenticationEntryPoint(authenticationEntryPoint())
                it.accessDeniedHandler(accessDeniedHandler())
            }

        return http.build()
    }

    @Bean
    @Profile("noAuth")
    fun filterChains(http: HttpSecurity): SecurityFilterChain {
        http
            .csrf { it.disable() }
            .authorizeHttpRequests {
                it.anyRequest().permitAll()
            }
        return http.build()
    }

    /**
     * Decodes and validates incoming JWTs against the standard issuer/expiry checks plus the custom
     * audience check.
     */
    @Bean
    @Profile("!noAuth")
    fun jwtDecoder(): JwtDecoder {
        val jwtDecoder = NimbusJwtDecoder.withIssuerLocation(issuerUri).build()
        jwtDecoder.setJwtValidator(
            DelegatingOAuth2TokenValidator(
                JwtValidators.createDefaultWithIssuer(issuerUri),
                AudienceValidator(apiSecurityProperties.audience),
            )
        )
        return jwtDecoder
    }

    @Bean
    fun accessDeniedHandler() = AccessDeniedHandler { _, response, _ ->
        response.status = HttpStatus.SC_FORBIDDEN
        response.contentType = MediaType.APPLICATION_JSON.toString()
        response.writer.write(
            """{"error":"FORBIDDEN","message":"Access denied"}"""
        )
    }

    @Bean
    fun authenticationEntryPoint() = AuthenticationEntryPoint { _, response, _ ->
        response.status = HttpStatus.SC_UNAUTHORIZED
        response.contentType = MediaType.APPLICATION_JSON.toString()
        response.writer.write(
            """{"error":"UNAUTHORIZED","message":"Authentication required"}"""
        )
    }

    @Bean
    fun jwtAuthenticationConverter(): JwtAuthenticationConverter {
        return JwtAuthenticationConverter().apply {
            setJwtGrantedAuthoritiesConverter(
                JwtGrantedAuthoritiesConverter().apply {
                    setAuthorityPrefix("ROLE_")
                    setAuthoritiesClaimName("roles")
                }
            )
        }
    }
}
