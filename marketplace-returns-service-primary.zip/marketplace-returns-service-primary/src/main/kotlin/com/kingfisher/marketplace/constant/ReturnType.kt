package com.kingfisher.marketplace.constant

enum class ReturnType {
    RETURN_TO_STORE,
    DELIVERY_EXPIRED,
    COLLECTION_EXPIRED
}
