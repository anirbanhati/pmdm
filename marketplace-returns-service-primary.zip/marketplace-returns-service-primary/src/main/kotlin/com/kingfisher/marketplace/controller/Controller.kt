package com.kingfisher.marketplace.controller

import ReturnLineResponse
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.DateFormatException
import com.kingfisher.marketplace.jms.ReturnOrderJmsListener
import com.kingfisher.marketplace.model.ConfirmReturnRequest
import com.kingfisher.marketplace.model.ConfirmReturnResponse
import com.kingfisher.marketplace.model.FetchOrdersResponse
import com.kingfisher.marketplace.model.UpdateRouteRequest
import com.kingfisher.marketplace.model.manualUpdate.UpdateReturnLineRequest
import com.kingfisher.marketplace.service.CarrierRebookService
import com.kingfisher.marketplace.service.ManualUpdateLineDetailsService
import com.kingfisher.marketplace.service.ReturnBusinessService
import com.kingfisher.marketplace.service.UpdateRouteBusinessService
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import jakarta.validation.Valid
import jakarta.validation.constraints.Pattern
import jakarta.validation.constraints.Size
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.format.annotation.DateTimeFormat
import org.springframework.format.annotation.DateTimeFormat.ISO.DATE_TIME
import org.springframework.http.HttpStatus.NO_CONTENT
import org.springframework.http.MediaType.APPLICATION_XML_VALUE
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import java.time.LocalDateTime

@RestController
@RequestMapping("/v1", "/v2") // TODO: remove "/v1" after disabling V1
class Controller
@Autowired
constructor(
    private val returnBusinessService: ReturnBusinessService,
    private val jmsListener: ReturnOrderJmsListener,
    private val updateRouteBusinessService: UpdateRouteBusinessService,
    private val manualUpdateLineDetailsService: ManualUpdateLineDetailsService,
    private val carrierRebookService: CarrierRebookService
) : ControllerSwagger {

    @GetMapping("/fetchReturnLines/{tenant}/{storeId}")
    override fun fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
        @PathVariable tenant: Tenant,
        @PathVariable @Size(
            min = 4,
            max = 4,
            message = "The Store Id should be of 4 digits"
        ) @Pattern(regexp = "^[0-9]{4}\$") storeId: String,
        @RequestParam(required = true) @DateTimeFormat(iso = DATE_TIME) dateFrom: LocalDateTime,
        @RequestParam(required = true) @DateTimeFormat(iso = DATE_TIME) dateTo: LocalDateTime,
    ): ReturnLineResponse? {
        if (dateTo.isBefore(dateFrom)) {
            throw DateFormatException(buildString {
                append("DateTo :")
                append(dateTo.toString())
                append(" DateFrom :")
                append(dateFrom.toString())
            })
        }
        return returnBusinessService.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
            tenant.name, storeId, dateFrom, dateTo
        )
    }

    @PutMapping("/updateRoute/{tenant}/{returnOrderNumber}")
    override fun updateRoute(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @Valid @RequestBody updateRouteRequest: UpdateRouteRequest
    ): ResponseEntity<ReturnLineResponse?> {
        return ResponseEntity.ok(
            updateRouteBusinessService.updateRoute(
                returnOrderNumber,
                updateRouteRequest,
                tenant.name
            )
        )
    }

    @PostMapping("/updateLastUpdated/{tenant}/{returnOrderNumber}/{returnLineNumber}/{lastUpdated}")
    override fun updateLastUpdated(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @PathVariable returnLineNumber: Long,
        @PathVariable lastUpdated: LocalDateTime,
    ): ConfirmReturnResponse? =
        this.returnBusinessService.updateLastUpdated(returnOrderNumber, returnLineNumber, lastUpdated)

    @GetMapping("/fetchAllOrders")
    override fun fetchAllOrders(): List<ReturnLine> = returnBusinessService.fetchAllReturnLines()

    @GetMapping("/fetchOrders")
    override fun fetchOrders(
        @RequestParam tenant: Tenant,
        @RequestParam count: Int,
        @RequestParam(required = false)
        nextCursor: String?
    ): ResponseEntity<FetchOrdersResponse> {
        return ResponseEntity.ok(
            returnBusinessService.fetchOrders(tenant, count, nextCursor)
        )
    }

    @PostMapping("/import", consumes = [APPLICATION_XML_VALUE])
    override fun loadReturnOrders(
        @RequestBody returnOrderPSO: String,
    ) {
        jmsListener.processReturnOrder(returnOrderPSO)
    }

    @PutMapping("/confirm/{tenant}/{returnOrderNumber}/{lineNumber}")
    override fun confirmReturn(
        @PathVariable tenant: Tenant,
        @PathVariable returnOrderNumber: Long,
        @PathVariable lineNumber: Long,
        @Valid @RequestBody confirmReturnRequest: ConfirmReturnRequest,
    ): ConfirmReturnResponse? =
        this.returnBusinessService.confirmReturn(returnOrderNumber, lineNumber, confirmReturnRequest)

    @DeleteMapping("/deleteLine/{returnOrderNumber}/{lineNumber}")
    @ApiResponses(ApiResponse(responseCode = "204", description = "Line deleted successfully if present in DB"))
    override fun deleteReturnLine(
        @PathVariable returnOrderNumber: Long,
        @PathVariable lineNumber: Long
    ): ResponseEntity<Unit> {
        this.returnBusinessService.deleteReturnLine(returnOrderNumber, lineNumber)
        return ResponseEntity(NO_CONTENT)
    }

    @DeleteMapping("/deleteOrder/{returnOrderNumber}")
    @ApiResponses(
        ApiResponse(responseCode = "204", description = "All lines related to this return are deleted successfully"),
        ApiResponse(responseCode = "404", description = "No lines found for this return order")
    )
    override fun deleteReturnOrder(
        @PathVariable returnOrderNumber: Long
    ): ResponseEntity<Unit> {
        this.returnBusinessService.deleteAllLineAssociatedWithReturnOrder(returnOrderNumber)
        return ResponseEntity(NO_CONTENT)
    }

    @GetMapping("/fetchAllLineDetails/{returnOrderNumber}")
    override fun fetchAllLineDetailsAssociatedWithReturnOrder(
        @PathVariable returnOrderNumber: Long
    ): ResponseEntity<ReturnLineResponse> {
        return ResponseEntity.ok(
            this.returnBusinessService.fetchAllLineDetailsAssociatedWithReturnOrder(
                returnOrderNumber
            )
        )
    }

    @PutMapping("/update")
    override fun updateLine(
        @RequestBody updateReturnLineRequest: UpdateReturnLineRequest
    ): ResponseEntity<ReturnLineResponse> {
        return ResponseEntity.ok(this.manualUpdateLineDetailsService.updateLineDetails(updateReturnLineRequest))
    }

    @PostMapping("/rebookCarrier/CAPL/{returnOrderNumber}")
    fun reBookCarrier(
        @PathVariable returnOrderNumber: Long
    ): ResponseEntity<Unit> {
        carrierRebookService.rebookCarrier(returnOrderNumber)
        return ResponseEntity.ok().build()
    }
}
