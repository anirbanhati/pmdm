package com.kingfisher.marketplace.exception

class IllegalUpdateException(val exceptionCause: String, val rejectedValue: String) : Exception()
