package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.constant.Constant.Companion.REASON_FOR_IFORCE
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status.AWAITING_LABEL_PRINTING
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_AUTO
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_ADDED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_TOTAL
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import com.kingfisher.marketplace.service.IForceRouteValidator
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class BQRouteProvider @Autowired constructor(
    private val iForceRouteValidator: IForceRouteValidator,
    private val customMetrics: CustomMetrics
) : TenantRouteProvider {

    override fun provide(orderInfo: SalesOrderInfo): TenantRouteContext {
        val reasonMap =
            iForceRouteValidator.validate(orderInfo.totalPrice, orderInfo.productAttributes, orderInfo.storeId)
        return if (reasonMap.isNotEmpty()) {
            customMetrics.incrementCounter(RETURN_ROUTE_I_FORCE_AUTO)
            TenantRouteContext(
                IFORCE.value,
                AWAITING_LABEL_PRINTING.name,
                reasonMap.getValue(REASON_FOR_IFORCE)
            )
        } else {
            customMetrics.incrementCounter(RETURN_ROUTE_TBC_TOTAL)
            customMetrics.incrementCounter(RETURN_ROUTE_TBC_CURRENT_ADDED)
            TenantRouteContext(
                TBC.value,
                AWAITING_STORE_CONFIRMATION.name,
            )
        }
    }
}
