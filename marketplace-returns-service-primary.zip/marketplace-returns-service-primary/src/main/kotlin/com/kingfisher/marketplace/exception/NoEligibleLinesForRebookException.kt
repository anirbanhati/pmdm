package com.kingfisher.marketplace.exception

class NoEligibleLinesForRebookException(returnOrderNumber: Long) :
    RuntimeException("No failed carrier bookings found to rebook for returnOrderNumber=$returnOrderNumber")
