package com.kingfisher.marketplace

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.ConfigurationPropertiesScan
import org.springframework.boot.runApplication

@SpringBootApplication(scanBasePackages = ["com.kingfisher.marketplace"])
@ConfigurationPropertiesScan
class MarketplaceReturnsServiceApplication

fun main(vararg args: String) {
    runApplication<MarketplaceReturnsServiceApplication>(*args)
}
