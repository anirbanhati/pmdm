package com.kingfisher.marketplace.validator

import com.kingfisher.marketplace.constant.Constant.Companion.CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED
import com.kingfisher.marketplace.constant.ROUTE.DPD
import com.kingfisher.marketplace.model.ConfirmReturnRequestData
import com.kingfisher.marketplace.model.UpdateReturnRequestLine
import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext

class ParcelTrackingInfoListValidator : ConstraintValidator<ValidParcelTrackingInfoList, Any> {
    override fun isValid(value: Any?, context: ConstraintValidatorContext?): Boolean {
        return value?.let {
            var result = false
            if (it is UpdateReturnRequestLine) {
                result = if (it.route == DPD.value) it.parcelTrackingInfo.isNotEmpty() else true
            } else if (it is ConfirmReturnRequestData) {
                result =
                    if (it.type == CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED) {
                        it.attributes.parcelTrackingInfo.isNotEmpty()
                    } else {
                        true
                    }
            }
            return result
        } ?: false
    }
}
