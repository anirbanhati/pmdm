package com.kingfisher.marketplace.entity

import com.kingfisher.marketplace.model.ParcelTrackingInfo
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey
import java.math.BigDecimal
import java.math.BigInteger.ZERO

@DynamoDbBean
data class ReturnLine(
    @set:DynamoDbPartitionKey
    @set:DynamoDbAttribute("return_order_number")
    var returnOrderNumber: Long = 0,
    @set:DynamoDbSortKey
    @set:DynamoDbAttribute("line_number")
    var lineNumber: Long = 0,
    @set:DynamoDbAttribute("original_line_number")
    var originalOrderLineNumber: Long = 0,
    @set:DynamoDbAttribute("tenant")
    var tenant: String = "",
    @set:DynamoDbAttribute("route")
    var route: String = "",
    @set:DynamoDbAttribute("line_status")
    var status: String = "",
    @set:DynamoDbAttribute("ean")
    var ean: String = "",
    @set:DynamoDbAttribute("quantity")
    var quantity: Long = 0,
    @set:DynamoDbAttribute("unit_price")
    var unitPrice: BigDecimal = BigDecimal(ZERO),
    @set:DynamoDbAttribute("returned_date")
    var returnDate: String = "",
    @set:DynamoDbSecondarySortKey(indexNames = ["store_id_returned_date_in_ms_index"])
    @set:DynamoDbAttribute("returned_date_in_ms")
    var returnDateInMilliSecond: Long = 0,
    @set:DynamoDbAttribute("last_updated")
    var lastUpdated: String = "",
    @set:DynamoDbAttribute("last_updated_in_ms")
    var lastUpdatedInMilliSecond: Long = 0,
    @set:DynamoDbAttribute("is_refund_created")
    var refundCreated: Boolean = false,
    @set:DynamoDbAttribute("is_cancellation_created")
    var cancellationCreated: Boolean = false,
    @set:DynamoDbAttribute("total_price")
    var totalPrice: BigDecimal = BigDecimal(ZERO),
    @set:DynamoDbSecondaryPartitionKey(indexNames = ["store_id_returned_date_in_ms_index"])
    @set:DynamoDbAttribute("store_id")
    var storeId: String = "",
    @set:DynamoDbAttribute("created_by")
    var createdBy: String = "",
    @set:DynamoDbAttribute("actioned_by")
    var actionedBy: String = "",
    @set:DynamoDbAttribute("return_reason_code")
    var returnReasonCode: String = "",
    @set:DynamoDbAttribute("reason_for_iforce")
    var reasonForIForce: String = "",
    @set:DynamoDbAttribute("store_address")
    var storeAddress: String = "",
    @set:DynamoDbAttribute("offer_id")
    var offerId: String = "",
    @set:DynamoDbAttribute("shop_id")
    var shopId: String = "",
    @set:DynamoDbAttribute("logistical_order_id")
    var logisticalOrderId: String = "",
    @set:DynamoDbAttribute("recipient_address")
    var recipientAddress: String = "",
    @set:DynamoDbAttribute("customer_id")
    var customerId: String = "",
    @set:DynamoDbAttribute("label_printing_requested_by")
    var labelPrintingRequestedBy: String = "",
    @set:DynamoDbAttribute("technical_attributes")
    var technicalAttributes: TechnicalAttributes = TechnicalAttributes(emptyList(), emptyList()),
    @set:DynamoDbAttribute("country_code")
    var countryCode: String = "",
    @set:DynamoDbAttribute("consignment_code")
    var consignmentCode: String = "",
    @set:DynamoDbAttribute("parcel_tracking_Info")
    var parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList(),
    @set:DynamoDbAttribute("product_name")
    var productName: String = "",
    @set:DynamoDbAttribute("primary_image_url")
    var primaryImageUrl: String = "",
    @set:DynamoDbAttribute("collection_date")
    var collectionDate: String = "",
    @set: DynamoDbAttribute("is_updated_manually")
    var isUpdatedManually: Boolean = false,
    @set:DynamoDbAttribute("return_type")
    var returnType: String = "",
    @set:DynamoDbAttribute("currency_iso_code")
    var currencyIsoCode: String = "",
    @set:DynamoDbAttribute("original_order_id")
    var originalOrderId: String = "",
    @set:DynamoDbAttribute("notes")
    var notes: String? = null
)
