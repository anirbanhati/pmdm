package com.kingfisher.marketplace.model

class ConfirmReturnResponseData(
    val type: String = "returnLines",
    var attributes: ConfirmReturnResponseAttributes = ConfirmReturnResponseAttributes(),
)
