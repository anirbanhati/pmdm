package com.kingfisher.marketplace.metrics

object MetricsTags {
    const val DYNAMO_OPERATION = "operation"
    const val RESULT = "result"
    const val TENANT = "tenant"
    const val SUCCESS = "success"
    const val FAILURE = "failure"
}
