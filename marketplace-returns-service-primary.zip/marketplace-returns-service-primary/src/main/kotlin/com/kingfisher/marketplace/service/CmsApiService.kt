package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.cms.CmsApiConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.NOT_APPLICABLE
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.helper.LineDimensionExtractor
import com.kingfisher.marketplace.model.cms.request.CmsApiRequest
import com.kingfisher.marketplace.model.cms.request.OrderLine
import com.kingfisher.marketplace.model.cms.request.Recipient
import com.kingfisher.marketplace.model.cms.response.CmsApiResponse
import com.kingfisher.marketplace.service.ReturnBusinessService.Companion.logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.stereotype.Service
import org.springframework.web.client.RestTemplate

@Service
class CmsApiService
@Autowired
constructor(
    @param:Qualifier("cmsRestTemplate") private var restTemplate: RestTemplate,
    private var miraklAPIService: MiraklAPIService,
    private var sellerService: SellerApiService,
    private var cmsApiConfigProperties: CmsApiConfigProperties,
    private var lineDimensionExtractor: LineDimensionExtractor
) {
    fun bookCarrier(
        returnLines: List<ReturnLine>,
        tenant: String,
    ): CmsApiResponse {
        val cmsApiRequest = buildCmsApiRequestBody(returnLines, tenant)
        logger().info("CMS API request body : {}", cmsApiRequest)
        // Headers (Authorization, Content-Type, Accept) are set by CmsApiAuthorizationInterceptor
        val entity = HttpEntity(cmsApiRequest, HttpHeaders())
        try {
            return restTemplate.postForEntity(
                cmsApiConfigProperties.cmsApiUrl,
                entity,
                CmsApiResponse::class.java,
                // current workaround for mocking until we get proper URL
                returnLines.first().returnOrderNumber
            ).body!!
        } catch (ex: Exception) {
            logger().error("Failed to book carrier via CMS API for return order ${returnLines[0].returnOrderNumber} : ${ex.message}")
            throw CmsApiException(ex.message!!)
        }
    }

    private fun buildCmsApiRequestBody(
        returnLines: List<ReturnLine>,
        tenant: String
    ): CmsApiRequest {
        val returnLine = returnLines.first()
        val shopId = resolveShopId(returnLine, tenant)
        return CmsApiRequest(
            sapOrderID = returnLine.returnOrderNumber.toString(),
            atgOrderID = returnLine.returnOrderNumber.toString(),
            deliveryGroupCode = returnLine.lineNumber.toString(),
            warehouseID = returnLine.storeId,
            bookingType = cmsApiConfigProperties.bookingType,
            clientSapOrderID = returnLine.originalOrderId,
            clientDeliveryGroupCode = cmsApiConfigProperties.clientDeliveryGroupCode,
            recipient = buildRecipient(shopId, tenant),
            deliveryTypeID = cmsApiConfigProperties.deliveryTypeId,
            orderLines = buildOrderLines(returnLines),
            comment = cmsApiConfigProperties.comment,
            orderCreatedBy = returnLine.createdBy,
            orderCreatedChannel = cmsApiConfigProperties.storeCode,
            extraNotes = listOfNotNull(returnLine.notes)
        )
    }

    private fun resolveShopId(returnLine: ReturnLine, tenant: String): String =
        if (returnLine.shopId.isBlank() || returnLine.shopId == NOT_APPLICABLE) {
            miraklAPIService.getMiraklOrderDetailsByOrderId(returnLine.logisticalOrderId, tenant).shopId
        } else {
            returnLine.shopId
        }

    private fun buildOrderLines(returnLines: List<ReturnLine>): ArrayList<OrderLine> =
        ArrayList(
            returnLines.map { line ->
                val dimensions = lineDimensionExtractor.extract(
                    line.technicalAttributes,
                    line.returnOrderNumber,
                    line.lineNumber
                )
                OrderLine(
                    lineNumber = line.lineNumber,
                    productCode = line.ean,
                    quantity = line.quantity,
                    height = dimensions.height,
                    length = dimensions.length,
                    width = dimensions.width,
                    weight = dimensions.weight,
                    name = line.productName
                )
            }
        )

    fun buildRecipient(shopId: String, tenant: String): Recipient {
        val sellerAddress = sellerService.fetchSeller(shopId, tenant)
        logger().info("Seller API response json for $tenant seller: $sellerAddress")

        val contactInformation = sellerAddress.body!!.data.attributes.contactInformation
        val inStoreReturnDetails = sellerAddress.body!!.data.attributes.inStoreReturnDetails

        return Recipient(
            mobilePhone = inStoreReturnDetails.mobileNumber,
            mobilePhonePrefix = inStoreReturnDetails.mobileNumberPrefix,
            contactPhone = contactInformation.phone,
            contactPhonePrefix = inStoreReturnDetails.country?.let { resolvePhonePrefix(it) },
            name = sellerAddress.body!!.data.attributes.sellerName,
            countryCode = inStoreReturnDetails.country,
            street = inStoreReturnDetails.street,
            houseNumber = inStoreReturnDetails.houseNumber,
            flatNumber = inStoreReturnDetails.flatNumber,
            city = inStoreReturnDetails.city,
            postCode = inStoreReturnDetails.zipCode,
            email = contactInformation.email
        )
    }

    private fun resolvePhonePrefix(countryCode: String): String? =
        when (countryCode.uppercase()) {
            "PL" -> "+48"
            "GB" -> "+44"
            "FR" -> "+33"
            "DE" -> "+49"
            else -> {
                logger().warn("No phone prefix mapping for countryCode=$countryCode")
                null
            }
        }
}
