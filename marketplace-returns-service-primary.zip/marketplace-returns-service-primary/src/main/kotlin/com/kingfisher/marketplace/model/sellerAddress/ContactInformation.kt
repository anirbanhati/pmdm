package com.kingfisher.marketplace.model.sellerAddress

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
data class ContactInformation(
    var street1: String? = null,
    var city: String? = null,
    var state: String? = null,
    var country: String? = null,
    var postCode: String? = null,
    var webSite: String? = null,
    var email: String? = null,
    var phone: String? = null,
)
