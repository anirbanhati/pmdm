package com.kingfisher.marketplace.service

import ReturnLineResponse
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Status.CANCELLED
import com.kingfisher.marketplace.constant.Status.LABEL_PRINTING_REQUESTED
import com.kingfisher.marketplace.exception.IllegalUpdateException
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_DPD_CONFIRMED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_DPD
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CANCELLED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_REMOVED
import com.kingfisher.marketplace.model.manualUpdate.UpdateReturnLineRequest
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import com.kingfisher.marketplace.utils.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDateTime.now

@Service
class ManualUpdateLineDetailsService @Autowired constructor(
    private val returnLineRepository: ReturnLineRepository,
    private val apiModelTransformer: ApiModelTransfomer,
    private val configProperties: ConfigProperties,
    private val customMetrics: CustomMetrics
) {
    fun updateLineDetails(updateReturnLineRequest: UpdateReturnLineRequest): ReturnLineResponse {
        val targetReturnOrder = updateReturnLineRequest.returnOrderNumber
        val targetLineNumber = updateReturnLineRequest.lineNumber
        when (val returnLine = returnLineRepository.fetchReturnItem(targetReturnOrder, targetLineNumber)) {
            null -> throw OrderNotFoundException("$targetReturnOrder-$targetLineNumber")
            else -> {
                val targetRoute = updateReturnLineRequest.route
                val targetStatus = updateReturnLineRequest.status

                if (ROUTE.fromValue(returnLine.route) != TBC) {
                    throw IllegalUpdateException(
                        "Not possible to update order $targetReturnOrder line $targetLineNumber as route is already ${returnLine.route}",
                        targetRoute.value
                    )
                } else if (Status.valueOf(returnLine.status) == CANCELLED) {
                    throw IllegalUpdateException(
                        "Not possible to update order $targetReturnOrder line $targetLineNumber as status is already ${returnLine.status}",
                        targetStatus.name
                    )
                } else {
                    if (configProperties.allowedRouteToStatusForUpdate.contains(targetRoute.value)) {
                        val availableValueToUpdate = configProperties.allowedRouteToStatusForUpdate[targetRoute.value]!!
                        if (availableValueToUpdate.indexOf(returnLine.status) < availableValueToUpdate.indexOf(
                                targetStatus.name
                            )
                        ) {
                            returnLine.route = targetRoute.value
                            returnLine.status = targetStatus.name
                        } else {
                            throw IllegalUpdateException(
                                "Not possible to update order $targetReturnOrder line $targetLineNumber as ${targetStatus.name} is not a valid status with route ${targetRoute.value}",
                                targetStatus.name
                            )
                        }
                    } else {
                        throw IllegalUpdateException(
                            "Not possible to update order $targetReturnOrder line $targetLineNumber as ${targetRoute.value} is not available to be updated",
                            targetRoute.value
                        )
                    }
                }

                val updateTime = now()
                returnLine.lastUpdated = updateTime.toString()
                returnLine.lastUpdatedInMilliSecond = DateTimeUtils.fetchTimeInMs(updateTime).toLong()
                returnLine.isUpdatedManually = true
                returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)
                if (targetRoute != TBC) {
                    customMetrics.incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
                    customMetrics.incrementCounter(RETURN_ROUTE_DPD)
                }
                when (targetStatus.name) {
                    LABEL_PRINTING_REQUESTED.name -> customMetrics.incrementCounter(RETURN_DPD_CONFIRMED)
                    CANCELLED.name -> customMetrics.incrementCounter(RETURN_ROUTE_TBC_CANCELLED)
                }
                return apiModelTransformer.transformToReturnLineResponse(listOf(returnLine))
            }
        }
    }
}
