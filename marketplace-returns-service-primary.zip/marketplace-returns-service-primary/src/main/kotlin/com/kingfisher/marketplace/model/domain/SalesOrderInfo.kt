package com.kingfisher.marketplace.model.domain

import com.kingfisher.marketplace.model.product.Attributes
import java.math.BigDecimal

data class SalesOrderInfo(
    val totalPrice: BigDecimal,
    val productAttributes: Attributes,
    val storeId: String
)
