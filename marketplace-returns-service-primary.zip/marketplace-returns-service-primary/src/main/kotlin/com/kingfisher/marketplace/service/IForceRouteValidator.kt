package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.PRODUCT_AMOUNT_THREASHOLD_FOR_COLLECTION_NOT_REACHED
import com.kingfisher.marketplace.constant.Constant.Companion.REASON_FOR_IFORCE
import com.kingfisher.marketplace.model.product.Attributes
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.math.BigDecimal

@Service
class
IForceRouteValidator
@Autowired
constructor(
    private val configProperties: ConfigProperties,
) {
    fun validate(
        totalPrice: BigDecimal,
        productAttributes: Attributes,
        storeId: String
    ): Map<String, String> {
        var result = mutableMapOf<String, String>()
        if (this.configProperties.defaultToIForceStoreIds.keys.contains(storeId)) {
            result[REASON_FOR_IFORCE] = this.configProperties.defaultToIForceStoreIds.getValue(storeId)
        } else {
            if (totalPrice < BigDecimal(this.configProperties.leastAmountForCollection)) {
                result[REASON_FOR_IFORCE] = PRODUCT_AMOUNT_THREASHOLD_FOR_COLLECTION_NOT_REACHED
                return result
            } else {
                return determineTechnicalReasonForIForce(productAttributes)
            }
        }
        return result
    }

    private fun determineTechnicalReasonForIForce(
        productAttributes: Attributes,
    ): Map<String, String> {
        var result = mutableMapOf<String, String>()
        productAttributes.technicalAttributes.technical.forEach { technicalAttribute ->
            configProperties.maxTechAttributeValueForCollection[technicalAttribute.groupName]?.get(
                technicalAttribute.uom
            )
                ?.let { it ->
                    if (technicalAttribute.value.toDouble() > it) {
                        result[REASON_FOR_IFORCE] = technicalAttribute.groupName
                        return result
                    }
                }

            if (configProperties.techAttributesForIForce[technicalAttribute.groupName] == technicalAttribute.value) {
                result[REASON_FOR_IFORCE] = technicalAttribute.groupName
                return result
            }
        }
        return result
    }
}
