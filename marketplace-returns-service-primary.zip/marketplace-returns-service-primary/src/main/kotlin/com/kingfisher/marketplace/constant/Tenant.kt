package com.kingfisher.marketplace.constant

enum class Tenant {
    BQUK,
    CAPL,
    CAFR,
}
