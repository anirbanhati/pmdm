package com.kingfisher.marketplace.model

import jakarta.validation.Valid

data class ConfirmReturnRequest(
    @field:Valid val data: ConfirmReturnRequestData,
)
