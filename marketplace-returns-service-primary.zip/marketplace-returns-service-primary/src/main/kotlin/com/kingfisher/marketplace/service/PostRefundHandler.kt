package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.utils.Logging
import org.springframework.stereotype.Service

/**
 * Handles all post-refund actions after return lines have been processed:
 *  1. Persists the return lines to the repository.
 *  2. Invokes tenant-specific actions (e.g. CMS carrier booking for CAPL).
 */
@Service
class PostRefundHandler(
    private val returnLineRepository: ReturnLineRepository,
    private val cmsApiService: CmsApiService
) {

    fun handle(tenant: String, returnLines: List<ReturnLine>) {
        if (returnLines.isEmpty()) return

        if (Tenant.CAPL.name == tenant) {
            returnLines
                .groupBy { it.logisticalOrderId }
                .forEach { (logisticalOrderId, linesForSeller) ->
                    val success = callBookCarrier(logisticalOrderId, linesForSeller, tenant)
                    linesForSeller.forEach {
                        it.status = if (success) Status.CARRIER_BOOKED.name else Status.CARRIER_BOOKING_FAILED.name
                    }
                }
        }
        returnLineRepository.save(returnLines)
    }

    private fun callBookCarrier(logisticalOrderId: String, linesForSeller: List<ReturnLine>, tenant: String): Boolean {
        return try {
            val response = cmsApiService.bookCarrier(linesForSeller, tenant)
            if (response.success) {
                logger().info("CMS API carrier successfully booked for logisticalOrderId=$logisticalOrderId")
                true
            } else {
                logCarrierBookingFailed(logisticalOrderId, response.errorMessage)
                false
            }
        } catch (ex: CmsApiException) {
            logCarrierBookingFailed(logisticalOrderId, ex.message!!)
            false
        }
    }

    private fun logCarrierBookingFailed(logisticalOrderId: String, message: String?) {
        logger().error("CMS API carrier booking failed for logisticalOrderId=$logisticalOrderId, msg=$message")
    }

    companion object : Logging
}
