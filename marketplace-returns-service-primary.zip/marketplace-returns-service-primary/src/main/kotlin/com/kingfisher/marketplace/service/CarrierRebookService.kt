package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.exception.NoEligibleLinesForRebookException
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.utils.Logging
import org.springframework.stereotype.Service

@Service
class CarrierRebookService(
    private val returnLineRepository: ReturnLineRepository,
    private val cmsApiService: CmsApiService
) {
    companion object : Logging

    fun rebookCarrier(returnOrderNumber: Long) {
        logger().info("Going to rebook carrier for returnOrderNumber=$returnOrderNumber")

        val failedLines = returnLineRepository.fetchItemsByHashKey(returnOrderNumber)
            .filter { it.status == Status.CARRIER_BOOKING_FAILED.name }
            .ifEmpty { throw NoEligibleLinesForRebookException(returnOrderNumber) }

        val errors = mutableListOf<CmsApiException>()

        failedLines.groupBy { it.logisticalOrderId }
            .forEach { (logisticalOrderId, linesForSeller) ->
                try {
                    val response = cmsApiService.bookCarrier(linesForSeller, Tenant.CAPL.name)
                    if (response.success) {
                        linesForSeller.forEach { it.status = Status.CARRIER_BOOKED.name }
                    } else {
                        linesForSeller.forEach { it.status = Status.CARRIER_BOOKING_FAILED.name }
                        errors.add(0, CmsApiException(response.errorMessage))
                    }
                } catch (ex: CmsApiException) {
                    logger().error("Failed to rebook carrier for logisticalOrderId=$logisticalOrderId", ex)
                    linesForSeller.forEach { it.status = Status.CARRIER_BOOKING_FAILED.name }
                    errors.add(ex)
                }
            }
        returnLineRepository.save(failedLines)
        logger().info("Carrier rebooking completed for returnOrderNumber=$returnOrderNumber, tenant=${Tenant.CAPL.name}")
        errors.firstOrNull()?.let { throw it }
    }
}
