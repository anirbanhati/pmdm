package com.kingfisher.marketplace.model.carrierBooking

data class CarrierBookingLineItem(
    var productCode: String,
    var lineNumber: String,
    var quantity: Int,
)
