package com.kingfisher.marketplace.config.mq

import com.ibm.mq.jakarta.jms.MQXAConnectionFactory
import com.ibm.msg.client.jakarta.wmq.WMQConstants.USERID
import com.ibm.msg.client.jakarta.wmq.WMQConstants.USER_AUTHENTICATION_MQCSP
import com.ibm.msg.client.jakarta.wmq.WMQConstants.WMQ_CLIENT_RECONNECT
import com.ibm.msg.client.jakarta.wmq.WMQConstants.WMQ_CM_CLIENT
import com.ibm.msg.client.jakarta.wmq.WMQConstants.WMQ_CONNECTION_MODE
import jakarta.jms.ConnectionFactory
import jakarta.jms.JMSException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import org.springframework.jms.annotation.EnableJms
import org.springframework.jms.core.JmsTemplate

@Configuration
@EnableJms
@Profile("!local")
class MQConnectionFactory
@Autowired
constructor(private val mqConfigProperties: MQConfigProperties) {
    @Bean
    @Throws(JMSException::class)
    fun buildJmsTemplate(): JmsTemplate? {
        val jmsTemplate = JmsTemplate()
        jmsTemplate.connectionFactory = createConnectionFactory()
        return jmsTemplate
    }

    @Bean
    @Throws(JMSException::class)
    fun createConnectionFactory(): ConnectionFactory? {
        val factory = MQXAConnectionFactory()
        factory.queueManager = mqConfigProperties.queueManager
        factory.hostName = mqConfigProperties.host
        factory.port = mqConfigProperties.port.toInt()
        factory.channel = mqConfigProperties.channel
        factory.setStringProperty(USERID, mqConfigProperties.user)
        factory.setBooleanProperty(USER_AUTHENTICATION_MQCSP, false)
        factory.setIntProperty(WMQ_CONNECTION_MODE, WMQ_CM_CLIENT)
        factory.clientReconnectOptions = WMQ_CLIENT_RECONNECT
        return factory
    }
}
