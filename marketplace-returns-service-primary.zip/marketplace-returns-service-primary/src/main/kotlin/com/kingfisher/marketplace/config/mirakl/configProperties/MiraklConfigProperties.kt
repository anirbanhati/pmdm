package com.kingfisher.marketplace.config.mirakl.configProperties

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.mirakl")
data class MiraklConfigProperties(
    var tenants: Map<String, MiraklTenantProperties> = emptyMap(),
    var authUrl: String,
)

data class MiraklTenantProperties(
    var url: String,
    var clientId: String,
    var clientSecret: String,
)
