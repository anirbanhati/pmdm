package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.productApi.configProperties.ProductApiConfigProperties
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.model.product.ProductAPIResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.web.client.RestTemplate

@Service
class
ProductApiQueryService
@Autowired
constructor(
    private val productApiConfigProperties: ProductApiConfigProperties,
    private var restTemplate: RestTemplate,
) {
    private fun queryProduct(
        ean: String,
        tenant: String,
    ): ResponseEntity<ProductAPIResponse> {
        return restTemplate.getForEntity(
            productApiConfigProperties.productApiUrl,
            ProductAPIResponse::class.java,
            tenant,
            ean,
        )
    }

    fun fetchProduct(
        eans: String,
        tenant: String,
    ): Map<String, Attributes> {
        val response = queryProduct(eans, tenant)
        val responseMap = mutableMapOf<String, Attributes>()
        for (responseData in response.body?.data!!) {
            responseMap[responseData.attributes.ean] = responseData.attributes
        }
        return responseMap
    }
}
