package com.kingfisher.marketplace.mapper

import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import org.springframework.stereotype.Service
import java.math.BigDecimal

@Service
class ReturnLineMapper {

    fun toEntity(
        returnOrderId: Long,
        logisticalOrderId: String,
        reasonCode: String,
        returnCreationDate: String,
        returnCreationDateInMs: Long,
        lastUpdatedInMilliSecond: Long,
        lastUpdated: String,
        status: String,
        tenant: String,
        ean: String,
        lineNumber: Long,
        originalOrderLineNumber: Long,
        quantity: Long,
        unitPrice: BigDecimal,
        totalPrice: BigDecimal,
        route: String,
        storeID: String,
        offerId: String,
        reasonForIForce: String,
        customerId: String,
        technicalAttributes: TechnicalAttributes,
        refundCreated: Boolean,
        cancellationCreated: Boolean,
        createdBy: String,
        name: String,
        primaryImageUrl: String,
        countryCode: String,
        shopId: String,
        returnType: String,
        currencyIsoCode: String,
        originalOrderId: String,
        notes: String?
    ): ReturnLine {
        return ReturnLine(
            returnOrderNumber = returnOrderId,
            lineNumber = lineNumber,
            originalOrderLineNumber = originalOrderLineNumber,
            tenant = tenant,
            route = route,
            status = status,
            ean = ean,
            quantity = quantity,
            unitPrice = unitPrice,
            returnDate = returnCreationDate,
            returnDateInMilliSecond = returnCreationDateInMs,
            refundCreated = refundCreated,
            cancellationCreated = cancellationCreated,
            lastUpdatedInMilliSecond = lastUpdatedInMilliSecond,
            lastUpdated = lastUpdated,
            totalPrice = totalPrice,
            storeId = storeID,
            createdBy = createdBy,
            actionedBy = "NA",
            returnReasonCode = reasonCode,
            reasonForIForce = reasonForIForce,
            storeAddress = "NA",
            offerId = offerId,
            shopId = shopId,
            logisticalOrderId = logisticalOrderId,
            recipientAddress = "NA",
            customerId = customerId,
            technicalAttributes = technicalAttributes,
            productName = name,
            primaryImageUrl = primaryImageUrl,
            countryCode = countryCode,
            returnType = returnType,
            currencyIsoCode = currencyIsoCode,
            originalOrderId = originalOrderId,
            notes = notes
        )
    }
}
