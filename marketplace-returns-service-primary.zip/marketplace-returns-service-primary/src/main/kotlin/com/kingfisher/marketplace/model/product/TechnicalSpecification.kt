package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class TechnicalSpecification(
    @JsonProperty("name") val name: String,
    @JsonProperty("value") val value: String,
)
