package com.kingfisher.marketplace.model.manualUpdate

import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.Status
import jakarta.validation.constraints.Positive

data class UpdateReturnLineRequest(
    @field:Positive(message = "Return order number must be positive")
    val returnOrderNumber: Long,
    @field:Positive(message = "Line number must be positive")
    val lineNumber: Long,
    val status: Status,
    val route: ROUTE
)
