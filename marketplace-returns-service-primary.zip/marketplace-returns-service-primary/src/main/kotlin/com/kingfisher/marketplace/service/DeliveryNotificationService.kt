package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.metrics.CAPL_ORDER_CARRIER_BOOKED
import com.kingfisher.marketplace.metrics.CAPL_ORDER_LINE_CARRIER_BOOKED
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.model.ParcelTrackingInfo
import com.kingfisher.marketplace.model.kafka.DeliveryNotification
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.utils.Logging
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Profile
import org.springframework.stereotype.Service

internal const val NOT_AVAILABLE = "N/A"

@Profile("local")
@Service
class DeliveryNotificationService @Autowired constructor(
    private val returnLineRepository: ReturnLineRepository,
    private val miraklAPIService: MiraklAPIService,
    private val sellerContentBuilder: SellerContentBuilder,
    private val customMetrics: CustomMetrics
) {

    fun processDeliveryNotification(notification: DeliveryNotification) {
        val lineNumbers = notification.items.associateBy { it.lineRef.toLong() }
        returnLineRepository.fetchItemsByHashKey(notification.orderNumber.toLong())
            .also { logIfEmpty(it, notification.orderNumber) }
            .filter { lineNumbers.keys.contains(it.lineNumber) }
            .forEach { line ->
                val item = lineNumbers[line.lineNumber]!!
                line.parcelTrackingInfo += ParcelTrackingInfo(
                    item.quantity,
                    NOT_AVAILABLE,
                    notification.trackingNumber
                )
                line.route = ROUTE.fromValue(notification.carrier)!!.name
                val success = notifySeller(line, item.quantity, notification.trackingUrl)
                line.status = if (success) Status.BOOKING_CONFIRMED.name else Status.BOOKING_NOTIFICATION_FAILED.name
                returnLineRepository.saveOrUpdateReturnLineDetails(line)
                customMetrics.incrementCounter(CAPL_ORDER_LINE_CARRIER_BOOKED)
            }
        customMetrics.incrementCounter(CAPL_ORDER_CARRIER_BOOKED)
        logger().info("Delivery Notification successfully handled for orderId=${notification.orderNumber}")
    }

    private fun notifySeller(line: ReturnLine, quantity: Long, trackingLink: String): Boolean {
        val message = sellerContentBuilder.buildSellerNotificationContent(
            line.route,
            line.returnType,
            line.productName,
            line.ean,
            quantity,
            line.returnReasonCode,
            MIRAKL_REFUND_REASON_CODE_PREFIX,
            line.tenant,
            trackingLink = trackingLink,
            orderNumber = line.originalOrderId
        )
        try {
            logger().info("Going to notify seller - orderNumber=${line.returnOrderNumber}, line=${line.lineNumber}, route=${line.route}")
            miraklAPIService.notifySeller(line.logisticalOrderId, message, line.tenant)
            return true
        } catch (e: Exception) {
            logger().error(
                "Error while notifying seller for orderId=${line.logisticalOrderId}, line=${line.lineNumber}",
                e
            )
            return false
        }
    }

    private fun logIfEmpty(items: List<ReturnLine>, orderId: String) {
        if (items.isEmpty()) {
            logger().warn("No items found for order $orderId")
        }
    }

    companion object : Logging
}
