package com.kingfisher.marketplace.config

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service")
data class ConfigProperties(
    var leastAmountForCollection: String,
    var maxTechAttributeValueForCollection: Map<String, Map<String, Double>>,
    var techAttributesForIForce: Map<String, String>,
    var brandTenantMap: Map<String, String>,
    var routeToSellerNotificationTemplate: Map<String, Map<String, String>>,
    var parcelTrackingUrlPattern: Map<String, String>,
    var reasonCodeMap: Map<String, Map<String, String>>,
    var iForceReasonMessageBasedOnReasonForIForce: Map<String, String>,
    var retentionPeriodInDaysForNonConfirmedLines: Long,
    var retentionPeriodInDaysForConfirmedLines: Long,
    var fetchReturnLinesQuery: String,
    var allowedRouteToStatusForUpdate: Map<String, List<String>>,
    var eventTypeToRouteMapping: Map<String, String>,
    var eventTypeToStatusMapping: Map<String, String>,
    var eventTypeToReasonCodeMapping: Map<String, String>,
    var pickExpiryEventTypesToProcess: List<String>,
    var eventTypesEligibleForImmediateRefund: List<String>,
    var pickEventShippingMethodTypesToProcess: List<String>,
    var tenantToCountryCodeMap: Map<String, String>,
    var eventTypesEligibleForRouteDetermination: List<String>,
    var iForceReturnTypesForRefundUponConfirmation: List<String>,
    var eventTypeToReturnTypeMapping: Map<String, String>,
    var defaultToIForceStoreIds: Map<String, String>,
    var eventTypesToUpdateStatusOfExistingRecords: List<String>,
    var eligibleCategoryCodes: List<String>,
    var fetchOrdersMaxCount: Int
)
