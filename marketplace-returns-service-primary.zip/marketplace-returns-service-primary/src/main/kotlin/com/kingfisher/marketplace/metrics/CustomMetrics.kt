package com.kingfisher.marketplace.metrics

import com.kingfisher.marketplace.metrics.MetricsTags.RESULT
import com.kingfisher.marketplace.metrics.MetricsTags.TENANT
import io.micrometer.core.instrument.MeterRegistry
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import org.springframework.util.StopWatch
import java.util.concurrent.TimeUnit

internal const val RETURN_ROUTE_I_FORCE_AUTO = "return.route.iForce.AUTO"
internal const val RETURN_ROUTE_I_FORCE_MANUAL = "return.route.iForce.manual"
internal const val RETURN_ROUTE_I_FORCE_DAMAGED = "return.route.iForce.damaged"
internal const val RETURN_ROUTE_TBC_TOTAL = "return.route.TBC.total"
internal const val RETURN_ROUTE_TBC_CURRENT_ADDED = "return.route.TBC.current.added"
internal const val RETURN_ROUTE_TBC_CURRENT_REMOVED = "return.route.TBC.current.removed"
internal const val RETURN_ROUTE_DPD = "return.route.DPD"
internal const val RETURN_I_FORCE_CONFIRMED = "return.iForce.confirmed"
internal const val RETURN_DPD_CONFIRMED = "return.DPD.confirmed"
internal const val REFUND_FAILED_FOR_I_FORCE = "return.refund.failed.iForce"
internal const val REFUND_FAILED_FOR_DPD = "return.refund.failed.DPD"
internal const val RETURN_ROUTE_TBC_CANCELLED = "return.route.TBC.cancelled"
internal const val CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED = "return.cancel.failed.shipmentNotInitiated"
internal const val PROCESS_JMS_ORDER = "return.jms.process.order"
internal const val PROCESS_JMS_ORDER_LINE = "return.jms.process.order.line"
internal const val PROCESS_KAFKA_PICK_EVENT = "return.kafka.process.pick.event"
internal const val PROCESS_KAFKA_PICK_EVENT_COLLECTED = "return.kafka.process.pick.collected"
internal const val CAPL_ORDER_CARRIER_BOOKED = "return.capl.carrier.booked"
internal const val CAPL_ORDER_LINE_CARRIER_BOOKED = "return.capl.carrier.booked.line"

@Component
class CustomMetrics @Autowired constructor(
    private val meterRegistry: MeterRegistry
) {
    fun incrementCounter(metricName: String) {
        meterRegistry.counter(metricName).increment()
    }

    fun recordJmsResult(stopwatch: StopWatch, result: String, tenant: String) {
        reportTimer(PROCESS_JMS_ORDER, stopwatch, RESULT, result, TENANT, tenant)
    }

    fun recordJmsLineResult(result: String, tenant: String) {
        meterRegistry.counter(PROCESS_JMS_ORDER_LINE, RESULT, result, TENANT, tenant).increment()
    }

    fun startTimer(): StopWatch {
        val stopWatch = StopWatch()
        stopWatch.start()
        return stopWatch
    }

    fun reportTimer(metricName: String, stopwatch: StopWatch, vararg tags: String) {
        stopwatch.stop()
        meterRegistry.timer(metricName, *tags).record(stopwatch.totalTimeMillis, TimeUnit.MILLISECONDS)
    }
}
