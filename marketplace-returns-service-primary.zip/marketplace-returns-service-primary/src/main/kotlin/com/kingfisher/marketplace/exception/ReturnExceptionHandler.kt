package com.kingfisher.marketplace.exception

import com.kingfisher.marketplace.constant.ErrorConstant.Companion.DATE_TO_IS_BEFORE_DATE_FROM
import com.kingfisher.marketplace.constant.ErrorConstant.Companion.RETURN_ORDER_NOT_FOUND
import com.kingfisher.marketplace.model.errors.Error
import com.kingfisher.marketplace.model.errors.ErrorResponseWrapper
import java.net.ConnectException
import java.net.SocketTimeoutException
import org.springframework.http.HttpStatus.BAD_REQUEST
import org.springframework.http.HttpStatus.FAILED_DEPENDENCY
import org.springframework.http.HttpStatus.GATEWAY_TIMEOUT
import org.springframework.http.HttpStatus.NOT_FOUND
import org.springframework.http.ResponseEntity
import org.springframework.validation.FieldError
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.RestControllerAdvice

@RestControllerAdvice
class ReturnExceptionHandler {

    @ExceptionHandler(OrderNotFoundException::class)
    fun handleOrderNotFoundException(ex: OrderNotFoundException): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(NOT_FOUND).body(
            ErrorResponseWrapper(
                NOT_FOUND.value(),
                listOf(Error(QUERY_PARAMETER_RETURN_ORDER_ID, ex.rejectedValue, RETURN_ORDER_NOT_FOUND))
            )
        )
    }

    @ExceptionHandler(MethodArgumentNotValidException::class)
    @ResponseBody
    fun handleValidationExceptions(ex: MethodArgumentNotValidException): ResponseEntity<ErrorResponseWrapper> {
        val errors = mutableListOf<Error>()
        ex.bindingResult.allErrors.forEach {
            errors.add(
                Error(
                    (it as FieldError).field,
                    it.rejectedValue,
                    it.defaultMessage
                )
            )
        }

        return ResponseEntity.status(BAD_REQUEST).body(ErrorResponseWrapper(BAD_REQUEST.value(), errors))
    }

    @ExceptionHandler(CarrierBookingException::class)
    fun handleCarrierBookingException(ex: CarrierBookingException): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(FAILED_DEPENDENCY).body(
            ErrorResponseWrapper(
                ex.statusCode.value(),
                listOf(Error(CARRIER_BOOKING_EXCEPTION, null, ex.errorMessage))
            )
        )
    }

    @ExceptionHandler(DateFormatException::class)
    fun handleDateFormatException(ex: DateFormatException): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(BAD_REQUEST).body(
            ErrorResponseWrapper(
                BAD_REQUEST.value(),
                listOf(Error(field = QUERY_PARAMETER_DATE_TO_AND_DATE_FROM, ex.rejectedValue, DATE_TO_IS_BEFORE_DATE_FROM))
            )
        )
    }

    @ExceptionHandler(IllegalUpdateException::class)
    fun handleIllegalUpdateException(ex: IllegalUpdateException): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(BAD_REQUEST).body(
            ErrorResponseWrapper(
                BAD_REQUEST.value(),
                listOf(Error(field = ILLEGAL_UPDATE_EXCEPTION, errorMessage = ex.exceptionCause, rejectedValue = ex.rejectedValue))
            )
        )
    }

    @ExceptionHandler(OrderNotFoundInMiraklException::class)
    fun handleOrderNotFoundInMiraklException(ex: OrderNotFoundInMiraklException): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(NOT_FOUND).body(
            ErrorResponseWrapper(
                NOT_FOUND.value(),
                listOf(Error(ORDER_NOT_FOUND_IN_MIRAKL_EXCEPTION, null, ex.message))
            )
        )
    }

    @ExceptionHandler(value = [SocketTimeoutException::class, ConnectException::class])
    fun handleConnectionTimeoutException(ex: Exception): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(GATEWAY_TIMEOUT).body(
            ErrorResponseWrapper(
                GATEWAY_TIMEOUT.value(),
                listOf(Error(CONNECTION_TIMEOUT_EXCEPTION, null, ex.message))
            )
        )
    }

    @ExceptionHandler(InvalidNextCursorException::class)
    fun handleInvalidNextCursorException(): ResponseEntity<ErrorResponseWrapper> {
        return ResponseEntity.status(BAD_REQUEST).body(
            ErrorResponseWrapper(
                BAD_REQUEST.value(),
                listOf(
                    Error(
                        field = NEXT_CURSOR,
                        rejectedValue = null,
                        errorMessage = "Invalid nextCursor"
                    )
                )
            )
        )
    }

    companion object {
        const val QUERY_PARAMETER_RETURN_ORDER_ID = "RETURN_ORDER_ID"
        const val CARRIER_BOOKING_EXCEPTION = "CARRIER_BOOKING_EXCEPTION"
        const val QUERY_PARAMETER_DATE_TO_AND_DATE_FROM = "QUERY_PARAMETER_DATE_TO_AND_DATE_FROM"
        const val ILLEGAL_UPDATE_EXCEPTION = "ILLEGAL_UPDATE_EXCEPTION"
        const val ORDER_NOT_FOUND_IN_MIRAKL_EXCEPTION = "ORDER_NOT_FOUND_IN_MIRAKL_EXCEPTION"
        const val CONNECTION_TIMEOUT_EXCEPTION = "CONNECTION_TIMEOUT_EXCEPTION"
        const val NEXT_CURSOR = "NEXT_CURSOR"
    }
}
