package com.kingfisher.marketplace.model

import com.kingfisher.marketplace.validator.ValidParcelTrackingInfoList
import com.kingfisher.marketplace.validator.ValidReasonForIForce
import jakarta.validation.Valid
import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.Positive
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean

@DynamoDbBean
@ValidParcelTrackingInfoList(message = "parcel tracking info must be provided")
@ValidReasonForIForce(message = "reason for iForce must be provided")
data class UpdateReturnRequestLine(
    @field:Positive(message = "line number must be greater than or equal to 1")
    val lineNumber: Long?,
    @field:NotBlank
    val ean: String = "",
    @field:NotBlank(message = "route must not be empty")
    val route: String = "",
    @field:Positive(message = "quantity must be greater than or equal to 1")
    val quantity: Long?,
    val reason: String? = "",
    @field:Valid val parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList(),
)
