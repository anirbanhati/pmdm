package com.kingfisher.marketplace.model

import jakarta.validation.Valid
import jakarta.validation.constraints.NotBlank

data class UpdateRequestData(
    @field:NotBlank(message = "type can not be blank") val type: String,
    @field:Valid val attributes: UpdateRequestAttributes,
)
