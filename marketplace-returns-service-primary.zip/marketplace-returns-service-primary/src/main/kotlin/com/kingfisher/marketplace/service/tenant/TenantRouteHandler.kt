package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.stereotype.Service

@Service
class TenantRouteHandler(
    @param:Qualifier("tenantToProviderMap") private val providers: Map<String, TenantRouteProvider>
) {
    fun retrieveContext(tenant: String, info: SalesOrderInfo): TenantRouteContext {
        return providers[tenant]
            ?.provide(info)
            ?: throw IllegalArgumentException("No TenantContextProvider found for tenant: $tenant")
    }
}
