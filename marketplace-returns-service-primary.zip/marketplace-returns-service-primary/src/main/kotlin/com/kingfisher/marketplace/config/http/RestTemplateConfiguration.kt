package com.kingfisher.marketplace.config.http

import com.kingfisher.marketplace.model.cms.response.CmsApiResponse
import org.springframework.boot.web.client.RestTemplateBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.context.annotation.Profile
import org.springframework.http.ResponseEntity
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager
import org.springframework.web.client.RestTemplate

@Configuration
class RestTemplateConfiguration {

    @Bean
    @Primary
    fun restTemplate(builder: RestTemplateBuilder): RestTemplate {
        return builder.build()
    }

    @Bean(name = ["cmsRestTemplate"])
    @Profile("local")
    fun cmsRestTemplate(
        builder: RestTemplateBuilder,
        authorizedClientManager: OAuth2AuthorizedClientManager
    ): RestTemplate {
        return builder
            .additionalInterceptors(CmsApiAuthorizationInterceptor(authorizedClientManager))
            .build()
    }

    @Bean(name = ["cmsRestTemplate"])
    @Profile("!local")
    fun mockRestTemplate(
        builder: RestTemplateBuilder,
    ): RestTemplate {
        return object : RestTemplate(builder.buildRequestFactory()) {
            override fun <T> postForEntity(
                url: String,
                request: Any?,
                responseType: Class<T>,
                vararg uriVariables: Any
            ): ResponseEntity<T> {
                @Suppress("UNCHECKED_CAST")
                return ResponseEntity.ok(CmsApiResponse(true, "", "") as T)
            }
        }
    }
}
