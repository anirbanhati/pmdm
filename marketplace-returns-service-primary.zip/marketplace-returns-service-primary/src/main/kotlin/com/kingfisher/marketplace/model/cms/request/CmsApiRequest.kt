package com.kingfisher.marketplace.model.cms.request

data class CmsApiRequest(
    var sapOrderID: String? = null,
    var atgOrderID: String? = null,
    var deliveryGroupCode: String? = null,
    var warehouseID: String? = null,
    var bookingType: Int? = 0,
    var clientSapOrderID: String? = null,
    var clientDeliveryGroupCode: String? = null,
    var recipient: Recipient = Recipient(),
    var deliveryTypeID: Int? = 0,
    var orderLines: ArrayList<OrderLine> = arrayListOf(),
    var comment: String? = null,
    var orderCreatedBy: String? = null,
    var orderCreatedChannel: Int? = 0,
    var extraNotes: List<String> = arrayListOf(),
)
