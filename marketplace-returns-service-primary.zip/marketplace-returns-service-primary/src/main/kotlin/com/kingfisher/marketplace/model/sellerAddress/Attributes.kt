package com.kingfisher.marketplace.model.sellerAddress

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
data class Attributes(
    var sellerName: String? = null,
    var contactInformation: ContactInformation = ContactInformation(),
    var inStoreReturnDetails: InStoreReturnDetails = InStoreReturnDetails(),
    var shippingCountry: String? = null,
)
