package com.kingfisher.marketplace.config.kafka

import com.kingfisher.marketplace.model.kafka.DeliveryNotification
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.common.serialization.StringDeserializer
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory
import org.springframework.kafka.core.ConsumerFactory
import org.springframework.kafka.core.DefaultKafkaConsumerFactory
import org.springframework.kafka.listener.ContainerProperties
import org.springframework.kafka.support.serializer.JsonDeserializer

@Profile("local")
@Configuration
class DeliveryNotificationConsumerConfiguration {

    @Bean
    fun deliveryNotificationConsumerFactory(
        @Value("\${spring.kafka.consumer.group-id}") groupId: String,
        @Value("\${spring.kafka.bootstrap-servers}") bootsrapServers: String,
    ): DefaultKafkaConsumerFactory<String, DeliveryNotification> {
        val config = mutableMapOf<String, Any>(
            ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG to bootsrapServers,
            ConsumerConfig.GROUP_ID_CONFIG to groupId,
            ConsumerConfig.AUTO_OFFSET_RESET_CONFIG to "latest",
            ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG to false,
            ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG to StringDeserializer::class.java,
            ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG to JsonDeserializer::class.java,
            JsonDeserializer.VALUE_DEFAULT_TYPE to DeliveryNotification::class.java
        )
        return DefaultKafkaConsumerFactory<String, DeliveryNotification>(config)
    }

    @Bean
    fun deliveryNotificationContainerFactory(
        deliveryNotificationConsumerFactory: ConsumerFactory<String, DeliveryNotification>
    ): ConcurrentKafkaListenerContainerFactory<String, DeliveryNotification> {
        val factory = ConcurrentKafkaListenerContainerFactory<String, DeliveryNotification>()
        factory.consumerFactory = deliveryNotificationConsumerFactory
        factory.isBatchListener = true
        factory.containerProperties.ackMode = ContainerProperties.AckMode.MANUAL_IMMEDIATE
        return factory
    }
}
