package com.kingfisher.marketplace.model

import com.kingfisher.marketplace.entity.ReturnLine

data class FetchOrdersResponse(
    val orders: List<ReturnLine>,
    val nextCursor: String?
)
