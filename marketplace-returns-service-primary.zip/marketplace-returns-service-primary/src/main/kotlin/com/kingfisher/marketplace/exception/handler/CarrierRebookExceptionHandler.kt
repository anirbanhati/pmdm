package com.kingfisher.marketplace.exception.handler

import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.exception.NoEligibleLinesForRebookException
import com.kingfisher.marketplace.model.errors.ErrorResponse
import com.kingfisher.marketplace.utils.Logging
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestControllerAdvice

@RestControllerAdvice
class CarrierRebookExceptionHandler {

    companion object : Logging

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(NoEligibleLinesForRebookException::class)
    fun handleNoEligibleLines(ex: NoEligibleLinesForRebookException): ErrorResponse {
        logger().warn(ex.message)
        return ErrorResponse(message = ex.message!!)
    }

    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    @ExceptionHandler(CmsApiException::class)
    fun handleCmsApiException(ex: CmsApiException): ErrorResponse {
        logger().error("Carrier re-booking failed", ex)
        return ErrorResponse(message = ex.message ?: "Carrier re-booking failed")
    }
}
