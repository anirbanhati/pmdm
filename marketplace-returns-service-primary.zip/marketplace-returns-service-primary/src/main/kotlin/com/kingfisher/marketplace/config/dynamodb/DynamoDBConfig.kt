package com.kingfisher.marketplace.config.dynamodb

import com.kingfisher.marketplace.config.dynamodb.configProperties.DynamoDBConfigProperties
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider
import software.amazon.awssdk.core.interceptor.ExecutionInterceptor
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient
import software.amazon.awssdk.regions.Region.of
import software.amazon.awssdk.services.dynamodb.DynamoDbClient
import java.net.URI.create

@Configuration
@Profile("!local")
class DynamoDBConfig
@Autowired
constructor(private val dynamoDBConfigProperties: DynamoDBConfigProperties) {
    @Bean
    @Profile("!test")
    fun dynamoDbClient(dynamoMetricsInterceptor: ExecutionInterceptor): DynamoDbClient =
        DynamoDbClient.builder()
            .region(of(dynamoDBConfigProperties.region))
            .credentialsProvider(DefaultCredentialsProvider.builder().build())
            .endpointOverride(dynamoDBConfigProperties.url?.let { create(it) })
            .overrideConfiguration { client -> client.addExecutionInterceptor(dynamoMetricsInterceptor) }
            .build()

    @Bean
    fun dynamoDbEnhancedClient(dynamoDbClient: DynamoDbClient): DynamoDbEnhancedClient =
        DynamoDbEnhancedClient.builder()
            .dynamoDbClient(dynamoDbClient)
            .build()
}
