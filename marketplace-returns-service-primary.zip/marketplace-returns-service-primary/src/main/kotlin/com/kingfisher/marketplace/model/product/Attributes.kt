package com.kingfisher.marketplace.model.product

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Attributes(
    @JsonProperty("ean") val ean: String,
    @JsonProperty("technicalAttributes") val technicalAttributes: TechnicalAttributes,
    @JsonProperty("name") val name: String,
    @JsonProperty("productMediaObjects") var productMediaObjects: List<ProductMediaObject> = emptyList(),
)
