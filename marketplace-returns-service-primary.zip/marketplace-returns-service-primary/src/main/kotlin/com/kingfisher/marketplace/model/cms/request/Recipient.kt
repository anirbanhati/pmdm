package com.kingfisher.marketplace.model.cms.request

data class Recipient(
    var mobilePhone: String? = null,
    var mobilePhonePrefix: String? = null,
    var contactPhone: String? = null,
    var contactPhonePrefix: String? = null,
    var name: String? = null,
    var countryCode: String? = null,
    var street: String? = null,
    var houseNumber: String? = null,
    var flatNumber: String? = null,
    var city: String? = null,
    var postCode: String? = null,
    var email: String? = null,
)
