package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.model.sellerAddress.SellerAddressResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.web.client.RestTemplate

@Service
class SellerApiService @Autowired constructor(
    private val restTemplate: RestTemplate,
    @param:Value("\${mktp-returns-service.seller-api.sellerAPIUrl}")
    private val sellerApiUrl: String,
) {

    fun fetchSeller(shopId: String, tenant: String): ResponseEntity<SellerAddressResponse> {
        return restTemplate.getForEntity(
            sellerApiUrl,
            SellerAddressResponse::class.java,
            tenant, shopId
            )
    }
}
