package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import org.springframework.stereotype.Service

@Service
class CAPLRouteProvider : TenantRouteProvider {

    override fun provide(orderInfo: SalesOrderInfo): TenantRouteContext {
        return TenantRouteContext(
            TBC.value,
            AWAITING_STORE_CONFIRMATION.name,
        )
    }
}
