package com.kingfisher.marketplace.config.cms

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.cms-api")
data class CmsApiConfigProperties(
    var bookingType: Int,
    var clientDeliveryGroupCode: String,
    var cmsApiUrl: String,
    var comment: String,
    var deliveryTypeId: Int,
    var height: Int,
    var length: Int,
    var storeCode: Int,
    var weight: Double,
    var width: Int
)
