package com.kingfisher.marketplace.config.carreirBookingAPI

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "mktp-returns-service.carrier-booking-api")
data class CarrierBookingAPIConfigProperties(
    var carrierBookingURL: String,
    var carrierBookingAPIKey: String,
    var sumConsignmentWeight: Double,
    var sumConsignmentVolume: Double,
    var maxConsignmentLength: Double,
    var maxConsignmentWidth: Double,
    var maxConsignmentWeight: Double,
    var maxConsignmentHeight: Int,
    var deliveryType: String,
    var deliveryGroupID: String,
    var deliveryPriority: String,
    var bookingType: String,
    var fulfilmentType: String,
    var defaultCountryCodeForRecipient: String,
)
