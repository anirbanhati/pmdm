package com.kingfisher.marketplace.model.kafka

import com.fasterxml.jackson.annotation.JsonProperty

data class DeliveryNotification(
    val carrier: String,
    @param:JsonProperty("order_number")
    val orderNumber: String,
    @param:JsonProperty("tracking_number")
    val trackingNumber: String,
    @param:JsonProperty("tracking_url")
    val trackingUrl: String,
    val items: List<Item> = listOf()
)

data class Item(
    @param:JsonProperty("line_ref")
    val lineRef: String,
    @param:JsonProperty("part_number")
    val partNumber: String,
    val quantity: Long,
)
