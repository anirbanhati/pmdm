@file:Suppress("TooManyFunctions")

package com.kingfisher.marketplace.jms

import com.kingfisher.marketplace.constant.Constant.Companion.SCHEME_NAME_SAP
import com.kingfisher.www.oagis._9.SalesOrderLineType
import com.kingfisher.www.oagis._9.SalesOrderType
import java.math.BigDecimal
import java.time.LocalDateTime
import java.time.ZoneId.systemDefault
import java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME

fun SalesOrderType.orderId(): Long = salesOrderHeader.documentID.id.stringValue.toLong()

fun SalesOrderType.tenant(): String = salesOrderHeader.brandChannel.brand.code.stringValue

fun SalesOrderType.eligibleOrderLines(categoryCodes: List<String>): List<SalesOrderLineType> =
    salesOrderLineArray.filter {
        categoryCodes.contains(it.categoryCodes.codeArray[0].stringValue)
    }.toList()

fun SalesOrderType.createdBy(): String = salesOrderHeader.userAccountArray[0].accountID.stringValue

fun SalesOrderType.storeId(): String = salesOrderHeader.sourceID.stringValue

fun SalesOrderType.countryCode(): String = salesOrderHeader.shipToParty.contact.location.addressArray[0].countryCode.stringValue

fun SalesOrderType.returnCreationDate(): String =
    LocalDateTime.ofInstant(salesOrderHeader.documentDateTime.toInstant(), systemDefault())
        .format(ISO_LOCAL_DATE_TIME)

fun SalesOrderType.returnCreationDateInMs(): Long = salesOrderHeader.documentDateTime.timeInMillis

fun SalesOrderType.customerId(): String = salesOrderHeader.customerParty.idArray.find {
    it.schemeName.equals(SCHEME_NAME_SAP)
}!!.stringValue

fun SalesOrderLineType.ean(): String = productItem.upcidArray[0].stringValue

fun SalesOrderLineType.logisticalOrderId(): String = salesOrderReferenceArray[0].documentReferenceArray[0].id.stringValue

fun SalesOrderLineType.originalOrderLineNumber(): Long = salesOrderReferenceArray[0].lineNumber.stringValue.toLong()

fun SalesOrderLineType.lineNumber(): String = lineNumber.stringValue

fun SalesOrderLineType.quantity(): Long = quantityArray[0].bigDecimalValue.toLong()

fun SalesOrderLineType.unitPrice(): BigDecimal = quantityArray[0].bigDecimalValue

fun SalesOrderLineType.totalPrice(): BigDecimal = totalAmount.bigDecimalValue

fun SalesOrderLineType.reasonCode(): String = reason.stringValue

fun SalesOrderLineType.offerId(): String = productItem.type?.listID.toString()

fun SalesOrderType.originalOrderId(): String = salesOrderHeader.salesOrderReferenceArray.get(0).documentID.id.stringValue

fun SalesOrderType.notes(): String? = salesOrderHeader?.noteArray?.mapNotNull { it?.stringValue?.trim() }?.filter { it.isNotBlank() }?.distinct()?.joinToString(separator = ", ")?.takeIf { it.isNotBlank() }
