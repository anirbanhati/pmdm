package com.kingfisher.marketplace.metrics.aspect

import com.kingfisher.marketplace.config.mirakl.CustomMiraklClient
import com.mirakl.client.core.error.MiraklErrorResponseBean
import com.mirakl.client.core.exception.MiraklApiException
import com.mirakl.client.core.exception.MiraklException
import io.micrometer.core.instrument.MeterRegistry
import io.micrometer.core.instrument.Tag
import io.micrometer.core.instrument.Tags
import org.apache.http.client.HttpResponseException
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.client.observation.ClientHttpObservationDocumentation.LowCardinalityKeyNames.*
import org.springframework.stereotype.Service
import org.springframework.util.StopWatch
import java.util.concurrent.TimeUnit

private const val CLIENT_REQUESTS = "http.client.requests"

@Service
@Aspect
class MiraklRequestAspect
@Autowired constructor(private val meterRegistry: MeterRegistry) {

    @Around("target(com.kingfisher.marketplace.config.mirakl.CustomMiraklClient)")
    @Throws(Throwable::class)
    fun interceptMiraklCall(pjp: ProceedingJoinPoint): Any? {
        val stopWatch = StopWatch()
        stopWatch.start()
        var status = 200

        try {
            val response = pjp.proceed()
            return response
        } catch (ex: Throwable) {
            status = extractStatus(ex)
            throw ex
        } finally {
            reportMetrics(extractName(pjp), status, stopWatch)
        }
    }

    private fun extractStatus(ex: Throwable?): Int {
        return if (ex is MiraklApiException && ex.error is MiraklErrorResponseBean) {
            ex.error.status
        } else if (ex is MiraklException && ex.cause is HttpResponseException) {
            (ex.cause as HttpResponseException).statusCode
        } else {
            500
        }
    }

    private fun extractName(pjp: ProceedingJoinPoint): String {
        val client = pjp.target as CustomMiraklClient
        return "Mirakl${client.tenant}"
    }

    private fun reportMetrics(methodName: String, status: Int, stopWatch: StopWatch) {
        stopWatch.stop()
        meterRegistry.timer(CLIENT_REQUESTS, Tags.of(
                Tag.of(CLIENT_NAME.asString(), "Mirakl"),
                Tag.of(URI.asString(), methodName),
                Tag.of(OUTCOME.asString(), extractStatusCode(status))
            )
        ).record(stopWatch.totalTimeMillis, TimeUnit.MILLISECONDS)
    }

    private fun extractStatusCode(statusCode: Int): String {
        return try {
            HttpStatus.valueOf(statusCode).series().name
        } catch (_: IllegalArgumentException) {
            "UNKNOWN"
        }
    }
}
