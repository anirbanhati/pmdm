package com.kingfisher.marketplace.constant

class FeatureFlagsConstant {
    companion object {
        const val STORE_INCLUSION_FEATURE_ENABLED = "store_inclusion_feature_enabled"
    }
}
