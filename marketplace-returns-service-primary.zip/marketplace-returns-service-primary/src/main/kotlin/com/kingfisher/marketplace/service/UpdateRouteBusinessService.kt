package com.kingfisher.marketplace.service

import ReturnLineResponse
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.IForceReason.DAMAGED
import com.kingfisher.marketplace.constant.IForceReason.TOO_LARGE
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.ROUTE.DPD
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.Status.AWAITING_LABEL_PRINTING
import com.kingfisher.marketplace.constant.Status.COLLECTION_BOOKED
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_DPD
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_DAMAGED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_MANUAL
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_REMOVED
import com.kingfisher.marketplace.model.ParcelTrackingInfo
import com.kingfisher.marketplace.model.UpdateRouteRequest
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingLineItem
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import com.kingfisher.marketplace.utils.DateTimeUtils
import com.kingfisher.marketplace.utils.Logging
import org.apache.commons.lang3.StringUtils.EMPTY
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.math.BigDecimal.valueOf
import java.time.LocalDateTime

@Service
class UpdateRouteBusinessService @Autowired constructor(
    private val returnLineRepository: ReturnLineRepository,
    private val dataTransformer: ApiModelTransfomer,
    private val configProperties: ConfigProperties,
    private val customMetrics: CustomMetrics,
    private val carrierBookingAPIService: CarrierBookingAPIService,
    private val sellerContentBuilder: SellerContentBuilder,
    private val miraklAPIService: MiraklAPIService
) {
    fun updateRoute(
        returnOrderNumber: Long,
        updateRouteRequest: UpdateRouteRequest,
        tenant: String
    ): ReturnLineResponse? {
        val returnLines = returnLineRepository.fetchItemsByHashKey(returnOrderNumber)
        if (returnLines.isEmpty()) {
            throw OrderNotFoundException(returnOrderNumber.toString())
        }
        var maxLineNumberStored = returnLines.stream().mapToLong(ReturnLine::lineNumber).max().asLong
        val carrierBookingLineItems = mutableListOf<CarrierBookingLineItem>()
        val returnLinesToStore = mutableListOf<ReturnLine>()
        val eligibleReturnLines = returnLines.filter { returnLine ->
            returnLine.route.equals(ROUTE.TBC.value, true)
        }
        logger().info("Going to update TBC line items $eligibleReturnLines for $returnOrderNumber")
        for (returnLine in eligibleReturnLines) {
            val updateLines = updateRouteRequest.data.attributes.lines
            for (line in updateLines) {
                val updateRequestLineNumber = line.lineNumber
                val updateRequestLineQuantity = line.quantity
                val updateRequestLineRoute = line.route
                if (updateRequestLineNumber == returnLine.lineNumber) {
                    logger().info("Going to update route as $updateRequestLineRoute for line number $updateRequestLineNumber")
                    val updatedLineNumber = if (updateLines.stream()
                            .filter { lineToUpdate -> lineToUpdate.lineNumber == updateRequestLineNumber }.findFirst()
                            .get() != line
                    ) {
                        ++maxLineNumberStored
                    } else {
                        null
                    }
                    processUpdateRoute(
                        returnLine,
                        updateRequestLineQuantity!!,
                        line.reason,
                        updatedLineNumber,
                        updateRequestLineRoute,
                        updateRouteRequest.data.attributes.userId,
                        line.parcelTrackingInfo,
                        carrierBookingLineItems,
                        returnLinesToStore,
                    )
                }
            }
        }
        logger().info("Number of dpdReturnLines to be processed: " + carrierBookingLineItems.size)
        updateConsignmentCodeForDPDItems(carrierBookingLineItems, returnLinesToStore, tenant)
        returnLinesToStore.forEach { returnLine ->
            if (returnLine.route == DPD.value) {
                customMetrics.incrementCounter(RETURN_ROUTE_DPD)
            } else if (returnLine.route == IFORCE.value) {
                val sellerNotificationContent = sellerContentBuilder.buildSellerNotificationContent(
                    returnLine.route, returnLine.returnType, returnLine.productName, returnLine.ean,
                    returnLine.quantity,
                    returnLine.returnReasonCode,
                    MIRAKL_REFUND_REASON_CODE_PREFIX,
                    tenant,
                    returnLine.reasonForIForce

                )
                miraklAPIService.notifySeller(
                    returnLine.logisticalOrderId,
                    sellerNotificationContent,
                    tenant
                )
                if (configProperties.iForceReturnTypesForRefundUponConfirmation.contains(returnLine.returnType)) {
                    miraklAPIService.createRefund(
                        returnLine.totalPrice,
                        returnLine.quantity,
                        returnLine.logisticalOrderId,
                        returnLine.originalOrderLineNumber,
                        returnLine.returnReasonCode,
                        returnLine.currencyIsoCode,
                        returnLine.tenant
                    )
                    returnLine.refundCreated = true
                }
                when (returnLine.reasonForIForce) {
                    DAMAGED.value -> customMetrics.incrementCounter(RETURN_ROUTE_I_FORCE_DAMAGED)
                    TOO_LARGE.value -> customMetrics.incrementCounter(RETURN_ROUTE_I_FORCE_MANUAL)
                }
            }
            returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)
        }
        return this.returnLineRepository.fetchItemsByHashKey(returnOrderNumber).let {
            this.dataTransformer.transformToReturnLineResponse(
                it,
            )
        }
    }

    private fun processUpdateRoute(
        returnLine: ReturnLine,
        updateRequestLineQuantity: Long,
        reason: String?,
        lineNumber: Long?,
        route: String,
        userId: String,
        updateRequestLineParcelTrackingInfo: List<ParcelTrackingInfo>,
        carrierBookingLineItems: MutableList<CarrierBookingLineItem>,
        returnLinesToStore: MutableList<ReturnLine>,
    ) {
        val returnLineToStore = returnLine.copy()
        if (lineNumber == null) {
            customMetrics.incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
        } else {
            returnLineToStore.lineNumber = lineNumber
        }
        updateReturnLineAttributes(
            returnLineToStore,
            route,
            updateRequestLineQuantity,
            if (route == IFORCE.value) AWAITING_LABEL_PRINTING.name else COLLECTION_BOOKED.name,
        )
        returnLineToStore.actionedBy = userId
        returnLineToStore.reasonForIForce = reason ?: EMPTY
        returnLineToStore.parcelTrackingInfo = updateRequestLineParcelTrackingInfo
        if (route == DPD.value) {
            logger().info(
                "Will call carrier booking API for ${returnLineToStore.returnOrderNumber} " + "with $updateRequestLineQuantity quantity for line ${returnLineToStore.lineNumber}",
            )
            val carrierBookingLineItem =
                CarrierBookingLineItem(
                    returnLineToStore.ean,
                    returnLineToStore.lineNumber.toString(),
                    returnLineToStore.quantity.toInt()
                )
            carrierBookingLineItems.add(carrierBookingLineItem)
        }
        returnLinesToStore.add(returnLineToStore)
    }

    private fun updateReturnLineAttributes(
        returnLine: ReturnLine,
        route: String,
        quantity: Long,
        status: String,
    ) {
        returnLine.quantity = quantity
        returnLine.route = route
        returnLine.status = status
        returnLine.lastUpdatedInMilliSecond = DateTimeUtils.fetchTimeInMs(LocalDateTime.now()).toLong()
        returnLine.lastUpdated = LocalDateTime.now().toString()
        returnLine.totalPrice = returnLine.unitPrice.multiply(valueOf(quantity))
    }

    private fun updateConsignmentCodeForDPDItems(
        carrierBookingLineItems: MutableList<CarrierBookingLineItem>,
        returnLines: MutableList<ReturnLine>,
        tenant: String,
    ) {
        val returnDPDLines = returnLines.filter { e -> e.route.equals(DPD.value) }.toMutableList()
        if (carrierBookingLineItems.isNotEmpty()) {
            val carrierBookingResponse = carrierBookingAPIService.invokeCarrierBookingAPI(
                returnDPDLines,
                carrierBookingLineItems,
                tenant
            )
            logger().info("carrierBookingResponse for ${returnLines[0].returnOrderNumber}:$carrierBookingResponse")
            val consignmentCode = carrierBookingResponse.body!!.orderMasters[0].consignmentCode
            val deliveryDate = carrierBookingResponse.body!!.orderMasters[0].deliveryDate
            logger().info("consignmentCode retrieved from carrierBookingResponse: $consignmentCode")
            updateDPDReturnLine(carrierBookingLineItems, returnDPDLines, consignmentCode, deliveryDate)
        }
    }

    private fun updateDPDReturnLine(
        carrierBookingLineItems: MutableList<CarrierBookingLineItem>,
        returnLines: MutableList<ReturnLine>,
        consignmentCode: String,
        deliveryDate: String
    ) {
        for (returnLine in returnLines) {
            for (dpdLine in carrierBookingLineItems) {
                if (dpdLine.lineNumber.toLong() == returnLine.lineNumber) {
                    returnLine.consignmentCode = consignmentCode
                    returnLine.collectionDate = deliveryDate
                    returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)
                }
            }
        }
    }

    companion object : Logging
}
