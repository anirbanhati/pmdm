package com.kingfisher.marketplace.model.cms.response

import com.fasterxml.jackson.annotation.JsonProperty

data class CmsApiResponse(
    @param:JsonProperty("Success")
    val success: Boolean,
    @param:JsonProperty("ErrorMessage")
    val errorMessage: String? = "",
    @param:JsonProperty("OrderDate")
    val orderDate: String = ""
)
