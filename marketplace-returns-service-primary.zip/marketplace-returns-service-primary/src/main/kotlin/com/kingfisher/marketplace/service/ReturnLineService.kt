package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_CANCEL_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.PRODUCT_MEDIA_OBJECT_DESCRIPTION_PRIMARY_IMAGE
import com.kingfisher.marketplace.constant.Constant.Companion.REASON_FOR_IFORCE
import com.kingfisher.marketplace.constant.Constant.Companion.RETURN_CREATED_BY_SYSTEM
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status.AWAITING_LABEL_PRINTING
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.mapper.ReturnLineMapper
import com.kingfisher.marketplace.metrics.CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.REFUND_FAILED_FOR_I_FORCE
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.utils.DateTimeUtils.Companion.fetchTimeInMs
import com.kingfisher.marketplace.utils.Logging
import com.kingfisher.orderManagement.avro.Payload
import com.kingfisher.orderManagement.avro.PickLine
import com.mirakl.client.core.exception.MiraklException
import com.mirakl.client.mmp.domain.order.MiraklOrder
import org.apache.commons.lang3.StringUtils.EMPTY
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDateTime.now
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Service
class ReturnLineService
@Autowired constructor(
    private val returnLineMapper: ReturnLineMapper,
    private val miraklAPIService: MiraklAPIService,
    private val configProperties: ConfigProperties,
    private val iForceRouteValidator: IForceRouteValidator,
    private val customMetrics: CustomMetrics,
    private val sellerContentBuilder: SellerContentBuilder
) {

    fun createNewReturnLine(
        pickedLine: PickLine,
        pickEventPayload: Payload,
        eventType: String,
        eventGeneratedDateTime: String,
        productApiResponseMap: Map<String, Attributes>,
        tenant: String
    ): ReturnLine {
        val totalPrice = pickedLine.itemTotal.amount.toBigDecimal()
        val quantity = pickedLine.lineQty
        val logisticalOrderId = pickEventPayload.logisticalOrderNumber
        val originalOrderLineNumber = pickedLine.lineNumber
        val ean = pickedLine.ean
        var route: String
        var status: String
        val returnType = configProperties.eventTypeToReturnTypeMapping[eventType].toString()
        var reasonForIForce: String = EMPTY
        val order: MiraklOrder = miraklAPIService.getMiraklOrderDetailsByOrderId(logisticalOrderId, tenant)
        val currencyIsoCode = order.currencyIsoCode.toString()
        if (configProperties.eventTypesEligibleForRouteDetermination.contains(eventType)) {
            val iForceReasonMap =
                iForceRouteValidator.validate(
                    totalPrice,
                    productApiResponseMap.getValue(ean),
                    pickEventPayload.site.number
                )
            if (iForceReasonMap.isNotEmpty()) {
                status = AWAITING_LABEL_PRINTING.name
                route = IFORCE.value
                reasonForIForce = iForceReasonMap.getValue(REASON_FOR_IFORCE)
            } else {
                status = AWAITING_STORE_CONFIRMATION.name
                route = TBC.value
            }
        } else {
            status = configProperties.eventTypeToStatusMapping.getOrDefault(
                eventType + '_' + order.status.state,
                configProperties.eventTypeToStatusMapping[eventType]
            ).toString()
            route = configProperties.eventTypeToRouteMapping.getOrDefault(
                eventType + '_' + order.status.state,
                configProperties.eventTypeToRouteMapping[eventType]
            ).toString()
        }
        val reasonCode = configProperties.eventTypeToReasonCodeMapping[eventType].toString()
        val productApiResponseAttributes: Attributes = productApiResponseMap.getValue(ean)
        val name = productApiResponseAttributes.name
        var refundCreated = false
        var cancellationCreated = false

        if (configProperties.eventTypesEligibleForImmediateRefund.contains(eventType)) {
            val sellerNotificationContent = sellerContentBuilder.buildSellerNotificationContent(
                route,
                returnType,
                name,
                ean,
                quantity,
                reasonCode,
                if (order.canCancel) MIRAKL_CANCEL_REASON_CODE_PREFIX else MIRAKL_REFUND_REASON_CODE_PREFIX,
                tenant
            )
            if (order.canCancel) {
                cancellationCreated = isCancelCreatedInMirakl(
                    totalPrice,
                    quantity,
                    logisticalOrderId,
                    originalOrderLineNumber,
                    reasonCode,
                    sellerNotificationContent,
                    currencyIsoCode,
                    tenant
                )
            } else {
                refundCreated = isRefundCreatedInMiraklAndSellerNotified(
                    totalPrice,
                    quantity,
                    logisticalOrderId,
                    originalOrderLineNumber,
                    reasonCode,
                    sellerNotificationContent,
                    currencyIsoCode,
                    tenant
                )
            }
        }
        return returnLineMapper.toEntity(
            (pickEventPayload.orderId + pickEventPayload.aggregateId.takeLast(2)).toLong(),
            logisticalOrderId,
            reasonCode,
            dateTimeFormatter(eventGeneratedDateTime),
            Instant.parse(eventGeneratedDateTime).toEpochMilli(),
            fetchTimeInMs(now()).toLong(),
            now().toString(),
            status,
            tenant,
            ean,
            pickedLine.lineNumber,
            originalOrderLineNumber,
            quantity.toLong(),
            (pickedLine.itemTotal.amount.toBigDecimal()).divide(
                BigDecimal.valueOf(quantity.toLong()),
                2,
                RoundingMode.HALF_UP
            ),
            totalPrice,
            route,
            pickEventPayload.site.number.toString(),
            "",
            reasonForIForce,
            pickEventPayload.customer.customerId,
            productApiResponseAttributes.technicalAttributes,
            refundCreated,
            cancellationCreated,
            RETURN_CREATED_BY_SYSTEM,
            name,
            productApiResponseAttributes.productMediaObjects
                .filter { it.description == PRODUCT_MEDIA_OBJECT_DESCRIPTION_PRIMARY_IMAGE }
                .map { it.contentUrl }
                .first(),
            configProperties.tenantToCountryCodeMap.getValue(tenant),
            order.shopId,
            returnType,
            currencyIsoCode,
            originalOrderId = "",
            notes = "",
        )
    }

    fun isRefundCreatedInMiraklAndSellerNotified(
        totalPrice: BigDecimal,
        quantity: Long,
        logisticalOrderId: String,
        originalOrderLineNumber: Long,
        reasonCode: String,
        messageToNotifySeller: String,
        currencyIsoCode: String,
        tenant: String
    ): Boolean {
        var refundCreated = false
        logger().info("Going to create refund for order: $logisticalOrderId tenant : $tenant")
        try {
            miraklAPIService.createRefund(
                totalPrice,
                quantity,
                logisticalOrderId,
                originalOrderLineNumber,
                reasonCode,
                currencyIsoCode,
                tenant
            )
            refundCreated = true
            if (messageToNotifySeller.isNotEmpty()) {
                logger().info("Going to notify seller for tenant : $tenant  order: $logisticalOrderId ")
                miraklAPIService.notifySeller(
                    logisticalOrderId,
                    messageToNotifySeller,
                    tenant
                )
            }
        } catch (e: MiraklException) {
            logger().error("Error while creating refund or notify seller for line $originalOrderLineNumber of order $logisticalOrderId due to exception $e")
        }
        if (!refundCreated) {
            customMetrics.incrementCounter(REFUND_FAILED_FOR_I_FORCE)
        }
        return refundCreated
    }

    fun isCancelCreatedInMirakl(
        totalPrice: BigDecimal,
        quantity: Long,
        logisticalOrderId: String,
        originalOrderLineNumber: Long,
        reasonCode: String,
        messageToNotifySeller: String,
        currencyIsoCode: String,
        tenant: String
    ): Boolean {
        var cancellationCreated = false
        try {
            miraklAPIService.createCancellation(
                totalPrice,
                quantity.toLong(),
                logisticalOrderId,
                originalOrderLineNumber,
                reasonCode,
                currencyIsoCode,
                tenant
            )
            cancellationCreated = true
            miraklAPIService.notifySeller(
                logisticalOrderId,
                messageToNotifySeller,
                tenant
            )
        } catch (e: MiraklException) {
            logger().error("Error while creating cancellation or notify seller for line $originalOrderLineNumber of order $logisticalOrderId due to exception $e")
        }
        if (!cancellationCreated) {
            customMetrics.incrementCounter(CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED)
        }
        return cancellationCreated
    }

    private fun dateTimeFormatter(orderCreatedDateTime: String): String {
        val parsedDate = ZonedDateTime.parse(orderCreatedDateTime)
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS")
        return parsedDate.format(formatter)
    }

    companion object : Logging
}
