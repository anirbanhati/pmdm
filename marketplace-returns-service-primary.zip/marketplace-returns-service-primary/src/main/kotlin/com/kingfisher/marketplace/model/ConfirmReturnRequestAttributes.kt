package com.kingfisher.marketplace.model

import jakarta.validation.Valid
import jakarta.validation.constraints.NotBlank

data class ConfirmReturnRequestAttributes(
    @field:NotBlank(message = "user id can not be blank") val userId: String = "",
    @field:Valid val parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList(),
)
