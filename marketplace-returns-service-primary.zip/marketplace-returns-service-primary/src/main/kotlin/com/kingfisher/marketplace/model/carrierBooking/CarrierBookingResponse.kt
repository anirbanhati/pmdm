package com.kingfisher.marketplace.model.carrierBooking

data class CarrierBookingResponse(
    var orderMasters: ArrayList<OrderMastersResponse> = arrayListOf(),
)
