package com.kingfisher.marketplace.config

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "api-security")
data class ApiSecurityProperties(
    var tenantId: String,
    var audience: String,
)
