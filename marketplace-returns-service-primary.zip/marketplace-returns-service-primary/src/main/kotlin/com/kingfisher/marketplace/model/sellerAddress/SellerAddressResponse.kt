package com.kingfisher.marketplace.model.sellerAddress

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
data class SellerAddressResponse(
    var data: Data = Data(),
)
