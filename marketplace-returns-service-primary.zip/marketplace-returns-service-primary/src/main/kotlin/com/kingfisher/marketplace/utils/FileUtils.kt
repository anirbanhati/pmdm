package com.kingfisher.marketplace.utils

import org.springframework.core.io.ClassPathResource

object FileUtils {
    fun fetchFileContent(filePath: String): String {
        return ClassPathResource(filePath).inputStream.bufferedReader().use { it.readText() }
    }
}
