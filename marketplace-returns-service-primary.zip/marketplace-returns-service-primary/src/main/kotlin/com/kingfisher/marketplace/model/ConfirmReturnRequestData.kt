package com.kingfisher.marketplace.model

import com.kingfisher.marketplace.validator.ValidParcelTrackingInfoList
import jakarta.validation.Valid
import jakarta.validation.constraints.NotBlank

@ValidParcelTrackingInfoList(message = "parcel tracking info must be available for DPD route")
data class ConfirmReturnRequestData(
    @field:NotBlank(message = "type can not be blank") val type: String,
    @field:Valid val attributes: ConfirmReturnRequestAttributes,
)
