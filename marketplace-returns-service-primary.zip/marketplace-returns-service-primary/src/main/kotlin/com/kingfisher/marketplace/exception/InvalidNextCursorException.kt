package com.kingfisher.marketplace.exception

class InvalidNextCursorException : RuntimeException()
