package com.kingfisher.marketplace.model.domain

data class TenantRouteContext(
    val route: String,
    val status: String,
    val reasonForIForce: String = ""
)
