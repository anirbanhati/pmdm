package com.kingfisher.marketplace.model.sellerAddress

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
data class Data(
    var attributes: Attributes = Attributes(),
)
