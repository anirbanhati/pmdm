package com.kingfisher.marketplace.exception

class CmsApiException(message: String?) : RuntimeException(message)
