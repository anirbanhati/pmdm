package com.kingfisher.marketplace.constant

enum class IForceReason(val value: String) {
    TOO_LARGE("Too Large"),
    DAMAGED("Damaged")
}
