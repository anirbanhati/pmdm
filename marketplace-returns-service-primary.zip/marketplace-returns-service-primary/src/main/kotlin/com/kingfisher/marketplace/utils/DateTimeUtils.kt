package com.kingfisher.marketplace.utils

import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Calendar
import java.util.Date

class DateTimeUtils {
    companion object {
        fun fetchTimeInMs(date: LocalDateTime): Number {
            val calendar: Calendar = Calendar.getInstance()
            calendar.time = Date.from(date.atZone(ZoneId.systemDefault()).toInstant())
            return calendar.timeInMillis
        }
    }
}
