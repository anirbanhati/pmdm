package com.kingfisher.marketplace.constant

class Constant {
    companion object {
        const val TOPIC_TYPE: String = "FREE_TEXT"
        const val TOPIC_VALUE: String = "Order being refunded"
        const val THREAD_TO: String = "SHOP"
        const val MIRAKL_REFUND_REASON_CODE_PREFIX: String = "REFUND"
        const val MIRAKL_CANCEL_REASON_CODE_PREFIX: String = "CANCELATION"
        const val GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX = "store_id_returned_date_in_ms_index"
        const val SCHEME_NAME_SAP = "SAP"
        const val LEADING_ZERO_IN_REASON_CODE = "0"
        const val CONTENT_TYPE_APPLICATION_VND_API_JSON = "application/vnd.api+json"
        const val PARCEL_TRACKING_NUMBER: String = "{trackingNumber}"
        const val REASON_FOR_IFORCE = "reason_for_iForce"
        const val PRODUCT_AMOUNT_THREASHOLD_FOR_COLLECTION_NOT_REACHED = "Product-amount"
        const val PRODUCT_MEDIA_OBJECT_DESCRIPTION_PRIMARY_IMAGE: String = "PrimaryImage"
        const val CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED = "labelPrintingRequested"
        const val RETURN_CREATED_BY_SYSTEM = "system"
        const val NOT_APPLICABLE = "NA"
        const val COMMA_SEPARATOR = ","
    }
}
