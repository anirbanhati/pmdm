package com.kingfisher.marketplace.kafka.consumer

import com.kingfisher.marketplace.model.kafka.DeliveryNotification
import com.kingfisher.marketplace.model.kafka.Item
import com.kingfisher.marketplace.service.DeliveryNotificationService
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.consumer.ConsumerRecords
import org.apache.kafka.common.TopicPartition
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.never
import org.mockito.kotlin.times
import org.mockito.kotlin.verify
import org.springframework.kafka.support.Acknowledgment

private const val ORDER_NUMBER = "100001"
private const val TRACKING_NUMBER = "TRK123456789"
private const val TRACKING_URL = "https://tracking.example.com/TRK123456789"
private const val CARRIER = "DPD"
private const val QUANTITY = 1L
private const val TOPIC = "delivery-notifications"
private const val PARTITION = 0

@ExtendWith(MockitoExtension::class)
class DeliveryNotificationConsumerTest {

    @InjectMocks
    private lateinit var deliveryNotificationConsumer: DeliveryNotificationConsumer

    @Mock
    private lateinit var deliveryNotificationService: DeliveryNotificationService

    @Mock
    private lateinit var acknowledgment: Acknowledgment

    private lateinit var notification: DeliveryNotification

    @BeforeEach
    fun setUp() {
        notification = buildDeliveryNotification()
    }

    private fun buildDeliveryNotification(
        orderNumber: String = ORDER_NUMBER,
        carrier: String = CARRIER,
        trackingNumber: String = TRACKING_NUMBER,
        trackingUrl: String = TRACKING_URL,
        items: List<Item> = listOf(
            Item(lineRef = "001", partNumber = "PN001", quantity = QUANTITY)
        )
    ): DeliveryNotification = DeliveryNotification(
        carrier = carrier,
        orderNumber = orderNumber,
        trackingNumber = trackingNumber,
        trackingUrl = trackingUrl,
        items = items
    )

    private fun createConsumerRecords(vararg notifications: DeliveryNotification): ConsumerRecords<String, DeliveryNotification> {
        val records = mutableListOf<ConsumerRecord<String, DeliveryNotification>>()
        notifications.forEachIndexed { index, notification ->
            records.add(
                ConsumerRecord(
                    TOPIC,
                    PARTITION,
                    index.toLong(),
                    "key-$index",
                    notification
                )
            )
        }
        return ConsumerRecords(mapOf(
            TopicPartition(TOPIC, PARTITION) to records
        ))
    }

    @Test
    fun `should process single delivery notification`() {
        val records = createConsumerRecords(notification)

        deliveryNotificationConsumer.consumeDeliveryNotification(records, acknowledgment)

        verify(deliveryNotificationService).processDeliveryNotification(notification)
        verify(acknowledgment).acknowledge()
    }

    @Test
    fun `should process multiple delivery notifications`() {
        val notification2 = buildDeliveryNotification(orderNumber = "100002")
        val notification3 = buildDeliveryNotification(orderNumber = "100003")
        val records = createConsumerRecords(notification, notification2, notification3)

        deliveryNotificationConsumer.consumeDeliveryNotification(records, acknowledgment)

        verify(deliveryNotificationService).processDeliveryNotification(notification)
        verify(deliveryNotificationService).processDeliveryNotification(notification2)
        verify(deliveryNotificationService).processDeliveryNotification(notification3)
        verify(acknowledgment, times(3)).acknowledge()
    }

    @Test
    fun `should handle empty consumer records`() {
        val records = createConsumerRecords()

        deliveryNotificationConsumer.consumeDeliveryNotification(records, acknowledgment)

        verify(deliveryNotificationService, never()).processDeliveryNotification(any())
        verify(acknowledgment, never()).acknowledge()
    }
}
