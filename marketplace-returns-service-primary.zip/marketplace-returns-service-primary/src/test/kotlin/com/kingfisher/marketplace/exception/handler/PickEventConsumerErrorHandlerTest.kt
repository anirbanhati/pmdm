package com.kingfisher.marketplace.exception.handler

import org.apache.kafka.clients.consumer.Consumer
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mockito.mock
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension
import org.springframework.kafka.listener.ListenerExecutionFailedException
import org.springframework.messaging.MessageHeaders
import org.springframework.messaging.handler.annotation.Payload
import org.springframework.messaging.support.MessageBuilder.createMessage

@ExtendWith(*arrayOf(MockitoExtension::class, OutputCaptureExtension::class))
class PickEventConsumerErrorHandlerTest {
    private val pickEventConsumerErrorHandler = PickEventConsumerErrorHandler()

    @Test
    fun `should log message in handleError`(output: CapturedOutput?) {
        val consumer = mock(Consumer::class.java)
        val exception = ListenerExecutionFailedException("testException")
        val headers = MessageHeaders(mapOf("testHeaderKey" to "testHeaderValue"))
        val message = createMessage(Payload(value = "testValue", expression = "test", required = false), headers)

        pickEventConsumerErrorHandler.handleError(message, exception, consumer)

        assertThat(output).contains("Failed to consume pick")
    }
}
