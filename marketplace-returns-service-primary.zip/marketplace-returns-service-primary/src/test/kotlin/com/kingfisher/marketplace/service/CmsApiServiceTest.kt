package com.kingfisher.marketplace.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.cms.CmsApiConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.NOT_APPLICABLE
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.helper.LineDimensionExtractor
import com.kingfisher.marketplace.model.cms.request.CmsApiRequest
import com.kingfisher.marketplace.model.cms.response.CmsApiResponse
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import com.kingfisher.marketplace.model.sellerAddress.SellerAddressResponse
import com.mirakl.client.mmp.domain.order.MiraklOrder
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.*
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension
import org.springframework.core.io.ClassPathResource
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.HttpStatus.FAILED_DEPENDENCY
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException.BadRequest
import org.springframework.web.client.RestTemplate
import java.nio.file.Files

private const val CMS_API_URL = "testCmsUrl"
private const val TENANT = "testTenant"
private const val TEST_SHOP_ID_1 = "testShopId1"
private const val TEST_SHOP_ID_2 = "testShopId2"
private const val LOGISTICAL_ORDER_ID = "1234567-AB"
private const val RETURN_ORDER_NUMBER = 100001L
private const val LINE_NUMBER = 1L
private const val ORIGINAL_ORDER_ID = "originalOrder123"
private const val NOTES = "notes"
private const val STORE_ID = "storeId"
private const val EAN = "1234567890"
private const val PRODUCT_NAME = "Test Product"
private const val SELLER_RESPONSE_BODY = "sellerResponseCapl.json"
private const val SELLER_RESPONSE_BODY_MISSING_DETAILS = "sellerResponseWithMissingAddressDetails.json"
private const val TEST_ERROR_MESSAGE = "testErrorMessage"
private const val BOOKING_TYPE = 2
private const val CLIENT_DELIVERY_GROUP_CODE = "999"
private const val COMMENT = "Return created from carrier booking flow"
private const val DELIVERY_TYPE_ID = 50
private const val STORE_CODE = 1
private const val EXTRA_NOTES = "Handle with care"

@ExtendWith(*arrayOf(MockitoExtension::class, OutputCaptureExtension::class))
class CmsApiServiceTest {

    @InjectMocks
    private lateinit var cmsApiService: CmsApiService

    @Mock
    private lateinit var mockRestTemplate: RestTemplate

    @Mock
    private lateinit var miraklAPIService: MiraklAPIService

    @Mock
    private lateinit var sellerApiService: SellerApiService

    @Mock
    private lateinit var cmsApiConfigProperties: CmsApiConfigProperties

    @Mock
    private lateinit var lineDimensionExtractor: LineDimensionExtractor

    @Mock
    private lateinit var miraklOrder: MiraklOrder

    @Captor
    private lateinit var httpEntityCaptor: ArgumentCaptor<HttpEntity<CmsApiRequest>>

    @BeforeEach
    fun setUp() {
        mockDimensionExtractor()
    }

    private fun buildReturnLine(shopId: String = TEST_SHOP_ID_1): ReturnLine = ReturnLine(
        returnOrderNumber = RETURN_ORDER_NUMBER,
        logisticalOrderId = LOGISTICAL_ORDER_ID,
        lineNumber = LINE_NUMBER,
        storeId = STORE_ID,
        ean = EAN,
        quantity = 1L,
        productName = PRODUCT_NAME,
        shopId = shopId,
        originalOrderId = ORIGINAL_ORDER_ID,
        notes = NOTES,
        technicalAttributes = TechnicalAttributes()
    )

    private fun loadSellerResponse(fileName: String): ResponseEntity<SellerAddressResponse> {
        val sellerAPIResponse = ObjectMapper().readValue(
            Files.readAllBytes(ClassPathResource(fileName).file.toPath()),
            SellerAddressResponse::class.java
        )
        return ResponseEntity(sellerAPIResponse, HttpStatus.OK)
    }

    private fun mockCmsApiCall(response: ResponseEntity<CmsApiResponse>) {
        whenever(cmsApiConfigProperties.cmsApiUrl).thenReturn(CMS_API_URL)
        whenever(
            mockRestTemplate.postForEntity(
                any<String>(), any(), eq(CmsApiResponse::class.java), any<Long>()
            )
        ).thenReturn(response)
    }

    private fun mockDimensionExtractor() {
        whenever(lineDimensionExtractor.extract(any<TechnicalAttributes>(), any<Long>(), any<Long>()))
            .thenReturn(LineDimensionExtractor.LineDimensions(30, 50, 20, 2.5))
    }

    @Test
    fun `should invoke CMS API successfully with seller details`() {
        val returnLine = buildReturnLine()
        val returnLines = listOf(returnLine)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        val cmsApiResponse = CmsApiResponse(success = true, errorMessage = "", orderDate = "2024-01-01")
        mockCmsApiCall(ResponseEntity(cmsApiResponse, HttpStatus.OK))

        val result = cmsApiService.bookCarrier(returnLines, TENANT)

        assertThat(result.success).isTrue()
        verify(miraklAPIService, never()).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }

    @Test
    fun `should build correct CMS API request body`() {
        val returnLine = buildReturnLine()
        val returnLines = listOf(returnLine)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))
        whenever(cmsApiConfigProperties.bookingType).thenReturn(BOOKING_TYPE)
        whenever(cmsApiConfigProperties.clientDeliveryGroupCode).thenReturn(CLIENT_DELIVERY_GROUP_CODE)
        whenever(cmsApiConfigProperties.comment).thenReturn(COMMENT)
        whenever(cmsApiConfigProperties.deliveryTypeId).thenReturn(DELIVERY_TYPE_ID)
        whenever(cmsApiConfigProperties.storeCode).thenReturn(STORE_CODE)
        val captor = ArgumentCaptor.forClass(HttpEntity::class.java)

        cmsApiService.bookCarrier(returnLines, TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), captor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        val request = captor.firstValue.body as CmsApiRequest
        assertThat(request.sapOrderID).isEqualTo(RETURN_ORDER_NUMBER.toString())
        assertThat(request.atgOrderID).isEqualTo(RETURN_ORDER_NUMBER.toString())
        assertThat(request.deliveryGroupCode).isEqualTo(LINE_NUMBER.toString())
        assertThat(request.warehouseID).isEqualTo(STORE_ID)
        assertThat(request.bookingType).isEqualTo(BOOKING_TYPE)
        assertThat(request.clientSapOrderID).isEqualTo(ORIGINAL_ORDER_ID)
        assertThat(request.extraNotes).isEqualTo(listOf(NOTES))
        assertThat(request.clientDeliveryGroupCode).isEqualTo(CLIENT_DELIVERY_GROUP_CODE)
        assertThat(request.comment).isEqualTo(COMMENT)
        assertThat(request.deliveryTypeID).isEqualTo(DELIVERY_TYPE_ID)
        assertThat(request.orderCreatedChannel).isEqualTo(STORE_CODE)
    }

    @Test
    fun `should populate order lines from return lines`() {
        val returnLine = ReturnLine(
            returnOrderNumber = RETURN_ORDER_NUMBER,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            lineNumber = LINE_NUMBER,
            storeId = STORE_ID,
            ean = EAN,
            quantity = 2L,
            productName = PRODUCT_NAME,
            shopId = TEST_SHOP_ID_1,
            originalOrderId = ORIGINAL_ORDER_ID,
        )
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))
        val captor = ArgumentCaptor.forClass(HttpEntity::class.java)

        cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), captor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        val request = captor.firstValue.body as CmsApiRequest
        assertThat(request.orderLines).hasSize(1)
        val orderLine = request.orderLines[0]
        assertThat(orderLine.productCode).isEqualTo(EAN)
        assertThat(orderLine.quantity).isEqualTo(2L)
        assertThat(orderLine.height).isEqualTo(30)
        assertThat(orderLine.length).isEqualTo(50)
        assertThat(orderLine.width).isEqualTo(20)
        assertThat(orderLine.weight).isEqualTo(2.5)
        assertThat(orderLine.name).isEqualTo(PRODUCT_NAME)
    }

    @Test
    fun `should throw CmsApiException when HttpStatusCodeException occurs`(output: CapturedOutput) {
        val returnLine = buildReturnLine()
        val returnLines = listOf(returnLine)
        whenever(cmsApiConfigProperties.cmsApiUrl).thenReturn(CMS_API_URL)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        val exp = BadRequest.create(TEST_ERROR_MESSAGE, FAILED_DEPENDENCY, "", HttpHeaders(), ByteArray(1), null)
        whenever(
            mockRestTemplate.postForEntity(
                any<String>(), any(), eq(CmsApiResponse::class.java), any<Long>()
            )
        ).thenThrow(exp)

        assertThatThrownBy {
            cmsApiService.bookCarrier(returnLines, TENANT)
        }.isInstanceOf(CmsApiException::class.java)
            .extracting("message").isEqualTo(TEST_ERROR_MESSAGE)
        assertThat(output).contains("Failed to book carrier via CMS API for return order $RETURN_ORDER_NUMBER : $TEST_ERROR_MESSAGE")
    }

    @Test
    fun `should fetch shopId from Mirakl when shopId is blank`() {
        val returnLine = ReturnLine(
            returnOrderNumber = RETURN_ORDER_NUMBER,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            lineNumber = LINE_NUMBER,
            storeId = STORE_ID,
            ean = EAN,
            quantity = 1L,
            productName = PRODUCT_NAME,
            shopId = "",
            originalOrderId = ORIGINAL_ORDER_ID,
            technicalAttributes = TechnicalAttributes()
        )
        whenever(miraklAPIService.getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)).thenReturn(miraklOrder)
        whenever(miraklOrder.shopId).thenReturn(TEST_SHOP_ID_2)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_2, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))

        val result = cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        assertThat(result).isNotNull
        verify(miraklAPIService).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }

    @Test
    fun `should fetch shopId from Mirakl when shopId is NOT_APPLICABLE`() {
        val returnLine = buildReturnLine(shopId = NOT_APPLICABLE)
        whenever(miraklAPIService.getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)).thenReturn(miraklOrder)
        whenever(miraklOrder.shopId).thenReturn(TEST_SHOP_ID_2)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_2, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))

        val result = cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        assertThat(result).isNotNull
        verify(miraklAPIService).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }

    @Test
    fun `should populate recipient with return address when present`() {
        val returnLine = buildReturnLine()
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(
            loadSellerResponse(
                SELLER_RESPONSE_BODY
            )
        )
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))
        val captor = ArgumentCaptor.forClass(HttpEntity::class.java)

        cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), captor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        val recipient = (captor.firstValue.body as CmsApiRequest).recipient
        assertThat(recipient.name).isEqualTo("seller_name")
        assertThat(recipient.mobilePhone).isEqualTo("987654567")
        assertThat(recipient.mobilePhonePrefix).isEqualTo("+48")
        assertThat(recipient.email).isEqualTo("test@test.com")
        assertThat(recipient.city).isEqualTo("Poland")
        assertThat(recipient.postCode).isEqualTo("79997")
        assertThat(recipient.street).isEqualTo("Street no 1")
        assertThat(recipient.houseNumber).isEqualTo("4")
        assertThat(recipient.flatNumber).isEqualTo("1B")
    }

    @Test
    fun `should use sellerName when departmentName is missing`() {
        val returnLine = buildReturnLine()
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
            .thenReturn(loadSellerResponse(SELLER_RESPONSE_BODY_MISSING_DETAILS))
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))
        val captor = ArgumentCaptor.forClass(HttpEntity::class.java)

        cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), captor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        val recipient = (captor.firstValue.body as CmsApiRequest).recipient
        // sellerResponseWithMissingAddressDetails.json has no departmentName, sellerName = "seller_name"
        assertThat(recipient.name).isEqualTo("seller_name")
    }

    @Test
    fun `should resolve phone prefix for known country codes`() {
        reset(lineDimensionExtractor)
        mapOf(
            "PL" to "+48",
            "GB" to "+44",
            "FR" to "+33",
            "DE" to "+49"
        ).forEach { (countryCode, expectedPrefix) ->
            val sellerResponse = ObjectMapper().readValue(
                Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
                SellerAddressResponse::class.java
            ).also { it.data.attributes.inStoreReturnDetails.country = countryCode }
            whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
                .thenReturn(ResponseEntity(sellerResponse, HttpStatus.OK))

            val recipient = cmsApiService.buildRecipient(TEST_SHOP_ID_1, TENANT)

            assertThat(recipient.contactPhonePrefix).isEqualTo(expectedPrefix)
        }
    }

    @Test
    fun `should return null phone prefix for unknown country code`(output: CapturedOutput) {
        reset(lineDimensionExtractor)
        val sellerResponse = ObjectMapper().readValue(
            Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
            SellerAddressResponse::class.java
        ).also { it.data.attributes.inStoreReturnDetails.country = "XX" }
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
            .thenReturn(ResponseEntity(sellerResponse, HttpStatus.OK))

        val recipient = cmsApiService.buildRecipient(TEST_SHOP_ID_1, TENANT)

        assertThat(recipient.contactPhonePrefix).isNull()
        assertThat(output).contains("No phone prefix mapping for countryCode=XX")
    }

    @Test
    fun `should pass empty extraNotes to CMS API when notes is null`() {
        val returnLine = buildReturnLine().copy(notes = null)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(loadSellerResponse(SELLER_RESPONSE_BODY))
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))

        cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), httpEntityCaptor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        assertThat((httpEntityCaptor.firstValue.body as CmsApiRequest).extraNotes).isEmpty()
    }

    @Test
    fun `should pass extraNotes to CMS API when notes is present`() {
        val returnLine = buildReturnLine().copy(notes = EXTRA_NOTES)
        whenever(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT)).thenReturn(loadSellerResponse(SELLER_RESPONSE_BODY))
        mockCmsApiCall(ResponseEntity(CmsApiResponse(true, "", "2024-01-01"), HttpStatus.OK))

        cmsApiService.bookCarrier(listOf(returnLine), TENANT)

        verify(mockRestTemplate).postForEntity(
            eq(CMS_API_URL), httpEntityCaptor.capture(), eq(CmsApiResponse::class.java), eq(RETURN_ORDER_NUMBER)
        )
        assertThat((httpEntityCaptor.firstValue.body as CmsApiRequest).extraNotes).containsExactly(EXTRA_NOTES)
    }
}
