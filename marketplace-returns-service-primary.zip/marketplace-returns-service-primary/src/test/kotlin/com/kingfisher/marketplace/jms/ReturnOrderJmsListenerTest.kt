package com.kingfisher.marketplace.jms

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.mapper.ReturnLineMapper
import com.kingfisher.marketplace.metrics.*
import com.kingfisher.marketplace.metrics.MetricsTags.FAILURE
import com.kingfisher.marketplace.metrics.MetricsTags.SUCCESS
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.model.product.ProductAPIResponse
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.service.*
import com.kingfisher.marketplace.service.tenant.TenantRouteHandler
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode.GBP
import com.mirakl.client.mmp.domain.order.MiraklOrder
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.lenient
import org.mockito.Spy
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.*
import org.springframework.boot.test.system.OutputCaptureExtension
import org.springframework.core.io.ClassPathResource
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.util.StopWatch
import java.lang.System.currentTimeMillis
import java.nio.file.Files
import java.time.LocalDateTime.now
import java.util.stream.Collectors

private const val RETURN_PSO_WITH_IFORCE_LINE = "4974019974408_iForce.xml"
private const val PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT = "4974019974408.json"
private const val EAN_WITH_PRODUCT_WIDTH = "4974019974408"
private const val TEST_BRAND = "brand"
private const val TEST_TENANT = "BQUK"
private const val TEST_IFORCE_REASON_PRODUCT_WEIGHT = "Product_weight"
private const val TEST_LOGISTICAL_ORDER_NUMBER = "7002-A"
private const val NOTIFICATION_MESSAGE_IFORCE =
    "Product name-Sharp YC-MS01U-S 20L 800W Microwave - Silver, ean - 4974019974408, quantity - 1, reason - test reason, iForceReasonMessage - It exceeds the maximum weight threshold"
private const val TEST_PRODUCT_NAME = "Sharp YC-MS01U-S 20L 800W Microwave - Silver"
private const val TEST_CONTENT_URL = "https://media.diy.com/is/image/KingfisherDigital/4974019974408_01c_MP"
private const val TEST_SHOP_ID = "testShopId"
private const val RETURN_PSO_FOR_MIXED_BASKET_ORDER = "mixedBasketReturnPso.xml"
private const val RETURN_PSO_WITH_MULTI_IFORCE_LINE = "4974019974408_3333333389333_iForce.xml"
private const val PRODUCT_API_RESPONSE_WITH_MULTI_LINE = "MultipleProductAPIResponse.json"
private const val TEST_REASON_FOR_IFORCE = "Test Reason For iFroce"
private const val TEST_DELIVERY_CODE = "testDeliveryCode"

@ExtendWith(*arrayOf(MockitoExtension::class, OutputCaptureExtension::class))
class ReturnOrderJmsListenerTest {

    @Mock
    private lateinit var productApiQueryServiceMock: ProductApiQueryService

    @Mock
    private lateinit var configPropertiesMock: ConfigProperties

    @Mock
    private lateinit var tenantRouteHandler: TenantRouteHandler

    @Mock
    private lateinit var returnLineRepositoryMock: ReturnLineRepository

    @Mock
    private lateinit var miraklApiServiceMock: MiraklAPIService

    @Mock
    private lateinit var customMetricsMock: CustomMetrics

    @Mock
    private lateinit var miraklOrder: MiraklOrder

    @Mock
    private lateinit var sellerContentBuilder: SellerContentBuilder

    @Suppress("Unused")
    @Spy
    private lateinit var returnLineMapper: ReturnLineMapper

    @Mock
    private lateinit var returnLineServiceMock: ReturnLineService

    @Mock
    private lateinit var stopwatch: StopWatch

    @Mock
    private lateinit var postRefundHandler: PostRefundHandler

    @InjectMocks
    private lateinit var returnOrderJmsListener: ReturnOrderJmsListener

    @BeforeEach
    fun setUp() {
        whenever(this.configPropertiesMock.eligibleCategoryCodes).thenReturn(listOf(TEST_DELIVERY_CODE))
        lenient().whenever(
            miraklApiServiceMock.getMiraklOrderDetailsByOrderId(
                TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT
            )
        ).thenReturn(miraklOrder)
        lenient().whenever(miraklOrder.shopId).thenReturn(TEST_SHOP_ID)
        lenient().whenever(miraklOrder.currencyIsoCode).thenReturn(GBP)
        whenever(customMetricsMock.startTimer()).thenReturn(stopwatch)
    }

    @Test
    fun shouldCallProductAPIWithSingleEan() {
        setUpRefundCreated(true)
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)
        whenever(productApiQueryServiceMock.fetchProduct(EAN_WITH_PRODUCT_WIDTH, TEST_TENANT)).thenReturn(
            buildProductAPIMap(productAPIResponse)
        )
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))
        whenever(tenantRouteHandler.retrieveContext(any<String>(), any<SalesOrderInfo>())).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_LABEL_PRINTING.name, TEST_IFORCE_REASON_PRODUCT_WEIGHT
                )
            )

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.firstValue[0].route).isEqualTo(IFORCE.value)
        assertThat(returnLinesCaptor.firstValue[0].ean).isEqualTo(EAN_WITH_PRODUCT_WIDTH)
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        assertThat(returnLinesCaptor.firstValue[0].tenant).isEqualTo(TEST_TENANT)
        assertThat(returnLinesCaptor.firstValue[0].reasonForIForce).isEqualTo(TEST_IFORCE_REASON_PRODUCT_WEIGHT)
        assertThat(returnLinesCaptor.firstValue[0].productName).isEqualTo(TEST_PRODUCT_NAME)
        assertThat(returnLinesCaptor.firstValue[0].primaryImageUrl).isEqualTo(TEST_CONTENT_URL)
        assertThat(returnLinesCaptor.firstValue[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        assertThat(returnLinesCaptor.firstValue[0].refundCreated).isTrue
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)
        verify(miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
        verify(customMetricsMock).recordJmsLineResult(SUCCESS, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    @Test
    fun shouldCallProductAPIWithMultipleEan() {
        setUpRefundCreated(true)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(fetchProductAPIResponse(PRODUCT_API_RESPONSE_WITH_MULTI_LINE), HttpStatus.OK)
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_MULTI_IFORCE_LINE)
        val productApiResponseMap = buildProductAPIMap(productAPIResponse)
        whenever(productApiQueryServiceMock.fetchProduct("4974019974408,5056709507581", TEST_TENANT)).thenReturn(
            productApiResponseMap
        )
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))

        whenever(
            tenantRouteHandler.retrieveContext(
                eq(TEST_TENANT), argThat { productAttributes.ean == "4974019974408" })
        ).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_LABEL_PRINTING.name, TEST_IFORCE_REASON_PRODUCT_WEIGHT
                )
            )

        whenever(
            tenantRouteHandler.retrieveContext(
                eq(TEST_TENANT), argThat { productAttributes.ean == "5056709507581" })
        ).thenReturn(TenantRouteContext(TBC.value, Status.AWAITING_LABEL_PRINTING.name))

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.firstValue.size).isEqualTo(2)
        assertThat(returnLinesCaptor.firstValue[0].route).isEqualTo(IFORCE.value)
        assertThat(returnLinesCaptor.firstValue[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[1].route).isEqualTo(TBC.value)
        assertThat(returnLinesCaptor.firstValue[1].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        assertThat(returnLinesCaptor.firstValue[1].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[1].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[1].shopId).isEqualTo(TEST_SHOP_ID)
        verify(this.miraklApiServiceMock, times(2)).getMiraklOrderDetailsByOrderId(
            TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT
        )
        verify(customMetricsMock, times(2)).recordJmsLineResult(SUCCESS, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    @Test
    fun shouldSaveReturnOrderIfStoreInInclusionList() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)
        whenever(productApiQueryServiceMock.fetchProduct(EAN_WITH_PRODUCT_WIDTH, TEST_TENANT)).thenReturn(
            buildProductAPIMap(productAPIResponse)
        )
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))
        whenever(tenantRouteHandler.retrieveContext(eq(TEST_TENANT), any<SalesOrderInfo>())).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_STORE_CONFIRMATION.name, TEST_REASON_FOR_IFORCE
                )
            )

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.firstValue[0].ean).isEqualTo(EAN_WITH_PRODUCT_WIDTH)
        assertThat(returnLinesCaptor.firstValue[0].route).isEqualTo(IFORCE.value)
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        assertThat(returnLinesCaptor.firstValue[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        assertThat(returnLinesCaptor.firstValue[0].productName).isEqualTo(TEST_PRODUCT_NAME)
        assertThat(returnLinesCaptor.firstValue[0].primaryImageUrl).isEqualTo(TEST_CONTENT_URL)
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)
        verify(this.miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
    }

    private fun fetchFileContent(psoPath: String): String {
        return ClassPathResource(psoPath).file.readLines().stream().collect(Collectors.joining())
    }

    private fun fetchProductAPIResponse(jsonPath: String): ProductAPIResponse {
        return ObjectMapper().readValue(
            Files.readAllBytes(ClassPathResource(jsonPath).file.toPath()),
            ProductAPIResponse::class.java,
        )
    }

    private fun setUpRefundCreated(returnValue: Boolean) {
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any<String>(),
                any<String>(),
                any<String>(),
                any<String>(),
                any<Long>(),
                any<String>(),
                any<String>(),
                any<String>(),
                anyOrNull(),
                anyOrNull(),
                anyOrNull()
            )
        ).thenReturn("")

        whenever(
            returnLineServiceMock.isRefundCreatedInMiraklAndSellerNotified(
                any(), any<Long>(), any<String>(), any<Long>(), any<String>(), any<String>(), any<String>(), any()
            )
        ).thenReturn(returnValue)
    }

    @Test
    fun `should save return line but set refunded false if refund is not successful in Mirakl`() {
        setUpReturnLineForAutoIForce()
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)
        setUpRefundCreated(false)

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        verifySingleLineAutoIForceLineProperties(returnLinesCaptor.firstValue[0])
        assertThat(returnLinesCaptor.firstValue[0].refundCreated).isFalse
        verify(miraklApiServiceMock, never()).notifySeller(
            TEST_LOGISTICAL_ORDER_NUMBER, NOTIFICATION_MESSAGE_IFORCE, TEST_TENANT
        )
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)

        verify(miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
        verify(customMetricsMock).recordJmsLineResult(FAILURE, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    @Test
    fun `should increase failed refund for iForce if counter is not null`() {
        setUpReturnLineForAutoIForce()
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)
        setUpRefundCreated(false)

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        verifySingleLineAutoIForceLineProperties(returnLinesCaptor.firstValue[0])
        assertThat(returnLinesCaptor.firstValue[0].refundCreated).isFalse
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)
        verify(miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
        verify(customMetricsMock).recordJmsLineResult(FAILURE, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    @Test
    fun `should save return line and set refunded true though notify seller is not successful in Mirakl`() {
        setUpReturnLineForAutoIForce()
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)
        setUpRefundCreated(true)
        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        verifySingleLineAutoIForceLineProperties(returnLinesCaptor.firstValue[0])
        assertThat(returnLinesCaptor.firstValue[0].refundCreated).isTrue
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).isEqualTo(TEST_SHOP_ID)
        verify(miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
        verify(customMetricsMock).recordJmsLineResult(SUCCESS, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    private fun setUpReturnLineForAutoIForce() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        whenever(productApiQueryServiceMock.fetchProduct(EAN_WITH_PRODUCT_WIDTH, TEST_TENANT)).thenReturn(
            buildProductAPIMap(productAPIResponse)
        )
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))
        whenever(tenantRouteHandler.retrieveContext(eq(TEST_TENANT), any<SalesOrderInfo>())).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_STORE_CONFIRMATION.name, TEST_IFORCE_REASON_PRODUCT_WEIGHT
                )
            )
    }

    private fun verifySingleLineAutoIForceLineProperties(returnLineSavedInDB: ReturnLine) {
        assertThat(returnLineSavedInDB.route).isEqualTo(IFORCE.value)
        assertThat(returnLineSavedInDB.ean).isEqualTo(EAN_WITH_PRODUCT_WIDTH)
        assertThat(returnLineSavedInDB.tenant).isEqualTo(TEST_TENANT)
        assertThat(returnLineSavedInDB.reasonForIForce).isEqualTo(TEST_IFORCE_REASON_PRODUCT_WEIGHT)
        assertThat(returnLineSavedInDB.productName).isEqualTo(TEST_PRODUCT_NAME)
        assertThat(returnLineSavedInDB.primaryImageUrl).isEqualTo(TEST_CONTENT_URL)
        assertThat(returnLineSavedInDB.logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
    }

    @Test
    fun `should filter 1P line before processing PSO for mixed basket order`() {
        setUpRefundCreated(true)
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        val returnPSO: String = fetchFileContent(RETURN_PSO_FOR_MIXED_BASKET_ORDER)
        whenever(productApiQueryServiceMock.fetchProduct(EAN_WITH_PRODUCT_WIDTH, TEST_TENANT)).thenReturn(
            buildProductAPIMap(productAPIResponse)
        )
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))
        whenever(tenantRouteHandler.retrieveContext(eq(TEST_TENANT), any<SalesOrderInfo>())).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_STORE_CONFIRMATION.name, TEST_IFORCE_REASON_PRODUCT_WEIGHT
                )
            )

        returnOrderJmsListener.processReturnOrder(returnPSO)

        val returnLinesCaptor = argumentCaptor<List<ReturnLine>>()
        verify(this.postRefundHandler).handle(any(), returnLinesCaptor.capture())

        assertThat(returnLinesCaptor.firstValue[0].route).isEqualTo(IFORCE.value)
        assertThat(returnLinesCaptor.firstValue[0].ean).isEqualTo(EAN_WITH_PRODUCT_WIDTH)
        assertThat(returnLinesCaptor.allValues.size).isEqualTo(1)
        assertThat(returnLinesCaptor.firstValue[0].tenant).isEqualTo(TEST_TENANT)
        assertThat(returnLinesCaptor.firstValue[0].reasonForIForce).isEqualTo(TEST_IFORCE_REASON_PRODUCT_WEIGHT)
        assertThat(returnLinesCaptor.firstValue[0].productName).isEqualTo(TEST_PRODUCT_NAME)
        assertThat(returnLinesCaptor.firstValue[0].primaryImageUrl).isEqualTo(TEST_CONTENT_URL)
        assertThat(returnLinesCaptor.firstValue[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        assertThat(returnLinesCaptor.firstValue[0].refundCreated).isTrue
        assertThat(returnLinesCaptor.firstValue[0].lastUpdated).contains(now().year.toString())
        assertThat(returnLinesCaptor.firstValue[0].lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(returnLinesCaptor.firstValue[0].shopId).contains(TEST_SHOP_ID)
        verify(miraklApiServiceMock).getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)
        verify(customMetricsMock).recordJmsLineResult(SUCCESS, TEST_TENANT)
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    @Test
    fun `should catch exception from product api`() {
        reset(sellerContentBuilder, miraklApiServiceMock, miraklOrder)
        val returnPSO: String = fetchFileContent(RETURN_PSO_FOR_MIXED_BASKET_ORDER)
        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))

        returnOrderJmsListener.processReturnOrder(returnPSO)

        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(FAILURE), eq(TEST_TENANT))
    }

    private fun buildProductAPIMap(productAPIResponse: ResponseEntity<ProductAPIResponse>): Map<String, Attributes> {
        val responseMap = mutableMapOf<String, Attributes>()
        for (responseData in productAPIResponse.body?.data!!) {
            responseMap[responseData.attributes.ean] = responseData.attributes
        }
        return responseMap
    }

    @Test
    fun `should call sellerContentBuilder for BQUK tenant`() {
        sellerContentBuilderHelper(Tenant.BQUK.name)
        verify(sellerContentBuilder).buildSellerNotificationContent(
            any(), any(), any(), any(), any(), any(), any(), eq(TEST_TENANT), anyOrNull(), anyOrNull(), anyOrNull()
        )
        verify(this.postRefundHandler).handle(any(), any())
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }

    private fun sellerContentBuilderHelper(tenant: String) {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)

        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to tenant))
        whenever(productApiQueryServiceMock.fetchProduct(EAN_WITH_PRODUCT_WIDTH, tenant)).thenReturn(
            buildProductAPIMap(productAPIResponse)
        )
        lenient().whenever(tenantRouteHandler.retrieveContext(eq(tenant), any<SalesOrderInfo>())).thenReturn(
                TenantRouteContext(
                    IFORCE.value, Status.AWAITING_STORE_CONFIRMATION.name, TEST_IFORCE_REASON_PRODUCT_WEIGHT
                )
            )
        lenient().whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), anyOrNull(), anyOrNull()
            )
        ).thenReturn(NOTIFICATION_MESSAGE_IFORCE)
        lenient().whenever(
            returnLineServiceMock.isRefundCreatedInMiraklAndSellerNotified(
                any(), any<Long>(), any<String>(), any<Long>(), any<String>(), any<String>(), any<String>(), any()
            )
        ).thenReturn(true)

        returnOrderJmsListener.processReturnOrder(returnPSO)
    }

    @Test
    fun `should not save return lines when no eligible order lines exist`() {
        val returnPSO: String = fetchFileContent(RETURN_PSO_WITH_IFORCE_LINE)

        whenever(configPropertiesMock.brandTenantMap).thenReturn(mapOf(TEST_BRAND to TEST_TENANT))
        // Return empty list so no lines match eligible category codes
        whenever(configPropertiesMock.eligibleCategoryCodes).thenReturn(emptyList())

        returnOrderJmsListener.processReturnOrder(returnPSO)

        verify(this.postRefundHandler).handle(any(), any())
        verify(customMetricsMock).recordJmsResult(any<StopWatch>(), eq(SUCCESS), eq(TEST_TENANT))
    }
}
