package com.kingfisher.marketplace.transformer

import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.model.ParcelTrackingInfo
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension

private const val TEST_LINE_NUMBER = 1L
private const val TEST_RETURN_ORDER_NUMBER = 123L
private const val USER_ID = "user_id"
private const val TRACKING_LINK = "https://www.tracking.com/track/abc1234"
private const val TRACKING_ID = "tracking_id"

@ExtendWith(MockitoExtension::class)
class DataTransformerTest {
    private val dataTransformer: ApiModelTransfomer = ApiModelTransfomer()

    @Test
    fun shouldTransformReturnLineToReturnDataIfRefundIsCreated() {
        var returnLine: ReturnLine = ReturnLine()
        returnLine.lineNumber = TEST_LINE_NUMBER
        returnLine.returnOrderNumber = TEST_RETURN_ORDER_NUMBER
        returnLine.refundCreated = true

        val result = this.dataTransformer.transformToReturnLineResponse(listOf(returnLine)).data.attributes.lines[0]

        assertThat(result.lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(result.refundCreated).isTrue
    }

    @Test
    fun shouldTransformReturnLineToReturnDataIfRefundIsNotCreated() {
        var returnLine: ReturnLine = ReturnLine()
        returnLine.lineNumber = TEST_LINE_NUMBER
        returnLine.returnOrderNumber = TEST_RETURN_ORDER_NUMBER
        returnLine.refundCreated = false

        val result = this.dataTransformer.transformToReturnLineResponse(listOf(returnLine)).data.attributes.lines[0]

        assertThat(result.lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(result.refundCreated).isFalse
    }

    @Test
    fun shouldTransformReturnLineToLabelPrintResponse() {
        var returnLine: ReturnLine = ReturnLine()
        returnLine.lineNumber = TEST_LINE_NUMBER
        returnLine.returnOrderNumber = TEST_RETURN_ORDER_NUMBER
        returnLine.refundCreated = true
        returnLine.labelPrintingRequestedBy = USER_ID
        returnLine.parcelTrackingInfo = listOf(
            ParcelTrackingInfo(1, TRACKING_ID, TRACKING_LINK)
        )
        returnLine.status = Status.LABEL_PRINTING_REQUESTED.toString()

        val result = this.dataTransformer.transformToReturnLineResponse(returnLine)!!.data.attributes.line

        assertThat(result.lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(result.refundCreated).isTrue
        assertThat(result.labelPrintingRequestedBy).isEqualTo(USER_ID)
        assertThat(result.parcelTrackingInfo.get(0).externalParcelIdentifier).isEqualTo(TRACKING_ID)
        assertThat(result.parcelTrackingInfo.get(0).trackingNumber).isEqualTo(TRACKING_LINK)
        assertThat(result.status).isEqualTo(Status.LABEL_PRINTING_REQUESTED.toString())
    }
}
