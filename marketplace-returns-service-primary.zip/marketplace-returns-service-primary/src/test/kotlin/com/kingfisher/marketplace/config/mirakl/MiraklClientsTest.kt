package com.kingfisher.marketplace.config.mirakl

import com.mirakl.client.mmp.operator.core.MiraklMarketplacePlatformOperatorApiClient
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension

private const val TENANT_BQUK = "BQUK"
private const val TENANT_CAPL = "CAPL"
private const val TENANT_UNKNOWN = "UNKNOWN"

@ExtendWith(MockitoExtension::class)
class MiraklClientsTest {

    @Mock
    private lateinit var bqukClient: MiraklMarketplacePlatformOperatorApiClient

    @Mock
    private lateinit var caplClient: MiraklMarketplacePlatformOperatorApiClient

    private lateinit var miraklClients: MiraklClients

    @BeforeEach
    fun setUp() {
        miraklClients = MiraklClients(
            mapOf(
                TENANT_BQUK to bqukClient,
                TENANT_CAPL to caplClient
            )
        )
    }

    @Test
    fun `should return correct client for BQUK tenant`() {
        val client = miraklClients.getClient(TENANT_BQUK)

        assertThat(client).isSameAs(bqukClient)
    }

    @Test
    fun `should return correct client for CAPL tenant`() {
        val client = miraklClients.getClient(TENANT_CAPL)

        assertThat(client).isSameAs(caplClient)
    }

    @Test
    fun `should throw IllegalArgumentException for unknown tenant`() {
        assertThatThrownBy { miraklClients.getClient(TENANT_UNKNOWN) }
            .isInstanceOf(IllegalArgumentException::class.java)
            .hasMessage("No Mirakl client configured for tenant: $TENANT_UNKNOWN")
    }

    @Test
    fun `should throw IllegalArgumentException for empty tenant id`() {
        assertThatThrownBy { miraklClients.getClient("") }
            .isInstanceOf(IllegalArgumentException::class.java)
            .hasMessage("No Mirakl client configured for tenant: ")
    }

    @Test
    fun `should throw IllegalArgumentException when clients map is empty`() {
        val emptyClients = MiraklClients(emptyMap())

        assertThatThrownBy { emptyClients.getClient(TENANT_BQUK) }
            .isInstanceOf(IllegalArgumentException::class.java)
            .hasMessage("No Mirakl client configured for tenant: $TENANT_BQUK")
    }
}
