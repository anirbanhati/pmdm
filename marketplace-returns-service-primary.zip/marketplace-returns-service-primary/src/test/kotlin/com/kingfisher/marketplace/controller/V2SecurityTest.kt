package com.kingfisher.marketplace.controller

import com.kingfisher.marketplace.config.SecurityConfig
import com.kingfisher.marketplace.jms.ReturnOrderJmsListener
import com.kingfisher.marketplace.service.CarrierRebookService
import com.kingfisher.marketplace.service.ManualUpdateLineDetailsService
import com.kingfisher.marketplace.service.ReturnBusinessService
import com.kingfisher.marketplace.service.UpdateRouteBusinessService
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Test
import org.mockito.kotlin.whenever
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.context.annotation.Import
import org.springframework.http.HttpStatus
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt
import org.springframework.test.context.ActiveProfiles
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status

@WebMvcTest(controllers = [Controller::class])
@Import(SecurityConfig::class)
@ActiveProfiles("test")
class V2SecurityTest {

    @Autowired
    lateinit var mockMvc: MockMvc

    @MockitoBean
    lateinit var jwtDecoder: JwtDecoder

    @MockitoBean
    lateinit var returnBusinessServiceMock: ReturnBusinessService

    @MockitoBean
    lateinit var jmsListener: ReturnOrderJmsListener

    @MockitoBean
    lateinit var updateRouteBusinessServiceMock: UpdateRouteBusinessService

    @MockitoBean
    lateinit var manualUpdateLineDetailsServiceMock: ManualUpdateLineDetailsService

    @MockitoBean
    lateinit var carrierRebookServiceMock: CarrierRebookService

    @Test
    fun `should return 401 for v2 endpoint when no token is provided`() {
        mockMvc.perform(get("/v2/fetchAllOrders"))
            .andExpect(status().isUnauthorized())
    }

    @Test
    fun `should return 403 for v2 endpoint when caller is not a member of the required group`() {
        mockMvc.perform(get("/v2/fetchAllOrders").with(jwt()))
            .andExpect(status().isForbidden())
    }

    @Test
    fun `should return 200 for v2 endpoint when caller is a member of the required group`() {
        whenever(returnBusinessServiceMock.fetchAllReturnLines()).thenReturn(listOf())

        mockMvc.perform(
            get("/v2/fetchAllOrders")
                .with(jwt().authorities(SimpleGrantedAuthority("ROLE_app-access")))
        ).andExpect(status().isOk())
    }

    @Test
    fun `should allow v1 endpoint without a token`() {
        whenever(returnBusinessServiceMock.fetchAllReturnLines()).thenReturn(listOf())

        mockMvc.perform(get("/v1/fetchAllOrders"))
            .andExpect(status().isOk())
    }

    @Test
    fun `should not mask the error dispatch of an unauthenticated request as 401`() {
        mockMvc.perform(get("/error"))
            .andExpect { assertNotEquals(HttpStatus.UNAUTHORIZED.value(), it.response.status) }
    }

    @Test
    fun `should return a json body when authentication is missing`() {
        mockMvc.perform(get("/v2/fetchAllOrders"))
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.error").value("UNAUTHORIZED"))
    }

    @Test
    fun `should return a json body when the caller lacks the required group`() {
        mockMvc.perform(get("/v2/fetchAllOrders").with(jwt()))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.error").value("FORBIDDEN"))
    }
}
