package com.kingfisher.marketplace.metrics

import com.kingfisher.marketplace.metrics.MetricsTags.DYNAMO_OPERATION
import com.kingfisher.marketplace.metrics.MetricsTags.FAILURE
import com.kingfisher.marketplace.metrics.MetricsTags.RESULT
import com.kingfisher.marketplace.metrics.MetricsTags.SUCCESS
import io.micrometer.core.instrument.MeterRegistry
import io.micrometer.core.instrument.Tag
import io.micrometer.core.instrument.Tags
import io.micrometer.core.instrument.Timer
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.eq
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import software.amazon.awssdk.core.interceptor.Context
import software.amazon.awssdk.core.interceptor.ExecutionAttribute
import software.amazon.awssdk.core.interceptor.ExecutionAttributes
import software.amazon.awssdk.core.interceptor.SdkExecutionAttribute
import java.util.concurrent.TimeUnit

@ExtendWith(MockitoExtension::class)
class DynamoMetricsInterceptorTest {

    @Mock
    private lateinit var contextBefore: Context.BeforeExecution

    @Mock
    private lateinit var contextAfter: Context.AfterExecution

    @Mock
    private lateinit var contextFailed: Context.FailedExecution

    @Mock
    private lateinit var attributes: ExecutionAttributes

    @Mock
    private lateinit var timer: Timer

    @Mock
    private lateinit var meterRegistry: MeterRegistry

    @InjectMocks
    private lateinit var underTest: DynamoMetricsInterceptor

    @Test
    fun `should put start_time to context`() {
        underTest.beforeExecution(contextBefore, attributes)
        verify(attributes).putAttribute(any<ExecutionAttribute<Long>>(), any<Long>())
    }

    @Test
    fun `should record success after execution`() {
        whenever(attributes.getAttribute(any<ExecutionAttribute<Long>>())).thenReturn(100L)
        whenever(attributes.getAttribute(SdkExecutionAttribute.OPERATION_NAME)).thenReturn("scan")
        whenever(meterRegistry.timer(any<String>(), any<Tags>())).thenReturn(timer)

        underTest.afterExecution(contextAfter, attributes)
        verify(meterRegistry).timer(any<String>(),
            eq(Tags.of(Tag.of(DYNAMO_OPERATION, "scan"), Tag.of(RESULT, SUCCESS))))
        verify(timer).record(any<Long>(), eq(TimeUnit.NANOSECONDS))
    }

    @Test
    fun `should record success after exception`() {
        whenever(attributes.getAttribute(any<ExecutionAttribute<Long>>())).thenReturn(100L)
        whenever(attributes.getAttribute(SdkExecutionAttribute.OPERATION_NAME)).thenReturn("scan")
        whenever(meterRegistry.timer(any<String>(), any<Tags>())).thenReturn(timer)

        underTest.onExecutionFailure(contextFailed, attributes)
        verify(meterRegistry).timer(any<String>(),
            eq(Tags.of(Tag.of(DYNAMO_OPERATION, "scan"), Tag.of(RESULT, FAILURE))))
        verify(timer).record(any<Long>(), eq(TimeUnit.NANOSECONDS))
    }
}
