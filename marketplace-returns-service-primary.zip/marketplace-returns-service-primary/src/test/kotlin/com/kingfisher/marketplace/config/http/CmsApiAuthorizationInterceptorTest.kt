package com.kingfisher.marketplace.config.http

import com.kingfisher.marketplace.constant.Constant.Companion.CONTENT_TYPE_APPLICATION_VND_API_JSON
import com.kingfisher.marketplace.exception.CmsApiException
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.never
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import org.springframework.http.HttpHeaders.*
import org.springframework.http.HttpMethod.POST
import org.springframework.http.HttpStatus.OK
import org.springframework.http.client.ClientHttpRequestExecution
import org.springframework.mock.http.client.MockClientHttpRequest
import org.springframework.mock.http.client.MockClientHttpResponse
import org.springframework.security.oauth2.client.ClientAuthorizationException
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager
import org.springframework.security.oauth2.client.registration.ClientRegistration
import org.springframework.security.oauth2.core.AuthorizationGrantType.CLIENT_CREDENTIALS
import org.springframework.security.oauth2.core.ClientAuthenticationMethod.CLIENT_SECRET_POST
import org.springframework.security.oauth2.core.OAuth2AccessToken
import org.springframework.security.oauth2.core.OAuth2AccessToken.TokenType.BEARER
import org.springframework.security.oauth2.core.OAuth2AuthorizationException
import org.springframework.security.oauth2.core.OAuth2Error
import java.io.IOException
import java.net.URI
import java.time.Instant

private const val TOKEN_VALUE = "test.entra-access-token"
private const val STALE_TOKEN = "stale-token-from-a-previous-request"
private const val CMS_URL = "https://carrierbooking-api-internal-gcm.example.com/v2/100001"
private const val TOKEN_URI = "https://login.microsoftonline.com/tenant-id/oauth2/v2.0/token"
private const val CMS_REGISTRATION_ID = CmsApiAuthorizationInterceptor.CMS_REGISTRATION_ID

@ExtendWith(MockitoExtension::class)
class CmsApiAuthorizationInterceptorTest {

    @Mock
    private lateinit var authorizedClientManager: OAuth2AuthorizedClientManager

    @Mock
    private lateinit var execution: ClientHttpRequestExecution

    private lateinit var interceptor: CmsApiAuthorizationInterceptor
    private lateinit var request: MockClientHttpRequest
    private val body = """{"sapOrderID":"100001"}""".toByteArray()

    @BeforeEach
    fun setUp() {
        interceptor = CmsApiAuthorizationInterceptor(authorizedClientManager)
        request = MockClientHttpRequest(POST, URI.create(CMS_URL))
    }

    // ---------- happy path ----------

    @Test
    fun `should add the Entra access token as a bearer header`() {
        stubAuthorizedClient(TOKEN_VALUE)
        whenever(execution.execute(request, body)).thenReturn(MockClientHttpResponse(ByteArray(0), OK))

        interceptor.intercept(request, body, execution)

        assertThat(request.headers.getFirst(AUTHORIZATION)).isEqualTo("Bearer $TOKEN_VALUE")
    }

    @Test
    fun `should set the vnd api content type and accept headers the CMS API expects`() {
        stubAuthorizedClient(TOKEN_VALUE)
        whenever(execution.execute(request, body)).thenReturn(MockClientHttpResponse(ByteArray(0), OK))

        interceptor.intercept(request, body, execution)

        assertThat(request.headers.getFirst(CONTENT_TYPE)).isEqualTo(CONTENT_TYPE_APPLICATION_VND_API_JSON)
        assertThat(request.headers.getFirst(ACCEPT)).isEqualTo(CONTENT_TYPE_APPLICATION_VND_API_JSON)
    }

    @Test
    fun `should return the response produced by the rest of the chain`() {
        stubAuthorizedClient(TOKEN_VALUE)
        val expected = MockClientHttpResponse(ByteArray(0), OK)
        whenever(execution.execute(request, body)).thenReturn(expected)

        assertThat(interceptor.intercept(request, body, execution)).isSameAs(expected)
    }

    @Test
    fun `should replace a stale Authorization header rather than append to it`() {
        stubAuthorizedClient(TOKEN_VALUE)
        request.headers.set(AUTHORIZATION, "Bearer $STALE_TOKEN")
        whenever(execution.execute(request, body)).thenReturn(MockClientHttpResponse(ByteArray(0), OK))

        interceptor.intercept(request, body, execution)

        assertThat(request.headers[AUTHORIZATION]).containsExactly("Bearer $TOKEN_VALUE")
    }

    // ---------- token acquisition failures ----------
    //
    // These must be CmsApiException specifically. It is the only type
    // PostRefundHandler.callBookCarrier catches, and anything else escapes
    // PostRefundHandler.handle before it saves the return lines.

    @Test
    fun `should throw CmsApiException when no authorized client is returned`() {
        whenever(authorizedClientManager.authorize(any())).thenReturn(null)

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(CmsApiException::class.java)
            .hasMessage("No access token available for client registration cms")
    }

    @Test
    fun `should not send the request when no access token could be obtained`() {
        whenever(authorizedClientManager.authorize(any())).thenReturn(null)

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(CmsApiException::class.java)

        verify(execution, never()).execute(any(), any())
        assertThat(request.headers.getFirst(AUTHORIZATION)).isNull()
    }

    @Test
    fun `should wrap a rejected client secret as CmsApiException`() {
        whenever(authorizedClientManager.authorize(any())).thenThrow(
            ClientAuthorizationException(
                OAuth2Error("invalid_client", "AADSTS7000215: Invalid client secret provided.", null),
                CMS_REGISTRATION_ID
            )
        )

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(CmsApiException::class.java)
            .hasMessage("Failed to obtain access token for cms: invalid_client")
        verify(execution, never()).execute(any(), any())
    }

    @Test
    fun `should wrap an unreachable token endpoint as CmsApiException`() {
        whenever(authorizedClientManager.authorize(any())).thenThrow(
            OAuth2AuthorizationException(
                OAuth2Error("invalid_token_response", "I/O error on POST to $TOKEN_URI", null)
            )
        )

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(CmsApiException::class.java)
            .hasMessage("Failed to obtain access token for cms: invalid_token_response")
    }

    // ---------- behaviour around the rest of the chain ----------

    @Test
    fun `should propagate an IOException from the downstream call unchanged`() {
        stubAuthorizedClient(TOKEN_VALUE)
        whenever(execution.execute(request, body)).thenThrow(IOException("connection reset"))

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(IOException::class.java)
            .hasMessage("connection reset")
    }

    @Test
    fun `should not surface unexpected exceptions as anything other than CmsApiException`() {
        whenever(authorizedClientManager.authorize(any())).thenThrow(
            RuntimeException("unexpected failure")
        )

        assertThatThrownBy { interceptor.intercept(request, body, execution) }
            .isInstanceOf(CmsApiException::class.java)
            .hasMessage("Unexpected error obtaining access token for cms: unexpected failure")
        verify(execution, never()).execute(any(), any())
    }

    private fun stubAuthorizedClient(tokenValue: String) {
        val issuedAt = Instant.parse("2026-08-07T10:00:00Z")
        val accessToken = OAuth2AccessToken(BEARER, tokenValue, issuedAt, issuedAt.plusSeconds(3599))
        val registration = ClientRegistration
            .withRegistrationId(CMS_REGISTRATION_ID)
            .clientId("client-id")
            .clientSecret("client-secret")
            .clientAuthenticationMethod(CLIENT_SECRET_POST)
            .authorizationGrantType(CLIENT_CREDENTIALS)
            .scope("api://cms/.default")
            .tokenUri(TOKEN_URI)
            .build()
        whenever(authorizedClientManager.authorize(any())).thenReturn(
            OAuth2AuthorizedClient(registration, CMS_REGISTRATION_ID, accessToken)
        )
    }
}
