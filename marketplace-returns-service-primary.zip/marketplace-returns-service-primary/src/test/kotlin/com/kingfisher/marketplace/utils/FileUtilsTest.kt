package com.kingfisher.marketplace.utils

import org.assertj.core.api.AssertionsForClassTypes.assertThat
import org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy
import org.junit.jupiter.api.Test
import java.io.FileNotFoundException

private const val VALID_FILE_PATH = "FileContentCheck.txt"
private const val INVALID_FILE_PATH = "InvalidFile.txt"
private const val FILE_CONTENT = "Has File Content"

class FileUtilsTest {
    @Test
    fun shouldFetchValidFileContent() {
        val result = FileUtils.fetchFileContent(VALID_FILE_PATH)
        assertThat(result).isEqualTo(FILE_CONTENT)
    }

    @Test
    fun shouldNotFetchInvalidFileContent() {
        val filePath = INVALID_FILE_PATH

        assertThatThrownBy { FileUtils.fetchFileContent(filePath) }.isInstanceOf(FileNotFoundException::class.java)
    }
}
