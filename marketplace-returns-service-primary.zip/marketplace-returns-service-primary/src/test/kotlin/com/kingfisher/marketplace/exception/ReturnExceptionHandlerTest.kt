package com.kingfisher.marketplace.exception

import com.kingfisher.marketplace.exception.ReturnExceptionHandler.Companion.NEXT_CURSOR
import java.net.SocketTimeoutException
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.http.HttpStatus
import org.springframework.http.HttpStatus.GATEWAY_TIMEOUT
import org.springframework.http.HttpStatus.NOT_FOUND
import org.springframework.http.ResponseEntity

private const val TEST_VALUE = "testValue"

@ExtendWith(MockitoExtension::class)
class ReturnExceptionHandlerTest {
    private var returnExceptionHandler = ReturnExceptionHandler()

    @Test
    fun `should handle OrderNotFoundInMiraklException and get ResponseEntity with status not found`() {
        val response =
            returnExceptionHandler.handleOrderNotFoundInMiraklException(OrderNotFoundInMiraklException(TEST_VALUE))

        assertThat(response).isInstanceOf(ResponseEntity::class.java)
        assertThat(response.statusCode).isEqualTo(NOT_FOUND)
    }

    @Test
    fun `should handle ConnectionTimeoutException and get ResponseEntity with status not found`() {
        val response =
            returnExceptionHandler.handleConnectionTimeoutException(SocketTimeoutException())

        assertThat(response).isInstanceOf(ResponseEntity::class.java)
        assertThat(response.statusCode).isEqualTo(GATEWAY_TIMEOUT)
    }

    @Test
    fun `should handle InvalidNextCursorException and return bad request`() {
        val response =
            returnExceptionHandler.handleInvalidNextCursorException()

        assertThat(response).isInstanceOf(ResponseEntity::class.java)
        assertThat(response.statusCode).isEqualTo(HttpStatus.BAD_REQUEST)

        assertThat(response.body).isNotNull
        assertThat(response.body!!.status).isEqualTo(HttpStatus.BAD_REQUEST.value())
        assertThat(response.body!!.errors).hasSize(1)

        val error = response.body!!.errors!![0]

        assertThat(error.field).isEqualTo(NEXT_CURSOR)
        assertThat(error.rejectedValue).isNull()
        assertThat(error.errorMessage).isEqualTo("Invalid nextCursor")
    }
}
