package com.kingfisher.marketplace.service

import ReturnLineResponse
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.ROUTE.*
import com.kingfisher.marketplace.constant.Status.*
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.IllegalUpdateException
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_DPD_CONFIRMED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_DPD
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CANCELLED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_REMOVED
import com.kingfisher.marketplace.model.manualUpdate.UpdateReturnLineRequest
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.anyList
import org.mockito.Mockito.lenient
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.argumentCaptor
import org.mockito.kotlin.never
import org.mockito.kotlin.verify
import org.mockito.kotlin.verifyNoInteractions
import java.lang.System.currentTimeMillis

private const val TEST_RETURN_ORDER_NUMBER = 4444L

private const val TEST_LINE_NUMBER_1 = 1L

private const val REJECTED_VALUE = "rejectedValue"

private const val EXCEPTION_CAUSE = "exceptionCause"

@ExtendWith(MockitoExtension::class)
class ManualUpdateLineDetailsServiceTest {

    @Mock
    private lateinit var returnLineRepositoryMock: ReturnLineRepository

    @Mock
    private lateinit var apiModelTransformerMock: ApiModelTransfomer

    @Mock
    private lateinit var configPropertiesMock: ConfigProperties

    @Mock
    private lateinit var customMetricsMock: CustomMetrics

    private lateinit var manualUpdateLineDetailsService: ManualUpdateLineDetailsService
    private var returnLineResponse = ReturnLineResponse()
    private var returnLinesCaptor = argumentCaptor<List<ReturnLine>>()

    @BeforeEach
    fun setUp() {
        this.manualUpdateLineDetailsService =
            ManualUpdateLineDetailsService(
                this.returnLineRepositoryMock,
                this.apiModelTransformerMock,
                this.configPropertiesMock,
                this.customMetricsMock
            )
        lenient().`when`(this.configPropertiesMock.allowedRouteToStatusForUpdate).thenReturn(
            mapOf(
                TBC.value to listOf(CANCELLED.name),
                DPD.value to listOf(COLLECTION_BOOKED.name, LABEL_PRINTING_REQUESTED.name)
            )
        )
    }

    @Test
    fun `should update route TBC line with given details`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = AWAITING_STORE_CONFIRMATION.name
            )
        )
        `when`(this.apiModelTransformerMock.transformToReturnLineResponse(anyList())).thenReturn(this.returnLineResponse)
        val updateLineRequest = UpdateReturnLineRequest(
            TEST_RETURN_ORDER_NUMBER,
            TEST_LINE_NUMBER_1, COLLECTION_BOOKED, DPD
        )

        val result = this.manualUpdateLineDetailsService.updateLineDetails(updateLineRequest)

        assertThat(result).isEqualTo(this.returnLineResponse)
        verify(this.apiModelTransformerMock).transformToReturnLineResponse(this.returnLinesCaptor.capture())
        val updatedReturnLine = this.returnLinesCaptor.firstValue[0]
        assertThat(updatedReturnLine.lineNumber).isEqualTo(TEST_LINE_NUMBER_1)
        assertThat(updatedReturnLine.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(updatedReturnLine.status).isEqualTo(COLLECTION_BOOKED.name)
        assertThat(updatedReturnLine.route).isEqualTo(DPD.value)
        assertThat(updatedReturnLine.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(updatedReturnLine.isUpdatedManually).isTrue
        verify(this.customMetricsMock).incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
        verify(this.customMetricsMock).incrementCounter(RETURN_ROUTE_DPD)
    }

    @Test
    fun `should throw order not found exception if order is not present in DB`() {
        assertThatThrownBy {
            this.manualUpdateLineDetailsService.updateLineDetails(
                UpdateReturnLineRequest(
                    TEST_RETURN_ORDER_NUMBER,
                    TEST_LINE_NUMBER_1, COLLECTION_BOOKED, DPD
                )
            )
        }.isInstanceOf(OrderNotFoundException::class.java).extracting(REJECTED_VALUE).isEqualTo("4444-1")
        verifyNoInteractions(this.apiModelTransformerMock)
        verify(this.returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should throw illegal update exception if return line status is not TBC`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = DPD.value,
                status = COLLECTION_BOOKED.name
            )
        )

        assertThatThrownBy {
            this.manualUpdateLineDetailsService.updateLineDetails(
                UpdateReturnLineRequest(
                    TEST_RETURN_ORDER_NUMBER,
                    TEST_LINE_NUMBER_1, LABEL_PRINTING_REQUESTED, DPD
                )
            )
        }.isInstanceOf(IllegalUpdateException::class.java).extracting(REJECTED_VALUE, EXCEPTION_CAUSE)
            .containsExactly(
                DPD.value,
                "Not possible to update order $TEST_RETURN_ORDER_NUMBER line $TEST_LINE_NUMBER_1 as route is already ${DPD.value}"
            )

        verifyNoInteractions(this.apiModelTransformerMock)
        verify(this.returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should throw illegal update exception if return line status is already cancelled`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = CANCELLED.name
            )
        )

        assertThatThrownBy {
            this.manualUpdateLineDetailsService.updateLineDetails(
                UpdateReturnLineRequest(
                    TEST_RETURN_ORDER_NUMBER,
                    TEST_LINE_NUMBER_1, AWAITING_LABEL_PRINTING, IFORCE
                )
            )
        }.isInstanceOf(IllegalUpdateException::class.java).extracting(EXCEPTION_CAUSE, REJECTED_VALUE)
            .containsExactly(
                "Not possible to update order $TEST_RETURN_ORDER_NUMBER line $TEST_LINE_NUMBER_1 as status is already ${CANCELLED.name}",
                AWAITING_LABEL_PRINTING.name
            )
        verifyNoInteractions(this.apiModelTransformerMock)
        verify(this.returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should throw illegal update exception if trying to update status not available for given route`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = AWAITING_STORE_CONFIRMATION.name
            )
        )

        assertThatThrownBy {
            this.manualUpdateLineDetailsService.updateLineDetails(
                UpdateReturnLineRequest(
                    TEST_RETURN_ORDER_NUMBER,
                    TEST_LINE_NUMBER_1, CANCELLED, DPD
                )
            )
        }.isInstanceOf(IllegalUpdateException::class.java).extracting(EXCEPTION_CAUSE, REJECTED_VALUE)
            .containsExactly(
                "Not possible to update order $TEST_RETURN_ORDER_NUMBER line $TEST_LINE_NUMBER_1 as ${CANCELLED.name} is not a valid status with route ${DPD.value}",
                CANCELLED.name
            )
        verifyNoInteractions(this.apiModelTransformerMock)
        verify(this.returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should throw illegal update exception if trying to update route which is not allowed`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = AWAITING_STORE_CONFIRMATION.name
            )
        )

        assertThatThrownBy {
            this.manualUpdateLineDetailsService.updateLineDetails(
                UpdateReturnLineRequest(
                    TEST_RETURN_ORDER_NUMBER,
                    TEST_LINE_NUMBER_1, CANCELLED, IFORCE
                )
            )
        }.isInstanceOf(IllegalUpdateException::class.java).extracting(EXCEPTION_CAUSE, REJECTED_VALUE)
            .containsExactly(
                "Not possible to update order $TEST_RETURN_ORDER_NUMBER line $TEST_LINE_NUMBER_1 as ${IFORCE.value} is not available to be updated",
                IFORCE.value
            )
        verifyNoInteractions(this.apiModelTransformerMock)
        verify(this.returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should update metric for updating TBC line with DPD route LABEL_PRINTING_REQUESTED status`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = AWAITING_STORE_CONFIRMATION.name
            )
        )
        `when`(this.apiModelTransformerMock.transformToReturnLineResponse(anyList())).thenReturn(this.returnLineResponse)
        val updateLineRequest = UpdateReturnLineRequest(
            TEST_RETURN_ORDER_NUMBER,
            TEST_LINE_NUMBER_1, LABEL_PRINTING_REQUESTED, DPD
        )

        val result = this.manualUpdateLineDetailsService.updateLineDetails(updateLineRequest)

        assertThat(result).isEqualTo(this.returnLineResponse)
        verify(this.apiModelTransformerMock).transformToReturnLineResponse(this.returnLinesCaptor.capture())
        val updatedReturnLine = this.returnLinesCaptor.firstValue[0]
        assertThat(updatedReturnLine.lineNumber).isEqualTo(TEST_LINE_NUMBER_1)
        assertThat(updatedReturnLine.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(updatedReturnLine.status).isEqualTo(LABEL_PRINTING_REQUESTED.name)
        assertThat(updatedReturnLine.route).isEqualTo(DPD.value)
        assertThat(updatedReturnLine.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(updatedReturnLine.isUpdatedManually).isTrue
        verify(this.customMetricsMock).incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
        verify(this.customMetricsMock).incrementCounter(RETURN_ROUTE_DPD)
        verify(this.customMetricsMock).incrementCounter(RETURN_DPD_CONFIRMED)
    }

    @Test
    fun `should update metric for updating TBC line with status CANCELLED`() {
        `when`(this.returnLineRepositoryMock.fetchReturnItem(TEST_RETURN_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_1,
                returnOrderNumber = TEST_RETURN_ORDER_NUMBER,
                route = TBC.value,
                status = AWAITING_STORE_CONFIRMATION.name
            )
        )
        `when`(this.apiModelTransformerMock.transformToReturnLineResponse(anyList())).thenReturn(this.returnLineResponse)
        val updateLineRequest = UpdateReturnLineRequest(
            TEST_RETURN_ORDER_NUMBER,
            TEST_LINE_NUMBER_1, CANCELLED, TBC
        )

        val result = this.manualUpdateLineDetailsService.updateLineDetails(updateLineRequest)

        assertThat(result).isEqualTo(this.returnLineResponse)
        verify(this.apiModelTransformerMock).transformToReturnLineResponse(this.returnLinesCaptor.capture())
        val updatedReturnLine = this.returnLinesCaptor.firstValue[0]
        assertThat(updatedReturnLine.lineNumber).isEqualTo(TEST_LINE_NUMBER_1)
        assertThat(updatedReturnLine.returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_NUMBER)
        assertThat(updatedReturnLine.status).isEqualTo(CANCELLED.name)
        assertThat(updatedReturnLine.route).isEqualTo(TBC.value)
        assertThat(updatedReturnLine.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        assertThat(updatedReturnLine.isUpdatedManually).isTrue
        verify(this.customMetricsMock, never()).incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
        verify(this.customMetricsMock, never()).incrementCounter(RETURN_ROUTE_DPD)
        verify(this.customMetricsMock).incrementCounter(RETURN_ROUTE_TBC_CANCELLED)
    }
}
