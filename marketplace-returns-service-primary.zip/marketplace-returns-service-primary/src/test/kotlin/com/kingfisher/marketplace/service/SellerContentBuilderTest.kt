package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.ROUTE
import org.assertj.core.api.AssertionsForInterfaceTypes.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.reset
import org.mockito.kotlin.whenever

private const val TENANT_BQ = "BQUK"
private const val TENANT_PL = "CAPL"
private const val PRODUCT_NAME = "Super name"
private const val EAN = "12345678"
private const val QUANTITY: Long = 1
private const val REASON = "REFUND"
private const val REASON_CODE = "04"
private const val IFORCE_MESSAGE = "Damaged"
private const val TRACKING_LINK = "https://TRACKMEIFYOUCAN"
private const val ORDER_NUMBER = "12345678"

@ExtendWith(MockitoExtension::class)
class SellerContentBuilderTest {

    @Mock
    private lateinit var configProperties: ConfigProperties

    private val templatesBq: Map<String, String> =
        mapOf(
            "TBC" to "TestTbcNotificationTemplate.txt",
            "iForce" to "TestIForceNotificationTemplate.txt",
        )

    private val templatesPl: Map<String, String> =
        mapOf(
            "TBC" to "TestCaplRouteNotificationTemplate.txt",
        )

    private val reasonsIforce: Map<String, String> = mapOf("Damaged" to "It is too damaged to safely ship.")

    private val refundReasonsBq: Map<String, String> = mapOf("REFUND_4" to "Damaged")
    private val refundReasonsPl: Map<String, String> = mapOf("REFUND_4" to "Produkt uszkodzony")

    @InjectMocks
    private lateinit var sellerContentBuilder: SellerContentBuilder

    @BeforeEach
    fun setUp() {
        whenever(configProperties.routeToSellerNotificationTemplate).thenReturn(
            mapOf(TENANT_BQ to templatesBq, TENANT_PL to templatesPl)
        )
        whenever(configProperties.iForceReasonMessageBasedOnReasonForIForce).thenReturn(reasonsIforce)
        whenever(configProperties.reasonCodeMap).thenReturn(
            mapOf(TENANT_BQ to refundReasonsBq, TENANT_PL to refundReasonsPl)
        )
    }

    @Test
    fun `should generate lost in transit notification TBC`() {
        val result = sellerContentBuilder.buildSellerNotificationContent(
            ROUTE.TBC.value,
            "WHATEVER",
            PRODUCT_NAME,
            EAN,
            QUANTITY,
            REASON_CODE,
            REASON,
            TENANT_BQ,
            trackingLink = TRACKING_LINK
        )
        assertThat(result).isEqualTo("TBC Product name-${PRODUCT_NAME}, ean - $EAN, quantity - $QUANTITY, reason - Damaged, trackingLink - ${TRACKING_LINK}")
    }

    @Test
    fun `should generate lost in transit notification for iForce`() {
        val result = sellerContentBuilder.buildSellerNotificationContent(
            ROUTE.IFORCE.value,
            "WHATEVER",
            PRODUCT_NAME,
            EAN,
            QUANTITY,
            REASON_CODE,
            REASON,
            TENANT_BQ,
            reasonForIForce = IFORCE_MESSAGE,
            )
        assertThat(result).isEqualTo("Product name-${PRODUCT_NAME}, ean - $EAN, quantity - $QUANTITY, reason - Damaged, iForceReasonMessage - It is too damaged to safely ship.")
    }

    @Test
    fun `should generate notification for capl`() {
        val result = sellerContentBuilder.buildSellerNotificationContent(
            ROUTE.TBC.value,
            "WHATEVER",
            PRODUCT_NAME,
            EAN,
            QUANTITY,
            REASON_CODE,
            REASON,
            TENANT_PL,
            orderNumber = ORDER_NUMBER,
            trackingLink = TRACKING_LINK
        )
        assertThat(result).isEqualTo("CAPL Nazwa produktu: $PRODUCT_NAME, ean: $EAN, ilosc: $QUANTITY, powod: Produkt uszkodzony, trackingLink: $TRACKING_LINK, numer zamowienia: $ORDER_NUMBER")
    }

    @Test
    fun `should throw exception on missing entry`() {
        reset(configProperties)
        whenever(configProperties.routeToSellerNotificationTemplate).thenReturn(mapOf(TENANT_BQ to templatesBq))
        assertThrows<NoSuchElementException> {
            sellerContentBuilder.buildSellerNotificationContent(
                ROUTE.DPD.value,
                "WHATEVER",
                PRODUCT_NAME,
                EAN,
                QUANTITY,
                REASON_CODE,
                REASON,
                TENANT_BQ,
            )
        }
    }
}
