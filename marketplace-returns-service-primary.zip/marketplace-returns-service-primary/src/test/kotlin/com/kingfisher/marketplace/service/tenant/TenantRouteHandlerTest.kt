package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.domain.TenantRouteContext
import com.kingfisher.orderManagement.avro.Tenant
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.verify
import org.mockito.kotlin.verifyNoMoreInteractions
import org.mockito.kotlin.whenever

@ExtendWith(MockitoExtension::class)
class TenantRouteHandlerTest {

    @Mock
    private lateinit var bqRouteProvider: BQRouteProvider

    @Mock
    private lateinit var caplRouteProvider: CAPLRouteProvider

    @Mock
    private lateinit var salesOrderInfo: SalesOrderInfo

    @Mock
    private lateinit var context: TenantRouteContext

    private lateinit var tenantRouteHandler: TenantRouteHandler

    @BeforeEach
    fun init() {
        tenantRouteHandler = TenantRouteHandler(mapOf(Tenant.BQUK.name to bqRouteProvider, Tenant.CAPL.name to caplRouteProvider))
    }

    @Test
    fun `should throw exception for unsupported tenant`() {
        val tenant = "CAFR"

        val ex = assertThrows<IllegalArgumentException> { tenantRouteHandler.retrieveContext(tenant, salesOrderInfo) }
        assertThat(ex.message).isEqualTo("No TenantContextProvider found for tenant: $tenant")

        verifyNoMoreInteractions(bqRouteProvider, caplRouteProvider)
    }

    @Test
    fun `should execute only one provider`() {
        val tenant = "CAPL"
        whenever(caplRouteProvider.provide(salesOrderInfo)).thenReturn(context)

        val result = tenantRouteHandler.retrieveContext(tenant, salesOrderInfo)
        assertThat(result).isEqualTo(context)
        verify(caplRouteProvider).provide(salesOrderInfo)
        verifyNoMoreInteractions(bqRouteProvider, caplRouteProvider)
    }
}
