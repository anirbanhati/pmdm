package com.kingfisher.marketplace.utils

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.assertj.core.api.Assertions.assertThatThrownBy
import software.amazon.awssdk.services.dynamodb.model.AttributeValue
import com.kingfisher.marketplace.exception.InvalidNextCursorException
import java.util.Base64

class CursorUtilsTest {

    @Test
    fun `should encode and decode cursor successfully`() {
        val lastEvaluatedKey = mapOf(
            "return_order_number" to AttributeValue.fromN("4001"),
            "line_number" to AttributeValue.fromN("2")
        )

        val encoded = CursorUtils.encode(lastEvaluatedKey)

        assertThat(encoded).isNotNull()

        val decoded = CursorUtils.decode(encoded)

        assertThat(decoded).isEqualTo(lastEvaluatedKey)
    }

    @Test
    fun `should return null when encoding null map`() {
        val encoded = CursorUtils.encode(null)

        assertThat(encoded).isNull()
    }

    @Test
    fun `should return null when encoding empty map`() {
        val encoded = CursorUtils.encode(emptyMap())

        assertThat(encoded).isNull()
    }

    @Test
    fun `should return null when decoding null cursor`() {
        val decoded = CursorUtils.decode(null)

        assertThat(decoded).isNull()
    }

    @Test
    fun `should return null when decoding blank cursor`() {
        val decoded = CursorUtils.decode("")

        assertThat(decoded).isNull()
    }

    @Test
    fun `should return null when decoding blank spaces`() {
        val decoded = CursorUtils.decode("   ")

        assertThat(decoded).isNull()
    }

    @Test
    fun `should decode encoded cursor correctly`() {
        val original = mapOf(
            "return_order_number" to AttributeValue.fromN("12345"),
            "line_number" to AttributeValue.fromN("10")
        )

        val encoded = CursorUtils.encode(original)

        val decoded = CursorUtils.decode(encoded)

        assertThat(decoded)
            .containsEntry("return_order_number", AttributeValue.fromN("12345"))
            .containsEntry("line_number", AttributeValue.fromN("10"))
    }

    @Test
    fun `should throw InvalidNextCursorException for invalid base64 cursor`() {
        assertThatThrownBy {
            CursorUtils.decode("invalid-cursor")
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException for invalid json`() {
        val cursor = Base64.getEncoder()
            .encodeToString("invalid-json".toByteArray())

        assertThatThrownBy {
            CursorUtils.decode(cursor)
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException when required key is missing`() {
        val cursor = Base64.getEncoder()
            .encodeToString(
                """{"return_order_number":"4001"}""".toByteArray()
            )

        assertThatThrownBy {
            CursorUtils.decode(cursor)
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException when unexpected key is present`() {
        val cursor = Base64.getEncoder()
            .encodeToString(
                """{"return_order_number":"4001","line_number":"1","invalid":"value"}""".toByteArray()
            )

        assertThatThrownBy {
            CursorUtils.decode(cursor)
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException when cursor value is not numeric`() {
        val cursor = Base64.getEncoder()
            .encodeToString(
                """{"return_order_number":"abc","line_number":"1"}""".toByteArray()
            )

        assertThatThrownBy {
            CursorUtils.decode(cursor)
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException when cursor is invalid base64`() {
        assertThatThrownBy {
            CursorUtils.decode("invalid-cursor!")
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }

    @Test
    fun `should throw InvalidNextCursorException when decoded cursor is invalid json`() {
        val invalidJsonCursor = Base64.getEncoder()
            .encodeToString("this-is-not-json".toByteArray())

        assertThatThrownBy {
            CursorUtils.decode(invalidJsonCursor)
        }.isInstanceOf(InvalidNextCursorException::class.java)
    }
}
