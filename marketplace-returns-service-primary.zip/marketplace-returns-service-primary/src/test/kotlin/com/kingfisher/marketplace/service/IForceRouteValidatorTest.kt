package com.kingfisher.marketplace.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.PRODUCT_AMOUNT_THREASHOLD_FOR_COLLECTION_NOT_REACHED
import com.kingfisher.marketplace.constant.Constant.Companion.REASON_FOR_IFORCE
import com.kingfisher.marketplace.model.product.ProductAPIResponse
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.lenient
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.core.io.ClassPathResource
import java.math.BigDecimal
import java.nio.file.Files
import java.util.*

private const val PRODUCT_API_RESPONSE_FILE_FOR_NON_IFORCE = "1234567890130.json"
private const val PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT = "4974019974408.json"
private const val PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT_IN_GRAM = "4974019974409.json"
private const val PRODUCT_API_RESPONSE_FILE_FOR_BATTERY_CHEMISTRY = "3333333389333.json"
private const val LEAST_AMOUNT_FOR_COLLECTION = "10"
private const val TECH_ATTRIBUTE_PRODUCT_WEIGHT = "Product_weight"
private const val TECH_ATTRIBUTE_PRODUCT_DEPTH = "Product_depth"
private const val DUMMY_STRING = "Dummy_string"
private const val TECH_ATTRIBUTE_BATTERY_CHEMISTRY = "Battery_chemistry"
private const val UNIT_OF_MEASURE_KG = "kg"
private const val UNIT_OF_MEASURE_GRAM = "g"
private const val PRODUCT_WEIGHT_ATTRIBUTE_VALUE = 29.0
private const val PRODUCT_WEIGHT_ATTRIBUTE_LESS_VALUE = 9.0
private const val PRODUCT_WEIGHT_ATTRIBUTE_VALUE_IN_GRAM = 29000.0
private const val BATTERY_CHEMISTRY_ATTRIBUTE_VALUE = "Li-ion"
private val TOTAL_PRICE = BigDecimal("9")
private val TEST_PRICE_GREATER_THAN_TOTAL_PRICE = BigDecimal("11")
private const val TENANT = "TENANT"
private const val PRODUCT_WEIGHT = "Product_weight"
private const val BATTERY_CHEMISTRY_PRODUCT = "Battery_chemistry"
private const val TEST_STORE_ID = "1211"
private const val WINDSOR_FRAMEWORK = "Windsor Framework"

@ExtendWith(MockitoExtension::class)
class IForceRouteValidatorTest {
    @Mock
    private lateinit var configPropertiesMock: ConfigProperties

    private lateinit var iForceRouteValidator: IForceRouteValidator

    @BeforeEach
    fun setUp() {
        iForceRouteValidator = IForceRouteValidator(configPropertiesMock)
        lenient().`when`(configPropertiesMock.defaultToIForceStoreIds).thenReturn(
            emptyMap()
        )
        lenient().`when`(configPropertiesMock.leastAmountForCollection).thenReturn(LEAST_AMOUNT_FOR_COLLECTION)
    }

    @Test
    fun shouldBeIForceWhenTotalPriceIsLess() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val result =
            iForceRouteValidator.validate(TOTAL_PRICE, productAPIResponseMock.data[0].attributes, TEST_STORE_ID)

        assertThat(result.get(REASON_FOR_IFORCE)).isEqualTo(PRODUCT_AMOUNT_THREASHOLD_FOR_COLLECTION_NOT_REACHED)
    }

    @Test
    fun shouldBeIForceWhenProductWeightIsMore() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        `when`(
            configPropertiesMock.maxTechAttributeValueForCollection,
        ).thenReturn(
            mapOf(
                TECH_ATTRIBUTE_PRODUCT_WEIGHT to mapOf(UNIT_OF_MEASURE_KG to PRODUCT_WEIGHT_ATTRIBUTE_VALUE)
            )
        )

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )

        assertThat(result.get(REASON_FOR_IFORCE)).isEqualTo(PRODUCT_WEIGHT)
    }

    @Test
    fun shouldBeIForceWhenProductWeightIsNotPresent() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT_IN_GRAM)
        `when`(
            configPropertiesMock.maxTechAttributeValueForCollection,
        ).thenReturn(
            mapOf(
                TECH_ATTRIBUTE_PRODUCT_DEPTH to mapOf(UNIT_OF_MEASURE_GRAM to PRODUCT_WEIGHT_ATTRIBUTE_VALUE_IN_GRAM)
            )
        )
        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )
        assertEquals(Collections.EMPTY_MAP, result)
    }

    @Test
    fun shouldBeIForceWhenProductWeightIsLessButBatteryChemMatches() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_BATTERY_CHEMISTRY)
        `when`(
            configPropertiesMock.techAttributesForIForce,
        ).thenReturn(mapOf(TECH_ATTRIBUTE_BATTERY_CHEMISTRY to BATTERY_CHEMISTRY_ATTRIBUTE_VALUE))

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )
        assertThat(result.get(REASON_FOR_IFORCE)).isEqualTo(BATTERY_CHEMISTRY_PRODUCT)
    }

    @Test
    fun shouldNotBeIForceWhenTechAttributeDoesNotMatch() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(
                PRODUCT_API_RESPONSE_FILE_FOR_NON_IFORCE
            )
        `when`(
            configPropertiesMock.maxTechAttributeValueForCollection,
        ).thenReturn(
            mapOf(
                TECH_ATTRIBUTE_PRODUCT_WEIGHT to mapOf(UNIT_OF_MEASURE_KG to PRODUCT_WEIGHT_ATTRIBUTE_VALUE)
            )
        )
        `when`(
            configPropertiesMock.techAttributesForIForce,
        ).thenReturn(
            mapOf(
                TECH_ATTRIBUTE_BATTERY_CHEMISTRY to BATTERY_CHEMISTRY_ATTRIBUTE_VALUE
            )
        )

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )

        assertEquals(Collections.EMPTY_MAP, result)
    }

    @Test
    fun shouldBeIForceIfMaxTechAttributeValueForCollectionDoesNotMatch() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        `when`(
            configPropertiesMock.maxTechAttributeValueForCollection,
        ).thenReturn(mapOf(DUMMY_STRING to mapOf(UNIT_OF_MEASURE_KG to PRODUCT_WEIGHT_ATTRIBUTE_VALUE)))

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )

        assertEquals(Collections.EMPTY_MAP, result)
    }

    @Test
    fun shouldNotBeIForceForNonConfiguredUOM() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        `when`(
            configPropertiesMock.maxTechAttributeValueForCollection,
        ).thenReturn(
            mapOf(
                TECH_ATTRIBUTE_PRODUCT_WEIGHT to mapOf(DUMMY_STRING to PRODUCT_WEIGHT_ATTRIBUTE_VALUE)
            )
        )

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )

        assertEquals(Collections.EMPTY_MAP, result)
    }

    @Test
    fun shouldDefaultToIForceForNorthernIrelandStoreReturn() {
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_NON_IFORCE)
        `when`(configPropertiesMock.defaultToIForceStoreIds).thenReturn(
            mapOf(
                "1211" to WINDSOR_FRAMEWORK,
                "1355" to WINDSOR_FRAMEWORK,
                "1353" to WINDSOR_FRAMEWORK,
                "1209" to WINDSOR_FRAMEWORK,
                "1318" to WINDSOR_FRAMEWORK,
            )
        )

        val result =
            iForceRouteValidator.validate(
                TEST_PRICE_GREATER_THAN_TOTAL_PRICE,
                productAPIResponseMock.data[0].attributes,
                TEST_STORE_ID,
            )

        assertThat(result.get(REASON_FOR_IFORCE)).isEqualTo(WINDSOR_FRAMEWORK)
    }
}

private fun fetchProductAPIResponse(jsonPath: String): ProductAPIResponse {
    return ObjectMapper().readValue(
        Files.readAllBytes(ClassPathResource(jsonPath).file.toPath()),
        ProductAPIResponse::class.java,
    )
}
