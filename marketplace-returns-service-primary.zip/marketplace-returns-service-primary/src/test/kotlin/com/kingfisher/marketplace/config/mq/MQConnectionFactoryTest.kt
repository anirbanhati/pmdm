package com.kingfisher.marketplace.config.mq

import com.ibm.mq.jakarta.jms.MQXAConnectionFactory
import jakarta.jms.JMSException
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.verify
import org.springframework.jms.core.JmsTemplate

@ExtendWith(MockitoExtension::class)
class MQConnectionFactoryTest {
    @Mock
    private val mQConfigPropertiesMock: MQConfigProperties? = null

    @InjectMocks
    private lateinit var mQConnectionFactory: MQConnectionFactory

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        mQConnectionFactory = mQConfigPropertiesMock?.let { MQConnectionFactory(it) }!!
    }

    @Test
    @Throws(JMSException::class)
    fun shouldBuildJMSConnectionFactory() {
        Mockito.`when`(mQConfigPropertiesMock?.user).thenReturn(TEST_USER)
        Mockito.`when`(mQConfigPropertiesMock?.channel).thenReturn(TEST_CHANNEL)
        Mockito.`when`(mQConfigPropertiesMock?.port).thenReturn(TEST_PORT)
        Mockito.`when`(mQConfigPropertiesMock?.host).thenReturn(TEST_HOST)
        Mockito.`when`(mQConfigPropertiesMock?.queueManager).thenReturn(TEST_QUEUEMANGER)
        val jmsTemplateResult: JmsTemplate? = mQConnectionFactory.buildJmsTemplate()

        val mqxaConnectionFactory = jmsTemplateResult!!.connectionFactory as MQXAConnectionFactory

        Assertions.assertThat(mqxaConnectionFactory.channel).isEqualTo(TEST_CHANNEL)
        Assertions.assertThat(mqxaConnectionFactory.queueManager).isEqualTo(TEST_QUEUEMANGER)
        verify(this.mQConfigPropertiesMock)?.queueManager
        verify(this.mQConfigPropertiesMock)?.user
        verify(this.mQConfigPropertiesMock)?.channel
        verify(this.mQConfigPropertiesMock)?.host
        verify(this.mQConfigPropertiesMock)?.port
    }

    companion object {
        const val TEST_HOST = "testHost"
        const val TEST_PORT = "111"
        const val TEST_USER = "testUserID"
        const val TEST_CHANNEL = "testChannel"
        const val TEST_QUEUEMANGER = "testQueueManager"
    }
}
