package com.kingfisher.marketplace.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.carreirBookingAPI.CarrierBookingAPIConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.NOT_APPLICABLE
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CarrierBookingException
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingLineItem
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingRequest
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingResponse
import com.kingfisher.marketplace.model.carrierBooking.OrderMastersResponse
import com.kingfisher.marketplace.model.sellerAddress.SellerAddressResponse
import com.mirakl.client.mmp.domain.order.MiraklOrder
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.ArgumentCaptor
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.Mockito.lenient
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.eq
import org.mockito.kotlin.firstValue
import org.mockito.kotlin.never
import org.mockito.kotlin.verify
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension
import org.springframework.core.io.ClassPathResource
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod.POST
import org.springframework.http.HttpStatus
import org.springframework.http.HttpStatus.FAILED_DEPENDENCY
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException.BadRequest
import org.springframework.web.client.RestTemplate
import java.nio.file.Files
import java.time.LocalDateTime.now

private const val CARRIER_API_URL = "testURL/{testTenant}"
private const val TENANT = "testTenant"
private const val OFFER_ID = "offerId"
private const val TEST_SHOP_ID_1 = "testShopId1"
private const val TEST_SHOP_ID_2 = "testShopId2"
private const val LOGISTICAL_ORDER_ID = "1234567-AB"
private const val RETURN_ORDER_ID = 100001L
private const val CONSIGNMENT_CODE = "consignmentCode"
private val CONSIGNMENT_DATE = now().toString()
private const val SELLER_RESPONSE_BODY = "sellerResponse.json"
private const val SELLER_RESPONSE_BODY_MISSING_DETAILS = "sellerResponseWithMissingAddressDetails.json"
private const val COUNTRY_CODE = "GB"
private const val ADDRESS_LINE_1 = "addressLine1"
private const val UNIQUE_RETURN_ID = "100001-AB"
private const val RECEIPIENT_NAME = "department_name"
private const val SELLER_NAME = "seller_name"
private const val TEST_ERROR_MESSAGE = "testErrorMessage"

@ExtendWith(*arrayOf(MockitoExtension::class, OutputCaptureExtension::class))
class CarrierBookingAPIServiceTest {

    private lateinit var carrierBookingAPIService: CarrierBookingAPIService

    @Mock
    private lateinit var mockRestTemplate: RestTemplate

    @Mock
    private lateinit var miraklAPIService: MiraklAPIService

    @Mock
    private lateinit var carrierBookingAPIConfigProperties: CarrierBookingAPIConfigProperties

    @Mock
    private var dpdReturnLine = CarrierBookingLineItem("ean", "lineNumber", 1)

    @Mock
    private var returnLine = ReturnLine()

    @Mock
    private lateinit var carrierBookingResponse: CarrierBookingResponse

    @Mock
    private lateinit var sellerApiService: SellerApiService

    @Mock
    private lateinit var miraklOrder: MiraklOrder

    @BeforeEach
    fun setUp() {
        carrierBookingAPIService = CarrierBookingAPIService(
            mockRestTemplate,
            miraklAPIService,
            sellerApiService,
            carrierBookingAPIConfigProperties,
            ObjectMapper()
        )
        lenient().`when`(returnLine.returnDate).thenReturn(now().toString())
        lenient().`when`(returnLine.offerId).thenReturn(OFFER_ID)
        lenient().`when`(returnLine.logisticalOrderId).thenReturn(LOGISTICAL_ORDER_ID)
        lenient().`when`(returnLine.returnOrderNumber).thenReturn(RETURN_ORDER_ID)
        lenient().`when`(returnLine.shopId).thenReturn(TEST_SHOP_ID_1)
        lenient().`when`(this.carrierBookingAPIConfigProperties.carrierBookingURL).thenReturn(CARRIER_API_URL)
        lenient().`when`(this.miraklAPIService.getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT))
            .thenReturn(miraklOrder)
        lenient().`when`(miraklOrder.shopId).thenReturn(TEST_SHOP_ID_2)
        lenient().`when`(this.carrierBookingAPIConfigProperties.defaultCountryCodeForRecipient).thenReturn(COUNTRY_CODE)
    }

    @Test
    fun shouldInvokeCarrierBookingAPIWithSellerDetails() {
        val sellerAPIResponse =
            ObjectMapper().readValue(
                Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
                SellerAddressResponse::class.java,
            )
        val responseEntitySellerAPI = ResponseEntity(sellerAPIResponse, HttpStatus.OK)
        var orderMasters = OrderMastersResponse(CONSIGNMENT_CODE, CONSIGNMENT_DATE)
        `when`(carrierBookingResponse.orderMasters).thenReturn(arrayListOf(orderMasters))
        `when`(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
            .thenReturn(responseEntitySellerAPI)
        val responseEntityCarrierBookingAPI = ResponseEntity(carrierBookingResponse, HttpStatus.OK)
        `when`(
            this.mockRestTemplate.exchange(
                anyString(),
                eq(POST),
                any(HttpEntity::class.java),
                eq(CarrierBookingResponse::class.java),
                eq(TENANT),
            )
        )
            .thenReturn(responseEntityCarrierBookingAPI)
        var carrierBookingRequestEntityArgCaptor = ArgumentCaptor.forClass(HttpEntity::class.java)
        var dPDReturnLines = mutableListOf(dpdReturnLine)
        var returnLines = listOf(returnLine)

        var result = this.carrierBookingAPIService.invokeCarrierBookingAPI(
            returnLines,
            dPDReturnLines,
            TENANT,
        )

        verify(this.mockRestTemplate).exchange(
            eq(CARRIER_API_URL),
            eq(POST),
            carrierBookingRequestEntityArgCaptor.capture(),
            eq(CarrierBookingResponse::class.java),
            eq(TENANT),
        )
        val carrierBookingRequest = carrierBookingRequestEntityArgCaptor.firstValue.body as CarrierBookingRequest
        val countryCode = carrierBookingRequest.recipient.countryCode
        assertThat(countryCode).isEqualTo(COUNTRY_CODE)
        assertThat(carrierBookingRequest.recipient.addressLine1).isEqualTo(ADDRESS_LINE_1)
        assertThat(carrierBookingRequest.sapOrderID).isEqualTo(UNIQUE_RETURN_ID)
        assertThat(carrierBookingRequest.recipient.name).isEqualTo(RECEIPIENT_NAME)
        assertThat(carrierBookingRequest.logisticOrderID).isEqualTo(LOGISTICAL_ORDER_ID)
        assertThat(result.body?.orderMasters?.get(0)?.consignmentCode).isEqualTo(CONSIGNMENT_CODE)
        verify(this.miraklAPIService, never()).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }

    @Test
    fun `should throw CarrierBookingException when HttpStatusCodeException occurs`(output: CapturedOutput) {
        val sellerAPIResponse =
            ObjectMapper().readValue(
                Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
                SellerAddressResponse::class.java,
            )
        val responseEntitySellerAPI = ResponseEntity(sellerAPIResponse, HttpStatus.OK)
        `when`(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
            .thenReturn(responseEntitySellerAPI)
        val exp = BadRequest.create(TEST_ERROR_MESSAGE, FAILED_DEPENDENCY, "", HttpHeaders(), ByteArray(1), null)
        val dPDReturnLines = mutableListOf(dpdReturnLine)
        val returnLines = listOf(returnLine)
        `when`(
            this.mockRestTemplate.exchange(
                anyString(),
                eq(POST),
                any(HttpEntity::class.java),
                eq(CarrierBookingResponse::class.java),
                eq(TENANT),
            )
        ).thenThrow(exp)

        assertThatThrownBy {
            carrierBookingAPIService.invokeCarrierBookingAPI(
                returnLines,
                dPDReturnLines,
                TENANT
            )
        }.isInstanceOf(CarrierBookingException::class.java).extracting("statusCode", "errorMessage").containsExactly(
            FAILED_DEPENDENCY,
            TEST_ERROR_MESSAGE
        )
        assertThat(output).contains("Failed to book carrier for return order ${returnLines[0].returnOrderNumber} : $TEST_ERROR_MESSAGE")
    }

    @Test
    fun shouldAddDefaultAddressDetailsForMissingAddressValues() {
        val sellerAPIResponse =
            ObjectMapper().readValue(
                Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY_MISSING_DETAILS).file.toPath()),
                SellerAddressResponse::class.java,
            )
        val responseEntitySellerAPI = ResponseEntity(sellerAPIResponse, HttpStatus.OK)
        `when`(sellerApiService.fetchSeller(TEST_SHOP_ID_1, TENANT))
            .thenReturn(responseEntitySellerAPI)
        val responseEntityCarrierBookingAPI = ResponseEntity(carrierBookingResponse, HttpStatus.OK)
        `when`(
            this.mockRestTemplate.exchange(
                anyString(),
                eq(POST),
                any(HttpEntity::class.java),
                eq(CarrierBookingResponse::class.java),
                eq(TENANT),
            )
        )
            .thenReturn(responseEntityCarrierBookingAPI)
        var carrierBookingRequestEntityArgCaptor = ArgumentCaptor.forClass(HttpEntity::class.java)
        var dPDReturnLines = mutableListOf(dpdReturnLine)
        var returnLines = listOf(returnLine)

        carrierBookingAPIService.invokeCarrierBookingAPI(returnLines, dPDReturnLines, TENANT)

        verify(this.mockRestTemplate).exchange(
            eq(CARRIER_API_URL),
            eq(POST),
            carrierBookingRequestEntityArgCaptor.capture(),
            eq(CarrierBookingResponse::class.java),
            eq(TENANT)
        )
        val carrierBookingRequest = carrierBookingRequestEntityArgCaptor.firstValue.body as CarrierBookingRequest
        val recepient = carrierBookingRequest.recipient
        assertThat(recepient.countryCode).isEqualTo(COUNTRY_CODE)
        assertThat(recepient.addressLine2).isEqualTo(ADDRESS_LINE_1)
        assertThat(recepient.name).isEqualTo(SELLER_NAME)
    }

    @Test
    fun `should fetch shop Id from mirakl if shop id is default value`() {
        `when`(sellerApiService.fetchSeller(TEST_SHOP_ID_2, TENANT))
            .thenReturn(
                ResponseEntity(
                    ObjectMapper().readValue(
                        Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
                        SellerAddressResponse::class.java,
                    ), HttpStatus.OK
                )
            )
        val responseEntityCarrierBookingAPI = ResponseEntity(carrierBookingResponse, HttpStatus.OK)
        `when`(
            this.mockRestTemplate.exchange(
                anyString(),
                eq(POST),
                any(HttpEntity::class.java),
                eq(CarrierBookingResponse::class.java),
                eq(TENANT)
            )
        )
            .thenReturn(responseEntityCarrierBookingAPI)
        val testReturnLine = ReturnLine(
            offerId = OFFER_ID,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            returnDate = now().toString(),
            returnOrderNumber = RETURN_ORDER_ID
        )

        assertThat(
            carrierBookingAPIService.invokeCarrierBookingAPI(
                listOf(testReturnLine),
                mutableListOf(),
                TENANT,
            )
        ).isNotNull
        verify(this.miraklAPIService).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }

    @Test
    fun `should fetch shop Id from mirakl if shop id is not applicable`() {
        `when`(sellerApiService.fetchSeller(TEST_SHOP_ID_2, TENANT))
            .thenReturn(
                ResponseEntity(
                    ObjectMapper().readValue(
                        Files.readAllBytes(ClassPathResource(SELLER_RESPONSE_BODY).file.toPath()),
                        SellerAddressResponse::class.java,
                    ), HttpStatus.OK
                )
            )
        val responseEntityCarrierBookingAPI = ResponseEntity(carrierBookingResponse, HttpStatus.OK)
        `when`(
            this.mockRestTemplate.exchange(
                anyString(),
                eq(POST),
                any(HttpEntity::class.java),
                eq(CarrierBookingResponse::class.java),
                eq(TENANT)
            )
        )
            .thenReturn(responseEntityCarrierBookingAPI)
        val testReturnLine = ReturnLine(
            offerId = OFFER_ID,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            returnDate = now().toString(),
            returnOrderNumber = RETURN_ORDER_ID,
            shopId = NOT_APPLICABLE
        )

        assertThat(
            carrierBookingAPIService.invokeCarrierBookingAPI(
                listOf(testReturnLine),
                mutableListOf(),
                TENANT,
            )
        ).isNotNull
        verify(this.miraklAPIService).getMiraklOrderDetailsByOrderId(LOGISTICAL_ORDER_ID, TENANT)
    }
}
