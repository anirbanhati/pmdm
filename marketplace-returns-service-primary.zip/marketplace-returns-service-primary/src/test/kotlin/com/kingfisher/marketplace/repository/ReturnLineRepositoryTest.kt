package com.kingfisher.marketplace.repository

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.config.dynamodb.configProperties.DynamoDBConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.utils.CursorUtils
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.argThat
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import org.mockito.kotlin.mock
import software.amazon.awssdk.enhanced.dynamodb.model.Page
import software.amazon.awssdk.core.pagination.sync.SdkIterable
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable
import software.amazon.awssdk.enhanced.dynamodb.TableSchema
import software.amazon.awssdk.enhanced.dynamodb.model.*
import software.amazon.awssdk.services.dynamodb.model.AttributeValue
import java.util.Collections.emptyIterator
import java.util.stream.Stream

private const val TABLE_NAME = "return-lines-table"
private const val RETURN_ORDER_NUMBER = 100001L
private const val LINE_NUMBER = 1L
private const val STORE_ID = "storeId123"
private const val TENANT = "CAPL"
private const val DATE_FROM = 1000000L
private const val DATE_TO = 2000000L

@ExtendWith(MockitoExtension::class)
class ReturnLineRepositoryTest {

    @Mock
    private lateinit var dynamoDbEnhancedClient: DynamoDbEnhancedClient

    @Mock
    private lateinit var dynamoDbTable: DynamoDbTable<ReturnLine>

    @Mock
    private lateinit var dynamoDbIndex: DynamoDbIndex<ReturnLine>

    @Mock
    private lateinit var configProperties: ConfigProperties

    @Mock
    private lateinit var dynamoDBConfigProperties: DynamoDBConfigProperties

    @Mock
    private lateinit var pageIterable: PageIterable<ReturnLine>

    private lateinit var returnLineRepository: ReturnLineRepository

    @BeforeEach
    fun setUp() {
        whenever(dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromClass(ReturnLine::class.java)))
            .thenReturn(dynamoDbTable)
        whenever(dynamoDBConfigProperties.tableName).thenReturn(TABLE_NAME)

        returnLineRepository = ReturnLineRepository(
            configProperties,
            dynamoDbEnhancedClient,
            dynamoDBConfigProperties
        )
    }

    private fun buildReturnLine(
        returnOrderNumber: Long = RETURN_ORDER_NUMBER,
        lineNumber: Long = LINE_NUMBER,
        storeId: String = STORE_ID,
        tenant: String = TENANT,
        status: String = "PENDING"
    ): ReturnLine = ReturnLine(
        returnOrderNumber = returnOrderNumber,
        lineNumber = lineNumber,
        storeId = storeId,
        tenant = tenant,
        status = status
    )

    @Test
    fun `should fetch all lines from table`() {
        val returnLine1 = buildReturnLine(lineNumber = 1L)
        val returnLine2 = buildReturnLine(lineNumber = 2L)
        val items = SdkIterable { mutableListOf(returnLine1, returnLine2).iterator() }
        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>())).thenReturn(pageIterable)
        whenever(pageIterable.items()).thenReturn(items)

        val result = returnLineRepository.fetchAllLines()

        assertThat(result).isNotEmpty
        assertThat(result).hasSize(2)
        verify(dynamoDbTable).scan(any<ScanEnhancedRequest>())
    }

    @Test
    fun `should fetch items by hash key`() {
        val returnLine1 = buildReturnLine(lineNumber = 1L)
        val returnLine2 = buildReturnLine(lineNumber = 2L)
        val items = SdkIterable { mutableListOf(returnLine1, returnLine2).iterator() }

        whenever(dynamoDbTable.query(any<QueryEnhancedRequest>())).thenReturn(pageIterable)
        whenever(pageIterable.items()).thenReturn(items)

        val result = returnLineRepository.fetchItemsByHashKey(RETURN_ORDER_NUMBER)

        assertThat(result).isNotEmpty
        assertThat(result).hasSize(2)
        verify(dynamoDbTable).query(any<QueryEnhancedRequest>())
    }

    @Test
    fun `should fetch return item by order number and line number`() {
        val returnLine = buildReturnLine()

        whenever(dynamoDbTable.getItem(any<java.util.function.Consumer<software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest.Builder>>()))
            .thenReturn(returnLine)

        val result = returnLineRepository.fetchReturnItem(RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result).isNotNull
        assertThat(result).isEqualTo(returnLine)
        verify(dynamoDbTable).getItem(any<java.util.function.Consumer<software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest.Builder>>())
    }

    @Test
    fun `should return null when item not found`() {
        whenever(dynamoDbTable.getItem(any<java.util.function.Consumer<software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest.Builder>>()))
            .thenReturn(null)

        val result = returnLineRepository.fetchReturnItem(RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result).isNull()
    }

    @Test
    fun `should save or update return line details`() {
        val returnLine = buildReturnLine()

        returnLineRepository.saveOrUpdateReturnLineDetails(returnLine)

        verify(dynamoDbTable).putItem(argThat<ReturnLine> { line ->
            line.returnOrderNumber == RETURN_ORDER_NUMBER &&
            line.lineNumber == LINE_NUMBER
        })
    }

    @Test
    fun `should save multiple return lines as batch`() {
        val returnLine1 = buildReturnLine(lineNumber = 1L)
        val returnLine2 = buildReturnLine(lineNumber = 2L)
        val returnLines = listOf(returnLine1, returnLine2)
        whenever(dynamoDbTable.tableSchema()).thenReturn(TableSchema.fromClass(ReturnLine::class.java))

        returnLineRepository.save(returnLines)

        verify(dynamoDbEnhancedClient).batchWriteItem(argThat<BatchWriteItemEnhancedRequest> { request ->
            request.writeBatches().first().writeRequests().size == 2
        })
    }

    @Test
    fun `should delete return line by order number and line number`() {
        returnLineRepository.deleteReturnLine(RETURN_ORDER_NUMBER, LINE_NUMBER)

        verify(dynamoDbTable).deleteItem(argThat<DeleteItemEnhancedRequest> { request ->
            request.key().partitionKeyValue().n() == RETURN_ORDER_NUMBER.toString() &&
                    request.key().sortKeyValue().get().n() == LINE_NUMBER.toString()
        })
    }

    @Test
    fun `should query by time range for specific store and tenant`() {
        whenever(dynamoDbTable.index(GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX))
            .thenReturn(dynamoDbIndex)

        val page = Page.builder(ReturnLine::class.java)
            .items(mutableListOf(buildReturnLine()))
            .build()

        val items = PageIterable.create { mutableListOf(page).iterator() }
        whenever(dynamoDbIndex.query(any<QueryEnhancedRequest>())).thenReturn(items)

        val result = returnLineRepository.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
            TENANT,
            STORE_ID,
            DATE_FROM,
            DATE_TO
        )

        assertThat(result).isNotNull
        assertThat(result).isNotEmpty
        verify(dynamoDbTable).index(GSI_STORE_ID_RETURNED_DATE_IN_MS_INDEX)
    }

    @Test
    fun `should fetch items by hash key with specific order number`() {
        val orderNumber = 999999L
        val items = SdkIterable<ReturnLine> { emptyIterator() }
        whenever(dynamoDbTable.query(any<QueryEnhancedRequest>())).thenReturn(pageIterable)
        whenever(pageIterable.items()).thenReturn(items)

        returnLineRepository.fetchItemsByHashKey(orderNumber)

        verify(dynamoDbTable).query(any<QueryEnhancedRequest>())
    }

    @Test
    fun `should fetch first page of orders`() {
        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(
            listOf(
                buildReturnLine(returnOrderNumber = 4000),
                buildReturnLine(returnOrderNumber = 4002)
            )
        )

        whenever(page.lastEvaluatedKey()).thenReturn(
            mapOf(
                "return_order_number" to AttributeValue.fromN("4002"),
                "line_number" to AttributeValue.fromN("1")
            )
        )

        whenever(pageIterable.stream()).thenReturn(java.util.stream.Stream.of(page))
        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>())).thenReturn(pageIterable)

        val response = returnLineRepository.fetchOrders(
            TENANT,
            2,
            null
        )

        assertThat(response.orders).hasSize(2)
        assertThat(response.nextCursor).isNotNull()
    }

    @Test
    fun `should return null cursor on last page`() {
        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(
            listOf(buildReturnLine())
        )

        whenever(page.lastEvaluatedKey()).thenReturn(emptyMap())

        whenever(pageIterable.stream()).thenReturn(java.util.stream.Stream.of(page))
        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>())).thenReturn(pageIterable)

        val response = returnLineRepository.fetchOrders(
            TENANT,
            10,
            null
        )

        assertThat(response.nextCursor).isNull()
    }

    @Test
    fun `should decode supplied cursor`() {
        val cursor = CursorUtils.encode(
            mapOf(
                "return_order_number" to AttributeValue.fromN("4002"),
                "line_number" to AttributeValue.fromN("1")
            )
        )

        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(
            listOf(buildReturnLine(returnOrderNumber = 4003))
        )

        whenever(page.lastEvaluatedKey()).thenReturn(emptyMap())

        whenever(pageIterable.stream()).thenReturn(java.util.stream.Stream.of(page))
        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>())).thenReturn(pageIterable)

        val response = returnLineRepository.fetchOrders(
            TENANT,
            1,
            cursor
        )

        assertThat(response.orders).hasSize(1)
    }

    @Test
    fun `should continue scanning while more pages exist`() {
        val page1 = mock<Page<ReturnLine>>()
        val page2 = mock<Page<ReturnLine>>()

        whenever(page1.items()).thenReturn(
            listOf(buildReturnLine(returnOrderNumber = 4000))
        )

        whenever(page1.lastEvaluatedKey()).thenReturn(
            mapOf(
                "return_order_number" to AttributeValue.fromN("4000"),
                "line_number" to AttributeValue.fromN("1")
            )
        )

        whenever(page2.items()).thenReturn(
            listOf(buildReturnLine(returnOrderNumber = 4001))
        )

        whenever(page2.lastEvaluatedKey()).thenReturn(emptyMap())

        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>()))
            .thenReturn(
                PageIterable.create(
                    SdkIterable<Page<ReturnLine>> {
                        listOf(page1).iterator() as MutableIterator<Page<ReturnLine>?>
                    }
                ),
                PageIterable.create(
                    SdkIterable<Page<ReturnLine>> {
                        listOf(page2).iterator() as MutableIterator<Page<ReturnLine>?>
                    }
                )
            )

        val response = returnLineRepository.fetchOrders(
            TENANT,
            2,
            null
        )

        assertThat(response.orders).hasSize(2)
        assertThat(response.nextCursor).isNull()
    }

    @Test
    fun `should stop scanning when requested count is reached even if next page exists`() {
        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(
            listOf(
                buildReturnLine(returnOrderNumber = 4000),
                buildReturnLine(returnOrderNumber = 4001)
            )
        )

        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>()))
            .thenReturn(
                PageIterable.create(
                    SdkIterable<Page<ReturnLine>> {
                        listOf(page).iterator() as MutableIterator<Page<ReturnLine>?>
                    }
                )
            )

        val response = returnLineRepository.fetchOrders(
            TENANT,
            1,
            null
        )

        val decodedCursor = CursorUtils.decode(response.nextCursor)

        assertThat(decodedCursor)
            .containsEntry(
                "return_order_number",
                AttributeValue.fromN("4000")
            )

        assertThat(decodedCursor)
            .containsEntry(
                "line_number",
                AttributeValue.fromN("1")
            )

        verify(dynamoDbTable).scan(any<ScanEnhancedRequest>())
    }

    @Test
    fun `should handle null last evaluated key`() {
        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(listOf(buildReturnLine()))
        whenever(page.lastEvaluatedKey()).thenReturn(null)

        whenever(pageIterable.stream()).thenReturn(Stream.of(page))
        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>()))
            .thenReturn(pageIterable)

        val response = returnLineRepository.fetchOrders(TENANT, 10, null)

        assertThat(response.nextCursor).isNull()
    }

    @Test
    fun `should create cursor from last returned item when only part of page is returned`() {
        val pageItems = listOf(
            buildReturnLine(returnOrderNumber = 4000),
            buildReturnLine(returnOrderNumber = 4001),
            buildReturnLine(returnOrderNumber = 4002),
            buildReturnLine(returnOrderNumber = 4003)
        )

        val page = mock<Page<ReturnLine>>()

        whenever(page.items()).thenReturn(pageItems)

        whenever(dynamoDbTable.scan(any<ScanEnhancedRequest>()))
            .thenReturn(pageIterable)

        whenever(pageIterable.stream())
            .thenReturn(Stream.of(page))

        val response = returnLineRepository.fetchOrders(
            TENANT,
            2,
            null
        )
        assertThat(response.orders).hasSize(2)

        val lastReturnedItem = response.orders.last()
        val decodedCursor = CursorUtils.decode(response.nextCursor)

        assertThat(decodedCursor)
            .containsEntry(
                "return_order_number",
                AttributeValue.fromN(lastReturnedItem.returnOrderNumber.toString())
            )

        assertThat(decodedCursor)
            .containsEntry(
                "line_number",
                AttributeValue.fromN(lastReturnedItem.lineNumber.toString())
            )
    }
}
