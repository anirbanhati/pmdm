package com.kingfisher.marketplace.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.productApi.configProperties.ProductApiConfigProperties
import com.kingfisher.marketplace.model.product.ProductAPIResponse
import org.assertj.core.api.AssertionsForInterfaceTypes.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.whenever
import org.springframework.core.io.ClassPathResource
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import java.nio.file.Files

private const val EAN = "1234567890123"
private const val TENANT = "testTenant"
private const val PRODUCT_API_URL = "https://api.productApiUrl.com/products"

private const val PRODUCT_API_RESPONSE_BODY = "1234567890130.json"

@ExtendWith(MockitoExtension::class)
class ProductApiQueryServiceTest {

    @Mock
    private lateinit var productApiConfigPropertiesMock: ProductApiConfigProperties

    @Mock
    private lateinit var restTemplate: RestTemplate

    @InjectMocks
    private lateinit var productApiQueryServiceMock: ProductApiQueryService

    @Test
    fun shouldReturnProductAPIResponse() {
        val ean = "1234567890130"
        val productAPIResponse =
            ObjectMapper().readValue(
                Files.readAllBytes(ClassPathResource(PRODUCT_API_RESPONSE_BODY).file.toPath()),
                ProductAPIResponse::class.java,
            )
        val responseEntity = ResponseEntity.ok(productAPIResponse)

        whenever(productApiConfigPropertiesMock.productApiUrl).thenReturn(PRODUCT_API_URL)
        whenever(
            restTemplate.getForEntity(
                PRODUCT_API_URL,
                ProductAPIResponse::class.java,
                TENANT,
                EAN,
            ),
        ).thenReturn(responseEntity)

        val response = productApiQueryServiceMock.fetchProduct(EAN, TENANT)

        val attributes = response[ean]!!
        assertThat(attributes.ean).isEqualTo(ean)
        assertThat(attributes.productMediaObjects).isNotEmpty
        assertThat(attributes.name).isNotEmpty
        assertThat(attributes.technicalAttributes.technical).isNotEmpty
        assertThat(attributes.technicalAttributes.dimension).isNotEmpty
    }

    @Test
    fun shouldReturnEmptyMapOnEmptyResponse() {
        val responseEntity = ResponseEntity.ok(ProductAPIResponse(emptyList()))

        whenever(productApiConfigPropertiesMock.productApiUrl).thenReturn(PRODUCT_API_URL)
        whenever(
            restTemplate.getForEntity(
                PRODUCT_API_URL,
                ProductAPIResponse::class.java,
                TENANT,
                EAN,
            ),
        ).thenReturn(responseEntity)

        val response = productApiQueryServiceMock.fetchProduct(EAN, TENANT)

        assertThat(response).isEmpty()
    }
}
