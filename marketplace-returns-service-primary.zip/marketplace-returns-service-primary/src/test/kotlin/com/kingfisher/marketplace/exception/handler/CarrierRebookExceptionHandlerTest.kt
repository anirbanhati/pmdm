package com.kingfisher.marketplace.exception.handler

import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.exception.NoEligibleLinesForRebookException
import com.kingfisher.marketplace.model.errors.ErrorResponse
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class CarrierRebookExceptionHandlerTest {

    private val handler = CarrierRebookExceptionHandler()

    @Test
    fun `should return 400 with message when NoEligibleLinesForRebookException is thrown`() {
        val exception = NoEligibleLinesForRebookException(1930157528L)

        val response = handler.handleNoEligibleLines(exception)

        assertEquals(ErrorResponse(message = exception.message!!), response)
    }

    @Test
    fun `should return 503 with message when CmsApiException is thrown`() {
        val exception = CmsApiException("CMS API unavailable")

        val response = handler.handleCmsApiException(exception)

        assertEquals(ErrorResponse(message = "CMS API unavailable"), response)
    }

    @Test
    fun `should return 503 with fallback message when CmsApiException has null message`() {
        val exception = CmsApiException(null)

        val response = handler.handleCmsApiException(exception)

        assertEquals(ErrorResponse(message = "Carrier re-booking failed"), response)
    }
}
