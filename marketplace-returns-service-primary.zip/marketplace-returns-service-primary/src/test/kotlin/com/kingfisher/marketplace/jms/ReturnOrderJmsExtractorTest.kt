package com.kingfisher.marketplace.jms

import com.kingfisher.www.oagis._9.SalesOrderHeaderType
import com.kingfisher.www.oagis._9.SalesOrderType
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Nested
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever
import org.openapplications.www.oagis._9.NoteType

@ExtendWith(MockitoExtension::class)
class ReturnOrderJmsExtractorTest {

    private fun buildOrderWithNotes(notes: List<String?>?): SalesOrderType {
        val header = mock<SalesOrderHeaderType>()
        val noteArray = notes?.map { value ->
            mock<NoteType>().also {
                whenever(it.stringValue).thenReturn(value)
            }
        }?.toTypedArray()

        whenever(header.noteArray).thenReturn(noteArray)

        return mock<SalesOrderType>().also {
            whenever(it.salesOrderHeader).thenReturn(header)
        }
    }

    @Nested
    inner class NotesTest {

        @Test
        fun `notes returns null when noteArray is null`() {
            assertNull(buildOrderWithNotes(null).notes())
        }

        @Test
        fun `notes returns null when noteArray is empty`() {
            assertNull(buildOrderWithNotes(emptyList()).notes())
        }

        @Test
        fun `notes returns null when all notes are null`() {
            assertNull(buildOrderWithNotes(listOf(null, null)).notes())
        }

        @Test
        fun `notes returns null when all notes are blank`() {
            assertNull(buildOrderWithNotes(listOf("  ", "")).notes())
        }

        @Test
        fun `notes returns single note`() {
            assertEquals("Leave at door", buildOrderWithNotes(listOf("Leave at door")).notes())
        }

        @Test
        fun `notes trims whitespace from note`() {
            assertEquals("Leave at door", buildOrderWithNotes(listOf("  Leave at door  ")).notes())
        }

        @Test
        fun `notes joins multiple notes with comma separator`() {
            assertEquals("Note one, Note two", buildOrderWithNotes(listOf("Note one", "Note two")).notes())
        }

        @Test
        fun `notes filters out null values`() {
            assertEquals("Valid note", buildOrderWithNotes(listOf("Valid note", null)).notes())
        }

        @Test
        fun `notes filters out blank values`() {
            assertEquals("Valid note", buildOrderWithNotes(listOf("Valid note", "  ", "")).notes())
        }

        @Test
        fun `notes trims and filters mixed valid blank and null notes`() {
            assertEquals(
                "Note one, Note two",
                buildOrderWithNotes(listOf("  Note one  ", "   ", null, "Note two")).notes()
            )
        }

        @Test
        fun `notes deduplicates repeated notes`() {
            assertEquals(
                "1st return, 2nd return",
                buildOrderWithNotes(listOf("1st return", "2nd return", "1st return", "2nd return")).notes()
            )
        }
    }
}
