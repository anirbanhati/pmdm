package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.model.cms.response.CmsApiResponse
import com.kingfisher.marketplace.repository.ReturnLineRepository
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.*

private const val ORDER_ID = 100001L
private const val CAPL_TENANT = "CAPL"
private const val OTHER_TENANT = "BQUK"

private const val LOGISTICAL_ORDER_ID_1 = "1234567-AB"
private const val LOGISTICAL_ORDER_ID_2 = "7654321-CD"

@ExtendWith(MockitoExtension::class)
class PostRefundHandlerTest {

    @Mock
    private lateinit var returnLineRepository: ReturnLineRepository

    @Mock
    private lateinit var cmsApiService: CmsApiService

    @InjectMocks
    private lateinit var postRefundHandler: PostRefundHandler

    private fun buildReturnLine(
        logisticalOrderId: String = LOGISTICAL_ORDER_ID_1,
        lineNumber: Long = 1L
    ): ReturnLine = ReturnLine(
        returnOrderNumber = ORDER_ID,
        logisticalOrderId = logisticalOrderId,
        lineNumber = lineNumber
    )

    @Test
    fun `should do nothing on empty list`() {
        postRefundHandler.handle(CAPL_TENANT, emptyList())
        verifyNoInteractions(returnLineRepository, cmsApiService)
    }

    @Test
    fun `should invoke CMS API and Update status for CAPL tenant`() {
        val returnLines = listOf(buildReturnLine())
        whenever(cmsApiService.bookCarrier(returnLines, CAPL_TENANT)).thenReturn(CmsApiResponse(true, "", ""))

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(returnLineRepository).save(returnLines)
        verify(cmsApiService).bookCarrier(returnLines, CAPL_TENANT)
        assertThat(returnLines.first().status).isEqualTo(Status.CARRIER_BOOKED.name)
    }

    @Test
    fun `should invoke CMS API and Update status for CAPL on error`() {
        whenever(cmsApiService.bookCarrier(any(), any<String>())).thenThrow(CmsApiException("error"))
        val returnLines = listOf(buildReturnLine())

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(returnLineRepository).save(returnLines)
        verify(cmsApiService).bookCarrier(returnLines, CAPL_TENANT)
        assertThat(returnLines.first().status).isEqualTo(Status.CARRIER_BOOKING_FAILED.name)
    }

    @Test
    fun `should invoke CMS API and Update status for CAPL on success=false`() {
        whenever(cmsApiService.bookCarrier(any(), any<String>())).thenReturn(CmsApiResponse(false, "", ""))
        val returnLines = listOf(buildReturnLine())

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(returnLineRepository).save(returnLines)
        verify(cmsApiService).bookCarrier(returnLines, CAPL_TENANT)
        assertThat(returnLines.first().status).isEqualTo(Status.CARRIER_BOOKING_FAILED.name)
    }

    @Test
    fun `should not invoke CMS API for non-CAPL tenant`() {
        val returnLines = listOf(buildReturnLine())

        postRefundHandler.handle(OTHER_TENANT, returnLines)

        verify(returnLineRepository).save(returnLines)
        verify(cmsApiService, never()).bookCarrier(any(), any())
    }

    @Test
    fun `should save and invoke CMS API for multiple return lines within same logistical group under CAPL`() {
        val returnLines = listOf(buildReturnLine(lineNumber = 1L), buildReturnLine(lineNumber = 2L))
        whenever(cmsApiService.bookCarrier(returnLines, CAPL_TENANT)).thenReturn(CmsApiResponse(true, "", ""))

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(returnLineRepository).save(returnLines)
        verify(cmsApiService).bookCarrier(returnLines, CAPL_TENANT)
        assertThat(returnLines[0].status).isEqualTo(Status.CARRIER_BOOKED.name)
        assertThat(returnLines[1].status).isEqualTo(Status.CARRIER_BOOKED.name)
    }

    @Test
    fun `should invoke CMS API once per logistical order group`() {
        val linesForSeller1 = listOf(buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_1))
        val linesForSeller2 = listOf(buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_2))
        val returnLines = linesForSeller1 + linesForSeller2
        whenever(cmsApiService.bookCarrier(any<List<ReturnLine>>(), eq(CAPL_TENANT))).thenReturn(CmsApiResponse(true, "", ""))

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(cmsApiService).bookCarrier(linesForSeller1, CAPL_TENANT)
        verify(cmsApiService).bookCarrier(linesForSeller2, CAPL_TENANT)
        assertThat(returnLines[0].status).isEqualTo(Status.CARRIER_BOOKED.name)
        assertThat(returnLines[1].status).isEqualTo(Status.CARRIER_BOOKED.name)
    }

    @Test
    fun `should update status for fail and proceed with next logistical group to success`() {
        val linesForSeller1 =
            listOf(buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_1), buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_1, lineNumber = 2L))
        val linesForSeller2 =
            listOf(buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_2), buildReturnLine(logisticalOrderId = LOGISTICAL_ORDER_ID_2, lineNumber = 2L))
        val returnLines = linesForSeller1 + linesForSeller2

        whenever(cmsApiService.bookCarrier(linesForSeller1, CAPL_TENANT)).thenThrow(CmsApiException("error"))
        whenever(cmsApiService.bookCarrier(linesForSeller2, CAPL_TENANT)).thenReturn(CmsApiResponse(true, "", ""))

        postRefundHandler.handle(CAPL_TENANT, returnLines)

        verify(cmsApiService).bookCarrier(linesForSeller1, CAPL_TENANT)
        verify(cmsApiService).bookCarrier(linesForSeller2, CAPL_TENANT)
        linesForSeller1.forEach {
            assertThat(it.status).isEqualTo(Status.CARRIER_BOOKING_FAILED.name)
        }
        linesForSeller2.forEach {
            assertThat(it.status).isEqualTo(Status.CARRIER_BOOKED.name)
        }
    }
}
