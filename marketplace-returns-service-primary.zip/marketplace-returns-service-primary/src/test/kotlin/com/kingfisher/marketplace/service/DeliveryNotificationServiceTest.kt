package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.metrics.CAPL_ORDER_CARRIER_BOOKED
import com.kingfisher.marketplace.metrics.CAPL_ORDER_LINE_CARRIER_BOOKED
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.model.ParcelTrackingInfo
import com.kingfisher.marketplace.model.kafka.DeliveryNotification
import com.kingfisher.marketplace.model.kafka.Item
import com.kingfisher.marketplace.repository.ReturnLineRepository
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.anyOrNull
import org.mockito.kotlin.argThat
import org.mockito.kotlin.doNothing
import org.mockito.kotlin.eq
import org.mockito.kotlin.never
import org.mockito.kotlin.times
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever

private const val ORDER_NUMBER = "100001"
private const val ORIGINAL_ORDER_NUMBER = "200000"
private const val LINE_NUMBER_1 = 1L
private const val LINE_NUMBER_2 = 2L
private const val TRACKING_NUMBER = "TRK123456789"
private const val TRACKING_URL = "https://tracking.example.com/TRK123456789"
private const val CARRIER = "DPD"
private const val QUANTITY = 1L
private const val LOGISTICAL_ORDER_ID = "1234567-AB"
private const val RETURN_TYPE = "RETURN"
private const val PRODUCT_NAME = "Test Product"
private const val EAN = "1234567890"
private const val RETURN_REASON_CODE = "DEFECT"
private const val TENANT = "CAPL"

@ExtendWith(MockitoExtension::class)
class DeliveryNotificationServiceTest {

    @InjectMocks
    private lateinit var deliveryNotificationService: DeliveryNotificationService

    @Mock
    private lateinit var returnLineRepository: ReturnLineRepository

    @Mock
    private lateinit var miraklAPIService: MiraklAPIService

    @Mock
    private lateinit var sellerContentBuilder: SellerContentBuilder

    @Mock
    private lateinit var customMetrics: CustomMetrics

    private lateinit var returnLine1: ReturnLine
    private lateinit var returnLine2: ReturnLine

    @BeforeEach
    fun setUp() {
        returnLine1 = buildReturnLine(
            lineNumber = LINE_NUMBER_1,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            returnOrderNumber = ORDER_NUMBER.toLong()
        )
        returnLine2 = buildReturnLine(
            lineNumber = LINE_NUMBER_2,
            logisticalOrderId = LOGISTICAL_ORDER_ID,
            returnOrderNumber = ORDER_NUMBER.toLong()
        )
    }

    private fun buildReturnLine(
        lineNumber: Long = LINE_NUMBER_1,
        logisticalOrderId: String = LOGISTICAL_ORDER_ID,
        returnOrderNumber: Long = ORDER_NUMBER.toLong(),
        quantity: Long = QUANTITY,
        parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList(),
        route: String = "",
        status: String = "",
        returnType: String = RETURN_TYPE,
        productName: String = PRODUCT_NAME,
        ean: String = EAN,
        returnReasonCode: String = RETURN_REASON_CODE,
        tenant: String = TENANT,
        originalOrder: String = ORIGINAL_ORDER_NUMBER
    ): ReturnLine = ReturnLine(
        returnOrderNumber = returnOrderNumber,
        lineNumber = lineNumber,
        logisticalOrderId = logisticalOrderId,
        quantity = quantity,
        parcelTrackingInfo = parcelTrackingInfo,
        route = route,
        status = status,
        returnType = returnType,
        productName = productName,
        ean = ean,
        returnReasonCode = returnReasonCode,
        tenant = tenant,
        originalOrderId = originalOrder
    )

    private fun buildDeliveryNotification(
        orderNumber: String = ORDER_NUMBER,
        carrier: String = CARRIER,
        trackingNumber: String = TRACKING_NUMBER,
        trackingUrl: String = TRACKING_URL,
        items: List<Item> = listOf(
            Item(lineRef = "001", partNumber = "PN001", quantity = QUANTITY),
            Item(lineRef = "002", partNumber = "PN002", quantity = QUANTITY)
        )
    ): DeliveryNotification = DeliveryNotification(
        carrier = carrier,
        orderNumber = orderNumber,
        trackingNumber = trackingNumber,
        trackingUrl = trackingUrl,
        items = items
    )

    @Test
    fun `should update parcel tracking info with notification data`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(argThat { line ->
            line.parcelTrackingInfo.isNotEmpty() &&
                    line.parcelTrackingInfo[0].quantity == QUANTITY &&
                    line.parcelTrackingInfo[0].trackingNumber == TRACKING_NUMBER &&
                    line.parcelTrackingInfo[0].externalParcelIdentifier == NOT_AVAILABLE
        })
    }

    @Test
    fun `should set status to BOOKING_CONFIRMED when seller notification succeeds`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(argThat { line ->
            line.status == Status.BOOKING_CONFIRMED.name
        })
    }

    @Test
    fun `should set status to BOOKING_NOTIFICATION_FAILED when seller notification fails`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")
        whenever(miraklAPIService.notifySeller(any(), any(), any()))
            .thenThrow(RuntimeException("Failed to notify seller"))

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(argThat { line ->
            line.status == Status.BOOKING_NOTIFICATION_FAILED.name
        })
    }

    @Test
    fun `should filter items by line numbers from notification`() {
        val items = listOf(
            Item(lineRef = "001", partNumber = "PN001", quantity = QUANTITY),
            Item(lineRef = "003", partNumber = "PN003", quantity = QUANTITY)
        )
        val notification = buildDeliveryNotification(items = items)
        val returnLine3 = buildReturnLine(lineNumber = 3L)
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1, returnLine2, returnLine3))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(returnLine1)
        verify(returnLineRepository).saveOrUpdateReturnLineDetails(returnLine3)
        verify(returnLineRepository, never()).saveOrUpdateReturnLineDetails(returnLine2)
        verify(customMetrics).incrementCounter(CAPL_ORDER_CARRIER_BOOKED)
        verify(customMetrics, times(2)).incrementCounter(CAPL_ORDER_LINE_CARRIER_BOOKED)
    }

    @Test
    fun `should handle empty items list in notification`() {
        val notification = buildDeliveryNotification(items = emptyList())
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1, returnLine2))

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository, times(0)).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should not process items that are not in notification`() {
        val items = listOf(
            Item(lineRef = "1", partNumber = "PN001", quantity = QUANTITY)
        )
        val notification = buildDeliveryNotification(items = items)
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1, returnLine2))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository, times(1)).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should build seller notification content with correct parameters`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(sellerContentBuilder).buildSellerNotificationContent(
            eq(ROUTE.fromValue(CARRIER)!!.name),
            eq(RETURN_TYPE),
            eq(PRODUCT_NAME),
            eq(EAN),
            eq(QUANTITY),
            eq(RETURN_REASON_CODE),
            eq(MIRAKL_REFUND_REASON_CODE_PREFIX),
            eq(TENANT),
            anyOrNull(),
            any(),
            any()
        )
    }

    @Test
    fun `should call mirakl API service with correct parameters`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(miraklAPIService).notifySeller(
            eq(LOGISTICAL_ORDER_ID),
            eq("Test message"),
            eq(TENANT)
        )
    }

    @Test
    fun `should preserve existing parcel tracking info and append new ones`() {
        val existingTrackingInfo = ParcelTrackingInfo(
            quantity = 1L,
            externalParcelIdentifier = "EXISTING_URL",
            trackingNumber = "EXISTING_TRK"
        )
        val lineWithExistingTracking = buildReturnLine(
            lineNumber = LINE_NUMBER_1,
            parcelTrackingInfo = listOf(existingTrackingInfo)
        )
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(lineWithExistingTracking))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(argThat { line ->
            line.parcelTrackingInfo.size == 2 &&
                    line.parcelTrackingInfo[0].trackingNumber == "EXISTING_TRK" &&
                    line.parcelTrackingInfo[1].trackingNumber == TRACKING_NUMBER
        })
    }

    @Test
    fun `should handle exception from miraklAPIService gracefully`() {
        val notification = buildDeliveryNotification()
        val exception = RuntimeException("API Error")
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")
        whenever(miraklAPIService.notifySeller(any(), any(), any())).thenThrow(exception)

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository).saveOrUpdateReturnLineDetails(argThat { line ->
            line.status == Status.BOOKING_NOTIFICATION_FAILED.name
        })
    }

    @Test
    fun `should update line status for each item independently`() {
        val notification = buildDeliveryNotification()
        whenever(returnLineRepository.fetchItemsByHashKey(ORDER_NUMBER.toLong()))
            .thenReturn(listOf(returnLine1, returnLine2))
        whenever(
            sellerContentBuilder.buildSellerNotificationContent(
                any(), any(), any(), any(), any(), any(), any(), any(), anyOrNull(), any(), any()
            )
        ).thenReturn("Test message")
        // First call succeeds, second fails
        doNothing().doThrow(RuntimeException("Failure"))
            .whenever(miraklAPIService).notifySeller(any(), any(), any())

        deliveryNotificationService.processDeliveryNotification(notification)

        verify(returnLineRepository, times(2)).saveOrUpdateReturnLineDetails(any())
    }
}
