package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.mapper.ReturnLineMapper
import com.kingfisher.marketplace.metrics.CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.mirakl.client.core.exception.MiraklException
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.doThrow
import org.mockito.kotlin.never
import org.mockito.kotlin.whenever
import java.math.BigDecimal

private val testTotalPrice = BigDecimal("100.50")
private val testQuantity = 2L
private val testLogisticalOrderId = "ORDER123"
private val testOriginalOrderLineNumber = 1L
private val testReasonCode = "EXPIRED"
private val TENANT_TENANT = "TEST_TENANT"
private val testMessageToNotifySeller = "Order cancelled due to delivery expiry"
private val testCurrencyIsoCode = MiraklIsoCurrencyCode.USD.toString()

@ExtendWith(MockitoExtension::class)
class ReturnLineServiceTest {

    @InjectMocks
    private lateinit var service: ReturnLineService

    @Mock
    private lateinit var returnLineMapper: ReturnLineMapper

    @Mock
    private lateinit var miraklAPIService: MiraklAPIService

    @Mock
    private lateinit var configProperties: ConfigProperties

    @Mock
    private lateinit var iForceRouteValidator: IForceRouteValidator

    @Mock
    private lateinit var customMetrics: CustomMetrics

    @Mock
    private lateinit var sellerContentBuilder: SellerContentBuilder

    @Test
    fun `should return false and update metric when createCancellation throws MiraklException`() {
        val miraklException = MiraklException("Cancellation failed")
        doThrow(miraklException).whenever(miraklAPIService).createCancellation(
            testTotalPrice,
            testQuantity,
            testLogisticalOrderId,
            testOriginalOrderLineNumber,
            testReasonCode,
            testCurrencyIsoCode,
            TENANT_TENANT
        )

        // When
        val result = service.isCancelCreatedInMirakl(
            testTotalPrice,
            testQuantity,
            testLogisticalOrderId,
            testOriginalOrderLineNumber,
            testReasonCode,
            testMessageToNotifySeller,
            testCurrencyIsoCode,
            TENANT_TENANT
        )

        // Then
        assertThat(result).isFalse
        verify(miraklAPIService).createCancellation(
            testTotalPrice,
            testQuantity,
            testLogisticalOrderId,
            testOriginalOrderLineNumber,
            testReasonCode,
            testCurrencyIsoCode,
            TENANT_TENANT
        )
        verify(miraklAPIService, never()).notifySeller(any(), any(), any())
        verify(customMetrics).incrementCounter(CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED)
    }

    @Test
    fun `should return true and update metric when notifySeller throws MiraklException`() {
        val miraklException = MiraklException("notify failed")
        doThrow(miraklException)
            .whenever(miraklAPIService)
            .notifySeller(testLogisticalOrderId, testMessageToNotifySeller, TENANT_TENANT)

        // When
        val result = service.isCancelCreatedInMirakl(
            testTotalPrice,
            testQuantity,
            testLogisticalOrderId,
            testOriginalOrderLineNumber,
            testReasonCode,
            testMessageToNotifySeller,
            testCurrencyIsoCode,
            TENANT_TENANT
        )

        // Then
        assertThat(result).isTrue
        verify(miraklAPIService).createCancellation(
            testTotalPrice,
            testQuantity,
            testLogisticalOrderId,
            testOriginalOrderLineNumber,
            testReasonCode,
            testCurrencyIsoCode,
            TENANT_TENANT
        )
        verify(miraklAPIService).notifySeller(testLogisticalOrderId, testMessageToNotifySeller, TENANT_TENANT)
        verify(customMetrics, never()).incrementCounter(CANCEL_FAILED_FOR_SHIPMENT_NOT_INITIATED)
    }
}
