package com.kingfisher.marketplace.controller

import ReturnLineResponse
import com.kingfisher.marketplace.config.SecurityConfig
import com.kingfisher.marketplace.constant.Constant.Companion.CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.exception.*
import com.kingfisher.marketplace.jms.ReturnOrderJmsListener
import com.kingfisher.marketplace.model.*
import com.kingfisher.marketplace.model.manualUpdate.UpdateReturnLineRequest
import com.kingfisher.marketplace.service.CarrierRebookService
import com.kingfisher.marketplace.service.ManualUpdateLineDetailsService
import com.kingfisher.marketplace.service.ReturnBusinessService
import com.kingfisher.marketplace.service.UpdateRouteBusinessService
import org.junit.jupiter.api.Test
import org.mockito.kotlin.doAnswer
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.context.annotation.Import
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.test.context.ActiveProfiles
import org.springframework.test.context.bean.override.mockito.MockitoBean
import org.springframework.test.web.reactive.server.WebTestClient
import java.time.LocalDateTime
import java.time.LocalDateTime.parse
import java.time.format.DateTimeFormatter.ISO_DATE_TIME

private const val TEST_TENANT = "testTenant"
private const val TEST_DATE_FROM = "2024-05-04T16:49:30.571"
private const val TEST_DATE_TO = "2024-05-09T17:48:30.571"
private const val TEST_LINE_NUMBER = 1L
private const val TEST_EAN = "testEan"
private const val TEST_ROUTE = "testRoute"
private const val TEST_QUANTITY = 10L
private const val TEST_REASON = "testReason"
private const val TEST_USER_ID = "testUserId"
private const val TEST_TYPE = "testType"
private const val TEST_ORDER_NO = 123L
private const val EXTERNAL_PARCEL_IDENTIFIER = "12432"
private const val TEST_TRACKING_LINK = "http://abc@tacking.com/2323"
private val TEST_LAST_UPDATED = LocalDateTime.now()
private const val INVALID_RETURN_ORDER_ID = 0L

@WebMvcTest(controllers = [Controller::class])
@Import(SecurityConfig::class)
@ActiveProfiles("test")
@AutoConfigureWebTestClient
class ControllerTest {

    @Autowired
    lateinit var webTestClient: WebTestClient

    @MockitoBean
    lateinit var jwtDecoder: JwtDecoder

    @MockitoBean
    lateinit var returnBusinessServiceMock: ReturnBusinessService

    @MockitoBean
    lateinit var jmsListener: ReturnOrderJmsListener

    @MockitoBean
    lateinit var updateRouteBusinessServiceMock: UpdateRouteBusinessService

    @MockitoBean
    lateinit var manualUpdateLineDetailsServiceMock: ManualUpdateLineDetailsService

    @MockitoBean
    lateinit var carrierRebookServiceMock: CarrierRebookService

    @Test
    fun shouldFetchRecordsInGivenTimeRangeForSpecificStoreAndTenant() {
        whenever(
            returnBusinessServiceMock.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
                Tenant.CAFR.name,
                "1234",
                parse(TEST_DATE_FROM, ISO_DATE_TIME),
                parse(TEST_DATE_TO, ISO_DATE_TIME),
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/1234?dateFrom=2024-05-04T16:49:30.571&dateTo=2024-05-09T17:48:30.571",
            ).exchange().expectStatus().isOk
    }

    @Test
    fun shouldNotFetchRecordsIfStoreIdIsBlank() {
        whenever(
            returnBusinessServiceMock.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
                Tenant.CAFR.name,
                "",
                parse(TEST_DATE_FROM, ISO_DATE_TIME),
                parse(TEST_DATE_TO, ISO_DATE_TIME),
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/?dateFrom=2024-05-04T16:49:30.571&dateTo=2024-05-09T17:48:30.571",
            ).exchange().expectStatus().isNotFound
    }

    @Test
    fun shouldNotFetchRecordsIfStoreIdIsAlphaNumeric() {
        whenever(
            returnBusinessServiceMock.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
                Tenant.CAFR.name,
                "Abc123",
                parse(TEST_DATE_FROM, ISO_DATE_TIME),
                parse(TEST_DATE_TO, ISO_DATE_TIME),
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/Abc123?dateFrom=2024-05-04T16:49:30.571&dateTo=2024-05-09T17:48:30.571",
            ).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldThrowExceptionIfDateFromIsGreaterThanDateTo() {
        webTestClient.get()
            .uri("/v1/fetchReturnLines/CAFR/1234?dateFrom=2024-05-09T16:49:30.571&dateTo=2024-05-04T17:48:30.571")
            .exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldNotFetchRecordsIfDateFromEqualsDateTo() {
        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/123?dateFrom=2024-05-09T16:49:30.571&dateTo=2024-05-09T16:49:30.571",
            ).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldNotFetchRecordsIfDateIsInvalid() {
        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/123?dateFrom=2024-05-9T16:49:30.571&dateTo=2024-05-4T17:48:30.571",
            ).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldNotFetchRecordsIfDateIsNotPresent() {
        webTestClient.get()
            .uri(
                "/v1/fetchReturnLines/CAFR/123?",
            ).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldUpdateRouteForDPDLineWithParcelTrackingInfo() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                ROUTE.DPD.value,
                TEST_QUANTITY,
                TEST_REASON,
                listOf(ParcelTrackingInfo(TEST_QUANTITY, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK))
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)
        whenever(
            updateRouteBusinessServiceMock.updateRoute(
                TEST_ORDER_NO,
                updateRouteRequest,
                Tenant.CAFR.name,
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/123",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().is2xxSuccessful
    }

    @Test
    fun shouldUpdateRouteForNonDPDLineWithoutParcelTrackingInfo() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                TEST_ROUTE,
                TEST_QUANTITY,
                TEST_REASON,
                listOf(ParcelTrackingInfo(TEST_QUANTITY, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK))
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)
        whenever(
            updateRouteBusinessServiceMock.updateRoute(
                TEST_ORDER_NO,
                updateRouteRequest,
                Tenant.CAFR.name,
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/123",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().is2xxSuccessful
    }

    @Test
    fun shouldConfirmReturnForDPDLineWithParcelTrackingInfo() {
        val confirmReturnRequestAttributes =
            ConfirmReturnRequestAttributes(
                TEST_USER_ID,
                listOf(
                    ParcelTrackingInfo(1, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK),
                ),
            )
        val confirmReturnRequestData =
            ConfirmReturnRequestData(CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED, confirmReturnRequestAttributes)
        val confirmReturnRequest = ConfirmReturnRequest(confirmReturnRequestData)
        whenever(
            returnBusinessServiceMock.confirmReturn(
                TEST_ORDER_NO,
                TEST_LINE_NUMBER,
                confirmReturnRequest,
            )
        ).thenReturn(ConfirmReturnResponse())

        webTestClient.put()
            .uri(
                "/v1/confirm/BQUK/123/1",
            ).bodyValue(confirmReturnRequest).exchange().expectStatus().isOk
    }

    @Test
    fun shouldConfirmReturnForNonDPDLineWithoutParcelTrackingInfo() {
        val confirmReturnRequestAttributes =
            ConfirmReturnRequestAttributes(
                TEST_USER_ID,
                listOf(
                    ParcelTrackingInfo(1, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK),
                ),
            )
        val confirmReturnRequestData =
            ConfirmReturnRequestData(TEST_TYPE, confirmReturnRequestAttributes)
        val confirmReturnRequest = ConfirmReturnRequest(confirmReturnRequestData)
        whenever(
            returnBusinessServiceMock.confirmReturn(
                TEST_ORDER_NO,
                TEST_LINE_NUMBER,
                confirmReturnRequest,
            )
        ).thenReturn(ConfirmReturnResponse())

        webTestClient.put()
            .uri(
                "/v1/confirm/BQUK/123/1",
            ).bodyValue(confirmReturnRequest).exchange().expectStatus().isOk
    }

    @Test
    fun shouldThrowExceptionForInvalidTenantPassedDuringUpdateRoute() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                TEST_ROUTE,
                TEST_QUANTITY,
                TEST_REASON,
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)
        whenever(
            updateRouteBusinessServiceMock.updateRoute(
                TEST_ORDER_NO,
                updateRouteRequest,
                TEST_TENANT,
            )
        ).thenReturn(ReturnLineResponse())

        webTestClient.put()
            .uri(
                "/v1/updateRoute/testTenant",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isNotFound
    }

    @Test
    fun shouldThrowBadRequestExceptionWhenParcelTrackingInfoMissingForDPDLine() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                ROUTE.DPD.value,
                TEST_QUANTITY,
                TEST_REASON,
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)

        webTestClient.put()
            .uri(
                "/v1/updateRoute/BQUK/123",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldThrowBadRequestExceptionWhenParcelTrackingInfoMissingForDPDConfirmLineRequest() {
        val confirmReturnRequestAttributes =
            ConfirmReturnRequestAttributes(
                TEST_USER_ID,
                emptyList(),
            )
        val confirmReturnRequestData =
            ConfirmReturnRequestData(CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED, confirmReturnRequestAttributes)
        val confirmReturnRequest = ConfirmReturnRequest(confirmReturnRequestData)

        webTestClient.put()
            .uri(
                "/v1/confirm/BQUK/123/1",
            ).bodyValue(confirmReturnRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldThrowOrderNotFoundExceptionForConfirmRoute() {
        val confirmReturnRequestAttributes =
            ConfirmReturnRequestAttributes(
                TEST_USER_ID,
                listOf(
                    ParcelTrackingInfo(1, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK),
                ),
            )
        val confirmReturnRequestData =
            ConfirmReturnRequestData(CONFIRM_RETURN_TYPE_LABEL_PRINTING_REQUESTED, confirmReturnRequestAttributes)
        val confirmReturnRequest = ConfirmReturnRequest(confirmReturnRequestData)

        whenever(
            returnBusinessServiceMock.confirmReturn(
                0,
                TEST_LINE_NUMBER,
                confirmReturnRequest,
            )
        ).thenThrow(OrderNotFoundException("Not found"))

        webTestClient.put()
            .uri(
                "/v1/confirm/BQUK/0/1",
            ).bodyValue(confirmReturnRequest).exchange().expectStatus().isNotFound
    }

    @Test
    fun shouldNotUpdateRouteWhenOrderNotFound() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                TEST_ROUTE,
                TEST_QUANTITY,
                TEST_REASON,
                listOf(ParcelTrackingInfo(TEST_QUANTITY, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK))
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)
        whenever(
            updateRouteBusinessServiceMock.updateRoute(
                0,
                updateRouteRequest,
                Tenant.CAFR.name,
            )
        ).thenThrow(OrderNotFoundException("Not found"))

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/0",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isNotFound
    }

    @Test
    fun shouldThrowExceptionWhenReasonForIForceIsMissing() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                ROUTE.IFORCE.value,
                TEST_QUANTITY,
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/0",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldThrowExceptionWhenReasonForIForceIsNull() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                ROUTE.IFORCE.value,
                TEST_QUANTITY,
                null
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/0",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldThrowExceptionWhenReasonForIForceIsNEmpty() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                ROUTE.IFORCE.value,
                TEST_QUANTITY,
                ""
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/0",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun shouldNotUpdateRouteWhenCarrierBookingExceptionOccurred() {
        val updateReturnRequestLine =
            UpdateReturnRequestLine(
                TEST_LINE_NUMBER,
                TEST_EAN,
                TEST_ROUTE,
                TEST_QUANTITY,
                TEST_REASON,
                listOf(ParcelTrackingInfo(TEST_QUANTITY, EXTERNAL_PARCEL_IDENTIFIER, TEST_TRACKING_LINK))
            )
        val updateRequestAttributes =
            UpdateRequestAttributes(TEST_USER_ID, listOf(updateReturnRequestLine))
        val updateRequestData = UpdateRequestData(TEST_TYPE, updateRequestAttributes)
        val updateRouteRequest = UpdateRouteRequest(updateRequestData)
        whenever(
            updateRouteBusinessServiceMock.updateRoute(
                0,
                updateRouteRequest,
                Tenant.CAFR.name,
            )
        ).thenThrow(CarrierBookingException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception From CarrierBooking API"))

        webTestClient.put()
            .uri(
                "/v1/updateRoute/CAFR/0",
            ).bodyValue(updateRouteRequest).exchange().expectStatus().is4xxClientError
    }

    @Test
    fun `should delete return line`() {
        webTestClient.delete()
            .uri(
                "/v1/deleteLine/123/1",
            ).exchange().expectStatus().isNoContent

        verify(returnBusinessServiceMock).deleteReturnLine(TEST_ORDER_NO, TEST_LINE_NUMBER)
    }

    @Test
    fun `should delete all lines for given return order`() {
        webTestClient.delete()
            .uri(
                "/v1/deleteOrder/123",
            ).exchange().expectStatus().isNoContent

        verify(returnBusinessServiceMock).deleteAllLineAssociatedWithReturnOrder(TEST_ORDER_NO)
    }

    @Test
    fun shouldUpdateLastUpdatedSuccessfully() {
        whenever(
            returnBusinessServiceMock.updateLastUpdated(
                    TEST_ORDER_NO,
                    TEST_LINE_NUMBER,
                    TEST_LAST_UPDATED,
            )
        ).thenReturn(ConfirmReturnResponse())

        webTestClient.post()
                .uri(
                        "/v1/updateLastUpdated/BQUK/123/1/$TEST_LAST_UPDATED",
                ).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk
    }

    @Test
    fun shouldNotUpdateLastUpdatedWhenOrderNotFound() {
        whenever(
            returnBusinessServiceMock.updateLastUpdated(
                INVALID_RETURN_ORDER_ID,
                TEST_LINE_NUMBER,
                TEST_LAST_UPDATED,
            )
        ).thenThrow(OrderNotFoundException("Not found"))

        webTestClient.post()
                .uri(
                        "/v1/updateLastUpdated/BQUK/$INVALID_RETURN_ORDER_ID/1/$TEST_LAST_UPDATED",
                ).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound
    }

    @Test
    fun `should fetch all line details for given return order`() {
        whenever(returnBusinessServiceMock.fetchAllLineDetailsAssociatedWithReturnOrder(TEST_ORDER_NO)).thenReturn(
            ReturnLineResponse()
        )
        webTestClient.get()
            .uri(
                "/v1/fetchAllLineDetails/123",
            ).exchange().expectStatus().isOk.expectBody(ReturnLineResponse::class.java)

        verify(returnBusinessServiceMock).fetchAllLineDetailsAssociatedWithReturnOrder(TEST_ORDER_NO)
    }

    @Test
    fun `should return not found if order is not present in DB`() {
        val updateReturnLineRequest =
            UpdateReturnLineRequest(TEST_ORDER_NO, TEST_LINE_NUMBER, AWAITING_STORE_CONFIRMATION, TBC)
        whenever(
            manualUpdateLineDetailsServiceMock.updateLineDetails(updateReturnLineRequest)
        ).thenThrow(OrderNotFoundException("Order not found"))

        webTestClient.put().uri("/v1/update").bodyValue(updateReturnLineRequest).exchange().expectStatus().isNotFound
    }

    @Test
    fun `should return bad request if unable to update`() {
        val updateReturnLineRequest =
            UpdateReturnLineRequest(TEST_ORDER_NO, TEST_LINE_NUMBER, AWAITING_STORE_CONFIRMATION, TBC)
        doAnswer { throw IllegalUpdateException("Test Cause", "Test reject value") }
            .whenever(manualUpdateLineDetailsServiceMock).updateLineDetails(updateReturnLineRequest)

        webTestClient.put().uri("/v1/update").bodyValue(updateReturnLineRequest).exchange().expectStatus().isBadRequest
    }

    @Test
    fun `should return ok if order is updated successfully`() {
        val updateReturnLineRequest =
            UpdateReturnLineRequest(TEST_ORDER_NO, TEST_LINE_NUMBER, AWAITING_STORE_CONFIRMATION, TBC)
        whenever(
            manualUpdateLineDetailsServiceMock.updateLineDetails(updateReturnLineRequest)
        ).thenReturn(ReturnLineResponse())

        webTestClient.put().uri("/v1/update").bodyValue(updateReturnLineRequest).exchange().expectStatus().isOk
    }

    @Test
    fun `should fetch all orders`() {
        whenever(
            returnBusinessServiceMock.fetchAllReturnLines()
        ).thenReturn(listOf())

        webTestClient.get()
            .uri(
                "/v1/fetchAllOrders",
            ).exchange().expectStatus().isOk
    }

    @Test
    fun `should return 200 when rebook is successful`() {
        webTestClient.post()
            .uri("/v1/rebookCarrier/CAPL/1930157528")
            .exchange()
            .expectStatus().isOk

        verify(carrierRebookServiceMock).rebookCarrier(1930157528L)
    }

    @Test
    fun `should return 400 when no eligible lines found for rebook`() {
        whenever(carrierRebookServiceMock.rebookCarrier(1930157528L))
            .thenThrow(NoEligibleLinesForRebookException(1930157528L))

        webTestClient.post()
            .uri("/v1/rebookCarrier/CAPL/1930157528")
            .exchange()
            .expectStatus().isBadRequest
            .expectBody()
            .jsonPath("$.message").isEqualTo("No failed carrier bookings found to rebook for returnOrderNumber=1930157528")
    }

    @Test
    fun `should fetch orders without cursor`() {
        val response = FetchOrdersResponse(
            orders = listOf(),
            nextCursor = "next-cursor"
        )

        whenever(
            returnBusinessServiceMock.fetchOrders(
                Tenant.BQUK,
                10,
                null
            )
        ).thenReturn(response)

        webTestClient.get()
            .uri("/v1/fetchOrders?tenant=BQUK&count=10")
            .exchange()
            .expectStatus().isOk
            .expectBody()
            .jsonPath("$.nextCursor").isEqualTo("next-cursor")

        verify(returnBusinessServiceMock)
            .fetchOrders(Tenant.BQUK, 10, null)
    }

    @Test
    fun `should fetch orders with cursor`() {
        val response = FetchOrdersResponse(
            orders = listOf(),
            nextCursor = null
        )

        whenever(
            returnBusinessServiceMock.fetchOrders(
                Tenant.BQUK,
                10,
                "cursor123"
            )
        ).thenReturn(response)

        webTestClient.get()
            .uri("/v1/fetchOrders?tenant=BQUK&count=10&nextCursor=cursor123")
            .exchange()
            .expectStatus().isOk

        verify(returnBusinessServiceMock)
            .fetchOrders(Tenant.BQUK, 10, "cursor123")
    }

    @Test
    fun `should return bad request when invalid next cursor is provided`() {
        whenever(
            returnBusinessServiceMock.fetchOrders(
                Tenant.BQUK,
                10,
                "invalid-cursor"
            )
        ).thenThrow(InvalidNextCursorException())

        webTestClient.get()
            .uri("/v1/fetchOrders?tenant=BQUK&count=10&nextCursor=invalid-cursor")
            .exchange()
            .expectStatus().isBadRequest
            .expectBody()
            .jsonPath("$.status").isEqualTo(400)
            .jsonPath("$.errors[0].field").isEqualTo("NEXT_CURSOR")
            .jsonPath("$.errors[0].errorMessage").isEqualTo("Invalid nextCursor")
    }
}
