package com.kingfisher.marketplace.helper

import com.kingfisher.marketplace.config.cms.CmsApiConfigProperties
import com.kingfisher.marketplace.model.product.Technical
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension

private const val RETURN_ORDER_NUMBER = 100001L
private const val LINE_NUMBER = 1L
private const val DEFAULT_HEIGHT = 10
private const val DEFAULT_LENGTH = 20
private const val DEFAULT_WIDTH = 30
private const val DEFAULT_WEIGHT = 5.0

@ExtendWith(MockitoExtension::class, OutputCaptureExtension::class)
class LineDimensionExtractorTest {

    private val cmsApiConfigProperties = CmsApiConfigProperties(
        bookingType = 2,
        clientDeliveryGroupCode = "999",
        cmsApiUrl = "http://test-url",
        comment = "test-comment",
        deliveryTypeId = 50,
        height = DEFAULT_HEIGHT,
        length = DEFAULT_LENGTH,
        storeCode = 1,
        weight = DEFAULT_WEIGHT,
        width = DEFAULT_WIDTH
    )

    private lateinit var lineDimensionExtractor: LineDimensionExtractor

    @BeforeEach
    fun setUp() {
        lineDimensionExtractor = LineDimensionExtractor(cmsApiConfigProperties)
    }

    private fun technical(groupName: String, value: String, uom: String) =
        Technical(groupName = groupName, value = value, uom = uom)

    private fun buildAttributes(vararg technicals: Technical) =
        TechnicalAttributes(dimension = technicals.toList())

    @Test
    fun `should return dimensions as-is when uom is cm`() {
        val attrs = buildAttributes(
            technical("Product_height", "50", "cm"),
            technical("Product_length", "100", "cm"),
            technical("Product_width", "40", "cm"),
            technical("Product_weight", "2.5", "kg")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(50)
        assertThat(result.length).isEqualTo(100)
        assertThat(result.width).isEqualTo(40)
        assertThat(result.weight).isEqualTo(2.5)
    }

    @Test
    fun `should convert mm to cm by dividing by 10`() {
        val attrs = buildAttributes(
            technical("Product_height", "300", "mm"),
            technical("Product_length", "500", "mm"),
            technical("Product_width", "200", "mm")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(30)
        assertThat(result.length).isEqualTo(50)
        assertThat(result.width).isEqualTo(20)
    }

    @Test
    fun `should convert m to cm by multiplying by 100`() {
        val attrs = buildAttributes(
            technical("Product_height", "1.5", "m"),
            technical("Product_length", "2.0", "m"),
            technical("Product_width", "0.5", "m")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(150)
        assertThat(result.length).isEqualTo(200)
        assertThat(result.width).isEqualTo(50)
    }

    @Test
    fun `should convert g to kg by dividing by 1000`() {
        val attrs = buildAttributes(
            technical("Product_weight", "1500", "g")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.weight).isEqualTo(1.5)
    }

    @Test
    fun `should return weight as-is when uom is kg`() {
        val attrs = buildAttributes(
            technical("Product_weight", "3.5", "kg")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.weight).isEqualTo(3.5)
    }

    @Test
    fun `should handle uom case-insensitively`() {
        val attrs = buildAttributes(
            technical("Product_height", "50", "CM"),
            technical("Product_length", "300", "MM"),
            technical("Product_width", "1.0", "M"),
            technical("Product_weight", "2000", "G")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(50)
        assertThat(result.length).isEqualTo(30)
        assertThat(result.width).isEqualTo(100)
        assertThat(result.weight).isEqualTo(2.0)
    }

    @Test
    fun `should fall back to config defaults when all technical attributes are missing`() {
        val attrs = TechnicalAttributes()

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(DEFAULT_HEIGHT)
        assertThat(result.length).isEqualTo(DEFAULT_LENGTH)
        assertThat(result.width).isEqualTo(DEFAULT_WIDTH)
        assertThat(result.weight).isEqualTo(DEFAULT_WEIGHT)
    }

    @Test
    fun `should fall back to config default only for missing attributes`() {
        val attrs = buildAttributes(
            technical("Product_height", "60", "cm")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(60)
        assertThat(result.length).isEqualTo(DEFAULT_LENGTH)
        assertThat(result.width).isEqualTo(DEFAULT_WIDTH)
        assertThat(result.weight).isEqualTo(DEFAULT_WEIGHT)
    }

    @Test
    fun `should fall back to config default when attribute value is not parseable`() {
        val attrs = buildAttributes(
            technical("Product_height", "not-a-number", "cm"),
            technical("Product_length", "100", "cm"),
            technical("Product_width", "40", "cm"),
            technical("Product_weight", "2.5", "kg")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(DEFAULT_HEIGHT)
        assertThat(result.length).isEqualTo(100)
        assertThat(result.width).isEqualTo(40)
        assertThat(result.weight).isEqualTo(2.5)
    }

    @Test
    fun `should treat unknown dimension uom as cm and log warning`(output: CapturedOutput) {
        val attrs = buildAttributes(
            technical("Product_height", "45", "inch"),
            technical("Product_length", "100", "cm"),
            technical("Product_width", "40", "cm"),
            technical("Product_weight", "2.5", "kg")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(45)
        assertThat(output).contains("Unknown dimension uom='inch'")
        assertThat(output).contains("order=$RETURN_ORDER_NUMBER")
        assertThat(output).contains("line=$LINE_NUMBER")
    }

    @Test
    fun `should treat unknown weight uom as kg and log warning`(output: CapturedOutput) {
        val attrs = buildAttributes(
            technical("Product_height", "30", "cm"),
            technical("Product_length", "50", "cm"),
            technical("Product_width", "20", "cm"),
            technical("Product_weight", "3.0", "lbs")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.weight).isEqualTo(3.0)
        assertThat(output).contains("Unknown weight uom='lbs'")
        assertThat(output).contains("order=$RETURN_ORDER_NUMBER")
        assertThat(output).contains("line=$LINE_NUMBER")
    }

    @Test
    fun `should find attributes from technical list when not in dimension list`() {
        val attrs = TechnicalAttributes(
            technical = listOf(technical("Product_height", "80", "cm"))
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(80)
        assertThat(result.length).isEqualTo(DEFAULT_LENGTH)
        assertThat(result.width).isEqualTo(DEFAULT_WIDTH)
        assertThat(result.weight).isEqualTo(DEFAULT_WEIGHT)
    }

    @Test
    fun `should prefer first matching attribute when duplicates exist`() {
        val attrs = buildAttributes(
            technical("Product_height", "50", "cm"),
            technical("Product_height", "99", "cm")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result.height).isEqualTo(50)
    }

    @Test
    fun `should return LineDimensions with correct types`() {
        val attrs = buildAttributes(
            technical("Product_height", "30", "cm"),
            technical("Product_length", "50", "cm"),
            technical("Product_width", "20", "cm"),
            technical("Product_weight", "2.5", "kg")
        )

        val result = lineDimensionExtractor.extract(attrs, RETURN_ORDER_NUMBER, LINE_NUMBER)

        assertThat(result).isInstanceOf(LineDimensionExtractor.LineDimensions::class.java)
        assertThat(result.height).isEqualTo(30)
        assertThat(result.length).isEqualTo(50)
        assertThat(result.width).isEqualTo(20)
        assertThat(result.weight).isEqualTo(2.5)
    }
}
