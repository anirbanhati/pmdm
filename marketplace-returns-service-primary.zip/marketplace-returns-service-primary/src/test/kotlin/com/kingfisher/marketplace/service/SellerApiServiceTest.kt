package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.model.sellerAddress.SellerAddressResponse
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.whenever
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

private const val TEST_URL: String = "TEST_URL"

@ExtendWith(MockitoExtension::class)
class SellerApiServiceTest {

    private lateinit var sellerService: SellerApiService

    @Mock
    private lateinit var restTemplate: RestTemplate

    @BeforeEach
    fun setUp() {
        sellerService = SellerApiService(restTemplate, TEST_URL)
    }

    @Test
    fun `should fetch seller`() {
        val response = ResponseEntity.ok(SellerAddressResponse())
        val tenant = "BQ"
        val shopId = "1123"

        whenever(
            restTemplate.getForEntity(
                TEST_URL,
                SellerAddressResponse::class.java,
                tenant, shopId
            )
        ).thenReturn(response)

        val result = sellerService.fetchSeller(shopId, tenant)

        assertThat(result).isEqualTo(response)
    }
}
