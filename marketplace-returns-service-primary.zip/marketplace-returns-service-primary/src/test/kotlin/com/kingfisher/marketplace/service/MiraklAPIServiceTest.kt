package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.mirakl.MiraklClients
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_CANCEL_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.exception.OrderNotFoundInMiraklException
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode.GBP
import com.mirakl.client.mmp.domain.order.MiraklOrder
import com.mirakl.client.mmp.domain.order.MiraklOrders
import com.mirakl.client.mmp.operator.core.MiraklMarketplacePlatformOperatorApiClient
import com.mirakl.client.mmp.operator.request.order.cancelation.MiraklCreateCancelationsRequest
import com.mirakl.client.mmp.operator.request.order.message.MiraklCreateOrderThreadRequest
import com.mirakl.client.mmp.operator.request.order.refund.MiraklOperatorCreateRefundRequest
import com.mirakl.client.mmp.request.order.MiraklGetOrdersRequest
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.lenient
import org.mockito.Mockito.verify
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.argumentCaptor
import java.math.BigDecimal.TEN
import java.math.BigDecimal.ZERO

private val TEST_PRICE = TEN
private const val TEST_QUANTITY = 10L
private const val TEST_LOGISTICAL_ORDER_ID = "11111-A"
private const val TEST_LINE_NUMBER = 1L
private const val TEST_REASON = "01"
private const val TEST_ORDER_LINE_ID = "11111-1"
private const val TEST_REASON_CODE = MIRAKL_REFUND_REASON_CODE_PREFIX + "_1"
private const val TEST_CANCEL_REASON_CODE = MIRAKL_CANCEL_REASON_CODE_PREFIX + "_1"
private const val TEST_MESSAGE = "testMessage"
private const val TEST_TENANT = "testTenant"
private const val TEST_SHOP_ID = "testShopId"
private const val TEST_URL = "testURL/{tenant}/{sellerId}"
private const val TEST_SELLER_NAME = "sellerName"

@ExtendWith(MockitoExtension::class)
class MiraklAPIServiceTest {

    private lateinit var miraklAPIService: MiraklAPIService

    @Mock
    private lateinit var miraklClientsMock: MiraklClients

    @Mock
    private lateinit var miraklClient: MiraklMarketplacePlatformOperatorApiClient

    private var miraklGetOrdersRequest = MiraklGetOrdersRequest()

    @BeforeEach
    fun setUp() {
        miraklAPIService = MiraklAPIService(miraklClientsMock)

        `when`(miraklClientsMock.getClient(TEST_TENANT))
            .thenReturn(miraklClient)

        val miraklOrders = MiraklOrders()
        val miraklOrder = MiraklOrder()
        miraklOrder.shopId = TEST_SHOP_ID
        miraklOrder.currencyIsoCode = GBP
        miraklOrders.orders = listOf(miraklOrder)
        miraklOrders.totalCount = 1
        miraklGetOrdersRequest.orderIds = listOf(TEST_LOGISTICAL_ORDER_ID)
        lenient().`when`(this.miraklClientsMock.getClient(TEST_TENANT).getOrders(miraklGetOrdersRequest))
            .thenReturn(miraklOrders)
    }

    @Test
    fun shouldCreateRefund() {
        this.miraklAPIService.createRefund(
            TEST_PRICE,
            TEST_QUANTITY,
            TEST_LOGISTICAL_ORDER_ID,
            TEST_LINE_NUMBER,
            TEST_REASON,
            GBP.toString(),
            TEST_TENANT
        )

        val refundRequestCaptor = argumentCaptor<(MiraklOperatorCreateRefundRequest)>()
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).requestRefundOrder(refundRequestCaptor.capture())
        val result = refundRequestCaptor.firstValue.refunds[0]
        assertThat(result.amount).isEqualTo(TEST_PRICE.toString())
        assertThat(result.currencyIsoCode).isEqualTo(GBP)
        assertThat(result.orderLineId).isEqualTo(TEST_ORDER_LINE_ID)
        assertThat(result.quantity).isEqualTo(TEST_QUANTITY.toInt())
        assertThat(result.shippingAmount).isEqualTo(ZERO.toString())
        assertThat(result.reasonCode).isEqualTo(TEST_REASON_CODE)
    }

    @Test
    fun shouldCreateCancellation() {
        this.miraklAPIService.createCancellation(
            TEST_PRICE,
            TEST_QUANTITY,
            TEST_LOGISTICAL_ORDER_ID,
            TEST_LINE_NUMBER,
            TEST_REASON,
            GBP.toString(),
            TEST_TENANT
        )

        val cancelRequestCaptor = argumentCaptor<(MiraklCreateCancelationsRequest)>()
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).cancelOrderLines(cancelRequestCaptor.capture())
        val result = cancelRequestCaptor.firstValue.cancelations[0]
        assertThat(result.amount).isEqualTo(TEST_PRICE.toString())
        assertThat(result.currencyIsoCode).isEqualTo(GBP)
        assertThat(result.orderLineId).isEqualTo(TEST_ORDER_LINE_ID)
        assertThat(result.quantity).isEqualTo(TEST_QUANTITY.toInt())
        assertThat(result.shippingAmount).isEqualTo(ZERO.toString())
        assertThat(result.reasonCode).isEqualTo(TEST_CANCEL_REASON_CODE)
    }

    @Test
    fun shouldNotifySeller() {
        this.miraklAPIService.notifySeller(TEST_LOGISTICAL_ORDER_ID, TEST_MESSAGE, TEST_TENANT)

        val miraklCreateOrderThreadRequestCaptor = argumentCaptor<(MiraklCreateOrderThreadRequest)>()
        verify(this.miraklClientsMock.getClient(TEST_TENANT))
            .createOrderThread(miraklCreateOrderThreadRequestCaptor.capture())
        val result = miraklCreateOrderThreadRequestCaptor.firstValue
        assertThat(result.orderId).isEqualTo(TEST_LOGISTICAL_ORDER_ID)
        assertThat(result.thread.body).isEqualTo(TEST_MESSAGE)
    }

    @Test
    fun shouldFetchShopIdFromMiraklOrder() {
        val result = this.miraklAPIService.getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_ID, TEST_TENANT).shopId

        assertThat(result).isEqualTo(TEST_SHOP_ID)
    }

    @Test
    fun shouldRetrieveCurrencyIsoCodeForCreatingCancellationIfNotSavedAlready() {
        this.miraklAPIService.createCancellation(
            TEST_PRICE,
            TEST_QUANTITY,
            TEST_LOGISTICAL_ORDER_ID,
            TEST_LINE_NUMBER,
            TEST_REASON,
            "",
            TEST_TENANT
        )

        val cancelRequestCaptor = argumentCaptor<(MiraklCreateCancelationsRequest)>()
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).cancelOrderLines(cancelRequestCaptor.capture())
        val result = cancelRequestCaptor.firstValue.cancelations[0]
        assertThat(result.amount).isEqualTo(TEST_PRICE.toString())
        assertThat(result.currencyIsoCode).isEqualTo(GBP)
        assertThat(result.orderLineId).isEqualTo(TEST_ORDER_LINE_ID)
        assertThat(result.quantity).isEqualTo(TEST_QUANTITY.toInt())
        assertThat(result.shippingAmount).isEqualTo(ZERO.toString())
        assertThat(result.reasonCode).isEqualTo(TEST_CANCEL_REASON_CODE)
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).getOrders(miraklGetOrdersRequest)
    }

    @Test
    fun shouldRetrieveCurrencyIsoCodeForCreatingRefundIfNotSavedAlready() {
        this.miraklAPIService.createRefund(
            TEST_PRICE,
            TEST_QUANTITY,
            TEST_LOGISTICAL_ORDER_ID,
            TEST_LINE_NUMBER,
            TEST_REASON,
            "",
            TEST_TENANT
        )

        val refundRequestCaptor = argumentCaptor<(MiraklOperatorCreateRefundRequest)>()
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).requestRefundOrder(refundRequestCaptor.capture())
        val result = refundRequestCaptor.firstValue.refunds[0]
        assertThat(result.amount).isEqualTo(TEST_PRICE.toString())
        assertThat(result.currencyIsoCode).isEqualTo(GBP)
        assertThat(result.orderLineId).isEqualTo(TEST_ORDER_LINE_ID)
        assertThat(result.quantity).isEqualTo(TEST_QUANTITY.toInt())
        assertThat(result.shippingAmount).isEqualTo(ZERO.toString())
        assertThat(result.reasonCode).isEqualTo(TEST_REASON_CODE)
        verify(this.miraklClientsMock.getClient(TEST_TENANT)).getOrders(miraklGetOrdersRequest)
    }

    @Test
    fun `should throw exception if order count is zero`() {
        val miraklOrders = MiraklOrders()
        miraklOrders.orders = listOf()

        `when`(this.miraklClientsMock.getClient(TEST_TENANT).getOrders(miraklGetOrdersRequest)).thenReturn(
            miraklOrders
        )

        assertThatThrownBy {
            this.miraklAPIService.getMiraklOrderDetailsByOrderId(
                TEST_LOGISTICAL_ORDER_ID,
                TEST_TENANT
            )
        }.isInstanceOf(
            OrderNotFoundInMiraklException::class.java
        ).hasMessage("Order not found in Mirakl with id $TEST_LOGISTICAL_ORDER_ID")
    }
}
