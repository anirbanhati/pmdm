package com.kingfisher.marketplace.config.testcontainer

import com.kingfisher.marketplace.config.dynamodb.configProperties.DynamoDBConfigProperties
import com.kingfisher.marketplace.utils.Logging
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.event.ApplicationReadyEvent
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.ApplicationContext
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Profile
import org.springframework.context.event.EventListener
import org.testcontainers.containers.localstack.LocalStackContainer
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.dynamodb.DynamoDbClient
import software.amazon.awssdk.services.dynamodb.model.AttributeDefinition
import software.amazon.awssdk.services.dynamodb.model.CreateTableRequest
import software.amazon.awssdk.services.dynamodb.model.GlobalSecondaryIndex
import software.amazon.awssdk.services.dynamodb.model.KeySchemaElement
import software.amazon.awssdk.services.dynamodb.model.KeyType
import software.amazon.awssdk.services.dynamodb.model.Projection
import software.amazon.awssdk.services.dynamodb.model.ProjectionType
import software.amazon.awssdk.services.dynamodb.model.ProvisionedThroughput
import software.amazon.awssdk.services.dynamodb.model.ScalarAttributeType

@TestConfiguration(proxyBeanMethods = false)
@Profile("test")
class DynamoDBConfigTest @Autowired constructor(
    val credentialsProvider: AwsCredentialsProvider?,
    val localstack: LocalStackContainer,
    val dynamoDBConfigProperties: DynamoDBConfigProperties
) : Logging {

    @Bean
    @Profile("test")
    fun dynamoDbClient(): DynamoDbClient {
        return DynamoDbClient.builder()
            .credentialsProvider(credentialsProvider)
            .region(Region.of(localstack.region))
            .endpointOverride(localstack.getEndpointOverride(LocalStackContainer.Service.DYNAMODB))
            .build()
    }

    @Bean
    @Profile("test")
    fun dynamoDbEnhancedClient(dynamoDbClient: DynamoDbClient): DynamoDbEnhancedClient =
        DynamoDbEnhancedClient.builder()
            .dynamoDbClient(dynamoDbClient)
            .build()

    @EventListener
    fun onApplicationReady(applicationReadyEvent: ApplicationReadyEvent) {
        val applicationContext: ApplicationContext = applicationReadyEvent.applicationContext
        logger().info("Retrieving DynamoDB Client to create Table")
        val dynamoClient = applicationContext.getBean(DynamoDbClient::class.java)
        val schemaDef = CreateTableRequest.builder()
            .attributeDefinitions(
                AttributeDefinition.builder()
                    .attributeName("return_order_number")
                    .attributeType(ScalarAttributeType.N)
                    .build(),
                AttributeDefinition.builder()
                    .attributeName("line_number")
                    .attributeType(ScalarAttributeType.N)
                    .build(),
                AttributeDefinition.builder()
                    .attributeName("store_id")
                    .attributeType(ScalarAttributeType.S)
                    .build(),
                AttributeDefinition.builder()
                    .attributeName("returned_date_in_ms")
                    .attributeType(ScalarAttributeType.N)
                    .build(),
            ).keySchema(
                KeySchemaElement.builder()
                    .attributeName("return_order_number")
                    .keyType(KeyType.HASH)
                    .build(),
                KeySchemaElement.builder()
                    .attributeName("line_number")
                    .keyType(KeyType.RANGE)
                    .build()
            ).globalSecondaryIndexes(
                GlobalSecondaryIndex.builder()
                    .indexName("store_id_returned_date_in_ms_index")
                    .keySchema(
                        KeySchemaElement.builder()
                            .attributeName("store_id")
                            .keyType(KeyType.HASH)
                            .build(),
                        KeySchemaElement.builder()
                            .attributeName("returned_date_in_ms")
                            .keyType(KeyType.RANGE)
                            .build(),
                    )
                    .provisionedThroughput(
                        ProvisionedThroughput.builder()
                            .readCapacityUnits(10L)
                            .writeCapacityUnits(10L).build()
                    )
                    .projection(
                        Projection.builder()
                            .projectionType(ProjectionType.ALL)
                            .build()
                    )
                    .build()
            )
            .provisionedThroughput(
                ProvisionedThroughput.builder()
                    .readCapacityUnits(10L)
                    .writeCapacityUnits(10L).build()
            )
            .tableName(dynamoDBConfigProperties.tableName)
            .build()
        dynamoClient.createTable(schemaDef)
    }
}
