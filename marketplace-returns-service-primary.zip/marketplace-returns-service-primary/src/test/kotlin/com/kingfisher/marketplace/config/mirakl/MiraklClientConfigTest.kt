package com.kingfisher.marketplace.config.mirakl

import com.kingfisher.marketplace.config.mirakl.configProperties.MiraklConfigProperties
import com.kingfisher.marketplace.config.mirakl.configProperties.MiraklTenantProperties
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.lenient
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension

private const val URL = "https://www.test.com"
private const val TEST_ID = "testId"
private const val TEST_SECRET = "testSecret"
private const val TEST_AUTH_URL = "testAuthUrl"
private const val EMPTY_STRING = ""
private const val TENANT_ID = "BQUK"

@ExtendWith(MockitoExtension::class)
class MiraklClientConfigTest {

    private lateinit var miraklClientConfig: MiraklClientConfig

    @Mock
    private lateinit var miraklConfigPropertiesMock: MiraklConfigProperties

    @Mock
    private lateinit var miraklTenantPropertiesMock: MiraklTenantProperties

    @BeforeEach
    fun setUp() {
        lenient().`when`(miraklTenantPropertiesMock.url).thenReturn(URL)
        lenient().`when`(miraklTenantPropertiesMock.clientId).thenReturn(TEST_ID)
        lenient().`when`(miraklTenantPropertiesMock.clientSecret).thenReturn(TEST_SECRET)
        lenient().`when`(miraklConfigPropertiesMock.authUrl).thenReturn(TEST_AUTH_URL)
        lenient().`when`(miraklConfigPropertiesMock.tenants).thenReturn(mapOf(TENANT_ID to miraklTenantPropertiesMock))

        miraklClientConfig = MiraklClientConfig(miraklConfigPropertiesMock)
    }

    @Test
    fun shouldBuildClientForEachTenant() {
        val secondTenantMock = org.mockito.Mockito.mock(MiraklTenantProperties::class.java)
        `when`(secondTenantMock.clientId).thenReturn(TEST_ID)
        `when`(secondTenantMock.clientSecret).thenReturn(TEST_SECRET)
        `when`(miraklConfigPropertiesMock.authUrl).thenReturn(TEST_AUTH_URL)
        `when`(secondTenantMock.url).thenReturn(URL)
        `when`(miraklConfigPropertiesMock.tenants).thenReturn(
            mapOf(TENANT_ID to miraklTenantPropertiesMock, "CAPL" to secondTenantMock)
        )

        val factory = miraklClientConfig.miraklClientFactory(miraklClientConfig.bqMiraklClient(), miraklClientConfig.caplMiraklClient())

        assertThat(factory).isInstanceOf(MiraklClients::class.java)
    }

    @Test
    fun shouldThrowExceptionForBlankClientIdIfOAuthIsEnabled() {
        `when`(miraklTenantPropertiesMock.clientId).thenReturn(EMPTY_STRING)

        assertThatThrownBy { miraklClientConfig.bqMiraklClient() }
            .isInstanceOf(RuntimeException::class.java)
            .hasMessage(ERROR_MSG_FAILED_TO_INITIALIZE_MIRAKL_CREDENTIAL)
    }

    @Test
    fun shouldThrowExceptionForBlankClientSecretIfOAuthIsEnabled() {
        `when`(miraklTenantPropertiesMock.clientSecret).thenReturn(EMPTY_STRING)

        assertThatThrownBy { miraklClientConfig.bqMiraklClient() }
            .isInstanceOf(RuntimeException::class.java)
            .hasMessage(ERROR_MSG_FAILED_TO_INITIALIZE_MIRAKL_CREDENTIAL)
    }

    @Test
    fun shouldThrowExceptionForBlankAuthUrlIfOAuthIsEnabled() {
        `when`(miraklConfigPropertiesMock.authUrl).thenReturn(EMPTY_STRING)

        assertThatThrownBy { miraklClientConfig.bqMiraklClient() }
            .isInstanceOf(RuntimeException::class.java)
            .hasMessage(ERROR_MSG_FAILED_TO_INITIALIZE_MIRAKL_CREDENTIAL)
    }
}
