package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.Constant.Companion.MIRAKL_REFUND_REASON_CODE_PREFIX
import com.kingfisher.marketplace.constant.IForceReason
import com.kingfisher.marketplace.constant.IForceReason.TOO_LARGE
import com.kingfisher.marketplace.constant.ROUTE.DPD
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.ReturnType
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_DPD
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_AUTO
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_DAMAGED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_MANUAL
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_REMOVED
import com.kingfisher.marketplace.model.ParcelTrackingInfo
import com.kingfisher.marketplace.model.UpdateRequestAttributes
import com.kingfisher.marketplace.model.UpdateRequestData
import com.kingfisher.marketplace.model.UpdateReturnRequestLine
import com.kingfisher.marketplace.model.UpdateRouteRequest
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingLineItem
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingResponse
import com.kingfisher.marketplace.model.carrierBooking.OrderMastersResponse
import com.kingfisher.marketplace.model.product.Technical
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import org.apache.commons.lang3.StringUtils.EMPTY
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.anyList
import org.mockito.Mockito.anyString
import org.mockito.Mockito.lenient
import org.mockito.Mockito.verify
import org.mockito.Mockito.`when`
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.argumentCaptor
import org.mockito.kotlin.eq
import org.mockito.kotlin.never
import org.mockito.kotlin.times
import org.springframework.http.HttpStatus.OK
import org.springframework.http.ResponseEntity
import java.lang.System.currentTimeMillis
import java.math.BigDecimal.ONE
import java.math.BigDecimal.TEN
import java.math.BigDecimal.valueOf
import java.time.LocalDateTime.now

private const val TEST_TENANT = "tenant"
private const val TEST_STORE_ID = "testStoreId"
private const val TEST_QUANTITY = 10L
private const val TEST_UPDATE_REQ_QUANTITY_1 = 1L
private const val TEST_UPDATE_REQ_QUANTITY_2 = 2L
private const val TEST_UPDATE_REQ_QUANTITY_3 = 3L
private const val TEST_UPDATE_REQ_QUANTITY_4 = 9L
private const val TEST_UPDATE_REQ_QUANTITY_5 = 8L
private const val TEST_UPDATE_REQ_QUANTITY_6 = 7L
private const val TEST_ORIGINAL_ORDER_LINE_NUMBER_1 = 1L
private const val TEST_ORIGINAL_ORDER_LINE_NUMBER_2 = 2L
private const val TEST_ORIGINAL_ORDER_LINE_NUMBER_3 = 3L
private const val TEST_ORDER_NUMBER = 1234L
private const val TEST_LOGISTICAL_ORDER_NUMBER = "7002-A"
private const val TEST_TYPE = "testType"
private const val TEST_USER_ID = "testUserId"
private const val TEST_EAN_1 = "testEan1"
private const val TEST_EAN_2 = "testEan2"
private const val TEST_EAN_3 = "testEan3"
private const val TEST_REASON_CODE = "testReasonCode"
private const val TEST_FILE_PATH_IFORCE = "TestIForceNotificationTemplate.txt"
private const val TEST_MIRAKL_REASON_CODE = "REFUND_testReasonCode"
private const val TEST_MIRAKL_REASON = "test reason"
private const val TEST_MESSAGE_FOR_IFORCE_1 = "Test Message For iForce 1"
private const val TEST_MESSAGE_FOR_IFORCE_2 = "Test Message For iForce 2"
private const val TEST_CONSIGNMENT_CODE = "testConsignmentCode"
private val CONSIGNMENT_DATE = now().toString()
private const val TEST_EXTERNAL_PARCEL_IDENTIFIER = "testExternalParcelIdentifier"
private const val TEST_REASON = "testReason"
private const val TEST_NAME = "testName"

@ExtendWith(MockitoExtension::class)
class UpdateRouteBusinessServiceTest {
    private lateinit var updateRouteBusinessService: UpdateRouteBusinessService
    private lateinit var returnLine1: ReturnLine
    private lateinit var returnLine2: ReturnLine
    private lateinit var returnLine3: ReturnLine
    private lateinit var returnLine4: ReturnLine
    private lateinit var carrierBookingResponse: CarrierBookingResponse
    private var returnLineCaptor = argumentCaptor<(ReturnLine)>()
    private var carrierBookingLineItemCaptor = argumentCaptor<MutableList<CarrierBookingLineItem>>()

    @Mock
    private lateinit var returnLineRepositoryMock: ReturnLineRepository

    @Mock
    private lateinit var dataTransformerMock: ApiModelTransfomer

    @Mock
    private lateinit var configPropertiesMock: ConfigProperties

    @Mock
    private lateinit var customMetricsMock: CustomMetrics

    @Mock
    private lateinit var carrierBookingAPIService: CarrierBookingAPIService

    @Mock
    private lateinit var orderMasterMock: OrderMastersResponse

    @Mock
    private lateinit var sellerContentBuilder: SellerContentBuilder

    @Mock
    private lateinit var miraklAPIService: MiraklAPIService

    @BeforeEach
    fun setUp() {
        updateRouteBusinessService = UpdateRouteBusinessService(
            returnLineRepositoryMock,
            dataTransformerMock,
            configPropertiesMock,
            customMetricsMock,
            carrierBookingAPIService,
            sellerContentBuilder,
            miraklAPIService = miraklAPIService
        )
        setUpReturnLine()
        carrierBookingResponse = CarrierBookingResponse(arrayListOf(orderMasterMock))
        lenient().`when`(carrierBookingAPIService.invokeCarrierBookingAPI(anyList(), anyList(), anyString()))
            .thenReturn(ResponseEntity(carrierBookingResponse, OK))
        lenient().`when`(
            configPropertiesMock.iForceReasonMessageBasedOnReasonForIForce,
        ).thenReturn(
            mapOf(
                IForceReason.DAMAGED.value to TEST_MESSAGE_FOR_IFORCE_1,
                TOO_LARGE.value to TEST_MESSAGE_FOR_IFORCE_2
            )
        )
        lenient().`when`(orderMasterMock.consignmentCode).thenReturn(TEST_CONSIGNMENT_CODE)
        lenient().`when`(orderMasterMock.deliveryDate).thenReturn(CONSIGNMENT_DATE)
    }

    private fun setUpReturnLine() {
        returnLine1 = ReturnLine(
            returnOrderNumber = TEST_ORDER_NUMBER,
            lineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
            originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
            tenant = TEST_TENANT,
            route = TBC.name,
            status = EMPTY,
            ean = TEST_EAN_1,
            productName = TEST_NAME,
            quantity = TEST_QUANTITY,
            unitPrice = ONE,
            totalPrice = TEN,
            returnDate = "123",
            returnDateInMilliSecond = 122L,
            refundCreated = false,
            storeId = TEST_STORE_ID,
            createdBy = "SYSTEM",
            actionedBy = "ACTION_BY",
            returnReasonCode = TEST_REASON_CODE,
            reasonForIForce = EMPTY,
            storeAddress = EMPTY,
            offerId = EMPTY,
            shopId = EMPTY,
            logisticalOrderId = TEST_LOGISTICAL_ORDER_NUMBER,
            recipientAddress = EMPTY,
            customerId = EMPTY,
            technicalAttributes = TechnicalAttributes(
                listOf(Technical(EMPTY, EMPTY, EMPTY, EMPTY, EMPTY)),
                listOf(Technical(EMPTY, EMPTY, EMPTY, EMPTY, EMPTY)),
            ),
            returnType = ReturnType.RETURN_TO_STORE.name
        )

        returnLine2 = returnLine1.copy()
        returnLine2.lineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_2
        returnLine2.originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_2
        returnLine2.ean = TEST_EAN_2
        returnLine3 = returnLine1.copy()
        returnLine3.lineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_3
        returnLine3.originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_3
        returnLine3.ean = TEST_EAN_3
        returnLine4 = returnLine1.copy()
        returnLine4.returnType = ReturnType.COLLECTION_EXPIRED.name
    }

    @Test
    fun `should throw OrderNotFoundException when Return Lines are not found during update route`() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(mutableListOf())
        val updateRouteRequest =
            UpdateRouteRequest(
                UpdateRequestData(
                    TEST_TYPE,
                    UpdateRequestAttributes(
                        TEST_USER_ID,
                        listOf(
                            UpdateReturnRequestLine(
                                TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                TEST_EAN_1,
                                IFORCE.value,
                                TEST_UPDATE_REQ_QUANTITY_1,
                                IForceReason.DAMAGED.value
                            ),
                        ),
                    ),
                ),
            )
        assertThatThrownBy {
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                updateRouteRequest,
                TEST_TENANT
            )
        }.isInstanceOf(OrderNotFoundException::class.java)
    }

    @Test
    fun `should update route for split qty multiple lines`() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(
            mutableListOf(
                returnLine1,
                returnLine2,
                returnLine3
            )
        )
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_1,
                TEST_UPDATE_REQ_QUANTITY_1,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Damaged",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_1,
                TEST_UPDATE_REQ_QUANTITY_2,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Too Large",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_2,
                TEST_UPDATE_REQ_QUANTITY_4,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Too Large",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_3,
                TEST_UPDATE_REQ_QUANTITY_5,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Damaged",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        assertThat(
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                UpdateRouteRequest(
                    UpdateRequestData(
                        TEST_TYPE,
                        UpdateRequestAttributes(
                            TEST_USER_ID,
                            listOf(
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                    TEST_EAN_1,
                                    IFORCE.value,
                                    TEST_UPDATE_REQ_QUANTITY_1,
                                    IForceReason.DAMAGED.value
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                    TEST_EAN_1,
                                    IFORCE.value,
                                    TEST_UPDATE_REQ_QUANTITY_2,
                                    TOO_LARGE.value
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_2,
                                    TEST_EAN_2,
                                    DPD.value,
                                    TEST_UPDATE_REQ_QUANTITY_3,
                                    null,
                                    listOf(
                                        ParcelTrackingInfo(
                                            TEST_UPDATE_REQ_QUANTITY_3,
                                            TEST_EXTERNAL_PARCEL_IDENTIFIER
                                        )
                                    )
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_2,
                                    TEST_EAN_2,
                                    IFORCE.value,
                                    TEST_UPDATE_REQ_QUANTITY_4,
                                    TOO_LARGE.value
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_3,
                                    TEST_EAN_3,
                                    IFORCE.value,
                                    TEST_UPDATE_REQ_QUANTITY_5,
                                    IForceReason.DAMAGED.value
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_3,
                                    TEST_EAN_3,
                                    DPD.value,
                                    TEST_UPDATE_REQ_QUANTITY_6,
                                    null,
                                    listOf(
                                        ParcelTrackingInfo(
                                            TEST_UPDATE_REQ_QUANTITY_6,
                                            TEST_EXTERNAL_PARCEL_IDENTIFIER
                                        )
                                    )
                                ),
                            )
                        )
                    )
                ),
                TEST_TENANT
            )
        ).isNull()

        // verifying and checking the lines those are going to be saved in db after route update is completed
        verify(returnLineRepositoryMock, times(8)).saveOrUpdateReturnLineDetails(returnLineCaptor.capture())
        val savedReturnLines = returnLineCaptor.allValues
        print(savedReturnLines.toSet())
        assertThat(savedReturnLines.toSet().size).isEqualTo(6)
        val savedReturnLine1 = savedReturnLines[2]
        val savedReturnLine2 = savedReturnLines[3]
        val savedReturnLine3 = savedReturnLines[0]
        val savedReturnLine4 = savedReturnLines[5]
        val savedReturnLine5 = savedReturnLines[6]
        val savedReturnLine6 = savedReturnLines[1]
        // first return line parameters check
        assertThat(savedReturnLine1.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_1)
        assertThat(savedReturnLine1.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine1.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_1)
        val totalPriceForLine1 = valueOf(TEST_UPDATE_REQ_QUANTITY_1).multiply(ONE)
        assertThat(savedReturnLine1.totalPrice).isEqualTo(totalPriceForLine1)
        assertThat(savedReturnLine1.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine1.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine1.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine1.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine1.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // second return line parameters check
        assertThat(savedReturnLine2.lineNumber).isEqualTo(4)
        assertThat(savedReturnLine2.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine2.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_2)
        val totalPriceForLine2 = valueOf(TEST_UPDATE_REQ_QUANTITY_2).multiply(ONE)
        assertThat(savedReturnLine2.totalPrice).isEqualTo(totalPriceForLine2)
        assertThat(savedReturnLine2.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine2.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine2.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine2.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine2.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine2.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine2.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // third return line parameters check
        assertThat(savedReturnLine3.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2)
        assertThat(savedReturnLine3.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2)
        assertThat(savedReturnLine3.route).isEqualTo(DPD.value)
        assertThat(savedReturnLine3.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_3)
        assertThat(savedReturnLine3.totalPrice).isEqualTo(valueOf(TEST_UPDATE_REQ_QUANTITY_3).multiply(ONE))
        assertThat(savedReturnLine3.parcelTrackingInfo[0].quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_3)
        assertThat(savedReturnLine3.parcelTrackingInfo[0].externalParcelIdentifier).isEqualTo(
            TEST_EXTERNAL_PARCEL_IDENTIFIER
        )
        assertThat(savedReturnLine3.consignmentCode).isEqualTo(TEST_CONSIGNMENT_CODE)
        assertThat(savedReturnLine3.collectionDate).isEqualTo(CONSIGNMENT_DATE)
        assertThat(savedReturnLine3.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine3.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // fourth return line parameters check
        assertThat(savedReturnLine4.lineNumber).isEqualTo(5)
        assertThat(savedReturnLine4.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine4.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_4)
        val totalPriceForLine4 = valueOf(TEST_UPDATE_REQ_QUANTITY_4).multiply(ONE)
        assertThat(savedReturnLine4.totalPrice).isEqualTo(totalPriceForLine4)
        assertThat(savedReturnLine4.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine4.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine4.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine4.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine4.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // fifth return line parameters check
        assertThat(savedReturnLine5.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_3)
        assertThat(savedReturnLine5.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine5.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_5)
        val totalPriceForLine5 = valueOf(TEST_UPDATE_REQ_QUANTITY_5).multiply(ONE)
        assertThat(savedReturnLine5.totalPrice).isEqualTo(totalPriceForLine5)
        assertThat(savedReturnLine5.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine5.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine5.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine5.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine5.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // sixth return line parameters check
        assertThat(savedReturnLines[5].lineNumber).isEqualTo(5)
        assertThat(savedReturnLine6.lineNumber).isEqualTo(6)
        assertThat(savedReturnLine6.route).isEqualTo(DPD.value)
        assertThat(savedReturnLine6.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_6)
        assertThat(savedReturnLine6.totalPrice).isEqualTo(valueOf(TEST_UPDATE_REQ_QUANTITY_6).multiply(ONE))
        assertThat(savedReturnLine6.parcelTrackingInfo[0].quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_6)
        assertThat(savedReturnLine6.parcelTrackingInfo[0].externalParcelIdentifier).isEqualTo(
            TEST_EXTERNAL_PARCEL_IDENTIFIER
        )
        assertThat(savedReturnLine6.consignmentCode).isEqualTo(TEST_CONSIGNMENT_CODE)
        assertThat(savedReturnLine6.collectionDate).isEqualTo(CONSIGNMENT_DATE)
        assertThat(savedReturnLine6.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine6.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        verify(sellerContentBuilder).buildSellerNotificationContent(
            IFORCE.value,
            ReturnType.RETURN_TO_STORE.name,
            TEST_NAME,
            TEST_EAN_3,
            TEST_UPDATE_REQ_QUANTITY_5,
            "testReasonCode",
            MIRAKL_REFUND_REASON_CODE_PREFIX,
            TEST_TENANT,
            "Damaged",
            null
        )
        // verifying the custom metrics are updating properly or not
        verify(customMetricsMock, times(3)).incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
        verify(customMetricsMock, times(2)).incrementCounter(RETURN_ROUTE_I_FORCE_MANUAL)
        verify(customMetricsMock, times(2)).incrementCounter(RETURN_ROUTE_I_FORCE_DAMAGED)
        verify(customMetricsMock, times(2)).incrementCounter(RETURN_ROUTE_DPD)
        // verifying the carrier booking API call
        verify(carrierBookingAPIService).invokeCarrierBookingAPI(
            eq(
                listOf(
                    savedReturnLines[0],
                    savedReturnLines[1]
                )
            ), carrierBookingLineItemCaptor.capture(), eq(TEST_TENANT)
        )
        val carrierBookingLineItem1 = carrierBookingLineItemCaptor.firstValue[0]
        assertThat(carrierBookingLineItem1.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2.toString())
        assertThat(carrierBookingLineItem1.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_3)
        assertThat(carrierBookingLineItem1.productCode).isEqualTo(TEST_EAN_2)
        val carrierBookingLineItem2 = carrierBookingLineItemCaptor.firstValue[1]
        assertThat(carrierBookingLineItem2.lineNumber).isEqualTo("6")
        assertThat(carrierBookingLineItem2.quantity).isEqualTo(TEST_UPDATE_REQ_QUANTITY_6)
        assertThat(carrierBookingLineItem2.productCode).isEqualTo(TEST_EAN_3)
    }

    @Test
    fun `should not update route if line not stored in db`() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(mutableListOf(returnLine1))
        val updateRouteRequest =
            UpdateRouteRequest(
                UpdateRequestData(
                    TEST_TYPE,
                    UpdateRequestAttributes(
                        TEST_USER_ID,
                        listOf(
                            UpdateReturnRequestLine(
                                TEST_ORIGINAL_ORDER_LINE_NUMBER_2,
                                TEST_EAN_2,
                                IFORCE.value,
                                TEST_UPDATE_REQ_QUANTITY_2,
                                TOO_LARGE.value
                            ),
                        ),
                    ),
                ),
            )
        assertThat(
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                updateRouteRequest,
                TEST_TENANT
            )
        ).isNull()
        verify(returnLineRepositoryMock, never()).saveOrUpdateReturnLineDetails(any())
    }

    @Test
    fun `should update route for full quantity`() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(
            mutableListOf(
                returnLine1,
                returnLine2,
                returnLine3
            )
        )
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_1,
                TEST_QUANTITY,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Damaged",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.RETURN_TO_STORE.name,
                TEST_NAME,
                TEST_EAN_3,
                TEST_QUANTITY,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                "BQUK",
                "Too Large",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        assertThat(
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                UpdateRouteRequest(
                    UpdateRequestData(
                        TEST_TYPE,
                        UpdateRequestAttributes(
                            TEST_USER_ID,
                            listOf(
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                    TEST_EAN_1,
                                    IFORCE.value,
                                    TEST_QUANTITY,
                                    IForceReason.DAMAGED.value
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_2,
                                    TEST_EAN_2,
                                    DPD.value,
                                    TEST_QUANTITY,
                                    null,
                                    listOf(
                                        ParcelTrackingInfo(
                                            TEST_QUANTITY,
                                            TEST_EXTERNAL_PARCEL_IDENTIFIER
                                        )
                                    )
                                ),
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_3,
                                    TEST_EAN_3,
                                    IFORCE.value,
                                    TEST_QUANTITY,
                                    TOO_LARGE.value
                                )
                            )
                        )
                    )
                ),
                TEST_TENANT
            )
        ).isNull()
        // verifying and checking the lines those are going to be saved in db after route update is completed
        verify(returnLineRepositoryMock, times(4)).saveOrUpdateReturnLineDetails(returnLineCaptor.capture())
        val savedReturnLines = returnLineCaptor.allValues
        assertThat(savedReturnLines.toSet().size).isEqualTo(3)
        val savedReturnLine1 = savedReturnLines[1]
        val savedReturnLine2 = savedReturnLines[0]
        val savedReturnLine3 = savedReturnLines[3]
        // first return line parameters check
        assertThat(savedReturnLine1.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_1)
        assertThat(savedReturnLine1.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine1.quantity).isEqualTo(TEST_QUANTITY)
        val totalPriceForLine1 = valueOf(TEST_QUANTITY).multiply(ONE)
        assertThat(savedReturnLine1.totalPrice).isEqualTo(totalPriceForLine1)
        assertThat(savedReturnLine1.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine1.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine1.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine1.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine1.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // second return line parameters check
        assertThat(savedReturnLine2.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2)
        assertThat(savedReturnLine2.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2)
        assertThat(savedReturnLine2.route).isEqualTo(DPD.value)
        assertThat(savedReturnLine2.quantity).isEqualTo(TEST_QUANTITY)
        assertThat(savedReturnLine2.totalPrice).isEqualTo(valueOf(TEST_QUANTITY).multiply(ONE))
        assertThat(savedReturnLine2.parcelTrackingInfo[0].quantity).isEqualTo(TEST_QUANTITY)
        assertThat(savedReturnLine2.parcelTrackingInfo[0].externalParcelIdentifier).isEqualTo(
            TEST_EXTERNAL_PARCEL_IDENTIFIER
        )
        assertThat(savedReturnLine2.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine2.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // third return line parameters check
        assertThat(savedReturnLine3.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_3)
        assertThat(savedReturnLine3.route).isEqualTo(IFORCE.value)
        assertThat(savedReturnLine3.quantity).isEqualTo(TEST_QUANTITY)
        assertThat(savedReturnLine3.totalPrice).isEqualTo(totalPriceForLine1)
        assertThat(savedReturnLine3.parcelTrackingInfo).isEmpty()
        assertThat(savedReturnLine3.consignmentCode).isEqualTo(EMPTY)
        assertThat(savedReturnLine3.collectionDate).isEqualTo(EMPTY)
        assertThat(savedReturnLine3.lastUpdated).contains(now().year.toString())
        assertThat(savedReturnLine3.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
        // verifying the carrier booking API call
        verify(carrierBookingAPIService).invokeCarrierBookingAPI(
            eq(
                listOf(
                    savedReturnLines[0],
                )
            ), carrierBookingLineItemCaptor.capture(), eq(TEST_TENANT)
        )
        val carrierBookingLineItem = carrierBookingLineItemCaptor.firstValue[0]
        assertThat(carrierBookingLineItem.lineNumber).isEqualTo(TEST_ORIGINAL_ORDER_LINE_NUMBER_2.toString())
        assertThat(carrierBookingLineItem.quantity).isEqualTo(TEST_QUANTITY)
        assertThat(carrierBookingLineItem.productCode).isEqualTo(TEST_EAN_2)
    }

    @Test
    fun `should not update iforce related metrics if iForce reason is neither Too Large nor Damaged`() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(mutableListOf(returnLine1))
        lenient().`when`(configPropertiesMock.iForceReasonMessageBasedOnReasonForIForce)
            .thenReturn(mapOf(TEST_REASON to TEST_MESSAGE_FOR_IFORCE_1))
        assertThat(
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                UpdateRouteRequest(
                    UpdateRequestData(
                        TEST_TYPE,
                        UpdateRequestAttributes(
                            TEST_USER_ID,
                            listOf(
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                    TEST_EAN_1,
                                    IFORCE.value,
                                    TEST_QUANTITY,
                                    TEST_REASON
                                )
                            )
                        )
                    )
                ),
                TEST_TENANT
            )
        ).isNull()

        verify(customMetricsMock, never()).incrementCounter(RETURN_ROUTE_I_FORCE_DAMAGED)
        verify(customMetricsMock, never()).incrementCounter(RETURN_ROUTE_I_FORCE_MANUAL)
        verify(customMetricsMock, never()).incrementCounter(RETURN_ROUTE_I_FORCE_AUTO)
        verify(customMetricsMock).incrementCounter(RETURN_ROUTE_TBC_CURRENT_REMOVED)
    }

    @Test
    fun `should create refund and notify seller for IForce collection expiry `() {
        `when`(returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(
            mutableListOf(
                returnLine4,
            )
        )
        lenient().`when`(configPropertiesMock.iForceReturnTypesForRefundUponConfirmation).thenReturn(listOf("COLLECTION_EXPIRED"))
        lenient().`when`(
            sellerContentBuilder.buildSellerNotificationContent(
                IFORCE.value,
                ReturnType.COLLECTION_EXPIRED.name,
                TEST_NAME,
                TEST_EAN_1,
                TEST_QUANTITY,
                "testReasonCode",
                MIRAKL_REFUND_REASON_CODE_PREFIX,
                TEST_TENANT,
                "Damaged",
                null
            )
        ).thenReturn(TEST_FILE_PATH_IFORCE)
        assertThat(
            updateRouteBusinessService.updateRoute(
                TEST_ORDER_NUMBER,
                UpdateRouteRequest(
                    UpdateRequestData(
                        TEST_TYPE,
                        UpdateRequestAttributes(
                            TEST_USER_ID,
                            listOf(
                                UpdateReturnRequestLine(
                                    TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                                    TEST_EAN_1,
                                    IFORCE.value,
                                    TEST_QUANTITY,
                                    IForceReason.DAMAGED.value
                                ),
                            )
                        )
                    )
                ),
                TEST_TENANT
            )
        ).isNull()
        // verifying and checking the lines those are going to be saved in db after route update is completed
        verify(returnLineRepositoryMock).saveOrUpdateReturnLineDetails(returnLineCaptor.capture())
        assertThat(returnLineCaptor.firstValue.refundCreated).isEqualTo(true)
        verify(this.miraklAPIService).notifySeller(TEST_LOGISTICAL_ORDER_NUMBER, TEST_FILE_PATH_IFORCE, TEST_TENANT)
        verify(this.miraklAPIService).createRefund(valueOf(TEST_QUANTITY).multiply(ONE),
            TEST_QUANTITY,
            TEST_LOGISTICAL_ORDER_NUMBER,
            TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
            TEST_REASON_CODE, "",
            TEST_TENANT)
    }
}
