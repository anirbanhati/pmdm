package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension

@ExtendWith(MockitoExtension::class)
class CAPLRouteProviderTest {

    @Mock
    private lateinit var salesOrderInfo: SalesOrderInfo

    private val provider: TenantRouteProvider = CAPLRouteProvider()

    @Test
    fun `should return context`() {
        val result = provider.provide(salesOrderInfo)
        assertThat(result.route).isEqualTo(ROUTE.TBC.value)
        assertThat(result.status).isEqualTo(AWAITING_STORE_CONFIRMATION.name)
    }
}
