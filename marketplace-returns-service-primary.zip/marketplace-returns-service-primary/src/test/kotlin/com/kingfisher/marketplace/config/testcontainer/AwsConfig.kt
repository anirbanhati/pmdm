package com.kingfisher.marketplace.config.testcontainer

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.testcontainers.containers.localstack.LocalStackContainer
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider

@TestConfiguration(proxyBeanMethods = false)
class AwsConfig @Autowired constructor(
    val localStack: LocalStackContainer
) {
    @Bean
    fun awsCredentialsProvider(): AwsCredentialsProvider {
        val credentials = AwsBasicCredentials.create(localStack.accessKey, localStack.secretKey)
        return StaticCredentialsProvider.create(credentials)
    }
}
