package com.kingfisher.marketplace.config.testcontainer

import com.kingfisher.marketplace.utils.Logging
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.testcontainers.containers.localstack.LocalStackContainer
import org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB
import java.time.Duration
import org.testcontainers.utility.DockerImageName

private const val LOCALSTACK_VERSION = "localstack/localstack:3.0.2"

@TestConfiguration(proxyBeanMethods = false)
class TestContainersConfig : Logging {
    @Bean
    fun localStackContainer(): LocalStackContainer {
        logger().info("Creating LocalStack Image for DynamoDB")
        return LocalStackContainer(LOCALSTACK_IMAGE_NAME)
            .withServices(DYNAMODB)
            .withStartupTimeout(Duration.ofSeconds(30))
    }

    companion object : Logging {
        private val LOCALSTACK_IMAGE_NAME: DockerImageName = DockerImageName.parse(LOCALSTACK_VERSION)
    }
}
