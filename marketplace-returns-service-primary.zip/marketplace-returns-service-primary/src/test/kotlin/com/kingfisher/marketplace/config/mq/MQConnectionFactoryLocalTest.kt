package com.kingfisher.marketplace.config.mq

import com.ibm.mq.jakarta.jms.MQXAConnectionFactory
import jakarta.jms.JMSException
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.verify

@ExtendWith(MockitoExtension::class)
class MQConnectionFactoryLocalTest {
    @Mock
    private val mQConfigPropertiesMock: MQConfigProperties? = null

    @InjectMocks
    private lateinit var mQConnectionFactory: MQConnectionFactoryLocal

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        mQConnectionFactory = mQConfigPropertiesMock?.let { MQConnectionFactoryLocal(it) }!!
    }

    @Test
    @Throws(JMSException::class)
    fun shouldBuildJMSConnectionFactory() {
        `when`(mQConfigPropertiesMock?.user).thenReturn(TEST_USER)
        `when`(mQConfigPropertiesMock?.channel).thenReturn(TEST_CHANNEL)
        `when`(mQConfigPropertiesMock?.port).thenReturn(TEST_PORT)
        `when`(mQConfigPropertiesMock?.password).thenReturn(TEST_PASSWORD)
        `when`(mQConfigPropertiesMock?.queueManager).thenReturn(TEST_QUEUEMANGER)

        val mqxaConnectionFactory = mQConnectionFactory.buildJmsTemplate()!!.connectionFactory as MQXAConnectionFactory

        assertThat(mqxaConnectionFactory.channel).isEqualTo(TEST_CHANNEL)
        assertThat(mqxaConnectionFactory.queueManager).isEqualTo(TEST_QUEUEMANGER)
        verify(this.mQConfigPropertiesMock)?.queueManager
        verify(this.mQConfigPropertiesMock)?.port
        verify(this.mQConfigPropertiesMock)?.user
        verify(this.mQConfigPropertiesMock)?.channel
        verify(this.mQConfigPropertiesMock)?.password
    }

    companion object {
        const val TEST_PASSWORD = "testPassword"
        const val TEST_PORT = "111"
        const val TEST_USER = "testUserID"
        const val TEST_CHANNEL = "testChannel"
        const val TEST_QUEUEMANGER = "testQueueManager"
    }
}
