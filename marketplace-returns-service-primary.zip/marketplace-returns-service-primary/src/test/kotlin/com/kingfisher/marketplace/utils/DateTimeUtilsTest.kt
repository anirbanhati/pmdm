package com.kingfisher.marketplace.utils

import java.time.LocalDateTime.now
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension

@ExtendWith(MockitoExtension::class)
class DateTimeUtilsTest {
    @Test
    fun shouldFetchTimeInMs() {
        assertThat(DateTimeUtils.fetchTimeInMs(now())).isNotNull
    }
}
