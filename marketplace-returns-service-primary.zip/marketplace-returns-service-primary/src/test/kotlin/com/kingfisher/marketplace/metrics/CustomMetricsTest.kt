package com.kingfisher.marketplace.metrics

import com.kingfisher.marketplace.metrics.MetricsTags.RESULT
import com.kingfisher.marketplace.metrics.MetricsTags.SUCCESS
import com.kingfisher.marketplace.metrics.MetricsTags.TENANT
import io.micrometer.core.instrument.*
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.eq
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import org.springframework.util.StopWatch
import java.util.concurrent.TimeUnit

private val TEST_TENANT: String = "BQUK"

@ExtendWith(MockitoExtension::class)
class CustomMetricsTest {

    @Mock
    private lateinit var counter: Counter

    @Mock
    private lateinit var timer: Timer

    @Mock
    private lateinit var stopWatch: StopWatch

    @Mock
    private lateinit var meterRegistry: MeterRegistry

    @InjectMocks
    private lateinit var customMetrics: CustomMetrics

    @Test
    fun `should increment counter`() {
        val metric = "TEST_METRIC"
        whenever(meterRegistry.counter(metric)).thenReturn(counter)

        customMetrics.incrementCounter(metric)

        verify(meterRegistry).counter(metric)
        verify(counter).increment()
    }

    @Test
    fun `should start timer`() {
        val stopWatch = customMetrics.startTimer()
        assertThat(stopWatch.isRunning).isTrue
    }

    @Test
    fun `should record JMS time`() {
        whenever(stopWatch.totalTimeMillis).thenReturn(100)
        whenever(meterRegistry.timer(eq(PROCESS_JMS_ORDER), any<String>(), any<String>(), any<String>(), any<String>())).thenReturn(timer)

        customMetrics.recordJmsResult(stopWatch, SUCCESS, TEST_TENANT)

        verify(stopWatch).stop()
        verify(meterRegistry).timer(PROCESS_JMS_ORDER, RESULT, SUCCESS, TENANT, TEST_TENANT)
        verify(timer).record(100, TimeUnit.MILLISECONDS)
    }

    @Test
    fun `should record JMS line result`() {
        whenever(meterRegistry.counter(eq(PROCESS_JMS_ORDER_LINE), any<String>(), any<String>(), any<String>(), any<String>())).thenReturn(counter)

        customMetrics.recordJmsLineResult(SUCCESS, TEST_TENANT)

        verify(meterRegistry).counter(PROCESS_JMS_ORDER_LINE, RESULT, SUCCESS, TENANT, TEST_TENANT)
        verify(counter).increment()
    }
}
