package com.kingfisher.marketplace.service

import ReturnLineResponse
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.constant.ReturnType.RETURN_TO_STORE
import com.kingfisher.marketplace.constant.Status.LABEL_PRINTING_REQUESTED
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.OrderNotFoundException
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_DPD_CONFIRMED
import com.kingfisher.marketplace.metrics.RETURN_I_FORCE_CONFIRMED
import com.kingfisher.marketplace.model.*
import com.kingfisher.marketplace.model.carrierBooking.CarrierBookingResponse
import com.kingfisher.marketplace.model.carrierBooking.OrderMastersResponse
import com.kingfisher.marketplace.model.product.Technical
import com.kingfisher.marketplace.model.product.TechnicalAttributes
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.transformer.ApiModelTransfomer
import com.kingfisher.marketplace.utils.*
import com.kingfisher.marketplace.utils.DateTimeUtils.Companion.fetchTimeInMs
import com.mirakl.client.core.exception.MiraklApiException
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode.GBP
import org.apache.commons.lang3.StringUtils.EMPTY
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.anyOrNull
import org.mockito.kotlin.never
import org.mockito.kotlin.verifyNoInteractions
import org.mockito.kotlin.whenever
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension
import java.lang.System.currentTimeMillis
import java.math.BigDecimal
import java.math.BigDecimal.TEN
import java.time.LocalDateTime.now

private const val TEST_TENANT = "BQUK"
private const val TEST_STORE_ID = "testStoreId"
private const val EAN_WITH_PRODUCT_WIDTH = "4974019974408"
private const val TEST_QUANTITY_1 = 3L
private const val TEST_QUANTITY_2 = 1L
private const val TEST_QUANTITY_4 = 5L
private const val TEST_LINE_NUMBER_1 = 1L
private const val TEST_LINE_NUMBER_2 = 2L
private const val TEST_LINE_NUMBER_3 = 3L
private const val TEST_LINE_NUMBER_4 = 4L
private const val TEST_LINE_NUMBER_5 = 5L
private const val TEST_LINE_NUMBER_6 = 6L
private const val TEST_ORIGINAL_ORDER_LINE_NUMBER_1 = 3L
private const val TEST_ORIGINAL_ORDER_LINE_NUMBER_4 = 4L
private const val TEST_ORDER_NUMBER = 1234L
private const val TEST_LOGISTICAL_ORDER_NUMBER = "7002-A"
private const val TEST_TYPE = "testType"
private const val TEST_USER_ID = "testUserId"
private const val TEST_EAN_2 = "testEan2"
private const val TEST_REASON_CODE = "testReasonCode"
private val TEST_PRICE_1 = BigDecimal(30L)
private const val TEST_TRACKING_ID = "12432"
private const val TEST_TRACKING_LINK = "Track2323"
private const val TEST_DPD_PARCEL_TRACKING_URL_PATTERN = "http://abc@tacking.com/{trackingNumber}"
private const val NOTIFICATION_MESSAGE_DPD =
    "Product name-Sharp YC-MS01U-S 20L 800W Microwave - Silver, ean - 4974019974408, quantity - 5, reason - test reason, trackingLink - http://abc@tacking.com/Track2323"
private const val TEST_IFORCE_REASON_PRODUCT_WEIGHT = "Product_weight"
private val TEST_LAST_UPDATED = now()
private const val RETURN_TYPE_DELIVERY_FAILED = "DELIVERY_FAILED"
private const val RETURN_TYPE_COLLECTION_EXPIRED = "COLLECTION_EXPIRED"

@ExtendWith(*arrayOf(MockitoExtension::class, OutputCaptureExtension::class))
class ReturnBusinessServiceTest {
    private lateinit var returnBusinessService: ReturnBusinessService
    private lateinit var returnLine1: ReturnLine
    private lateinit var returnLine2: ReturnLine
    private lateinit var returnLine3: ReturnLine
    private lateinit var returnLine4: ReturnLine
    private lateinit var returnLine5: ReturnLine
    private lateinit var returnLine6: ReturnLine
    private lateinit var returnLine7: ReturnLine
    private lateinit var returnLineResponse: ReturnLineResponse
    private lateinit var confirmReturnResponse: ConfirmReturnResponse
    private lateinit var carrierBookingResponse: CarrierBookingResponse

    @Mock
    private lateinit var returnLineRepositoryMock: ReturnLineRepository

    @Mock
    private lateinit var dataTransformerMock: ApiModelTransfomer

    @Mock
    private lateinit var miraklAPIServiceMock: MiraklAPIService

    @Mock
    private lateinit var configPropertiesMock: ConfigProperties

    @Mock
    private lateinit var customMetricsMock: CustomMetrics

    @Mock
    private lateinit var orderMaster: OrderMastersResponse

    @Mock
    private lateinit var sellerContentBuilderMock: SellerContentBuilder

    @BeforeEach
    fun setUp() {
        returnBusinessService =
            ReturnBusinessService(
                returnLineRepositoryMock,
                dataTransformerMock,
                miraklAPIServiceMock,
                sellerContentBuilderMock,
                configPropertiesMock,
                customMetricsMock
            )
        setUpReturnLine()
        setUpReturnLineResponse()
        setUpLabelPrintingResponse()
        this.carrierBookingResponse = CarrierBookingResponse(arrayListOf(orderMaster))
    }

    private fun setUpReturnLine() {
        this.returnLine1 =
            ReturnLine(
                returnOrderNumber = TEST_ORDER_NUMBER,
                lineNumber = TEST_LINE_NUMBER_1,
                originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_1,
                tenant = TEST_TENANT,
                route = TBC.name,
                status = EMPTY,
                ean = EAN_WITH_PRODUCT_WIDTH,
                quantity = TEST_QUANTITY_1,
                unitPrice = TEN,
                returnDate = "123",
                returnDateInMilliSecond = 122L,
                refundCreated = false,
                storeId = TEST_STORE_ID,
                createdBy = "SYSTEM",
                actionedBy = "ACTION_BY",
                returnReasonCode = TEST_REASON_CODE,
                reasonForIForce = EMPTY,
                storeAddress = EMPTY,
                offerId = EMPTY,
                shopId = EMPTY,
                logisticalOrderId = TEST_LOGISTICAL_ORDER_NUMBER,
                recipientAddress = EMPTY,
                customerId = EMPTY,
                technicalAttributes =
                    TechnicalAttributes(
                        listOf(Technical(EMPTY, EMPTY, EMPTY, EMPTY, EMPTY)),
                        listOf(Technical(EMPTY, EMPTY, EMPTY, EMPTY, EMPTY)),
                    ),
                returnType = RETURN_TO_STORE.name
            )

        this.returnLine2 =
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_2,
                tenant = TEST_TENANT,
                returnOrderNumber = TEST_ORDER_NUMBER,
                route = TBC.name,
                quantity = TEST_QUANTITY_1,
                logisticalOrderId = TEST_LOGISTICAL_ORDER_NUMBER,
                returnReasonCode = TEST_REASON_CODE,
                ean = TEST_EAN_2,
                refundCreated = false,
                returnType = RETURN_TO_STORE.name
            )
        this.returnLine3 =
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_3,
                tenant = TEST_TENANT,
                returnOrderNumber = TEST_ORDER_NUMBER,
                route = IFORCE.value,
                quantity = TEST_QUANTITY_1,
                logisticalOrderId = TEST_LOGISTICAL_ORDER_NUMBER,
                returnReasonCode = TEST_REASON_CODE,
                ean = EAN_WITH_PRODUCT_WIDTH,
                refundCreated = false,
                returnType = RETURN_TO_STORE.name
            )
        this.returnLine4 =
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_4,
                returnOrderNumber = TEST_ORDER_NUMBER,
                route = ROUTE.DPD.value,
                tenant = TEST_TENANT,
                quantity = TEST_QUANTITY_4,
                logisticalOrderId = TEST_ORDER_NUMBER.toString(),
                returnReasonCode = TEST_REASON_CODE,
                ean = EAN_WITH_PRODUCT_WIDTH,
                refundCreated = false,
                totalPrice = TEST_PRICE_1,
                originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
                parcelTrackingInfo = listOf(
                    ParcelTrackingInfo(
                        1,
                        TEST_TRACKING_ID, TEST_TRACKING_LINK
                    )
                ),
                productName = "Sharp YC-MS01U-S 20L 800W Microwave - Silver",
                currencyIsoCode = GBP.toString()
            )
        this.returnLine5 =
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_5,
                status = LABEL_PRINTING_REQUESTED.name,
                returnOrderNumber = TEST_ORDER_NUMBER,
                tenant = TEST_TENANT,
                reasonForIForce = TEST_IFORCE_REASON_PRODUCT_WEIGHT,
                route = IFORCE.value,
                quantity = TEST_QUANTITY_2,
                logisticalOrderId = TEST_ORDER_NUMBER.toString(),
                totalPrice = TEST_PRICE_1,
                returnReasonCode = TEST_REASON_CODE,
                ean = EAN_WITH_PRODUCT_WIDTH,
                refundCreated = true,
                returnType = RETURN_TYPE_COLLECTION_EXPIRED,
                originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
                productName = "Sharp YC-MS01U-S 20L 800W Microwave - Silver",
                currencyIsoCode = GBP.toString()
            )
        this.returnLine6 =
            ReturnLine(
                lineNumber = TEST_LINE_NUMBER_6,
                tenant = TEST_TENANT,
                status = LABEL_PRINTING_REQUESTED.name,
                returnOrderNumber = TEST_ORDER_NUMBER,
                reasonForIForce = TEST_IFORCE_REASON_PRODUCT_WEIGHT,
                route = IFORCE.value,
                quantity = TEST_QUANTITY_2,
                logisticalOrderId = TEST_ORDER_NUMBER.toString(),
                totalPrice = TEST_PRICE_1,
                returnReasonCode = TEST_REASON_CODE,
                ean = EAN_WITH_PRODUCT_WIDTH,
                refundCreated = false,
                returnType = RETURN_TYPE_DELIVERY_FAILED,
                originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
                productName = "Sharp YC-MS01U-S 20L 800W Microwave - Silver"
            )
        this.returnLine7 = ReturnLine(
            lineNumber = TEST_LINE_NUMBER_4,
            returnOrderNumber = TEST_ORDER_NUMBER,
            tenant = TEST_TENANT,
            route = ROUTE.DPD.value,
            quantity = TEST_QUANTITY_4,
            logisticalOrderId = TEST_ORDER_NUMBER.toString(),
            returnReasonCode = TEST_REASON_CODE,
            ean = EAN_WITH_PRODUCT_WIDTH,
            refundCreated = true,
            totalPrice = TEST_PRICE_1,
            originalOrderLineNumber = TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
            parcelTrackingInfo = listOf(
                ParcelTrackingInfo(
                    1,
                    TEST_TRACKING_ID, TEST_TRACKING_LINK
                )
            ),
            productName = "Sharp YC-MS01U-S 20L 800W Microwave - Silver",
            currencyIsoCode = GBP.toString()
        )
    }

    private fun setUpReturnLineResponse() {
        this.returnLineResponse =
            ReturnLineResponse(
                ReturnData(
                    attributes =
                        ReturnDataAttributes(
                            listOf(ReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)),
                        ),
                ),
            )
    }

    private fun setUpLabelPrintingResponse() {
        this.confirmReturnResponse =
            ConfirmReturnResponse(
                ConfirmReturnResponseData(
                    attributes =
                        ConfirmReturnResponseAttributes(
                            ReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4),
                        ),
                ),
            )
    }

    @Test
    fun shouldFetchRecordsInGivenTimeRangeForSpecificStoreAndTenant() {
        val dateTo = now()
        val dateFrom = now().minusHours(1)
        val returnLines = mutableListOf(this.returnLine1)
        `when`(
            this.returnLineRepositoryMock.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
                TEST_TENANT,
                TEST_STORE_ID,
                fetchTimeInMs(dateFrom),
                fetchTimeInMs(dateTo),
            ),
        ).thenReturn(returnLines)
        `when`(this.dataTransformerMock.transformToReturnLineResponse(returnLines)).thenReturn(this.returnLineResponse)
        val result =
            this.returnBusinessService.fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant(
                TEST_TENANT,
                TEST_STORE_ID,
                dateFrom,
                dateTo,
            )!!.data.attributes.lines[0]

        assertThat(result.lineNumber).isEqualTo(TEST_LINE_NUMBER_1)
        assertThat(result.returnOrderNumber).isEqualTo(TEST_ORDER_NUMBER)
    }

    @Test
    fun shouldCreateRefundAndUpdateStatusForDPD() {
        whenever(
            this.configPropertiesMock.parcelTrackingUrlPattern,
        ).thenReturn(mapOf(ROUTE.DPD.value to TEST_DPD_PARCEL_TRACKING_URL_PATTERN))
        whenever(sellerContentBuilderMock.buildSellerNotificationContent(anyString(), anyString(), anyString(), anyString(), anyLong(), anyString(), anyString(), anyString(), anyString(), anyString(),
            anyOrNull()
        ))
            .thenReturn(NOTIFICATION_MESSAGE_DPD)
        val confirmReturnRequest =
            setUpRequestToConfirmReturnForDPD(this.returnLine4)

        val result =
            this.returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4, confirmReturnRequest)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4)
        verify(
            this.miraklAPIServiceMock,
        ).createRefund(
            TEST_PRICE_1,
            TEST_QUANTITY_4,
            TEST_ORDER_NUMBER.toString(),
            TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(
            this.miraklAPIServiceMock,
        ).notifySeller(
            TEST_ORDER_NUMBER.toString(),
            NOTIFICATION_MESSAGE_DPD,
            TEST_TENANT
        )
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine4.route).isEqualTo(ROUTE.DPD.value)
        assertThat(returnLine4.refundCreated).isTrue
        assertThat(returnLine4.reasonForIForce).isEmpty()
        assertThat(returnLine4.status).isEqualTo(LABEL_PRINTING_REQUESTED.toString())
        assertThat(returnLine4.labelPrintingRequestedBy).isEqualTo(TEST_USER_ID)
        assertThat(returnLine4.parcelTrackingInfo.get(0).trackingNumber).isEqualTo(TEST_TRACKING_LINK)
        assertThat(returnLine4.parcelTrackingInfo.get(0).externalParcelIdentifier).isEqualTo(TEST_TRACKING_ID)
        verify(this.customMetricsMock).incrementCounter(RETURN_DPD_CONFIRMED)
    }

    @Test
    fun shouldUpdateStatusForIForce() {
        `when`(
            this.returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1),
        ).thenReturn(this.returnLine3)
        `when`(
            this.dataTransformerMock.transformToReturnLineResponse(this.returnLine3),
        ).thenReturn(this.confirmReturnResponse)
        val confirmReturnRequest =
            ConfirmReturnRequest(
                ConfirmReturnRequestData(
                    TEST_TYPE,
                    ConfirmReturnRequestAttributes(
                        TEST_USER_ID,
                    ),
                ),
            )

        val result =
            this.returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1, confirmReturnRequest)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)
        verifyNoInteractions(miraklAPIServiceMock)
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine3.route).isEqualTo(IFORCE.value)
        assertThat(returnLine3.status).isEqualTo(LABEL_PRINTING_REQUESTED.toString())
        assertThat(returnLine3.labelPrintingRequestedBy).isEqualTo(TEST_USER_ID)
        assertThat(returnLine3.returnType).isEqualTo(RETURN_TO_STORE.name)
        verify(this.customMetricsMock).incrementCounter(RETURN_I_FORCE_CONFIRMED)
    }

    @Test
    fun `should update lastUpdated when returnLine is found`() {
        `when`(
            this.returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1),
        ).thenReturn(this.returnLine3)
        `when`(
            this.dataTransformerMock.transformToReturnLineResponse(this.returnLine3),
        ).thenReturn(this.confirmReturnResponse)

        val result =
            this.returnBusinessService.updateLastUpdated(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1, TEST_LAST_UPDATED)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine3.lastUpdated).contains(now().year.toString())
        assertThat(returnLine3.lastUpdatedInMilliSecond).isLessThanOrEqualTo(currentTimeMillis())
    }

    @Test
    fun `should fetch all return lines`() {
        assertThat(
            this.returnBusinessService.fetchAllReturnLines()
        ).isEmpty()
        verify(this.returnLineRepositoryMock).fetchAllLines()
    }

    @Test
    fun `should throw OrderNotFoundException when returnLine is not found during confirm return`() {
        val confirmReturnRequest =
            ConfirmReturnRequest(
                ConfirmReturnRequestData(
                    TEST_TYPE,
                    ConfirmReturnRequestAttributes(
                        TEST_USER_ID,
                        listOf(
                            ParcelTrackingInfo(TEST_QUANTITY_4, TEST_TRACKING_ID, TEST_TRACKING_LINK)
                        ),
                    ),
                ),
            )
        `when`(returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(null)
        assertThrows(OrderNotFoundException::class.java) {
            returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1, confirmReturnRequest)
        }
    }

    @Test
    fun `should throw OrderNotFoundException when returnLine is not found during updating lastUpdated`() {
        `when`(returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)).thenReturn(null)
        assertThrows(OrderNotFoundException::class.java) {
            returnBusinessService.updateLastUpdated(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1, TEST_LAST_UPDATED)
        }
    }

    @Test
    fun `should delete return line`() {
        this.returnBusinessService.deleteReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)

        verify(this.returnLineRepositoryMock).deleteReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)
    }

    @Test
    fun `should delete all lines of return order`() {
        `when`(this.returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(
            mutableListOf(
                this.returnLine1,
                this.returnLine2
            )
        )

        this.returnBusinessService.deleteAllLineAssociatedWithReturnOrder(TEST_ORDER_NUMBER)

        verify(this.returnLineRepositoryMock).fetchItemsByHashKey(TEST_ORDER_NUMBER)
        verify(this.returnLineRepositoryMock).deleteReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_1)
        verify(this.returnLineRepositoryMock).deleteReturnLine(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_2)
    }

    @Test
    fun `should throw OrderNotFoundException if no line present for given return order`() {
        `when`(this.returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(mutableListOf())

        assertThatThrownBy { this.returnBusinessService.deleteAllLineAssociatedWithReturnOrder(TEST_ORDER_NUMBER) }.isInstanceOf(
            OrderNotFoundException::class.java
        )

        verify(this.returnLineRepositoryMock).fetchItemsByHashKey(TEST_ORDER_NUMBER)
        verify(this.returnLineRepositoryMock, never()).deleteReturnLine(anyLong(), anyLong())
    }

    @Test
    fun `should create refund but log error if notify seller is not successful`(output: CapturedOutput) {
        whenever(
            this.configPropertiesMock.parcelTrackingUrlPattern,
        ).thenReturn(mapOf(ROUTE.DPD.value to TEST_DPD_PARCEL_TRACKING_URL_PATTERN))
        whenever(sellerContentBuilderMock.buildSellerNotificationContent(anyString(), anyString(), anyString(), anyString(), anyLong(), anyString(), anyString(), anyString(), anyString(), anyString(), anyOrNull()))
            .thenReturn(NOTIFICATION_MESSAGE_DPD)
        whenever(
            this.miraklAPIServiceMock.notifySeller(
                TEST_ORDER_NUMBER.toString(),
                NOTIFICATION_MESSAGE_DPD,
                TEST_TENANT
            )
        ).thenThrow(MiraklApiException::class.java)

        assertThat(
            returnBusinessService.confirmReturn(
                TEST_ORDER_NUMBER,
                TEST_LINE_NUMBER_4,
                setUpRequestToConfirmReturnForDPD(this.returnLine4)
            )
        ).isEqualTo(confirmReturnResponse)
        assertThat(output).contains("Error while creating refund or notify seller for line $TEST_ORIGINAL_ORDER_LINE_NUMBER_4 of order $TEST_ORDER_NUMBER due to exception")
        verifyDPDLinesWhileConfirmingReturn()
        verify(
            this.miraklAPIServiceMock,
        ).notifySeller(
            TEST_ORDER_NUMBER.toString(),
            NOTIFICATION_MESSAGE_DPD,
            TEST_TENANT
        )
        assertThat(returnLine4.refundCreated).isTrue
    }

    @Test
    fun `should not update createRefund if create refund is failed in Mirakl`(output: CapturedOutput) {
        `when`(
            this.miraklAPIServiceMock.createRefund(
                TEST_PRICE_1,
                TEST_QUANTITY_4,
                TEST_ORDER_NUMBER.toString(),
                TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
                TEST_REASON_CODE,
                GBP.toString(),
                TEST_TENANT
            )
        ).thenThrow(MiraklApiException::class.java)

        assertThat(
            returnBusinessService.confirmReturn(
                TEST_ORDER_NUMBER,
                TEST_LINE_NUMBER_4,
                setUpRequestToConfirmReturnForDPD(this.returnLine4)
            )
        ).isEqualTo(confirmReturnResponse)
        assertThat(output).contains("Error while creating refund or notify seller for line $TEST_ORIGINAL_ORDER_LINE_NUMBER_4 of order $TEST_ORDER_NUMBER due to exception")
        verifyDPDLinesWhileConfirmingReturn()
        verify(
            this.miraklAPIServiceMock, never()
        ).notifySeller(
            TEST_ORDER_NUMBER.toString(),
            NOTIFICATION_MESSAGE_DPD,
            TEST_TENANT
        )
        assertThat(returnLine4.refundCreated).isFalse
    }

    @Test
    fun `should increase failed refund counter for DPD if create refund is failed in Mirakl`(output: CapturedOutput) {
        `when`(
            this.miraklAPIServiceMock.createRefund(
                TEST_PRICE_1,
                TEST_QUANTITY_4,
                TEST_ORDER_NUMBER.toString(),
                TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
                TEST_REASON_CODE,
                GBP.toString(),
                TEST_TENANT
            )
        ).thenThrow(MiraklApiException::class.java)
        assertThat(
            returnBusinessService.confirmReturn(
                TEST_ORDER_NUMBER,
                TEST_LINE_NUMBER_4,
                setUpRequestToConfirmReturnForDPD(this.returnLine4)
            )
        ).isEqualTo(confirmReturnResponse)
        assertThat(output).contains("Error while creating refund or notify seller for line $TEST_ORIGINAL_ORDER_LINE_NUMBER_4 of order $TEST_ORDER_NUMBER due to exception")
        verifyDPDLinesWhileConfirmingReturn()
        verify(
            this.miraklAPIServiceMock, never()
        ).notifySeller(
            TEST_ORDER_NUMBER.toString(),
            NOTIFICATION_MESSAGE_DPD,
            TEST_TENANT
        )
        assertThat(returnLine4.refundCreated).isFalse
    }

    private fun setUpRequestToConfirmReturnForDPD(returnLine: ReturnLine): ConfirmReturnRequest {
        `when`(
            this.returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4),
        ).thenReturn(returnLine)
        `when`(
            this.dataTransformerMock.transformToReturnLineResponse(returnLine),
        ).thenReturn(this.confirmReturnResponse)
        val confirmReturnRequest =
            ConfirmReturnRequest(
                ConfirmReturnRequestData(
                    TEST_TYPE,
                    ConfirmReturnRequestAttributes(
                        TEST_USER_ID,
                        listOf(
                            ParcelTrackingInfo(TEST_QUANTITY_4, TEST_TRACKING_ID, TEST_TRACKING_LINK)
                        ),
                    ),
                ),
            )
        return confirmReturnRequest
    }

    private fun setUpRequestToConfirmReturnForIForce(iForceReturnLine: ReturnLine): ConfirmReturnRequest {
        `when`(
            this.returnLineRepositoryMock.fetchReturnItem(TEST_ORDER_NUMBER, iForceReturnLine.lineNumber),
        ).thenReturn(iForceReturnLine)
        `when`(
            this.dataTransformerMock.transformToReturnLineResponse(iForceReturnLine),
        ).thenReturn(this.confirmReturnResponse)
        val confirmReturnRequest =
            ConfirmReturnRequest(
                ConfirmReturnRequestData(
                    TEST_TYPE,
                    ConfirmReturnRequestAttributes(
                        TEST_USER_ID,
                        listOf(),
                    ),
                ),
            )
        return confirmReturnRequest
    }

    private fun verifyDPDLinesWhileConfirmingReturn() {
        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4)
        verify(
            this.miraklAPIServiceMock,
        ).createRefund(
            TEST_PRICE_1,
            TEST_QUANTITY_4,
            TEST_ORDER_NUMBER.toString(),
            TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        assertThat(returnLine4.route).isEqualTo(ROUTE.DPD.value)
        assertThat(returnLine4.reasonForIForce).isEmpty()
        assertThat(returnLine4.status).isEqualTo(LABEL_PRINTING_REQUESTED.toString())
        assertThat(returnLine4.labelPrintingRequestedBy).isEqualTo(TEST_USER_ID)
        assertThat(returnLine4.parcelTrackingInfo[0].trackingNumber).isEqualTo(TEST_TRACKING_LINK)
        assertThat(returnLine4.parcelTrackingInfo[0].externalParcelIdentifier).isEqualTo(TEST_TRACKING_ID)
    }

    @Test
    fun `should fetch all lines of return order`() {
        val returnLines = mutableListOf(
            this.returnLine1,
            this.returnLine2
        )
        `when`(this.returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(
            returnLines
        )
        `when`(this.dataTransformerMock.transformToReturnLineResponse(returnLines)).thenReturn(ReturnLineResponse())

        val result = this.returnBusinessService.fetchAllLineDetailsAssociatedWithReturnOrder(TEST_ORDER_NUMBER)

        assertThat(result).isNotNull
        assertThat(result.data.type).isEqualTo("returnLines")
        verify(this.returnLineRepositoryMock).fetchItemsByHashKey(TEST_ORDER_NUMBER)
    }

    @Test
    fun `should throw OrderNotFoundException if no line present for given return order while fetching details`() {
        `when`(this.returnLineRepositoryMock.fetchItemsByHashKey(TEST_ORDER_NUMBER)).thenReturn(mutableListOf())

        assertThatThrownBy { this.returnBusinessService.fetchAllLineDetailsAssociatedWithReturnOrder(TEST_ORDER_NUMBER) }.isInstanceOf(
            OrderNotFoundException::class.java
        )

        verify(this.returnLineRepositoryMock).fetchItemsByHashKey(TEST_ORDER_NUMBER)
    }

    @Test
    fun `should not update metric is route is neither iForce nor DPD`() {
        val confirmReturnRequest =
            setUpRequestToConfirmReturnForDPD(this.returnLine4)
        this.returnLine4.route = TBC.value
        this.returnLine4.refundCreated = true

        returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4, confirmReturnRequest)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4)
        verify(this.customMetricsMock, never()).incrementCounter(anyString())
    }

    @Test
    fun `should not create refund for iForce incase of any other events apart form collection expiry`() {
        val confirmReturnRequest =
            setUpRequestToConfirmReturnForIForce(returnLine6)

        val result =
            this.returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_6, confirmReturnRequest)
        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_6)
        verify(
            this.miraklAPIServiceMock, never()
        ).createRefund(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()
        )
        verify(
            this.miraklAPIServiceMock, never()
        ).notifySeller(
            any(),
            any(),
            any()
        )
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine6.route).isEqualTo(IFORCE.value)
        assertThat(returnLine6.refundCreated).isFalse()
    }

    @Test
    fun `should not create refund for iForce if refund is already created`() {
        val confirmReturnRequest =
            setUpRequestToConfirmReturnForIForce(returnLine5)

        val result =
            this.returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_5, confirmReturnRequest)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_5)
        verify(
            this.miraklAPIServiceMock, never()
        ).createRefund(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()
        )
        verify(
            this.miraklAPIServiceMock, never()
        ).notifySeller(
            any(),
            any(),
            any()
        )
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine5.route).isEqualTo(IFORCE.value)
        assertThat(returnLine5.refundCreated).isTrue
        assertThat(returnLine5.reasonForIForce).isEqualTo(TEST_IFORCE_REASON_PRODUCT_WEIGHT)
        assertThat(returnLine5.status).isEqualTo(LABEL_PRINTING_REQUESTED.toString())
        verify(this.customMetricsMock).incrementCounter(RETURN_I_FORCE_CONFIRMED)
    }

    @Test
    fun shouldNotCreateRefundForDPDIfAlreadyCreatedDuringConfirmRoute() {
        whenever(
            this.configPropertiesMock.parcelTrackingUrlPattern,
        ).thenReturn(mapOf(ROUTE.DPD.value to TEST_DPD_PARCEL_TRACKING_URL_PATTERN))
        whenever(sellerContentBuilderMock.buildSellerNotificationContent(anyString(), anyString(), anyString(), anyString(), anyLong(), anyString(), anyString(), anyString(), anyString(), anyString(), anyOrNull()))
            .thenReturn(NOTIFICATION_MESSAGE_DPD)
        val confirmReturnRequest =
            setUpRequestToConfirmReturnForDPD(this.returnLine7)

        val result =
            this.returnBusinessService.confirmReturn(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4, confirmReturnRequest)

        verify(this.returnLineRepositoryMock).fetchReturnItem(TEST_ORDER_NUMBER, TEST_LINE_NUMBER_4)
        verify(
            this.miraklAPIServiceMock, never()
        ).createRefund(
            TEST_PRICE_1,
            TEST_QUANTITY_4,
            TEST_ORDER_NUMBER.toString(),
            TEST_ORIGINAL_ORDER_LINE_NUMBER_4,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(
            this.miraklAPIServiceMock,
        ).notifySeller(
            TEST_ORDER_NUMBER.toString(),
            NOTIFICATION_MESSAGE_DPD,
            TEST_TENANT
        )
        assertThat(result).isEqualTo(confirmReturnResponse)
        assertThat(returnLine7.route).isEqualTo(ROUTE.DPD.value)
        assertThat(returnLine7.refundCreated).isTrue
        assertThat(returnLine7.reasonForIForce).isEmpty()
        assertThat(returnLine7.status).isEqualTo(LABEL_PRINTING_REQUESTED.toString())
        assertThat(returnLine7.labelPrintingRequestedBy).isEqualTo(TEST_USER_ID)
        assertThat(returnLine7.parcelTrackingInfo.get(0).trackingNumber).isEqualTo(TEST_TRACKING_LINK)
        assertThat(returnLine7.parcelTrackingInfo.get(0).externalParcelIdentifier).isEqualTo(TEST_TRACKING_ID)
        verify(this.customMetricsMock).incrementCounter(RETURN_DPD_CONFIRMED)
    }

    @Test
    fun `should fetch orders`() {
        val expectedResponse = FetchOrdersResponse(
            orders = listOf(returnLine1, returnLine2),
            nextCursor = "next-cursor"
        )

        whenever(
            returnLineRepositoryMock.fetchOrders(
                TEST_TENANT,
                2,
                null
            )
        ).thenReturn(expectedResponse)

        val result = returnBusinessService.fetchOrders(
            Tenant.BQUK,
            2,
            null
        )

        assertThat(result).isEqualTo(expectedResponse)

        verify(returnLineRepositoryMock).fetchOrders(
            TEST_TENANT,
            2,
            null
        )
    }
}
