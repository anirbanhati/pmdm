package com.kingfisher.marketplace.service.tenant

import com.kingfisher.marketplace.constant.Constant.Companion.REASON_FOR_IFORCE
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_I_FORCE_AUTO
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_CURRENT_ADDED
import com.kingfisher.marketplace.metrics.RETURN_ROUTE_TBC_TOTAL
import com.kingfisher.marketplace.model.domain.SalesOrderInfo
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.service.IForceRouteValidator
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension
import org.mockito.kotlin.any
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import java.math.BigDecimal

@ExtendWith(MockitoExtension::class)
class BQRouteProviderTest {

    @Mock
    private lateinit var salesOrderInfo: SalesOrderInfo

    @Mock
    private lateinit var attributes: Attributes

    @Mock
    private lateinit var iForceRouteValidator: IForceRouteValidator

    @Mock
    private lateinit var customMetrics: CustomMetrics

    @InjectMocks
    private lateinit var provider: BQRouteProvider

    @Test
    fun `should return iForce on non empty map`() {
        val reason = "reason"
        whenever(salesOrderInfo.storeId).thenReturn("1233")
        whenever(salesOrderInfo.totalPrice).thenReturn(BigDecimal.ONE)
        whenever(salesOrderInfo.productAttributes).thenReturn(attributes)
        whenever(iForceRouteValidator.validate(any<BigDecimal>(), any<Attributes>(), any<String>()))
            .thenReturn(mapOf(REASON_FOR_IFORCE to reason))

        val result = provider.provide(salesOrderInfo)

        assertThat(result.route).isEqualTo(ROUTE.IFORCE.value)
        assertThat(result.status).isEqualTo(Status.AWAITING_LABEL_PRINTING.name)
        assertThat(result.reasonForIForce).isEqualTo(reason)
        verify(customMetrics).incrementCounter(RETURN_ROUTE_I_FORCE_AUTO)
    }

    @Test
    fun `should return TBC on empty map`() {
        whenever(salesOrderInfo.storeId).thenReturn("1233")
        whenever(salesOrderInfo.totalPrice).thenReturn(BigDecimal.ONE)
        whenever(salesOrderInfo.productAttributes).thenReturn(attributes)
        whenever(iForceRouteValidator.validate(any<BigDecimal>(), any<Attributes>(), any<String>()))
            .thenReturn(emptyMap())

        val result = provider.provide(salesOrderInfo)

        assertThat(result.route).isEqualTo(ROUTE.TBC.value)
        assertThat(result.status).isEqualTo(Status.AWAITING_STORE_CONFIRMATION.name)
        assertThat(result.reasonForIForce).isEqualTo("")
        verify(customMetrics).incrementCounter(RETURN_ROUTE_TBC_TOTAL)
        verify(customMetrics).incrementCounter(RETURN_ROUTE_TBC_CURRENT_ADDED)
    }
}
