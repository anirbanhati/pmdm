package com.kingfisher.marketplace.kafka.consumer

import com.fasterxml.jackson.databind.ObjectMapper
import com.kingfisher.marketplace.config.ConfigProperties
import com.kingfisher.marketplace.config.dynamodb.configProperties.DynamoDBConfigProperties
import com.kingfisher.marketplace.config.mirakl.MiraklClientConfigTest
import com.kingfisher.marketplace.config.testcontainer.AwsConfig
import com.kingfisher.marketplace.config.testcontainer.DynamoDBConfigTest
import com.kingfisher.marketplace.config.testcontainer.TestContainersConfig
import com.kingfisher.marketplace.constant.ROUTE
import com.kingfisher.marketplace.constant.ROUTE.IFORCE
import com.kingfisher.marketplace.constant.ROUTE.TBC
import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Status.AWAITING_LABEL_PRINTING
import com.kingfisher.marketplace.constant.Status.AWAITING_STORE_CONFIRMATION
import com.kingfisher.marketplace.mapper.ReturnLineMapper
import com.kingfisher.marketplace.metrics.CustomMetrics
import com.kingfisher.marketplace.model.product.Attributes
import com.kingfisher.marketplace.model.product.ProductAPIResponse
import com.kingfisher.marketplace.repository.ReturnLineRepository
import com.kingfisher.marketplace.service.IForceRouteValidator
import com.kingfisher.marketplace.service.MiraklAPIService
import com.kingfisher.marketplace.service.PickEventService
import com.kingfisher.marketplace.service.ProductApiQueryService
import com.kingfisher.marketplace.service.ReturnLineService
import com.kingfisher.marketplace.service.SellerContentBuilder
import com.kingfisher.orderManagement.avro.Amendment
import com.kingfisher.orderManagement.avro.BespokeType
import com.kingfisher.orderManagement.avro.BomType
import com.kingfisher.orderManagement.avro.Channel
import com.kingfisher.orderManagement.avro.Customer
import com.kingfisher.orderManagement.avro.FulfilmentType
import com.kingfisher.orderManagement.avro.Metadata
import com.kingfisher.orderManagement.avro.MonetaryAmount
import com.kingfisher.orderManagement.avro.OrderPaymentStatus
import com.kingfisher.orderManagement.avro.Payload
import com.kingfisher.orderManagement.avro.Payment
import com.kingfisher.orderManagement.avro.Pick
import com.kingfisher.orderManagement.avro.PickLine
import com.kingfisher.orderManagement.avro.PickLineType
import com.kingfisher.orderManagement.avro.ShippingMethodType
import com.kingfisher.orderManagement.avro.Site
import com.kingfisher.orderManagement.avro.Source
import com.kingfisher.orderManagement.avro.State
import com.kingfisher.orderManagement.avro.Tenant
import com.mirakl.client.core.exception.MiraklException
import com.mirakl.client.mmp.domain.common.currency.MiraklIsoCurrencyCode.GBP
import com.mirakl.client.mmp.domain.order.MiraklOrder
import com.mirakl.client.mmp.domain.order.state.MiraklOrderStatus
import org.apache.kafka.clients.producer.ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG
import org.apache.kafka.clients.producer.ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.ByteArraySerializer
import org.apache.kafka.common.serialization.StringSerializer
import org.assertj.core.api.Assertions.assertThat
import org.awaitility.Awaitility.await
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.kotlin.any
import org.mockito.kotlin.atLeast
import org.mockito.kotlin.eq
import org.mockito.kotlin.never
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.system.CapturedOutput
import org.springframework.boot.test.system.OutputCaptureExtension
import org.springframework.context.annotation.Import
import org.springframework.core.io.ClassPathResource
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.kafka.core.DefaultKafkaProducerFactory
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.kafka.test.EmbeddedKafkaBroker
import org.springframework.kafka.test.context.EmbeddedKafka
import org.springframework.kafka.test.utils.KafkaTestUtils.producerProps
import org.springframework.test.context.ActiveProfiles
import org.springframework.test.context.bean.override.mockito.MockitoBean
import java.nio.file.Files
import java.time.Duration
import com.kingfisher.inStoreFulfilment.avro.Allocation as InstoreAllocation
import com.kingfisher.inStoreFulfilment.avro.Channel as InstorePickChannel
import com.kingfisher.inStoreFulfilment.avro.Collection as InstoreCollection
import com.kingfisher.inStoreFulfilment.avro.Customer as InstoreCustomer
import com.kingfisher.inStoreFulfilment.avro.Metadata as InstoreMetadata
import com.kingfisher.inStoreFulfilment.avro.Payload as InstorePayload
import com.kingfisher.inStoreFulfilment.avro.Payment as InstorePayment
import com.kingfisher.inStoreFulfilment.avro.Pick as InstorePick
import com.kingfisher.inStoreFulfilment.avro.Pickline as InstorePickLines
import com.kingfisher.inStoreFulfilment.avro.Site as InstoreSite
import com.mirakl.client.mmp.domain.order.state.AbstractMiraklOrderStatus.State as MiraklOrderState

private const val TEST_EVENT_TYPE_COLLECTION_EXPIRED = "public.orderManagement.pickCollectionExpired"
private const val TEST_EVENT_TYPE_COLLECTED = "public.orderManagement.pickCollected"
private const val TEST_EVENT_TYPE_PICK_COLLECTED = "public.inStoreFulfilment.pickCollected"
private const val TEST_CREATED_BY = "system"
private const val TEST_CREATED_ON = "2025-01-14T12:39:22Z"
private const val TEST_TRACE_ID = "4251554b173685836277763940162578"
private const val TEST_CURRENCY_CODE = "GBP"
private const val TEST_SHIPPING_GROUP_ID = "sg1252"
private const val TEST_SHIPPING_GROUP_ID_PICK_COLLECTED = "1252"
private const val TEST_LOGISTICAL_ORDER_NUMBER = "7002-A"
private const val TEST_PROMISED_DATE = "2025-01-14T12:39:22Z"
private const val TEST_ORDER_ID = "1930167769"
private const val TEST_RETURN_ORDER_ID = 193016776952L
private const val TEST_ORDER_ID_1 = "9999999999"
private const val TEST_RETURN_ORDER_ID_1 = 999999999952L
private const val TEST_ORDER_ID_2 = "8888888888"
private const val TEST_RETURN_ORDER_ID_2 = 888888888852L
private const val TEST_ORDER_ID_3 = "7777777777"
private const val TEST_RETURN_ORDER_ID_3 = 777777777752L
private const val TEST_ORDER_ID_4 = "6666666666"
private const val TEST_RETURN_ORDER_ID_4 = 666666666652L
private const val TEST_ORDER_ID_5 = "5555555555"
private const val TEST_RETURN_ORDER_ID_5 = 555555555552L
private const val TEST_ORDER_ID_6 = "4444444444"
private const val TEST_RETURN_ORDER_ID_6 = 444444444452L
private const val TEST_ORDER_ID_7 = "2323232323"
private const val TEST_RETURN_ORDER_ID_7 = 232323232352L
private const val TEST_ORDER_ID_8 = "8888888888"
private const val TEST_RETURN_ORDER_ID_8 = 888888888852L
private const val TEST_ORDER_ID_9 = "1111111111"
private const val TEST_RETURN_ORDER_ID_9 = 111111111152L
private const val TEST_ORDER_ID_0 = "5252525252"
private const val TEST_RETURN_ORDER_ID_0 = 525252525222L
private const val TEST_ORDER_ID_10 = "1010101010"
private const val TEST_RETURN_ORDER_ID_10 = 101010101052L
private const val ZER_AMOUNT = 0.0
private const val AMOUNT = 2.0
private const val TEST_CUSTOMER_ID = "2000015308"
private const val TEST_CUSTOMER_NAME = "Customer Name"
private const val TEST_CUSTOMER_CONTACT = "0123456789"
private const val TEST_CARD_TYPE = "0123456789"
private const val TEST_CARD_NUMBER = "411111******1111"
private const val TEST_SITE_ID = "1358"
private const val TEST_COMMERCE_ITEM_ID = "ci11"
private const val TEST_COMMERCE_ITEM_ID_PICK_COLLECTED = "11"
private const val DIFFERENT_LINE_ITEM_ID = "22"
private const val TEST_EAN = "4974019974408"
private const val TEST_DESCRIPTION = "Varnished Hot-rolled steel Equal L-shaped Angle profile, (L)1m (W)30mm"
private const val TEST_UOM = "EA"
private const val TEST_QTY = 2
private const val TEST_LINE_NUMBER = 1L
private const val TEST_SHOP_ID = "1234"
private const val TEST_KEY = "testKey"
private const val PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT = "4974019974408.json"
private const val TEST_EVENT_TYPE_DELIVERY_EXPIRY = "public.orderManagement.pickDeliveryExpired"
private const val TEST_STATUS = "DELIVERY_EXPIRED"
private const val TEST_STATUS_COLLECTED = "COLLECTED"
private const val TEST_ROUTE = "LOST_IN_TRANSIT"
private const val NOTIFICATION_MESSAGE_LOST_IN_TRANSIT =
    "Product name-Sharp YC-MS01U-S 20L 800W Microwave - Silver, ean - 4974019974408, quantity - 2, reason - Delivery Expiry"
private const val TEST_REASON_CODE = "73"
private const val PRODUCT_AMOUNT = "Product-amount"
private const val TEST_EAN_TBC = "5056709507581"
private const val PRODUCT_API_RESPONSE_TBC = "ProductAPIResponseForTBC.json"
private const val AMOUNT_MORE_THAN_10 = 20.0
private const val UNITP_RICE_10 = 10
private const val RETURN_TYPE_COLLECTION_EXPIRED = "COLLECTION_EXPIRED"
private const val STATUS_CANCELLED = "CANCELLED"
private const val COMMAND_ID = "None"
private const val NOT_SETTLED = "NOT_SETTLED"
private const val TEST_CHANNEL_SOURCE = "Web"
private const val NONE = "None"
private const val TEST_PICK_LINE_TYPE = "Standard"
private const val TEST_ALLOCATION = "fullyAllocated"
private const val TEST_EVENT_ID = "12879"
private const val TEST_TENANT = "BQUK"

@SpringBootTest(
    classes = [
        PickEventConsumer::class,
        PickEventService::class,
        ReturnLineService::class,
        ReturnLineMapper::class,
        ReturnLineRepository::class,
        IForceRouteValidator::class,
        SellerContentBuilder::class,
    ]
)
@ExtendWith(OutputCaptureExtension::class)
@EnableConfigurationProperties(value = [DynamoDBConfigProperties::class, ConfigProperties::class])
@ActiveProfiles("test")
@EmbeddedKafka(
    partitions = 1,
    bootstrapServersProperty = "spring.kafka.bootstrap-servers",
    controlledShutdown = true, count = 1
)
@Import(
    TestContainersConfig::class, AwsConfig::class, DynamoDBConfigTest::class, MiraklClientConfigTest::class,
    KafkaAutoConfiguration::class
)
class PickEventConsumerTest {

    @Autowired
    private lateinit var returnLineRepository: ReturnLineRepository

    @Autowired
    private lateinit var kafkaTemplate: KafkaTemplate<String, Any>

    @Autowired
    private lateinit var embeddedKafkaBroker: EmbeddedKafkaBroker

    @Value("\${mktp-returns-service.topics}")
    private lateinit var topicName: String

    @Value("\${mktp-returns-service.topicForPickCollectedEvent}")
    private lateinit var topicNameForPickCollectedEvent: String

    @MockitoBean
    private lateinit var miraklAPIServiceMock: MiraklAPIService

    @MockitoBean
    private lateinit var productApiQueryServiceMock: ProductApiQueryService

    @MockitoBean
    private lateinit var miraklOrder: MiraklOrder

    @MockitoBean
    private lateinit var miraklOrderStatus: MiraklOrderStatus

    @MockitoBean
    private lateinit var customMetrics: CustomMetrics

    @BeforeEach
    fun setUp() {
        whenever(miraklAPIServiceMock.getMiraklOrderDetailsByOrderId(TEST_LOGISTICAL_ORDER_NUMBER, TEST_TENANT)).thenReturn(
            miraklOrder
        )
        whenever(miraklOrder.shopId).thenReturn(TEST_SHOP_ID)
        whenever(miraklOrder.currencyIsoCode).thenReturn(GBP)
        val productAPIResponseMock: ProductAPIResponse =
            fetchProductAPIResponse(PRODUCT_API_RESPONSE_FILE_FOR_PRODUCT_WEIGHT)
        val productAPIResponse: ResponseEntity<ProductAPIResponse> =
            ResponseEntity(productAPIResponseMock, HttpStatus.OK)
        whenever(productApiQueryServiceMock.fetchProduct(TEST_EAN, Tenant.BQUK.name)).thenReturn(
            buildProductAPIMap(
                productAPIResponse
            )
        )
    }

    @Test
    fun shouldConsumePickCollectionExpiredEvent() {
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID,
                TEST_EAN,
                AMOUNT,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID)).hasSize(
                1
            )
        }
        val result = this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].totalPrice.toDouble()).isEqualTo(AMOUNT)
        assertThat(result[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        verify(miraklAPIServiceMock, never()).createRefund(any(), any(), any(), any(), any(), any(), any())
        verify(miraklAPIServiceMock, never()).notifySeller(any(), any(), any())
        verify(miraklAPIServiceMock, never()).createCancellation(any(), any(), any(), any(), any(), any(), any())
    }

    @Test
    fun shouldConsumePickDeliveryExpiredEvent() {
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID_4,
                TEST_EAN,
                AMOUNT,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_DELIVERY_EXPIRY
            )
        whenever(miraklOrder.canCancel).thenReturn(false)
        whenever(miraklOrder.status).thenReturn(miraklOrderStatus)
        whenever(miraklOrderStatus.state).thenReturn(MiraklOrderState.SHIPPED)
        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_4)).hasSize(
                1
            )
        }
        val result = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_4)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_4)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].status).isEqualTo(TEST_STATUS)
        assertThat(result[0].returnType).isEqualTo(TEST_STATUS)
        assertThat(result[0].route).isEqualTo(TEST_ROUTE)
        assertThat(result[0].refundCreated).isEqualTo(true)
        assertThat(result[0].cancellationCreated).isEqualTo(false)
        assertThat(result[0].totalPrice.toDouble()).isEqualTo(AMOUNT)
        assertThat(result[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        verify(miraklAPIServiceMock).createRefund(
            AMOUNT.toBigDecimal(),
            TEST_QTY.toLong(),
            TEST_LOGISTICAL_ORDER_NUMBER,
            TEST_LINE_NUMBER,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(miraklAPIServiceMock, never()).createCancellation(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()
        )
        verify(miraklAPIServiceMock).notifySeller(
            TEST_LOGISTICAL_ORDER_NUMBER,
            NOTIFICATION_MESSAGE_LOST_IN_TRANSIT,
            TEST_TENANT
        )
    }

    @Test
    fun shouldConsumePickDeliveryExpiredEventAndCreateCancellation() {
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID_10,
                TEST_EAN,
                AMOUNT,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_DELIVERY_EXPIRY
            )
        whenever(miraklOrder.canCancel).thenReturn(true)
        whenever(miraklOrder.status).thenReturn(miraklOrderStatus)
        whenever(miraklOrderStatus.state).thenReturn(MiraklOrderState.SHIPPING)
        kafkaTemplate.send(topicName, pickEvent)

        await().atMost(Duration.ofSeconds(10))
            .untilAsserted {
                assertThat(returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_10))
                    .hasSize(1)
            }
        val result = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_10)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_10)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].status).isEqualTo(Status.SHIPMENT_EXPIRED.name)
        assertThat(result[0].route).isEqualTo(ROUTE.SHIPMENT_NOT_INITIATED.name)
        assertThat(result[0].refundCreated).isEqualTo(false)
        assertThat(result[0].cancellationCreated).isEqualTo(true)
        assertThat(result[0].totalPrice.toDouble()).isEqualTo(AMOUNT)
        assertThat(result[0].logisticalOrderId).isEqualTo(TEST_LOGISTICAL_ORDER_NUMBER)
        verify(miraklOrder, atLeast(1)).canCancel
        verify(miraklAPIServiceMock, never()).createRefund(
            AMOUNT.toBigDecimal(),
            TEST_QTY.toLong(),
            TEST_LOGISTICAL_ORDER_NUMBER,
            TEST_LINE_NUMBER,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(miraklAPIServiceMock).createCancellation(
            AMOUNT.toBigDecimal(),
            TEST_QTY.toLong(),
            TEST_LOGISTICAL_ORDER_NUMBER,
            TEST_LINE_NUMBER,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(miraklAPIServiceMock).notifySeller(
            eq(TEST_LOGISTICAL_ORDER_NUMBER),
            any(),
            any()
        )
    }

    @Test
    fun shouldSetRefundCreatedFlagAsFalseForMiraklAPIException(output: CapturedOutput?) {
        whenever(miraklOrder.canCancel).thenReturn(false)
        whenever(miraklOrder.status).thenReturn(miraklOrderStatus)
        whenever(miraklOrderStatus.state).thenReturn(MiraklOrderState.SHIPPED)
        whenever(
            miraklAPIServiceMock.createRefund(
                any(),
                any(),
                any(),
                any(),
                any(),
                any(),
                any()
            )
        ).thenThrow(MiraklException("Error while creating refund or notify seller"))
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID_5,
                TEST_EAN,
                AMOUNT,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_DELIVERY_EXPIRY
            )

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_5)).hasSize(
                1
            )
        }
        val result = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_5)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_5)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].refundCreated).isEqualTo(false)
        assertThat(result[0].cancellationCreated).isEqualTo(false)
    }

    @Test
    fun `should not process pick event for non configured event type and shipping method`(output: CapturedOutput?) {
        val pickEvent =
            buildPickEvent(TEST_ORDER_ID_1, TEST_EAN, AMOUNT, ShippingMethodType.None, TEST_EVENT_TYPE_COLLECTED)

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_1)).hasSize(
                0
            )
        }
        val result = this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_1)
        assertThat(result).isEmpty()
    }

    @Test
    fun `should not process pick event for non configured event type`(output: CapturedOutput?) {
        val pickEvent = buildPickEvent(
            TEST_ORDER_ID_2, TEST_EAN, AMOUNT, ShippingMethodType.ClickCollectMP,
            TEST_EVENT_TYPE_COLLECTED
        )

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_2)).hasSize(
                0
            )
        }
        val result = this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_2)
        assertThat(result).isEmpty()
    }

    @Test
    fun `should not process pick event for non configured shipping method`(output: CapturedOutput?) {
        val pickEvent =
            buildPickEvent(TEST_ORDER_ID_3, TEST_EAN, AMOUNT, ShippingMethodType.None, TEST_EVENT_TYPE_COLLECTED)

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_3)).hasSize(
                0
            )
        }
        val result = this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_3)
        assertThat(result).isEmpty()
    }

    @Test
    fun `should log error for deserialization exception`(output: CapturedOutput?) {
        val kafkaTemplate =
            KafkaTemplate(DefaultKafkaProducerFactory<String, ByteArray>(producerProps(embeddedKafkaBroker).apply {
                put(KEY_SERIALIZER_CLASS_CONFIG, StringSerializer::class.java)
                put(
                    VALUE_SERIALIZER_CLASS_CONFIG,
                    ByteArraySerializer::class.java
                )
            }))
        kafkaTemplate.defaultTopic = topicName
        kafkaTemplate.send(ProducerRecord(topicName, TEST_KEY, byteArrayOf(0x01, 0x02, 0x03)))

        await().untilAsserted {
            assertThat(output).contains("Failed to Deserialize Pick")
        }
    }

    @Test
    fun `should determine the route as TBC for Collection Event`() {
        val productAPIResponse = ResponseEntity.ok(fetchProductAPIResponse(PRODUCT_API_RESPONSE_TBC))
        whenever(productApiQueryServiceMock.fetchProduct(TEST_EAN_TBC, Tenant.BQUK.name))
            .thenReturn(buildProductAPIMap(productAPIResponse))
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID_7,
                TEST_EAN_TBC,
                AMOUNT_MORE_THAN_10,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_7)).hasSize(
                1
            )
        }
        val result = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_7)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_7)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].status).isEqualTo(AWAITING_STORE_CONFIRMATION.name)
        assertThat(result[0].route).isEqualTo(TBC.name)
        assertThat(result[0].refundCreated).isEqualTo(false)
        assertThat(result[0].returnType).isEqualTo(RETURN_TYPE_COLLECTION_EXPIRED)
        assertEquals(result[0].unitPrice, UNITP_RICE_10.toBigDecimal())
        verify(miraklAPIServiceMock, never()).createRefund(
            AMOUNT.toBigDecimal(),
            TEST_QTY.toLong(),
            TEST_LOGISTICAL_ORDER_NUMBER,
            TEST_LINE_NUMBER,
            TEST_REASON_CODE,
            GBP.toString(),
            TEST_TENANT
        )
        verify(miraklAPIServiceMock, never()).notifySeller(
            TEST_LOGISTICAL_ORDER_NUMBER,
            NOTIFICATION_MESSAGE_LOST_IN_TRANSIT,
            TEST_TENANT
        )
    }

    @Test
    fun `should determine the route as iForce for Collection Event`() {
        val pickEvent =
            buildPickEvent(
                TEST_ORDER_ID_6,
                TEST_EAN,
                AMOUNT,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )

        kafkaTemplate.send(topicName, pickEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_6)).hasSize(
                1
            )
        }
        val result = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_6)
        assertThat(result).isNotNull.hasSize(1)
        assertThat(result[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_6)
        assertThat(result[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(result[0].status).isEqualTo(AWAITING_LABEL_PRINTING.name)
        assertThat(result[0].route).isEqualTo(IFORCE.value)
        assertThat(result[0].reasonForIForce).isEqualTo(PRODUCT_AMOUNT)
        assertThat(result[0].refundCreated).isEqualTo(false)
        assertThat(result[0].returnType).isEqualTo(RETURN_TYPE_COLLECTION_EXPIRED)
        verify(miraklAPIServiceMock, never()).createRefund(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()
        )
        verify(miraklAPIServiceMock, never()).notifySeller(
            any(),
            any(),
            any()
        )
    }

    @Test
    fun `should update status as cancelled for pick collected event for existing record`() {
        val productAPIResponse = ResponseEntity.ok(fetchProductAPIResponse(PRODUCT_API_RESPONSE_TBC))
        whenever(productApiQueryServiceMock.fetchProduct(TEST_EAN_TBC, Tenant.BQUK.name))
            .thenReturn(buildProductAPIMap(productAPIResponse))
        val pickEventCollectionExpired =
            buildPickEvent(
                TEST_ORDER_ID_8,
                TEST_EAN_TBC,
                AMOUNT_MORE_THAN_10,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )
        kafkaTemplate.send(topicName, pickEventCollectionExpired)
        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_8)).hasSize(
                1
            )
        }
        val resultPickCollectionExpired = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_8)
        assertThat(resultPickCollectionExpired).isNotNull.hasSize(1)
        assertThat(resultPickCollectionExpired[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_8)
        assertThat(resultPickCollectionExpired[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(resultPickCollectionExpired[0].status).isEqualTo(AWAITING_STORE_CONFIRMATION.name)

        val pickCollectedEvent =
            buildPickCollectedEvent(
                TEST_ORDER_ID_8,
                TEST_EAN_TBC,
                TEST_COMMERCE_ITEM_ID_PICK_COLLECTED,
                TEST_EVENT_TYPE_PICK_COLLECTED
            )
        kafkaTemplate.send(topicNameForPickCollectedEvent, pickCollectedEvent)
        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_8)).hasSize(
                1
            )
        }
        val resultPickCollectedEvent = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_8)
        assertThat(resultPickCollectedEvent).isNotNull.hasSize(1)
        assertThat(resultPickCollectedEvent[0].status).isEqualTo(STATUS_CANCELLED)
        verify(miraklAPIServiceMock, never()).notifySeller(any(), any(), any())
    }

    @Test
    fun `should not update status as cancelled for any event type other than pick collected`() {
        val productAPIResponse = ResponseEntity.ok(fetchProductAPIResponse(PRODUCT_API_RESPONSE_TBC))
        whenever(productApiQueryServiceMock.fetchProduct(TEST_EAN_TBC, Tenant.BQUK.name))
            .thenReturn(buildProductAPIMap(productAPIResponse))
        val pickEventCollectionExpired =
            buildPickEvent(
                TEST_ORDER_ID_9,
                TEST_EAN_TBC,
                AMOUNT_MORE_THAN_10,
                ShippingMethodType.ClickCollectMP,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )
        kafkaTemplate.send(topicName, pickEventCollectionExpired)
        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_9)).hasSize(
                1
            )
        }
        val resultPickCollectionExpired = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_9)
        assertThat(resultPickCollectionExpired).isNotNull.hasSize(1)
        assertThat(resultPickCollectionExpired[0].returnOrderNumber).isEqualTo(TEST_RETURN_ORDER_ID_9)
        assertThat(resultPickCollectionExpired[0].lineNumber).isEqualTo(TEST_LINE_NUMBER)
        assertThat(resultPickCollectionExpired[0].status).isEqualTo(AWAITING_STORE_CONFIRMATION.name)

        val pickCollectedEvent =
            buildPickCollectedEvent(
                TEST_ORDER_ID_9,
                TEST_EAN_TBC,
                TEST_COMMERCE_ITEM_ID_PICK_COLLECTED,
                TEST_EVENT_TYPE_COLLECTION_EXPIRED
            )
        kafkaTemplate.send(topicNameForPickCollectedEvent, pickCollectedEvent)
        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_9)).hasSize(
                1
            )
        }
        val resultPickCollectedEvent = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_9)
        assertThat(resultPickCollectedEvent).isNotNull.hasSize(1)
        assertThat(resultPickCollectedEvent[0].status).isNotEqualTo(STATUS_CANCELLED)
        verify(miraklAPIServiceMock, never()).notifySeller(any(), any(), any())
    }

    @Test
    fun `should not update status for pick collected event when return lines is null`() {
        val pickCollectedEvent =
            buildPickCollectedEvent(
                TEST_ORDER_ID_0,
                TEST_EAN_TBC,
                DIFFERENT_LINE_ITEM_ID.substring(2),
                TEST_EVENT_TYPE_PICK_COLLECTED
            )
        kafkaTemplate.send(topicNameForPickCollectedEvent, pickCollectedEvent)

        await().untilAsserted {
            assertThat(this.returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_0)).hasSize(
                0
            )
        }

        val resultPickCollectedEvent = returnLineRepository.fetchItemsByHashKey(TEST_RETURN_ORDER_ID_0)
        assertThat(resultPickCollectedEvent).isEmpty()
        verify(miraklAPIServiceMock, never()).notifySeller(any(), any(), any())
    }

    private fun fetchProductAPIResponse(jsonPath: String): ProductAPIResponse {
        return ObjectMapper().readValue(
            Files.readAllBytes(ClassPathResource(jsonPath).file.toPath()),
            ProductAPIResponse::class.java,
        )
    }

    private fun buildPickEvent(
        retrunOrderId: String,
        ean: String,
        amount: Double,
        shippingMethodType: ShippingMethodType,
        testEventType: String
    ): Pick? {
        // Create Metadata
        val metadata = Metadata.newBuilder()
            .setCreatedBy(TEST_CREATED_BY)
            .setCreatedOn(
                TEST_CREATED_ON
            )
            .setTraceId(TEST_TRACE_ID)
            .build()

        // Create MonetaryAmount for orderTotal and orderTotalTax
        val orderTotal = MonetaryAmount.newBuilder()
            .setAmount(amount)
            .setCurrencyCode(TEST_CURRENCY_CODE)
            .build()

        val orderTotalTax = MonetaryAmount.newBuilder()
            .setAmount(ZER_AMOUNT)
            .setCurrencyCode(TEST_CURRENCY_CODE)
            .build()

        // Create Payment
        val payment = Payment.newBuilder()
            .setTradeUkCard(false)
            .setPaymentType(TEST_CARD_TYPE)
            .setOrderPaymentStatus(OrderPaymentStatus.settled)
            .setMaskedPaymentCard(TEST_CARD_NUMBER)
            .build()

        // Create Customer
        val customer = Customer.newBuilder()
            .setCustomerId(TEST_CUSTOMER_ID)
            .setCustomerName(TEST_CUSTOMER_NAME)
            .setCustomerContactNumber(TEST_CUSTOMER_CONTACT)
            .build()

        // Create Channel
        val channel = Channel.newBuilder()
            .setSource(Source.ContactCentre)
            .setAmendment(Amendment.None)
            .build()

        // Create PickLine
        val pickLine = PickLine.newBuilder()
            .setLineItemId(TEST_COMMERCE_ITEM_ID)
            .setBespokeType(BespokeType.None)
            .setBomType(BomType.None)
            .setSpecificationValue("NA")
            .setEan(ean)
            .setArticleNumber(ean)
            .setUnitOfMeasure(TEST_UOM)
            .setDescription(TEST_DESCRIPTION)
            .setLineQty(TEST_QTY.toLong())
            .setPickedQty(TEST_QTY.toLong())
            .setLineNumber(TEST_LINE_NUMBER)
            .setPickLineType(PickLineType.Standard)
            .setParentLine("NA")
            .setChildLines(emptyList<String>())
            .setItemTotal(orderTotal)
            .setItemTotalTax(orderTotalTax)
            .build()

        // Create Payload
        val payload = Payload.newBuilder()
            .setAggregateId(TEST_SHIPPING_GROUP_ID)
            .setLogisticalOrderNumber(TEST_LOGISTICAL_ORDER_NUMBER)
            .setState(State.None)
            .setFulfilmentType(FulfilmentType.None)
            .setPromisedDateTime(TEST_PROMISED_DATE)
            .setShippingMethodType(shippingMethodType)
            .setOrderCreatedDateTime(TEST_CREATED_ON)
            .setOrderId(retrunOrderId)
            .setAgeRestricted(false)
            .setRefundAmount(ZER_AMOUNT)
            .setOrderTotal(orderTotal)
            .setOrderTotalTax(orderTotalTax)
            .setChannel(channel)
            .setCustomer(customer)
            .setPayment(payment)
            .setSite(
                Site.newBuilder()
                    .setNumber(TEST_SITE_ID)
                    .setTenant(Tenant.BQUK)
                    .build()
            )
            .setPickLine(listOf(pickLine))
            .build()

        // Create Pick Event
        val pickEvent = Pick.newBuilder()
            .setEventType(testEventType)
            .setMetadata(metadata)
            .setPayload(payload)
            .build()
        return pickEvent
    }

    private fun buildPickCollectedEvent(
        returnOrderId: String,
        ean: String,
        lineItemId: String,
        testEventType: String
    ): InstorePick? {
        // Create Metadata
        val metadata = InstoreMetadata.newBuilder()
            .setCreatedBy(TEST_CREATED_BY)
            .setCreatedOn(
                TEST_CREATED_ON
            )
            .setTraceId(TEST_TRACE_ID)
            .setCommandId(COMMAND_ID)
            .build()

        // Create Payment
        val payment = InstorePayment.newBuilder()
            .setPaymentType(TEST_CARD_TYPE)
            .setOrderPaymentStatus(NOT_SETTLED)
            .setMaskedPaymentCard(TEST_CARD_NUMBER)
            .build()

        // Create Customer
        val customer = InstoreCustomer.newBuilder()
            .setCustomerID(TEST_CUSTOMER_ID)
            .setCustomerName(TEST_CUSTOMER_NAME)
            .setCustomerContactNumber(TEST_CUSTOMER_CONTACT)
            .build()

        // Create Channel
        val channel = InstorePickChannel.newBuilder()
            .setSource(TEST_CHANNEL_SOURCE)
            .setAmendment(NONE)
            .build()

        val collection = InstoreCollection.newBuilder()
            .setCollectorName("null")
            .setIdentityProof("null")
            .setIsAgeVerified(false)
            .build()

        val allocation = InstoreAllocation.newBuilder()
            .setStatus(TEST_ALLOCATION)
            .build()

        // Create PickLine
        val pickLine = InstorePickLines.newBuilder()
            .setLineItemId(lineItemId)
            .setBespokeType(NONE)
            .setSpecificationValue("NA")
            .setEan(ean)
            .setArticleNumber(ean)
            .setUnitOfMeasure(TEST_UOM)
            .setDescription(TEST_DESCRIPTION)
            .setLineQty(TEST_QTY.toLong())
            .setPickedQty(TEST_QTY.toLong())
            .setPickLineType(TEST_PICK_LINE_TYPE)
            .setParentLine("NA")
            .setChildLines(emptyList<String>())
            .build()

        // Create Payload
        val payload = InstorePayload.newBuilder()
            .setAggregateId(TEST_SHIPPING_GROUP_ID_PICK_COLLECTED)
            .setLogisticalOrderNumber(TEST_LOGISTICAL_ORDER_NUMBER)
            .setStatus(TEST_STATUS_COLLECTED)
            .setFulfilmentType(FulfilmentType.StoreDeliveryToHome.toString())
            .setPromisedDateTime(TEST_PROMISED_DATE)
            .setOrderCreatedDateTime(TEST_CREATED_ON)
            .setOrderId(returnOrderId)
            .setAgeRestricted(false)
            .setDcManualOrder(false)
            .setChannel(channel)
            .setCustomer(customer)
            .setPayment(payment)
            .setSite(
                InstoreSite.newBuilder()
                    .setNumber(TEST_SITE_ID)
                    .setTenant(Tenant.BQUK.toString())
                    .build()
            )
            .setCollection(collection)
            .setAllocation(allocation)
            .setPicklines(listOf(pickLine))
            .build()

        // Create Pick Event
        val pickEvent = InstorePick.newBuilder()
            .setEventType(testEventType)
            .setMetadata(metadata)
            .setEventId(TEST_EVENT_ID)
            .setPayload(payload)
            .build()
        return pickEvent
    }

    private fun buildProductAPIMap(productAPIResponse: ResponseEntity<ProductAPIResponse>): Map<String, Attributes> {
        val responseMap = mutableMapOf<String, Attributes>()
        for (responseData in productAPIResponse.body?.data!!) {
            responseMap[responseData.attributes.ean] = responseData.attributes
        }
        return responseMap
    }
}
