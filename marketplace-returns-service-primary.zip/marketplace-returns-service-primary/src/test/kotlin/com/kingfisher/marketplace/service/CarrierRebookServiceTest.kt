package com.kingfisher.marketplace.service

import com.kingfisher.marketplace.constant.Status
import com.kingfisher.marketplace.constant.Tenant
import com.kingfisher.marketplace.entity.ReturnLine
import com.kingfisher.marketplace.exception.CmsApiException
import com.kingfisher.marketplace.exception.NoEligibleLinesForRebookException
import com.kingfisher.marketplace.model.cms.response.CmsApiResponse
import com.kingfisher.marketplace.repository.ReturnLineRepository
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.mockito.kotlin.mock
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever

class CarrierRebookServiceTest {

    private val returnLineRepository: ReturnLineRepository = mock()
    private val cmsApiService: CmsApiService = mock()
    private val service = CarrierRebookService(returnLineRepository, cmsApiService)

    private fun returnLine(
        logisticalOrderId: String,
        status: String = Status.CARRIER_BOOKING_FAILED.name
    ) = ReturnLine().apply {
        this.logisticalOrderId = logisticalOrderId
        this.status = status
    }

    @Test
    fun `should rebook successfully when CMS returns success`() {
        val lines = listOf(returnLine("19001"))
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(lines)
        whenever(cmsApiService.bookCarrier(lines, Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = true))

        service.rebookCarrier(1930157528L)

        assert(lines.all { it.status == Status.CARRIER_BOOKED.name })
        verify(returnLineRepository).save(lines)
    }

    @Test
    fun `should throw NoEligibleLinesForRebookException when no failed lines exist`() {
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L))
            .thenReturn(listOf(returnLine("19001", Status.CARRIER_BOOKED.name)))

        assertThrows<NoEligibleLinesForRebookException> {
            service.rebookCarrier(1930157528L)
        }
    }

    @Test
    fun `should throw NoEligibleLinesForRebookException when no lines exist`() {
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(emptyList())

        assertThrows<NoEligibleLinesForRebookException> {
            service.rebookCarrier(1930157528L)
        }
    }

    @Test
    fun `should throw CmsApiException and keep status as CARRIER_BOOKING_FAILED when CMS returns business error`() {
        val lines = listOf(returnLine("19001"))
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(lines)
        whenever(cmsApiService.bookCarrier(lines, Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = false, errorMessage = "Your order is a nonsense"))

        val ex = assertThrows<CmsApiException> {
            service.rebookCarrier(1930157528L)
        }

        assert(ex.message == "Your order is a nonsense")
        assert(lines.all { it.status == Status.CARRIER_BOOKING_FAILED.name })
        verify(returnLineRepository).save(lines)
    }

    @Test
    fun `should throw CmsApiException and keep status as CARRIER_BOOKING_FAILED when technical error occurs`() {
        val lines = listOf(returnLine("19001"))
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(lines)
        whenever(cmsApiService.bookCarrier(lines, Tenant.CAPL.name))
            .thenThrow(CmsApiException("connection refused"))

        assertThrows<CmsApiException> {
            service.rebookCarrier(1930157528L)
        }

        assert(lines.all { it.status == Status.CARRIER_BOOKING_FAILED.name })
        verify(returnLineRepository).save(lines)
    }

    @Test
    fun `should process each logisticalOrderId group independently`() {
        val line1 = returnLine("19001")
        val line2 = returnLine("41001")
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(listOf(line1, line2))
        whenever(cmsApiService.bookCarrier(listOf(line1), Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = true))
        whenever(cmsApiService.bookCarrier(listOf(line2), Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = true))

        service.rebookCarrier(1930157528L)

        assert(line1.status == Status.CARRIER_BOOKED.name)
        assert(line2.status == Status.CARRIER_BOOKED.name)
        verify(returnLineRepository).save(listOf(line1, line2))
    }

    @Test
    fun `should throw business error and save when one group succeeds and one fails`() {
        val line1 = returnLine("19001")
        val line2 = returnLine("41001")
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L)).thenReturn(listOf(line1, line2))
        whenever(cmsApiService.bookCarrier(listOf(line1), Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = false, errorMessage = "Your order is a nonsense"))
        whenever(cmsApiService.bookCarrier(listOf(line2), Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = true))

        assertThrows<CmsApiException> {
            service.rebookCarrier(1930157528L)
        }

        assert(line1.status == Status.CARRIER_BOOKING_FAILED.name)
        assert(line2.status == Status.CARRIER_BOOKED.name)
        verify(returnLineRepository).save(listOf(line1, line2))
    }

    @Test
    fun `should only save failed lines not all lines in the order`() {
        val failedLine = returnLine("19001", Status.CARRIER_BOOKING_FAILED.name)
        val bookedLine = returnLine("41001", Status.CARRIER_BOOKED.name)
        whenever(returnLineRepository.fetchItemsByHashKey(1930157528L))
            .thenReturn(listOf(failedLine, bookedLine))
        whenever(cmsApiService.bookCarrier(listOf(failedLine), Tenant.CAPL.name))
            .thenReturn(CmsApiResponse(success = true))

        service.rebookCarrier(1930157528L)

        verify(returnLineRepository).save(listOf(failedLine))
    }
}
