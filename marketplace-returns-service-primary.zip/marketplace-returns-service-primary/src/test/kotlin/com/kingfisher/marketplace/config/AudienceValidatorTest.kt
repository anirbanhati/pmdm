package com.kingfisher.marketplace.config

import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.springframework.security.oauth2.jwt.Jwt

private const val EXPECTED_AUDIENCE = "expected-audience"

class AudienceValidatorTest {

    private val validator = AudienceValidator(EXPECTED_AUDIENCE)

    @Test
    fun `should pass when the expected audience is present`() {
        val jwt = jwtWithAudience(listOf(EXPECTED_AUDIENCE))

        val result = validator.validate(jwt)

        assertFalse(result.hasErrors())
    }

    @Test
    fun `should pass when the expected audience is one of several`() {
        val jwt = jwtWithAudience(listOf("other-audience", EXPECTED_AUDIENCE))

        val result = validator.validate(jwt)

        assertFalse(result.hasErrors())
    }

    @Test
    fun `should fail when the audience does not match`() {
        val jwt = jwtWithAudience(listOf("wrong-audience"))

        val result = validator.validate(jwt)

        assertTrue(result.hasErrors())
    }

    private fun jwtWithAudience(audience: List<String>): Jwt =
        Jwt.withTokenValue("token")
            .header("alg", "none")
            .audience(audience)
            .build()
}
