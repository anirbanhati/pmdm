# Marketplace Returns Service
## Functionality
1. ATG will send 3p returns to existing queue. IIB will route 3p returns to a new queue. Marketplace-Returns-Service will receive the 3p return from the new queue and store into it's own DB.
2. It will determine whether the item needs to be disposed or not by fetching product attributes from Mktp-Products-Service.
   • If it is determined as iForce, it will call Mirakl APIs to notify seller and create
   refund.
   • If it is not determined as iForce, it will store the route as 'TBC'.
3. All the return lines will be displayed in Digital Colleague Application (DCA) to verify if the item can fit into DPD box or damaged/leaking etc. If for any reason, the items can not be sent via DPD, Store
   colleague will update the route as 'iForce' and Mktp-Return-Service will notify seller & create refund.
4. If DPD collection can be booked, Store colleague will select the option in DCA and Marketplace-Returns-Service will call Carrier Routing API which internally calls Carrier Booking and Carrier Availability
   API to book collection.
5. Marketplace-Returns-Service will also call Mktp-Sellers-Service to fetch in-store return address of seller.
6. DCA will use existing API as used for Store to Home Delivery for Label Printing. DCA will also internally call an API to update the status as 'Label_Printing_Requested' in Marketplace-Returns-Service.

## Technical details
This has implementation of Kotlin, DynamoDB, MQ.

## Local set up guidelines

1. Main menu -> Select Run -> Edit Configurations -> Then set:
 > Active profile: local
2. Build Application 
 > * `./gradlew clean build -x dependencyCheckAnalyze`
 > 
 > OR
 > * `./gradlew clean build` (use this command for including dependency check which will take a bit of time)
3. Run App
4. (Optional) If you need to consume JMS messages - Refer to this README file for setting up mq docker - https://gitlab.kfplc.com/group-api/mq-docker and https://wiki.kfplc.com/pages/viewpage.action?spaceKey=MAI&title=How+to+send+message+to+IIB+queue+through+microservice

## Additional Local guildelines (Optional)

### Wiremock Mappings
> 
> > #### Details about mock responses
> > * ###### Product API Responses
> >   * EAN 1111111111111 is for creating lines with route iForce (Auto) due to order amount.
> >   * EAN 1111111111112 same as 1111111111111 but for CAPL
> >   * EAN 2222222222222 is for creating lines with route iForce (Auto) due to battery chemistry.
> >   * EAN 3333333333333 is for creating lines with route iForce (Auto) due to product weight.
> >   * EANs 444444444444, 5555555555555 are used to create TBC lines together, in this case there will be two TBC lines created with that return.
> >   * EAN 6666666666666 is for mocking ean not found error from Product API.
> > * ###### Seller API Responses
> >   * Seller id 1000 is to mock seller not found error.
> >   * Rest all sellers will give successful response.
> > * ###### Carrier Booking API Responses
> >   * SAP order id 1000000002-A is to mock processing error response for carrier booking API.
> >   * Rest orders will give successful response.
> > * ###### Mirakl API Responses
> >   * Offer id 1000 is to mock offer not found error.
> >   * Offer id 1001 will give successful response, it is associated to seller 1000 which is  to mock seller not found error.
> >   * Rest offers will give successful response with different seller.
> >   * Order line 1 of order 1000000000 is to mock exception while creating refund in Mirakl.
> >   * Rest will give successful response while creating refund in Mirakl.
> >   * Any lines for order id 1000000001 if to mock exception while notifying seller.
> >   * Any lines for rest orders will give successful response while notifying seller.
> 
> _For any other custom response to be mapped please add the mapping in `request_mapping.json` file in `container-setup` folder and store response body file (if needed) in `__files` folder under that same folder._

### Kafka Details 
>
> > * ###### Kafka Details
> >   * Control center UI link: http://localhost:9021/
> >   * To check schema registry is up properly or not, please visit the link: http://localhost:8081/subjects
> >   * Producer service to publish events in local kafka broker: https://gitlab.kfplc.com/dcom-mktp/spring-kafka-producer


### Setting MQ in windows _(Docker required)_

> *  Pull ibm mq image by using command
     > `docker pull icr.io/ibm-messaging/mq:latest`
> *  Check the image with command
     > `docker images`
> * Up the container
    > `docker run --env LICENSE=accept --env MQ_QMGR_NAME=<QUEUE_MANAGER_NAME> --publish 1414:1414 --publish 9443:9443 --detach --env MQ_APP_PASSWORD=<MQ_APP_PASSWORD> --env MQ_ADMIN_PASSWORD=<MQ_APP_PASSWORD> --name QM1 icr.io/ibm-messaging/mq:latest`
> * Now check the mq is up or not
    > `docker ps`
> * Check in local from URL
    > https://localhost:9443/ibmmq/console
> * Create a queue with name same given in application.yml
> * Finally pass environment variables in application.yml
    >  * ACTIVE_PROFILE=local
>  * QUEUE_USER_NAME=<MQ_APP_USERNAME>
>  * QUEUE_PASSWORD=<MQ_APP_PASSWORD>
>
> _Please make sure docker or rancher is installed in system._
 