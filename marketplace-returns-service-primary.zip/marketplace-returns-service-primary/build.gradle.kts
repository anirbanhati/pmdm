import org.gradle.api.JavaVersion.VERSION_17
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    id("org.springframework.boot") version "3.5.16"
    id("io.spring.dependency-management") version "1.1.4"
    id("org.jetbrains.kotlin.jvm") version "1.9.23"
    id("org.jetbrains.kotlin.plugin.spring") version "1.9.23"
    id("io.gitlab.arturbosch.detekt") version "1.23.6"
    id ("com.github.davidmc24.gradle.plugin.avro") version "1.9.1"
    id("java-test-fixtures")
    id("jacoco")
    id("com.kingfisher.marketplace.changelog-plugin") version "20250711-1246-6449ea0"
}

group = "com.kingfisher.marketplace"
version = "0.0.1-SNAPSHOT"

java {
    sourceCompatibility = VERSION_17
}

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

// replace non compatible transient swagger-annotations dep from kafka-avro-serializer:8.2.0
configurations.all {
    resolutionStrategy.dependencySubstitution {
        substitute(module("io.swagger.core.v3:swagger-annotations"))
            .using(module("io.swagger.core.v3:swagger-annotations-jakarta:2.2.47"))

        substitute(module("io.netty:netty-codec-http"))
            .using(module("io.netty:netty-codec-http:4.1.136.Final"))

        substitute(module("io.netty:netty-codec-http2"))
            .using(module("io.netty:netty-codec-http2:4.1.136.Final"))

        substitute(module("io.netty:netty-codec-dns"))
            .using(module("io.netty:netty-codec-dns:4.1.136.Final"))

        substitute(module("io.netty:netty-codec"))
            .using(module("io.netty:netty-codec:4.1.136.Final"))

        substitute(module("io.netty:netty-transport-native-epoll"))
            .using(module("io.netty:netty-transport-native-epoll:4.1.136.Final"))

        substitute(module("io.netty:netty-handler-proxy"))
            .using(module("io.netty:netty-handler-proxy:4.1.136.Final"))

        substitute(module("io.netty:netty-resolver-dns"))
            .using(module("io.netty:netty-resolver-dns:4.1.136.Final"))

        substitute(module("io.netty:netty-handler"))
            .using(module("io.netty:netty-handler:4.1.136.Final"))
    }
}

repositories {
    mavenLocal()
    mavenCentral()
    maven {
        url = uri("https://nexus.kfplc.com:8443/nexus/content/repositories/Atg_Releases")
    }
    maven {
        url = uri("https://nexus-internal-gts-prod.k8s.ap.digikfplc.com/repository/public-repo")
    }
    maven {
        url = uri("https://nexus.k8s.an.digikfplc.com/repository/maven-public")
    }
    maven {
        url = uri("https://packages.confluent.io/maven")
    }
}

dependencyManagement {
    dependencies {
        dependency("com.fasterxml.jackson.core:jackson-core:2.21.5")
        dependency("com.fasterxml.jackson.core:jackson-databind:2.21.5")
        dependency("com.fasterxml.jackson.datatype:jackson-datatype-jdk8:2.21.5")
        dependency("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.21.5")
        dependency("com.fasterxml.jackson.dataformat:jackson-dataformat-csv:2.21.5")
        dependency("com.fasterxml.jackson.dataformat:jackson-dataformat-yaml:2.21.5")
        dependency("com.fasterxml.jackson.module:jackson-module-kotlin:2.21.5")
        dependency("com.fasterxml.jackson.module:jackson-module-parameter-names:2.21.5")
    }
}

val awsSdkVersion by extra { "2.46.7" }
val miraklSdkVersion by extra { "10.2.0" }
val axiomVersion by extra { "1.4.0" }
val micrometerVersion by extra { "1.16.6" }
val detektVersion by extra { "1.23.6" }
val serializerSchemaRegistryVersion by extra { "8.2.0" }

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("org.springframework.boot:spring-boot-starter-aop")
    implementation("org.springframework.kafka:spring-kafka:3.3.16")
    implementation("org.springframework.boot:spring-boot-starter-security")
    implementation("org.springframework.boot:spring-boot-starter-oauth2-resource-server")
    implementation("org.springframework.boot:spring-boot-starter-oauth2-client")
    implementation("com.ibm.mq:mq-jms-spring-boot-starter:3.5.13")
    implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:2.8.17")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
    implementation(platform("com.fasterxml.jackson:jackson-bom:2.21.5"))
    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("kf.ws:kf-services:0.0.40")
    implementation("org.apache.xmlbeans:xmlbeans:2.7.1")
    implementation(platform("software.amazon.awssdk:bom:$awsSdkVersion"))
    implementation("software.amazon.awssdk:dynamodb-enhanced")
    implementation("software.amazon.awssdk:url-connection-client")
    implementation("com.mirakl:mmp-sdk-operator:$miraklSdkVersion")
    implementation("org.apache.ws.commons.axiom:axiom-api:$axiomVersion")
    implementation("org.apache.ws.commons.axiom:axiom-impl:$axiomVersion")
    implementation("org.apache.ws.commons.axiom:axiom-dom:$axiomVersion")
    implementation("javax.activation:activation:1.1.1")
    implementation("org.apache.james:apache-mime4j-core:0.8.11")
    implementation("com.fasterxml.woodstox:woodstox-core:7.0.0")
    implementation("org.apache.xmlbeans:xmlbeans:5.3.0")
    implementation("org.apache.httpcomponents.client5:httpclient5:5.6.3")
    implementation("org.apache.httpcomponents.core5:httpcore5:5.4.3")
    implementation("org.apache.httpcomponents.core5:httpcore5-h2:5.4.3")
    implementation("io.micrometer:micrometer-core:$micrometerVersion")
    implementation("io.micrometer:micrometer-registry-datadog:$micrometerVersion")
    implementation("ch.qos.logback:logback-core:1.5.34")
    detekt("io.gitlab.arturbosch.detekt:detekt-cli:$detektVersion")
    detekt("io.gitlab.arturbosch.detekt:detekt-formatting:$detektVersion")
    implementation("io.confluent:kafka-avro-serializer:$serializerSchemaRegistryVersion")
    implementation("io.confluent:kafka-schema-registry-client:$serializerSchemaRegistryVersion")
    implementation("commons-beanutils:commons-beanutils:1.11.0")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.springframework.security:spring-security-test")
    testImplementation("org.springframework.boot:spring-boot-starter-webflux")
    testImplementation("org.springframework.kafka:spring-kafka-test")
    testImplementation("org.mockito.kotlin:mockito-kotlin:5.3.1")
    testFixturesImplementation("org.springframework.boot:spring-boot-testcontainers")
    testFixturesImplementation("org.testcontainers:localstack:1.19.3")
    developmentOnly("org.springframework.boot:spring-boot-docker-compose")

    // dependency alignment for vulnerability scan
    // Override vulnerable tomcat dep from spring boot
    implementation("org.apache.tomcat.embed:tomcat-embed-core:10.1.55")
    // Override version for commons-lang3
    implementation("org.apache.commons:commons-lang3:3.20.0")
    // Override vulnerable bcprov and bckix dep from ibm mq starter
    implementation("org.bouncycastle:bcprov-jdk18on:1.84")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.84")
    implementation("org.apache.logging.log4j:log4j-api:2.25.5")
    implementation("at.yawk.lz4:lz4-java:1.11.1")
}

tasks.withType<JacocoReport> {
    reports {
        xml.required.set(true)
        csv.required.set(false)
    }
}

tasks.withType<KotlinCompile> {
    kotlinOptions {
        freeCompilerArgs += "-Xjsr305=strict"
        jvmTarget = "17"
    }
}

tasks.withType<JacocoReport> {
    reports {
        xml.required.set(true)
        csv.required.set(false)
    }
}

tasks.withType<Test> {
    maxParallelForks = 2
    useJUnitPlatform()
    finalizedBy("jacocoTestReport") // report is always generated after tests run
}

tasks.withType<io.gitlab.arturbosch.detekt.Detekt>().configureEach {
    this.jvmTarget = VERSION_17.toString()
    this.languageVersion = "1.9"
    doNotTrackState("jdkHome property is not able to be tracked!")
}

tasks.withType<io.gitlab.arturbosch.detekt.DetektCreateBaselineTask>().configureEach {
    this.jvmTarget = VERSION_17.toString()
    doNotTrackState("jdkHome property is not able to be tracked!")
}

tasks.register<io.gitlab.arturbosch.detekt.Detekt>("codeAnalyze") {
    description = "Runs a custom detekt build."
    setSource(files("src/main/kotlin", "src/test/kotlin"))
    config.setFrom(files("config/detekt/detekt.yml"))
    debug = true
    include("**/*.kt")
    include("**/*.kts")
    exclude("resources/")
    exclude("build/")
}

tasks.register<Exec>("composeUp") {
    group = "docker"
    description = "Starts all services defined in docker-compose.yml"
    commandLine("docker-compose", "up", "-d")
    doLast {
        println("Docker Compose services started")
    }
}

tasks.register<Exec>("composeDown") {
    group = "docker"
    description = "Stops all services defined in docker-compose.yml"
    commandLine("docker-compose", "down")
    doLast {
        println("Docker Compose services stopped")
    }
}


tasks.register<Exec>("initDynamoDB"){
    commandLine("sh", "-c", "./init-dynamodb.sh")
    setIgnoreExitValue(true)
    doLast{
        println("DynamoDB initialization completed")
    }
}
