# Local Service Setup and Execution

This README provides instructions on how to set up and run the service locally.

## Prerequisites

- AWS CLI 
  - Setting up AWS CLI run command
  >   * `aws configure`
  >   * Then set AWS Access Key ID, AWS Secret Access Key, Default region name, Default output format.
- Docker and Docker Compose installed on your machine
- Gradle build tool
- JDK 17
  >   * Make sure that the all project settings point to correct java version

## Steps to Run the Service Locally

1. **Start Docker Containers**

If you have the image of our service build locally you can go to `docker-compose-ci.yml` file and set the value of 
`image: ${RETURNS_SERVICE_IMAGE}` to reference the image of the marketplace-returns-service.
Then just in terminal execute `docker compose -f docker-compose-ci.yml up -d` this will set up containers with all 
required services.

2. Starting the tests
   You can run these tests using:

    `./gradlew runFunctionalIntegrationTests`

Add `-Pshowstreams` or `-Pstacktrace` to the gradle command
if you need more detailed output for debugging.

3. After You are done with testing do the cleanup with
    
    `docker compose -f docker-compose-ci.yml down`

## Troubleshooting

If you encounter any issues:
- check the output of `aws configure` command to make sure it is set to thwe same values as in docker compose file.
- Ensure all required Docker images are pulled and up-to-date
- Check that the required ports (8080, 8000, 9090, 9092, 2181, 8081) are not in use by other applications
- Check the status of the containers that were run using the docker compose. 
   If any off them reports as unhealthy something went wrong with setup 
- Verify that your `docker-compose.yml` or `docker-compose-ci.yml` file is correctly configured

For more detailed logs, you can run Docker Compose without the detached mode:
`docker compose -f docker-compose-ci.yml up`

This will show the logs from all containers in your terminal.

## Additional Information

- The service uses JDK 17. Make sure you have the correct Java version installed.
