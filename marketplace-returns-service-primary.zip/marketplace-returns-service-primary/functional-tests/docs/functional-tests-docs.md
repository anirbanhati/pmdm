# Marketplace Returns Service - Functional Test Suite Documentation

**Version:** 1.0
**Last Updated:** February 2026
**Maintainer:** Software Developer in Test
**Purpose:** Complete documentation of the functional test suite for knowledge transfer

---

## Table of Contents

1. [Overview](#1-overview)
2. [How to Run Tests Locally](#2-how-to-run-tests-locally)
3. [How Tests Run in GitLab CI](#3-how-tests-run-in-gitlab-ci)
4. [Test Infrastructure](#4-test-infrastructure)
5. [Current Test Coverage](#5-current-test-coverage)
6. [Test Architecture & Patterns](#6-test-architecture--patterns)
7. [Gap Analysis](#7-gap-analysis)

---

## 1. Overview

The functional test suite validates the Marketplace Returns Service end-to-end through REST API testing. 
Tests run against a fully containerized environment including DynamoDB, Kafka, and WireMock for external service mocking.

### Key Characteristics

- **Framework:** JUnit 5 (Jupiter) with Kotlin
- **HTTP Testing:** REST Assured 4.5.0
- **Total Test Files:** 6
- **Total Test Cases:** 25 (including parameterized tests)
- **Test Type:** Black-box API integration tests
- **Execution Time:** ~3-5 minutes
- **Location:** `/functional-tests/src/test/kotlin/com/kingfisher/`

---

## 2. How to Run Tests Locally

### Prerequisites

1. **Docker & Docker Compose** installed and running
2. **JDK 17** or higher
3. **Gradle** (wrapper included in project)
4. **Available Ports:** 8080, 8000, 9090, 9092, 2181, 8081

### Step-by-Step Execution

#### Option 1: One-line Script (Recommended)

**Note:** The Gradle task does NOT automatically start containers. You must start them first.

```bash
# From project root - Start containers, run tests, then cleanup
docker compose -f docker-compose-ci.yml up -d && \
./gradlew runFunctionalIntegrationTests && \
docker compose -f docker-compose-ci.yml down -v
```

This will:
1. Start all containerized dependencies via `docker-compose-ci.yml`
2. Wait for services to be healthy (docker-compose health checks)
3. Execute all functional tests
4. Generate HTML and XML reports
5. Tear down containers and volumes

#### Option 2: Manual Step-by-Step

Run each step separately for more control:

```bash
# Step 1: Start all services
docker compose -f docker-compose-ci.yml up -d

# Step 2: Wait for service health (manual check)
curl http://localhost:8080/v1/fetchAllOrders

# Step 3: Run tests
./gradlew :functional-tests:runFunctionalIntegrationTests

# Step 4: Clean up
docker compose -f docker-compose-ci.yml down -v
```

### Command Options

**Important:** All commands assume Docker containers are already running via `docker compose -f docker-compose-ci.yml up -d`

| Command | Description |
|---------|-------------|
| `./gradlew runFunctionalIntegrationTests` | Run all functional tests (containers must be running) |
| `./gradlew runFunctionalIntegrationTests -Pshowstreams` | Enable detailed output/logs |
| `./gradlew runFunctionalIntegrationTests -Pstacktrace` | Show stack traces on failures |
| `./gradlew runFunctionalIntegrationTests --tests "ClassName"` | Run specific test class |
| `./gradlew runFunctionalIntegrationTests --tests "ClassName.testMethod"` | Run specific test method |

### Test Reports

After test execution, reports are generated at:

| Report Type | Location |
|-------------|----------|
| **HTML Report** | `functional-tests/build/reports/integrationTests/index.html` |
| **JUnit XML** | `functional-tests/build/test-results/runFunctionalIntegrationTests/*.xml` |
| **Console Logs** | `functional-tests/test-execution.log` |

Open the HTML report for detailed test results:
```bash
open functional-tests/build/reports/integrationTests/index.html
```

---

## 3. How Tests Run in GitLab CI

### CI Pipeline Overview

Functional tests run as part of the GitLab CI/CD pipeline in the **`test`** stage.

**Pipeline Stages:**
```
build → dependency_scanning → sonar-scan → test → deploy-db-h → deploy-h → ...
```

### The `run_mocked_ci_tests` Job

**File:** `.gitlab-ci.yml` (lines 102-184)

#### Job Configuration

```yaml
run_mocked_ci_tests:
  image: docker/compose:latest
  stage: test
  needs:
    - sonar-scan
```

**Key Details:**
- **Trigger Rules:**
  - Automatically runs on **merge requests** (when: on_success)
  - Automatically runs on **push to primary branch** (when: on_success)
  - **Manual** on other branch pushes (allow_failure: true)
  - **Never** runs on scheduled pipelines with ACTION=deploy
- **Image:** `docker/compose:latest` (for orchestrating containers)
- **Services:** `docker:24.0.6-dind` (Docker-in-Docker)
- **Depends On:** `sonar-scan` job must complete first

#### Environment Variables

```yaml
variables:
  DOCKER_HOST: tcp://docker:2375
  DOCKER_TLS_CERTDIR: ""
  RETURNS_SERVICE_IMAGE: ${CI_REGISTRY}/${PROJECT_PATH}:${CI_COMMIT_SHA}
```

- `RETURNS_SERVICE_IMAGE`: Uses the Docker image built in the `build:image` job (tagged with commit SHA)
- `DOCKER_HOST`: Points to the Docker-in-Docker service
- `DOCKER_TLS_CERTDIR`: Disabled for CI environment

#### Execution Flow

**1. Before Script (Setup Phase)**

```bash
# Authenticate with Docker registry
- !reference [.dockerauth, before_script]

# Install curl for health checks
- apk update && apk add --no-cache curl

# Verify Docker authentication
- cat ~/.docker/config.json | grep "docker.io"

# Start all services via docker-compose
- docker-compose -f docker-compose-ci.yml up -d

# Create log directory
- mkdir -p docker-logs

# Save initial logs
- docker-compose -f docker-compose-ci.yml logs > docker-logs/all-logs-initial.txt

# Health check: Wait for service to be ready (10 minute timeout)
- timeout=600
- counter=0
- until curl -s http://localhost:8080/v1/fetchAllOrders > /dev/null || [ $counter -eq $timeout ]; do
    echo "Waiting for service to be ready... ($counter/$timeout)"
    sleep 1
    counter=$((counter + 1))
  done
- if [ $counter -eq $timeout ]; then
    echo "Timeout waiting for service to start"
    docker-compose -f docker-compose-ci.yml logs > docker-logs/all-logs-timeout.txt
    exit 1
  fi
- echo "Service is ready!"
```

**Key Points:**
- Waits up to **10 minutes (600 seconds)** for service health check
- Health check endpoint: `http://localhost:8080/v1/fetchAllOrders`
- If timeout occurs, saves logs and fails the job

**2. Script Phase (Test Execution)**

```bash
# Save pre-test logs
- docker-compose -f docker-compose-ci.yml logs > docker-logs/all-logs-before-tests.txt

# Run tests in a separate container
- docker run --rm \
  --network="${CI_PROJECT_NAME}_default" \
  -v $(pwd):/app \
  -w /app \
  -e WIREMOCK_HOST=wiremock-service \
  -e WIREMOCK_PORT=9090 \
  --entrypoint /bin/sh \
  bellsoft/liberica-openjdk-alpine:17 \
  -c "apk add --no-cache findutils curl && \
      export BASE_URL=http://returns-service:8080 && \
      echo 'Waiting for service to be ready...' && \
      while ! curl -s returns-service:8080/v1/fetchAllOrders > /dev/null; do \
        echo 'Waiting for service...' && \
        sleep 5; \
      done && \
      echo 'Service is ready, running tests...' && \
      ./gradlew clean :functional-tests:runFunctionalIntegrationTests -Pshowstreams"
```

**Key Points:**
- Tests run in **isolated container** (`bellsoft/liberica-openjdk-alpine:17`)
- Connected to same Docker network as services (`${CI_PROJECT_NAME}_default`)
- Volume mount: Current directory → `/app` (contains test code)
- Environment variables:
  - `WIREMOCK_HOST=wiremock-service` (container name)
  - `WIREMOCK_PORT=9090`
  - `BASE_URL=http://returns-service:8080` (service URL within Docker network)
- Additional health check inside test container before running tests
- Command: `./gradlew clean :functional-tests:runFunctionalIntegrationTests -Pshowstreams`

**3. After Script (Teardown Phase)**

```bash
# Save final logs
- docker-compose -f docker-compose-ci.yml logs > docker-logs/all-logs-final.txt

# Stop and remove all containers and volumes
- docker-compose -f docker-compose-ci.yml down -v
```

**Key Points:**
- Always runs (even if tests fail)
- Captures final state of all containers
- Cleans up all containers and volumes

#### Artifacts

```yaml
artifacts:
  when: always  # Upload artifacts even if job fails
  paths:
    - functional-tests/build/reports/integrationTests/      # HTML reports
    - functional-tests/build/test-results/runFunctionalIntegrationTests/  # XML results
    - docker-logs/                                          # Container logs
  reports:
    junit: functional-tests/build/test-results/runFunctionalIntegrationTests/TEST-*.xml
  expire_in: 1 week
```

**Available Artifacts:**
- **HTML Test Report:** Browse test results in GitLab UI
- **JUnit XML:** Integrated into GitLab's test reporting
- **Docker Logs:** All container logs (initial, before-tests, timeout, final)
- **Expiration:** 1 week retention

### When Tests Run in CI

| Scenario | Behavior |
|----------|----------|
| **Merge Request** | ✅ Automatically runs (required for merge) |
| **Push to primary branch** | ✅ Automatically runs |
| **Push to feature branch** | ⚠️ Manual trigger (allow_failure: true) |
| **Scheduled pipeline** | ❌ Skipped (schedule pipelines are for deployment) |
| **Tag creation** | ❌ Skipped |

### Debugging Failed CI Tests

**1. Check GitLab Job Logs**
- Navigate to Pipeline → `run_mocked_ci_tests` job
- Review console output for errors

**2. Download Artifacts**
- Click "Browse" on job page
- Download `docker-logs/` directory
- Check `all-logs-final.txt` for service errors

**3. Review Test Reports**
- Download HTML report from artifacts
- Open `functional-tests/build/reports/integrationTests/index.html`
- Identify failed test cases

**4. Common Failure Modes**

| Symptom | Likely Cause | Solution |
|---------|--------------|----------|
| Health check timeout (600s) | Service failed to start | Check `docker-logs/all-logs-timeout.txt` for startup errors |
| Tests fail immediately | WireMock stubs not loaded | Verify `BaseMockedReturnOrderTest` setup |
| Intermittent failures | Race condition or timing issue | Review test cleanup (AfterEach) |
| All tests fail | BASE_URL not set correctly | Verify environment variables in CI job |

---

## 4. Test Infrastructure

### 4.1 Docker Services (docker-compose-ci.yml)

The test environment consists of 7 containerized services:

#### Service 1: WireMock (wiremock-service)

**Purpose:** Mock external APIs (Product API, Mirakl, Seller API, Carrier Booking API)

```yaml
wiremock-service:
  image: wiremock/wiremock:latest
  ports:
    - "9090:8080"
  volumes:
    - ./container-setup/__files:/home/wiremock/__files
    - ./container-setup/mappings:/home/wiremock/mappings
```

**Configuration:**
- **Port:** 9090 (host) → 8080 (container)
- **Container Stubs Location:** `./container-setup/__files/` and `./container-setup/mappings/`
- **Test Stubs Location:** `/functional-tests/src/test/resources/data/response/`
- **Accessed By Tests:** `http://localhost:9090` (local) or `http://wiremock-service:8080` (CI)

**Two Mocking Approaches:**

1. **Container-Mounted Stubs (Static)** - Pre-configured stubs loaded on container startup
   - Location: `/container-setup/__files/` (responses) + `/container-setup/mappings/` (URL patterns)
   - Always available, no test setup needed
   - Examples: Product API variations (battery, weight, price), Seller API, Carrier Booking API, Mirakl API

2. **Programmatic Stubs (Dynamic)** - Created in test code via `WireMock.stubFor()`
   - Location: `/functional-tests/src/test/resources/data/response/` (response files)
   - Test-specific, can override container stubs using priority
   - Examples: `BaseMockedReturnOrderTest.stubProductEndpoint()`

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` for detailed explanation of both approaches and how they work together.

**Current Container Stubs:**
- **Product API:** 7 variations (battery, weight, price, TBC, errors, mixed basket)
- **Seller API:** Success and 404 error responses  
- **Carrier Booking API:** Success and processing error responses
- **Mirakl API:** Authentication, orders, refunds, notifications (success and error)

#### Service 2: DynamoDB Local (dynamodb-local)

**Purpose:** Local AWS DynamoDB instance for data persistence

```yaml
dynamodb-local:
  image: amazon/dynamodb-local:latest
  ports:
    - "8000:8000"
  command: "-jar DynamoDBLocal.jar -sharedDb -inMemory"
```

**Configuration:**
- **Port:** 8000
- **Storage:** In-memory (data lost on restart)
- **Region:** eu-west-1 (configured in application)
- **Table:** `marketPlaceReturnService` (auto-created on startup)

**Table Schema:**
- **Partition Key:** return_order_number (Long)
- **Sort Key:** line_number (Long)
- **GSI:** store_id_returned_date_in_ms_index

#### Service 3: Zookeeper

**Purpose:** Kafka cluster coordination

```yaml
zookeeper:
  image: confluentinc/cp-zookeeper:latest
  ports:
    - "2181:2181"
  environment:
    ZOOKEEPER_CLIENT_PORT: 2181
    ZOOKEEPER_TICK_TIME: 2000
```

#### Service 4: Kafka Broker

**Purpose:** Message streaming for pick events

```yaml
kafka:
  image: confluentinc/cp-kafka:latest
  ports:
    - "9092:9092"
  environment:
    KAFKA_BROKER_ID: 1
    KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
    KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092,PLAINTEXT_HOST://localhost:9092
    KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
```

**Topics Used:**
- `public.bquk.order-management.test.pick`
- `public.bquk.in-store-fulfilment.test.pick`

#### Service 5: Schema Registry

**Purpose:** Avro schema management for Kafka events

```yaml
schema-registry:
  image: confluentinc/cp-schema-registry:latest
  ports:
    - "8081:8081"
  environment:
    SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS: kafka:29092
    SCHEMA_REGISTRY_HOST_NAME: schema-registry
```

#### Service 6: Returns Service (returns-service)

**Purpose:** Application under test

```yaml
returns-service:
  image: ${RETURNS_SERVICE_IMAGE}  # Built in CI
  ports:
    - "8080:8080"
  environment:
    # Application config
    BASE_URL: http://localhost:8080
    REGION: eu-west-1
    TABLE_NAME: marketPlaceReturnService
    # External service URLs
    PRODUCT_API_URL: http://wiremock-service:8080
    MIRAKL_URL: http://wiremock-service:8080
    # Kafka config
    BOOTSTRAP_SERVER_URL: kafka:29092
    SCHEMA_REGISTRY_URL: http://schema-registry:8081
  depends_on:
    - dynamodb-local
    - kafka
    - wiremock-service
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:8080/v1/fetchAllOrders"]
    interval: 10s
    timeout: 5s
    retries: 30
```

**Health Check:**
- Endpoint: `GET /v1/fetchAllOrders`
- Interval: Every 10 seconds
- Timeout: 5 seconds per check
- Retries: 30 attempts (5 minutes total)

### 4.2 Test Configuration

#### Configuration File: local.properties

**Location:** `/functional-tests/src/test/resources/local.properties`

```properties
base.url=http://localhost:8080
delete.order.path=/v1/deleteOrder
confirm.return.path=/v1/confirm
update.route.path=/v1/updateRoute
fetch.all.orders.path=/v1/fetchAllOrders
```

**Usage:** Loaded by `ConfigurationManager.kt` singleton

#### Logging Configuration: logback-test.xml

**Location:** `/functional-tests/src/test/resources/logback-test.xml`

```xml
<configuration>
  <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>

  <appender name="FILE" class="ch.qos.logback.core.FileAppender">
    <file>test-execution.log</file>
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>

  <logger name="com.kingfisher" level="DEBUG"/>
  <logger name="io.restassured" level="INFO"/>

  <root level="INFO">
    <appender-ref ref="CONSOLE"/>
    <appender-ref ref="FILE"/>
  </root>
</configuration>
```

**Log Levels:**
- `com.kingfisher` package: DEBUG
- `io.restassured` package: INFO
- Root: INFO

### 4.3 Build Configuration

**File:*_* `/functional-tests/build.gradle.kts`_

```kotlin
tasks.register<Test>("runFunctionalIntegrationTests") {
    useJUnitPlatform {
        includeTags("integration")  // Only run tests tagged with @Tag("integration")
    }

    testLogging {
        events("passed", "skipped", "failed")
        showStandardStreams = project.hasProperty("showstreams")
        showStackTraces = project.hasProperty("stacktrace")
    }

    reports {
        html.required.set(true)
        html.outputLocation.set(file("$buildDir/reports/integrationTests"))
        junitXml.required.set(true)
        junitXml.outputLocation.set(file("$buildDir/test-results/runFunctionalIntegrationTests"))
    }
}
```

**Key Dependencies:**
```kotlin
dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter:5.9.3")
    testImplementation("io.rest-assured:rest-assured:4.5.0")
    testImplementation("com.willowtreeapps.assertk:assertk-jvm:0.25")
    testImplementation("org.wiremock:wiremock:3.9.2")
    testImplementation("org.assertj:assertj-core:3.22.0")
    testImplementation("org.hamcrest:hamcrest:2.2")
    testImplementation("net.javacrumbs.json-unit:json-unit-assertj:3.2.2")
    testImplementation("org.junit-pioneer:junit-pioneer:2.3.0")
}
```

---

## 5. Current Test Coverage

### 5.1 Test Class Overview

| Test Class | Location | Test Count | Focus |
|-----------|----------|-----------|-------|
| **CreateReturnOrderTest** | `/api/CreateReturnOrderTest.kt` | 3 | Order creation workflows |
| **ConfirmReturnOrderTest** | `/api/ConfirmReturnOrderTest.kt` | 2 | Order confirmation with tracking |
| **DeleteReturnOrderTest** | `/api/DeleteReturnOrderTest.kt` | 1 | Order deletion workflows |
| **UpdateRouteTest** | `/api/UpdateRouteTest.kt` | 3 | Route/fulfillment updates |
| **ExceptionHandlingTest** | `/api/ExceptionHandlingTest.kt` | 6 | Input validation & error handling |
| **WindsorFrameworkTest** | `/api/WindsorFrameworkTest.kt` | 10 (4 parameterized) | Route determination logic |

**Total:** 25 test cases

### 5.2 Detailed Test Case Documentation

---

#### CreateReturnOrderTest.kt

**Purpose:** Validate return order creation through PSO XML import

**Base Class:** `BaseMockedReturnOrderTest`

##### Test 1: `should create return order successfully`

**Scenario:** Happy path order creation

```kotlin
@Test
@Tag("integration")
fun `should create return order successfully`()
```

**Steps:**
1. Generate unique order ID (auto-incremented from 4001876521)
2. Create PSO XML with order details
3. POST XML to `/v1/import`
4. Verify HTTP 200 response
5. Fetch all orders via `/v1/fetchAllOrders`
6. Assert order appears in response
7. Assert status = "AWAITING_STORE_CONFIRMATION"

**Assertions:**
- Response status code = 200
- Order ID present in fetch response
- Status field correct

**Cleanup:** Order deleted in `@AfterEach`

##### Test 2: `should handle special characters in customer details`

**Scenario:** Unicode character support in customer names

```kotlin
@ParameterizedTest
@ValueSource(strings = [
    "Obżęściąski",                          // Polish
    "田中さんにあげて下さい",                  // Japanese
    "表ポあA鷗ŒéＢ逍Üßªąñ丂㐀𠀀"              // Mixed Unicode
])
@Tag("integration")
fun `should handle special characters in customer details`(customerName: String)
```

**Steps:**
1. Create order with `customerLastName = customerName`
2. POST to `/v1/import`
3. Verify HTTP 200
4. Verify order stored correctly

**Assertions:**
- No encoding errors
- Response status code = 200

**Purpose:** Ensure internationalization support for global customers

##### Test 3: `should handle duplicate orders`

**Scenario:** Idempotent order creation

```kotlin
@Test
@Tag("integration")
fun `should handle duplicate orders`()
```

**Steps:**
1. Create order with ID X
2. POST to `/v1/import` → expect 200
3. POST **same order** again → expect 200 (not 409 or 400)
4. Verify both requests succeed

**Assertions:**
- Both requests return 200
- Idempotent behavior (no duplicate key errors)

---

#### ConfirmReturnOrderTest.kt

**Purpose:** Validate return line confirmation and label printing requests

**Base Class:** `BaseMockedReturnOrderTest`

##### Test 1: `should confirm return line with parcel tracking info`

**Scenario:** Confirm return with DPD tracking information

```kotlin
@Test
@Tag("integration")
fun `should confirm return line with parcel tracking info`()
```

**Steps:**
1. Create return order
2. Build confirmation request with:
   - `userId = "user123"`
   - `parcelTrackingInfo = [{ quantity: 1, externalParcelIdentifier: "P123", trackingNumber: "T123" }]`
3. POST to `/v1/confirm/{tenant}/{returnOrderNumber}/{lineNumber}`
4. Verify HTTP 200 response
5. Assert response contains:
   - `returnOrderNumber`
   - `parcelTrackingInfo` array
   - `labelPrintingRequestedBy = userId`

**Assertions:**
- Response status code = 200
- JSONPath: `data.attributes.line.returnOrderNumber` = expected order ID
- JSONPath: `data.attributes.line.parcelTrackingInfo` not empty

##### Test 2: `should throw bad request when parcel tracking info missing for DPD confirm line request`

**Scenario:** Validation for missing tracking info

```kotlin
@Test
@Tag("integration")
@ExpectedToFail  // Currently marked as expected to fail
fun `should throw bad request when parcel tracking info missing for DPD confirm line request`()
```

**Steps:**
1. Create return order
2. Build confirmation request **without** `parcelTrackingInfo`
3. POST to `/v1/confirm/{tenant}/{returnOrderNumber}/{lineNumber}`
4. Expect HTTP 400 Bad Request

**Assertions:**
- Response status code = 400

**Status:** ⚠️ **Currently fails** - marked with `@ExpectedToFail` annotation

---

#### DeleteReturnOrderTest.kt

**Purpose:** Validate return order deletion

**Base Class:** `BaseMockedReturnOrderTest`

##### Test 1: `test should delete return order`

**Scenario:** Delete order and verify removal

```kotlin
@Test
@Tag("integration")
fun `test should delete return order`()
```

**Steps:**
1. Create return order
2. Verify order exists in `/v1/fetchAllOrders`
3. DELETE `/v1/deleteOrder/{returnOrderNumber}`
4. Verify HTTP 204 No Content
5. Fetch all orders again
6. Assert order no longer present
7. Verify WireMock product endpoint was called (side effect check)

**Assertions:**
- DELETE response status code = 204
- Order ID not in fetch response (negation matcher)
- WireMock stub invoked

---

#### UpdateRouteTest.kt

**Purpose:** Validate manual route updates for return lines

**Base Class:** `BaseMockedReturnOrderTest`

##### Test 1: `should successfully update route for return order`

**Scenario:** Update route from TBC to DPD with tracking info

```kotlin
@Test
@Tag("integration")
fun `should successfully update route for return order`()
```

**Steps:**
1. Create return order (initial route = TBC)
2. Build update request:
   - `route = "DPD"`
   - `parcelTrackingInfo = [{ quantity: 1, externalParcelIdentifier: "P123", trackingNumber: "T123" }]`
   - `tenant = "BQUK"`
3. POST to `/v1/updateRoute/{tenant}/{returnOrderNumber}`
4. Verify HTTP 200

**Assertions:**
- Response status code = 200

##### Test 2: `should throw bad request when required fields are missing`

**Scenario:** Validation for empty EAN and reason

```kotlin
@Test
@Tag("integration")
fun `should throw bad request when required fields are missing`()
```

**Steps:**
1. Build update request with:
   - `ean = ""`
   - `reason = ""`
2. POST to `/v1/updateRoute/{tenant}/{returnOrderNumber}`
3. Expect HTTP 400

**Assertions:**
- Response status code = 400

##### Test 3: `should throw bad request when invalid tenant provided`

**Scenario:** Tenant enum validation

```kotlin
@Test
@Tag("integration")
fun `should throw bad request when invalid tenant provided`()
```

**Steps:**
1. Build valid update request
2. POST to `/v1/updateRoute/INVALID_TENANT/{returnOrderNumber}`
3. Expect HTTP 400

**Assertions:**
- Response status code = 400

---

#### ExceptionHandlingTest.kt

**Purpose:** Validate input validation and error handling for fetch endpoint

**Base Class:** `BaseReturnsServiceTest`

**Endpoint Tested:** `GET /v1/fetchReturnLines/{tenant}/{storeId}?dateFrom={dateFrom}&dateTo={dateTo}`

##### Test 1: `test incorrect date format - missing time`

```kotlin
@Test
@Tag("integration")
fun `test incorrect date format - missing time`()
```

**Input:** `dateFrom=2024-08-29` (missing time component)

**Expected:** HTTP 400

##### Test 2: `test incorrect date format - missing date`

```kotlin
@Test
@Tag("integration")
fun `test incorrect date format - missing date`()
```

**Input:** `dateFrom=08:31:06` (missing date component)

**Expected:** HTTP 400

##### Test 3: `test empty date_from`

```kotlin
@Test
@Tag("integration")
fun `test empty date_from`()
```

**Input:** `dateFrom=""` (empty parameter)

**Expected:** HTTP 400

##### Test 4: `test store_id not a number`

```kotlin
@Test
@Tag("integration")
fun `test store_id not a number`()
```

**Input:** `storeId="abcd"` (non-numeric)

**Expected:** HTTP 400

##### Test 5: `test dateFrom is bigger than dateTo`

```kotlin
@Test
@Tag("integration")
fun `test dateFrom is bigger than dateTo`()
```

**Input:** `dateFrom=2024-08-30T10:00:00`, `dateTo=2024-08-29T10:00:00`

**Expected:** HTTP 400 (date range validation)

##### Test 6: `test valid request`

```kotlin
@Test
@Tag("integration")
fun `test valid request`()
```

**Input:** Valid ISO_LOCAL_DATE_TIME format for both dates

**Expected:** HTTP 200

---

#### WindsorFrameworkTest.kt

**Purpose:** Validate route determination logic based on store type and order value

**Base Class:** `BaseMockedReturnOrderTest`

**Test Strategy:** Parameterized tests with store ID variations

##### Store Categories

**Windsor Framework Stores:**
```kotlin
@JvmStatic
fun windsorStoreIds() = listOf(1211, 1355, 1353, 1209, 1318)
```

**B&Q Stores:**
```kotlin
@JvmStatic
fun bqStoreIds() = listOf(1017, 1052)
```

##### Test 1: `should check route and reasonForIForce when order meets conditions for TBC`

**Scenario:** High-value orders routing behavior

```kotlin
@ParameterizedTest
@MethodSource("windsorStoreIds", "bqStoreIds")
@Tag("integration")
fun `should check route and reasonForIForce when order meets conditions for TBC`(storeId: Int)
```

**Input:**
- `currencyID = 20.3` (high value)
- `storeId = {parameterized}`

**Expected Behavior:**

| Store Type | Expected Route | Expected reasonForIForce | Expected Status |
|-----------|---------------|-------------------------|-----------------|
| **Windsor** (1211, 1355, etc.) | `"iForce"` | `"Windsor Framework"` | `"AWAITING_STORE_CONFIRMATION"` or `"AWAITING_LABEL_PRINTING"` |
| **B&Q** (1017, 1052) | `"TBC"` | `""` (empty) | `"AWAITING_STORE_CONFIRMATION"` |

**Business Logic Tested:**
- Windsor Framework stores → **always route to iForce** regardless of value
- B&Q stores → route to TBC for high-value items (manual confirmation required)

##### Test 2: `should check route and reasonForIForce when order meets conditions for iForce`

**Scenario:** Low-value orders routing behavior

```kotlin
@ParameterizedTest
@MethodSource("windsorStoreIds", "bqStoreIds")
@Tag("integration")
fun `should check route and reasonForIForce when order meets conditions for iForce`(storeId: Int)
```

**Input:**
- `currencyID = -0.3` (low/negative value)
- `storeId = {parameterized}`

**Expected Behavior:**

| Store Type | Expected Route | Expected reasonForIForce | Expected Status |
|-----------|---------------|-------------------------|-----------------|
| **Windsor** (1211, 1355, etc.) | `"iForce"` | `"Windsor Framework"` | `"AWAITING_LABEL_PRINTING"` |
| **B&Q** (1017, 1052) | `"iForce"` | `"Product-amount"` | `"AWAITING_LABEL_PRINTING"` |

**Business Logic Tested:**
- Windsor Framework stores → route to iForce with "Windsor Framework" reason
- B&Q stores → route to iForce with "Product-amount" reason (below threshold)

**Total Executions:** 4 test methods × parameterized values = **10 test executions**

---

### 5.3 Integration Points Tested

| Integration | Test Coverage | Test File | Status |
|------------|---------------|-----------|--------|
| **REST API Endpoints** | Full CRUD + validation | All test files | ✅ Covered |
| **DynamoDB** | Implicit via API | All test files | ✅ Covered |
| **WireMock (Product API)** | Basic stub setup | BaseMockedReturnOrderTest | ⚠️ Partial |
| **IBM MQ** | Not tested | - | ❌ Missing |
| **Kafka Events** | Not tested | - | ❌ Missing |
| **Mirakl API** | Not mocked/tested | - | ❌ Missing |
| **Seller API** | Not mocked/tested | - | ❌ Missing |
| **Carrier Booking API** | Not mocked/tested | - | ❌ Missing |

---

## 6. Test Architecture & Patterns

### 6.1 Base Classes

#### BaseReturnsServiceTest.kt

**Purpose:** Base class for all REST Assured tests

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/core/BaseReturnsServiceTest.kt`

**Responsibilities:**
- Initialize REST Assured configuration
- Configure default headers
- Set up request/response logging
- Provide fluent `When()` method

**Configuration:**
```kotlin
init {
    RestAssured.baseURI = ConfigurationManager.getBaseUrl()
    RestAssured.port = ConfigurationManager.getPort().toInt()

    // Default headers
    RestAssured.requestSpecification = RequestSpecBuilder()
        .addHeader("User-Agent", "mktp-returns-ta")
        .setContentType(ContentType.JSON)
        .build()

    // Logging
    RestAssured.filters(
        SpecLoggingFilter.requestLog(),
        SpecLoggingFilter.responseLog()
    )

    // Validation
    RestAssured.config = RestAssured.config()
        .logConfig(LogConfig.logConfig().enableLoggingOfRequestAndResponseIfValidationFails())

    // Redirect handling
    RestAssured.config = RestAssured.config()
        .redirect(RedirectConfig.redirectConfig().followRedirects(true).maxRedirects(1))
}

fun When(): RequestSpecification = RestAssured.given()
```

**Usage in Tests:**
```kotlin
When().get("/v1/fetchAllOrders")
    .then()
    .statusCode(200)
```

---

#### BaseMockedReturnOrderTest.kt

**Purpose:** Base class for tests requiring WireMock and order lifecycle management

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/api/BaseMockedReturnOrderTest.kt`

**Extends:** `BaseReturnsServiceTest`

**Additional Features:**
- WireMock configuration
- Product API stub setup
- Order cleanup management
- Unique order ID generation

**Lifecycle:**

```kotlin
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
abstract class BaseMockedReturnOrderTest : BaseReturnsServiceTest() {

    private val wireMockServer = WireMockServer(9090)
    private val ordersToCleanup = mutableListOf<String>()
    private val orderIdGenerator = AtomicLong(4001876521)

    @BeforeEach
    fun setupWireMock() {
        // Configure Product API stub
        wireMockServer.stubFor(
            WireMock.get(WireMock.urlMatching("/v1/products/BQUK\\?filter%5Bean%5D=\\d+(,\\d+)?"))
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("product_response.json")
                )
        )
    }

    @AfterEach
    fun cleanup() {
        ordersToCleanup.forEach { orderId ->
            try {
                When().delete("/v1/deleteOrder/{RETURN_ORDER_ID}", orderId)
                    .then()
                    .statusCode(204)
            } catch (e: Exception) {
                println("Cleanup warning: ${e.message}")
            }
        }
        ordersToCleanup.clear()
    }

    @AfterAll
    fun teardownWireMock() {
        wireMockServer.resetAll()
    }

    fun generateUniqueOrderDetails(): PSO.ReturnOrderDetails {
        val orderId = orderIdGenerator.incrementAndGet().toString()
        ordersToCleanup.add(orderId)
        return PSO.ReturnOrderDetails(
            orderId = orderId,
            alternateId = "ret16650152",
            originalOrderId = "1930157522",
            customerEmail = "test@example.com",
            customerFirstName = "John",
            customerLastName = "Doe",
            phoneNumber = "1234567890",
            storeId = "1017",
            currencyID = "20.3"
        )
    }
}
```

**Key Features:**
- **Automatic cleanup:** All created orders deleted in `@AfterEach`
- **Unique IDs:** Auto-incremented starting from 4001876521
- **WireMock lifecycle:** Stubs configured per test, reset after all tests
- **Graceful cleanup:** Continues cleanup even if delete fails

---

### 6.2 Data Builders

#### PSO.kt

**Purpose:** Build and send PSO (Product Sales Order) XML messages

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/PSO.kt`

**Usage:**
```kotlin
val orderDetails = PSO.ReturnOrderDetails(
    orderId = "4001876522",
    alternateId = "ret16650152",
    originalOrderId = "1930157522",
    customerEmail = "test@example.com",
    customerFirstName = "John",
    customerLastName = "Doe",
    phoneNumber = "1234567890",
    storeId = "1017",
    currencyID = "20.3"
)

val response = PSO.createReturnOrder(orderDetails)
```

**Implementation:**
```kotlin
object PSO {
    data class ReturnOrderDetails(
        val orderId: String,
        val alternateId: String,
        val originalOrderId: String,
        val customerEmail: String,
        val customerFirstName: String,
        val customerLastName: String,
        val phoneNumber: String,
        val storeId: String,
        val currencyID: String
    )

    fun createReturnOrder(details: ReturnOrderDetails): Response {
        val template = javaClass.getResource("/data/request/SingleLineReturnPSO.xml")?.readText()
            ?: throw IllegalStateException("Template not found")

        val xml = template
            .replace("{{orderId}}", details.orderId)
            .replace("{{alternateId}}", details.alternateId)
            .replace("{{originalOrderId}}", details.originalOrderId)
            .replace("{{customerEmail}}", details.customerEmail)
            .replace("{{customerFirstName}}", details.customerFirstName)
            .replace("{{customerLastName}}", details.customerLastName)
            .replace("{{phoneNumber}}", details.phoneNumber)
            .replace("{{storeId}}", details.storeId)
            .replace("{{currencyID}}", details.currencyID)

        return RestAssured.given()
            .contentType(ContentType.XML)
            .body(xml)
            .post("/v1/import")
    }
}
```

**Template:** `/functional-tests/src/test/resources/data/request/SingleLineReturnPSO.xml`

---

#### ConfirmReturnRequestBuilder.kt

**Purpose:** Build confirmation request payloads

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/ConfirmReturnRequestBuilder.kt`

**Usage:**
```kotlin
val request = ConfirmReturnRequestBuilder()
    .withUserId("user123")
    .withTrackingNumber("T123")
    .withParcelId("P123")
    .withQuantity(1)
    .buildDpdRequest()
```

**Methods:**
- `withUserId(userId: String)`: Set user ID
- `withTrackingNumber(trackingNumber: String)`: Set tracking number
- `withParcelId(parcelId: String)`: Set external parcel identifier
- `withQuantity(quantity: Int)`: Set quantity
- `buildDpdRequest()`: Build with parcel tracking info
- `buildNonDpdRequest()`: Build without tracking info

---

#### UpdateRouteBuilder.kt

**Purpose:** Build route update request payloads

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/UpdateRouteBuilder.kt`

**Usage:**
```kotlin
val request = UpdateRouteBuilder()
    .withUserId("user123")
    .addUpdateRouteAttributesWithTracking(
        lineNumber = 1,
        ean = "1234567890",
        route = "DPD",
        quantity = 1,
        reason = "Customer requested",
        parcelTrackingInfo = listOf(
            ParcelTrackingInfo(quantity = 1, externalParcelIdentifier = "P123", trackingNumber = "T123")
        )
    )
    .build()
```

**Methods:**
- `withUserId(userId: String)`: Set user ID
- `addUpdateRouteAttributes(...)`: Add line without tracking
- `addUpdateRouteAttributesWithTracking(...)`: Add line with tracking
- `build()`: Build request object

---

### 6.3 Test Utilities

#### ConfigurationManager.kt

**Purpose:** Load and manage test configuration

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/config/ConfigurationManager.kt`

**Implementation:**
```kotlin
object ConfigurationManager {
    private val properties = Properties()

    init {
        val inputStream = javaClass.classLoader.getResourceAsStream("local.properties")
            ?: throw IllegalStateException("local.properties not found")
        properties.load(inputStream)
    }

    fun getBaseUrl(): String = System.getenv("BASE_URL") ?: properties.getProperty("base.url")
    fun getPort(): String = System.getenv("PORT") ?: "8080"
    fun getProperty(key: String): String = properties.getProperty(key)
}
```

**Priority:** Environment variables override properties file

---

#### SpecLoggingFilter.kt

**Purpose:** Custom REST Assured logging filter

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/config/SpecLoggingFilter.kt`

**Features:**
- Logs request/response with test method name
- Supports debug mode via system property
- Min status code filtering for response logs

**Factory Methods:**
```kotlin
object SpecLoggingFilter {
    fun requestLog(): Filter = RequestLoggingFilter()
    fun responseLog(minStatusCode: Int = 0): Filter = ResponseLoggingFilter(minStatusCode)
}
```

---

### 6.4 Assertion Patterns

#### Hamcrest Matchers

```kotlin
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.*

// Status code assertion
assertThat(response.statusCode, equalTo(HttpStatus.SC_OK))

// Collection contains
assertThat(orderIds, hasItem(testOrderId))

// Negation
assertThat(responseBody, not(containsString(deletedOrderId)))
```

#### REST Assured JSONPath

```kotlin
When().get("/v1/fetchAllOrders")
    .then()
    .statusCode(200)
    .body("returnOrderNumber", hasItem(testOrderId.toLong()))
    .body("status", hasItem("AWAITING_STORE_CONFIRMATION"))
```

#### AssertJ (JSON Unit)

```kotlin
import net.javacrumbs.jsonunit.assertj.JsonAssertions.assertThatJson

assertThatJson(response.asString())
    .node("data.attributes.line.returnOrderNumber")
    .isEqualTo(expectedOrderId)
```

---

### 6.5 Common Test Patterns

#### Pattern 1: Create → Assert → Cleanup

```kotlin
@Test
fun `test scenario`() {
    // Arrange
    val orderDetails = generateUniqueOrderDetails()

    // Act
    val response = PSO.createReturnOrder(orderDetails)

    // Assert
    assertThat(response.statusCode, equalTo(200))

    // Cleanup handled by @AfterEach
}
```

#### Pattern 2: Parameterized Testing

```kotlin
@ParameterizedTest
@MethodSource("storeIds")
fun `test with multiple stores`(storeId: Int) {
    // Test logic
}

companion object {
    @JvmStatic
    fun storeIds() = listOf(1017, 1052, 1211)
}
```

#### Pattern 3: WireMock Verification

```kotlin
@Test
fun `verify external API called`() {
    // Act
    PSO.createReturnOrder(orderDetails)

    // Assert
    wireMockServer.verify(
        getRequestedFor(urlMatching("/v1/products/BQUK.*"))
    )
}
```

---

## 7. Gap Analysis

### 7.1 Critical Missing Coverage

#### ❌ IBM MQ Message Processing

**Business Impact:** Primary ingestion mechanism for returns

**Current Coverage:** 0%

**Missing Scenarios:**
1. Process valid PSO XML message
2. Handle eligible vs ineligible category codes
3. Multi-line return processing
4. Invalid XML format handling
5. Product API integration during MQ processing

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt:processReturnOrder()`

---

#### ❌ Kafka Pick Event Processing

**Business Impact:** Handles delivery/collection expiry events (automated refunds)

**Current Coverage:** 0%

**Missing Scenarios:**
1. Pick delivery expiry event → LOST_IN_TRANSIT status
2. Pick collection expiry event → immediate refund
3. Pick collected event → CANCELLED status
4. Eligible vs ineligible shipping method filtering
5. Event type mapping to status/route
6. Order cancellation vs refund logic based on `canCancel` flag

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt:processPickEvent()`
- `src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt:processPickCollectedEvent()`
- `src/main/kotlin/com/kingfisher/marketplace/kafka/PickEventConsumer.kt`

---

#### ❌ Route Determination Logic (Advanced)

**Business Impact:** Incorrect routing causes operational issues

**Current Coverage:** ~20% (only price-based via WindsorFrameworkTest)

**Missing Scenarios:**
1. Battery chemistry (Li-ion) → iForce with "Battery" reason
2. Product weight > 29kg → iForce with "Weight" reason
3. Technical attribute exceeds max threshold → iForce
4. Technical attribute matches specific value → iForce
5. Multiple technical attributes → first match wins
6. Store in default iForce list + high value → iForce (store precedence)

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/IForceRouteValidator.kt:validate()`

---

#### ❌ Carrier Booking API Integration

**Business Impact:** DPD collection booking for customer returns

**Current Coverage:** 0%

**Missing Scenarios:**
1. Valid carrier booking request → success
2. Seller API integration for address lookup
3. Department name vs seller name fallback
4. Carrier booking API failure → exception handling
5. Consignment code and delivery date extraction
6. Address validation (zip, phone, email)

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/CarrierBookingAPIService.kt:invokeCarrierBookingAPI()`

---

#### ❌ Mirakl API Integration

**Business Impact:** Refunds, cancellations, seller notifications

**Current Coverage:** 0%

**Missing Scenarios:**
1. Create refund with valid data
2. Create cancellation with CANCEL reason prefix
3. Currency fallback logic (invalid → order currency)
4. Seller notification with template parameters
5. Refund failure → metrics updated
6. Notification failure → logged but continues
7. Order line ID parsing from logistical order ID

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt:createRefund()`
- `src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt:createCancellation()`
- `src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt:notifySeller()`

---

#### ⚠️ Quantity Split Flow

**Business Impact:** Complex business logic with line creation

**Current Coverage:** 0%

**Missing Scenarios:**
1. Single line split into DPD + iForce
2. New line number generation
3. Quantity distribution
4. Max line number tracking
5. Multiple splits in single request

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/UpdateRouteBusinessServiceImpl.kt:processUpdateRoute()`

---

#### ⚠️ Manual Update Validations

**Business Impact:** Prevents invalid state transitions

**Current Coverage:** 0%

**Missing Scenarios:**
1. Update non-TBC route → reject (400)
2. Update CANCELLED line → reject (400)
3. Status progression validation (forward only)
4. Status valid for given route
5. Allowed route list validation

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/service/ManualUpdateLineDetailsServiceImpl.kt:updateLineDetails()`

---

#### ⚠️ DynamoDB GSI Queries

**Business Impact:** Store-specific queries with date filtering

**Current Coverage:** 0%

**Missing Scenarios:**
1. Query by store ID + date range
2. Tenant filtering
3. Status filtering (multiple statuses)
4. Retention period filtering (confirmed vs non-confirmed)
5. Pagination handling

**Required Files to Test:**
- `src/main/kotlin/com/kingfisher/marketplace/repository/ReturnLineRepository.kt:fetchRecordsInGivenTimeRangeForSpecificStoreAndTenant()`

---

### 7.2 Coverage Metrics by Module

| Module | Business Logic Scenarios | Current Coverage | Gap | Priority |
|--------|-------------------------|------------------|-----|----------|
| **Return Processing (MQ)** | 10 | 0 | 100% | CRITICAL |
| **Kafka Event Processing** | 16 | 0 | 100% | CRITICAL |
| **Route Determination** | 8 | 2 | 75% | CRITICAL |
| **Carrier Booking** | 10 | 0 | 100% | CRITICAL |
| **Mirakl Integration** | 28 | 0 | 100% | HIGH |
| **Manual Updates** | 10 | 0 | 100% | HIGH |
| **Route Updates** | 11 | 1 | 90% | HIGH |
| **Quantity Splits** | 5 | 0 | 100% | MEDIUM |
| **DynamoDB Queries** | 12 | 2 | 83% | MEDIUM |
| **Input Validation** | 7 | 6 | 14% | LOW |
| **CRUD Operations** | 12 | 3 | 75% | LOW |

**Overall Coverage:** ~12% of business scenarios (25 / ~150 total scenarios)

**Estimated Coverage After Phase 1 Implementation:** ~40%
**Estimated Coverage After All Phases:** ~90%

---

## Appendix A: Quick Reference

### Test Execution Commands

```bash
# STEP 1: Start all required services (REQUIRED before running tests)
docker compose -f docker-compose-ci.yml up -d

# STEP 2: Run all tests (after containers are running)
./gradlew runFunctionalIntegrationTests

# Run with detailed logs
./gradlew runFunctionalIntegrationTests -Pshowstreams

# Run specific test class
./gradlew runFunctionalIntegrationTests --tests "CreateReturnOrderTest"

# STEP 3: Stop and clean up services
docker compose -f docker-compose-ci.yml down -v

# --- Monitoring Commands ---

# View service logs (while running)
docker compose -f docker-compose-ci.yml logs -f returns-service

# Check service health
docker compose -f docker-compose-ci.yml ps
```

### Key Directories

```
/functional-tests/
├── build.gradle.kts                     # Build configuration
├── src/
│   └── test/
│       ├── kotlin/com/kingfisher/
│       │   ├── api/                     # Test classes
│       │   ├── core/                    # Base classes
│       │   ├── config/                  # Configuration utilities
│       │   ├── utils/                   # Data builders
│       │   └── model/                   # DTOs
│       └── resources/
│           ├── local.properties         # Test config
│           ├── logback-test.xml         # Logging config
│           └── data/
│               ├── request/             # XML templates
│               └── response/            # WireMock responses
└── build/
    ├── reports/integrationTests/        # HTML reports
    └── test-results/runFunctionalIntegrationTests/  # XML results
```

### Important File Paths

| File | Purpose |
|------|---------|
| `.gitlab-ci.yml` | CI/CD pipeline configuration |
| `docker-compose-ci.yml` | Service orchestration |
| `container-setup/__files/` | WireMock container stub responses |
| `container-setup/mappings/` | WireMock container stub URL patterns |
| `functional-tests/build.gradle.kts` | Test build config |
| `functional-tests/src/test/resources/local.properties` | Test endpoints |
| `functional-tests/src/test/resources/data/response/` | Programmatic stub responses |
| `functional-tests/src/test/kotlin/com/kingfisher/core/BaseReturnsServiceTest.kt` | Base test class |
| `functional-tests/src/test/kotlin/com/kingfisher/api/BaseMockedReturnOrderTest.kt` | Base with WireMock |

---

## Appendix B: Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| **Port 8080 already in use** | Kill existing process: `lsof -ti:8080 \| xargs kill -9` |
| **DynamoDB table not created** | Check docker-compose logs: `docker compose -f docker-compose-ci.yml logs dynamodb-local` |
| **WireMock stubs not loading** | Check container stubs: `ls -la container-setup/__files/` and verify mappings |
| **Tests timeout waiting for service** | Check service logs: `docker compose -f docker-compose-ci.yml logs returns-service` |
| **Cleanup fails in AfterEach** | Normal - test continues, check logs for details |

---

## Document Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Feb 2026 | SDiT Team | Initial comprehensive documentation |

---

**End of Document**
