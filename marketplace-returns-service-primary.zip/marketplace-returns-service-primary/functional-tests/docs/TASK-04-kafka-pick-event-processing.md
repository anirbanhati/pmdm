# TASK-04: Kafka Pick Event Processing Testing

**Complexity:** ⭐⭐⭐⭐ Most Complex
**Estimated Effort:** 3-4 days
**Can Run in Parallel:** ⚠️ Partially see dependencies section
**Priority:** HIGH (Phase 2 - Event-Driven Flows)

---

## Why This is Needed

### Business Problem

The returns service subscribes to Kafka events from the **Order Management** and **In-Store Fulfilment** systems to automatically handle delivery/collection expiry scenarios:

**Use Cases:**
1. **Delivery Expiry** (Pick delivery expired waiting at store)
   - Customer never collected their order from store
   - System automatically marks return as LOST_IN_TRANSIT
   - Triggers refund process

2. **Collection Expiry** (Pick collection expired - customer didn't drop off)
   - Customer requested return but never dropped item at store
   - System creates cancellation (if eligible) OR refund
   - Based on `canCancel` flag in the event

3. **Pick Collected** (Customer collected their order - not a return scenario)
   - Customer picked up their order successfully
   - Return order should be CANCELLED (no longer needed)

**Current Gap:** Zero functional test coverage for Kafka event processing. The integration tests mock the entire `ReturnBusinessService`, meaning the actual event consumption, Avro deserialization, filtering logic, status transitions, and Mirakl integration triggered by events are **never verified end-to-end**.

**Business Impact:**
- Silent event processing failures mean customers don't get refunds
- Incorrect status transitions cause operational confusion
- Wrong refund vs cancellation logic costs money
- Event filtering bugs process events that should be ignored
- Kafka consumer errors not detected until production

**Financial Impact:**
- Missed refunds lead to customer complaints and chargebacks
- Incorrect cancellations when refund needed (accounting issues)
- Manual intervention for failed automated processes (~£20 per case)

### What You'll Learn

- Event-driven architecture testing
- Kafka producer/consumer patterns for testing
- Avro schema serialization/deserialization
- Complex business state machines (event → status → action)
- Asynchronous testing with Awaitility
- Multi-system integration (Kafka + DynamoDB + Mirakl via WireMock)
- How marketplace order lifecycle works

---

## What Needs to Be Done

### Objectives

1. **Create functional tests** for Kafka Pick event processing
2. **Set up Kafka test infrastructure** to produce events to test topics
3. **Implement 7 test scenarios** covering all event types and business rules
4. **Verify complex event filtering** (shipping methods, event types)
5. **Test status transitions** and downstream actions (refunds, cancellations)
6. **Validate Avro schema** compatibility and deserialization
7. **Document event-driven testing patterns** for future event processing tests

### Scope

**New Files to Create:**
- `/functional-tests/src/test/kotlin/com/kingfisher/kafka/KafkaPickEventTest.kt` (main test class)
- `/functional-tests/src/test/kotlin/com/kingfisher/kafka/util/KafkaTestProducer.kt` (Kafka utility)
- `/functional-tests/src/test/kotlin/com/kingfisher/kafka/util/PickEventBuilder.kt` (Test data builder)
- `/functional-tests/src/test/resources/schemas/pick-event.avsc` (Avro schema copy)
- `/functional-tests/docs/KAFKA-EVENT-PROCESSING.md` (comprehensive documentation)

**Business Logic Under Test:**
Located in:
- `/src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt`
  - `processPickEvent()` method (~50 lines)
  - `processPickCollectedEvent()` method (~30 lines)
- `/src/main/kotlin/com/kingfisher/marketplace/kafka/PickEventConsumer.kt`
  - `consumePickEvent()` listener method

**Complex Business Rules:**

1. **Shipping Method Filtering:**
   ```
   Eligible: PICKUP_AT_STORE, CLICK_AND_COLLECT
   Ineligible: HOME_DELIVERY, SHIP_TO_STORE
   → Only process events for eligible shipping methods
   ```

2. **Event Type Mapping:**
   ```
   Event Type              → Action
   PICK_DELIVERY_EXPIRY   → Status: LOST_IN_TRANSIT, then refund
   PICK_COLLECTION_EXPIRY → Cancellation OR Refund (based on canCancel flag)
   PICK_COLLECTED         → Status: CANCELLED (order fulfilled, return not needed)
   ```

3. **Cancellation vs Refund Decision:**
   ```
   if (event.canCancel == true)  → Create cancellation in Mirakl
   if (event.canCancel == false) → Create refund in Mirakl
   ```

4. **Order Matching:**
   ```
   Event.orderLineId must match existing return order's orderLineId
   If no match → Skip event (not a return scenario)
   ```

---

## High-Level Technical Approach

### Step 1: Understand Kafka Infrastructure

**Current Setup (from docker-compose-ci.yml):**
```yaml
kafka-broker:
  image: confluentinc/cp-kafka:7.2.2
  ports: 9092:9092

schema-registry:
  image: confluentinc/cp-schema-registry:6.2.0
  ports: 8081:8081

zookeeper:
  ports: 2181:2181
```

**Topics Used:**
- `public.bquk.order-management.test.pick` - Pick delivery/collection events
- `public.in-store-fulfilment.test.pick` - Pick collected events

**Key Concepts:**
- Events are Avro-serialized (binary format)
- Schema Registry holds event schemas
- Consumer group: `marketplace-return-test-pick-event-group`
- Auto-commit disabled (manual acknowledgment)

### Step 2: Create Kafka Test Producer Utility

**Purpose:** Send test events to Kafka topics from tests

```kotlin
package com.kingfisher.kafka.util

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.clients.producer.RecordMetadata
import io.confluent.kafka.serializers.KafkaAvroSerializer
import java.util.Properties

/**
 * Utility to produce Kafka events for functional testing.
 * Uses Apache Kafka client directly (not Spring Kafka).
 */
class KafkaTestProducer(
    private val bootstrapServers: String = "localhost:9092",
    private val schemaRegistryUrl: String = "http://localhost:8081"
) {

    private val producer: KafkaProducer<String, Any>

    init {
        val props = Properties().apply {
            put("bootstrap.servers", bootstrapServers)
            put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
            put("value.serializer", KafkaAvroSerializer::class.java.name)
            put("schema.registry.url", schemaRegistryUrl)
        }
        producer = KafkaProducer(props)
    }

    /**
     * Send Avro event to topic
     * @return RecordMetadata for verification
     */
    fun sendEvent(topic: String, key: String, event: Any): RecordMetadata {
        val record = ProducerRecord(topic, key, event)
        val future = producer.send(record)
        return future.get() // Blocking wait for send completion
    }

    fun close() {
        producer.flush()
        producer.close()
    }
}
```

### Step 3: Create Pick Event Builder

**Purpose:** Fluent builder for test events

```kotlin
package com.kingfisher.kafka.util

import java.time.Instant

/**
 * Builder for Pick event test data.
 * Supports all event types: DELIVERY_EXPIRY, COLLECTION_EXPIRY, COLLECTED
 */
class PickEventBuilder {

    private var orderLineId: String = "ORDER-123-A"
    private var eventType: String = "PICK_DELIVERY_EXPIRY"
    private var shippingMethod: String = "PICKUP_AT_STORE"
    private var canCancel: Boolean = true
    private var expiryDate: Instant = Instant.now()

    fun withOrderLineId(id: String) = apply { this.orderLineId = id }
    fun withEventType(type: String) = apply { this.eventType = type }
    fun withShippingMethod(method: String) = apply { this.shippingMethod = method }
    fun withCanCancel(canCancel: Boolean) = apply { this.canCancel = canCancel }
    fun withExpiryDate(date: Instant) = apply { this.expiryDate = date }

    // Convenience methods for common scenarios
    fun deliveryExpiry() = apply { eventType = "PICK_DELIVERY_EXPIRY" }
    fun collectionExpiry() = apply { eventType = "PICK_COLLECTION_EXPIRY" }
    fun collected() = apply { eventType = "PICK_COLLECTED" }

    fun ineligibleShippingMethod() = apply { shippingMethod = "HOME_DELIVERY" }

    /**
     * Build Avro GenericRecord (or actual PickEvent POJO if available)
     */
    fun build(): Any {
        // TODO: Use actual Avro schema to create GenericRecord
        // OR use generated Avro POJO class
        return mapOf(
            "orderLineId" to orderLineId,
            "eventType" to eventType,
            "shippingMethod" to shippingMethod,
            "canCancel" to canCancel,
            "expiryDate" to expiryDate.toString()
        )
    }
}
```

### Step 4: Implement Test Scenarios

**7 Required Scenarios:**

| # | Scenario | Event Type | Expected Outcome | Complexity |
|---|----------|------------|------------------|------------|
| 1 | Delivery expiry → LOST_IN_TRANSIT | PICK_DELIVERY_EXPIRY | Status updated, refund created | ⭐⭐⭐ |
| 2 | Collection expiry + canCancel=true | PICK_COLLECTION_EXPIRY | Cancellation created in Mirakl | ⭐⭐⭐ |
| 3 | Collection expiry + canCancel=false | PICK_COLLECTION_EXPIRY | Refund created in Mirakl | ⭐⭐⭐ |
| 4 | Pick collected → CANCELLED | PICK_COLLECTED | Return order cancelled | ⭐⭐ |
| 5 | Ineligible shipping method | Any | Event ignored, no processing | ⭐⭐ |
| 6 | Ineligible event type | UNKNOWN_EVENT | Event ignored | ⭐⭐ |
| 7 | Order not found | Any | Event skipped gracefully | ⭐⭐ |

### Step 5: Example Test Implementation

**Scenario 1: Delivery Expiry → LOST_IN_TRANSIT**

```kotlin
package com.kingfisher.kafka

import com.kingfisher.api.BaseMockedReturnOrderTest
import com.kingfisher.kafka.util.KafkaTestProducer
import com.kingfisher.kafka.util.PickEventBuilder
import org.awaitility.Awaitility.await
import org.junit.jupiter.api.*
import java.util.concurrent.TimeUnit
import static org.assertj.core.api.Assertions.assertThat

@TestMethodOrder(MethodOrderer.OrderAnnotation::class)
class KafkaPickEventTest : BaseMockedReturnOrderTest() {

    private lateinit var kafkaProducer: KafkaTestProducer
    private val pickTopic = "public.bquk.order-management.test.pick"

    @BeforeAll
    fun setupKafka() {
        kafkaProducer = KafkaTestProducer(
            bootstrapServers = "localhost:9092",
            schemaRegistryUrl = "http://localhost:8081"
        )
    }

    @AfterAll
    fun teardownKafka() {
        kafkaProducer.close()
    }

    @Test
    @Order(1)
    fun `should update status to LOST_IN_TRANSIT when delivery expiry event received`() {
        // GIVEN: Return order exists with AWAITING_STORE_CONFIRMATION status
        val orderLineId = "ORDER-4001-A"
        val returnOrder = createReturnOrder(
            orderLineId = orderLineId,
            status = "AWAITING_STORE_CONFIRMATION",
            route = "TBC"
        )

        // Setup Mirakl refund stub (delivery expiry triggers refund)
        setupMiraklRefundStub()

        // WHEN: Pick delivery expiry event published to Kafka
        val event = PickEventBuilder()
            .withOrderLineId(orderLineId)
            .deliveryExpiry()
            .withShippingMethod("PICKUP_AT_STORE")
            .build()

        kafkaProducer.sendEvent(pickTopic, orderLineId, event)

        // THEN: Wait for event to be processed (async)
        await()
            .atMost(30, TimeUnit.SECONDS)
            .pollInterval(2, TimeUnit.SECONDS)
            .untilAsserted {
                val updatedOrder = fetchReturnOrder(returnOrder.id)
                assertThat(updatedOrder.status).isEqualTo("LOST_IN_TRANSIT")
            }

        // AND: Verify Mirakl refund API was called
        wireMockServer.verify(
            postRequestedFor(urlPathEqualTo("/api/refunds"))
                .withRequestBody(matchingJsonPath("$.order_id", containing("ORDER-4001")))
        )

        // AND: Verify order in DynamoDB has updated timestamp
        val finalOrder = fetchReturnOrder(returnOrder.id)
        assertThat(finalOrder.lastModifiedDate).isAfter(returnOrder.createdDate)
    }
}
```

**Scenario 2: Collection Expiry with Cancellation**

```kotlin
@Test
@Order(2)
fun `should create cancellation when collection expiry event with canCancel true`() {
    // GIVEN: Return order exists
    val orderLineId = "ORDER-4002-A"
    createReturnOrder(orderLineId = orderLineId, route = "TBC")

    // Setup Mirakl cancellation stub
    wireMockServer.stubFor(
        post(urlPathEqualTo("/api/cancellations"))
            .willReturn(aResponse().withStatus(201))
    )

    // WHEN: Collection expiry event with canCancel=true
    val event = PickEventBuilder()
        .withOrderLineId(orderLineId)
        .collectionExpiry()
        .withCanCancel(true)  // Important!
        .build()

    kafkaProducer.sendEvent(pickTopic, orderLineId, event)

    // THEN: Verify cancellation API called (NOT refund)
    await()
        .atMost(30, TimeUnit.SECONDS)
        .untilAsserted {
            wireMockServer.verify(
                postRequestedFor(urlPathEqualTo("/api/cancellations"))
                    .withRequestBody(matchingJsonPath("$.reason", matching("^CANCEL:.*")))
            )
        }

    // AND: Verify refund was NOT created
    wireMockServer.verify(
        exactly(0),
        postRequestedFor(urlPathEqualTo("/api/refunds"))
    )
}
```

**Scenario 3: Collection Expiry with Refund**

```kotlin
@Test
@Order(3)
fun `should create refund when collection expiry event with canCancel false`() {
    // GIVEN: Return order exists
    val orderLineId = "ORDER-4003-A"
    createReturnOrder(orderLineId = orderLineId, route = "iForce")

    setupMiraklRefundStub()

    // WHEN: Collection expiry event with canCancel=false
    val event = PickEventBuilder()
        .withOrderLineId(orderLineId)
        .collectionExpiry()
        .withCanCancel(false)  // Key difference from scenario 2!
        .build()

    kafkaProducer.sendEvent(pickTopic, orderLineId, event)

    // THEN: Verify refund API called (NOT cancellation)
    await()
        .atMost(30, TimeUnit.SECONDS)
        .untilAsserted {
            wireMockServer.verify(
                postRequestedFor(urlPathEqualTo("/api/refunds"))
            )
        }

    // AND: Verify cancellation was NOT created
    wireMockServer.verify(
        exactly(0),
        postRequestedFor(urlPathEqualTo("/api/cancellations"))
    )
}
```

**Scenario 5: Ineligible Shipping Method (Filtering)**

```kotlin
@Test
@Order(5)
fun `should skip event when shipping method is ineligible`() {
    // GIVEN: Return order exists
    val orderLineId = "ORDER-4005-A"
    createReturnOrder(orderLineId = orderLineId)

    // WHEN: Event with HOME_DELIVERY (ineligible)
    val event = PickEventBuilder()
        .withOrderLineId(orderLineId)
        .deliveryExpiry()
        .ineligibleShippingMethod()  // Sets to HOME_DELIVERY
        .build()

    kafkaProducer.sendEvent(pickTopic, orderLineId, event)

    // THEN: Wait reasonable time and verify NO processing occurred
    Thread.sleep(5000) // Wait 5 seconds

    val order = fetchReturnOrder(orderLineId)
    assertThat(order.status).isNotEqualTo("LOST_IN_TRANSIT") // Status unchanged

    // AND: Verify no Mirakl API calls
    wireMockServer.verify(
        exactly(0),
        postRequestedFor(urlPathMatching("/api/.*"))
    )
}
```

### Step 6: Asynchronous Testing Patterns

**Key Challenge:** Kafka processing is asynchronous - event consumption happens in background thread.

**Solution:** Use Awaitility for polling assertions

```kotlin
import org.awaitility.Awaitility.await
import java.util.concurrent.TimeUnit

// Pattern 1: Wait for status change
await()
    .atMost(30, TimeUnit.SECONDS)
    .pollInterval(2, TimeUnit.SECONDS)
    .pollDelay(1, TimeUnit.SECONDS)
    .untilAsserted {
        val order = fetchReturnOrder(orderId)
        assertThat(order.status).isEqualTo("LOST_IN_TRANSIT")
    }

// Pattern 2: Wait for API call
await()
    .atMost(30, TimeUnit.SECONDS)
    .until({
        wireMockServer.findAll(postRequestedFor(urlPathEqualTo("/api/refunds")))
            .isNotEmpty()
    })

// Pattern 3: Wait with custom condition
await()
    .atMost(20, TimeUnit.SECONDS)
    .until({ checkEventProcessed(orderId) }, { it == true })
```

---

## Success Metrics

### Test Coverage Metrics

- ✅ **7 test scenarios** covering all event types and business rules
- ✅ **Kafka event processing coverage**: 0% → 100%
- ✅ **All event types tested**: DELIVERY_EXPIRY, COLLECTION_EXPIRY, COLLECTED
- ✅ **Filtering logic verified**: Shipping methods, event types
- ✅ **Tests run reliably**: 100% pass rate over 10 runs

### Quality Metrics

- ✅ **Asynchronous handling correct**: No race conditions, proper waits
- ✅ **Avro serialization works**: Events properly deserialized
- ✅ **Business logic verified**: canCancel flag determines cancellation vs refund
- ✅ **Integration verified**: Kafka → Service → Mirakl → DynamoDB flow
- ✅ **Error scenarios**: Missing orders, invalid events handled gracefully

### Documentation Metrics

- ✅ **KAFKA-EVENT-PROCESSING.md**: Event schemas, business rules, testing patterns
- ✅ **Reusable utilities**: KafkaTestProducer, PickEventBuilder documented
- ✅ **Testing guide**: How to add new event processing tests

---

## Acceptance Criteria

**Before Considering Task Complete:**

- [ ] All 7 test scenarios implemented and passing
- [ ] KafkaTestProducer utility created and documented
- [ ] PickEventBuilder for fluent test data creation
- [ ] Avro schema compatibility verified
- [ ] Asynchronous testing patterns working (Awaitility)
- [ ] All event types tested (delivery/collection expiry, collected)
- [ ] Filtering logic tested (shipping methods, event types)
- [ ] canCancel flag behavior verified (cancellation vs refund)
- [ ] Order matching logic tested (event.orderLineId → return order)
- [ ] KAFKA-EVENT-PROCESSING.md comprehensive documentation
- [ ] Tests pass reliably (10 consecutive runs)
- [ ] No flaky tests due to timing issues
- [ ] Tests pass in CI/CD pipeline
- [ ] Kafka consumer offset committed correctly
- [ ] Code review approved by senior developer/architect
- [ ] Knowledge sharing session delivered to team

---

## Dependencies & Parallelization

**Can Start Immediately:** ⚠️ **Partially**

**Dependencies:**
- **Recommended**: Complete TASK-03 (Mirakl Integration) first
  - Reason: Kafka events trigger Mirakl API calls (refunds, cancellations)
  - If Mirakl tests exist, you can reuse WireMock stub patterns
  - Can start without, but will need to create Mirakl stubs anyway

**Blocked By:** None (hard requirement)

**Blocks:** None

**Parallel Execution:**
- Can work in parallel with TASK-01, TASK-02
- **Coordinate with TASK-03** if both being worked simultaneously
- Separate test file, minimal merge conflicts

**Required Services (Critical):**
- Kafka broker (port 9092)
- Zookeeper (port 2181)
- Schema Registry (port 8081)
- WireMock (port 9090)
- DynamoDB (port 8000)
- **Application must be running** to consume events

---

## Getting Started Guide

### 1. Understand Event-Driven Architecture (3-4 hours)

**Critical Learning:**

```bash
# Find Kafka consumer code
grep -r "@KafkaListener\|@Consumer" src/main/kotlin/

# Study event processing logic
src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt

# Find event schemas
find src/main/resources -name "*.avsc" -o -name "*schema*"
```

**Key Questions:**
- What Kafka topics does the service consume?
- What event types exist? (schemas)
- How are events deserialized? (Avro? JSON?)
- What business actions are triggered by each event?
- What's the consumer group name?

### 2. Set Up Kafka Test Infrastructure (2-3 hours)

**Verify Kafka is running:**
```bash
# Start all containers
docker-compose -f docker-compose-ci.yml up -d

# Check Kafka is accessible
docker exec -it kafka-broker kafka-topics --bootstrap-server localhost:9092 --list

# Check Schema Registry
curl http://localhost:8081/subjects
```

**Create test topics:**
```bash
docker exec -it kafka-broker kafka-topics \
  --create \
  --bootstrap-server localhost:9092 \
  --topic public.bquk.order-management.test.pick \
  --partitions 1 \
  --replication-factor 1
```

### 3. Implement KafkaTestProducer (3-4 hours)

**Add Kafka dependencies** to `build.gradle.kts`:
```kotlin
functionalTestImplementation("org.apache.kafka:kafka-clients:3.4.0")
functionalTestImplementation("io.confluent:kafka-avro-serializer:7.3.0")
functionalTestImplementation("org.awaitility:awaitility:4.2.0")
```

**Implement producer utility:**
- Handle Avro serialization
- Connect to local Schema Registry
- Send events and return metadata

**Test the producer in isolation:**
```kotlin
@Test
fun `producer can send event successfully`() {
    val producer = KafkaTestProducer()
    val event = mapOf("test" to "data")
    val metadata = producer.sendEvent("test-topic", "key", event)
    assertThat(metadata.hasOffset()).isTrue()
    producer.close()
}
```

### 4. Implement Happy Path First (1 day)

**Start with Scenario 1:**
- Delivery expiry event
- Verify status changes to LOST_IN_TRANSIT
- Use Awaitility for async waiting
- Get this working end-to-end before moving on

### 5. Implement Remaining Scenarios (1.5 days)

**Order of implementation:**
1. Scenario 4 (Pick collected) - simplest
2. Scenarios 2 & 3 (Collection expiry) - canCancel flag logic
3. Scenarios 5 & 6 (Filtering) - negative cases
4. Scenario 7 (Order not found) - error handling

### 6. Refine Asynchronous Testing (0.5 day)

**Common issues:**
- Tests fail intermittently (timing issues)
- Events not consumed (consumer config wrong)
- Assertions run before event processed (need longer wait)

**Solutions:**
- Increase Awaitility timeout
- Add debug logging
- Verify consumer is actually running
- Check Kafka consumer lag

### 7. Documentation and Review (0.5 day)

- Document event schemas
- Explain async testing patterns
- Create troubleshooting guide
- Knowledge share with team

---

## Resources

### Code References

- **Event processing**: `/src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt`
- **Kafka consumer**: `/src/main/kotlin/com/kingfisher/marketplace/kafka/PickEventConsumer.kt`
- **Event schemas**: `/src/main/resources/schemas/` (if exists)

### Documentation

- **Coverage plan**: `/functional-tests-coverage-plan.md` (Section 2.1)
- **Kafka container config**: `/docker-compose-ci.yml` lines 89-157

### External Resources

- [Apache Kafka Testing](https://kafka.apache.org/documentation/#testing)
- [Awaitility User Guide](https://github.com/awaitility/awaitility/wiki/Usage)
- [Confluent Avro Serializers](https://docs.confluent.io/platform/current/schema-registry/serdes-develop/serdes-avro.html)

---

## Tips for Success

### For Senior QAs

1. **Master async testing first** - Understanding Awaitility is critical
2. **Debug Kafka consumer** - Use Kafka tools to verify events are actually consumed
3. **Start simple** - Get one event working end-to-end before complex scenarios
4. **Monitor consumer lag** - Check if events are piling up or being processed
5. **Think about timing** - Events might be processed before your assertion runs

### Advanced Techniques

**Verify event was consumed:**
```bash
# Check consumer group offset
docker exec -it kafka-broker kafka-consumer-groups \
  --bootstrap-server localhost:9092 \
  --group marketplace-return-test-pick-event-group \
  --describe
```

**Manual event inspection:**
```bash
# Consume events manually to see what's in topic
docker exec -it kafka-broker kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --topic public.bquk.order-management.test.pick \
  --from-beginning
```

**Schema Registry debugging:**
```bash
# List schemas
curl http://localhost:8081/subjects

# Get specific schema
curl http://localhost:8081/subjects/pick-event-value/versions/latest
```

### Common Pitfalls

❌ **Not waiting long enough** - Increase Awaitility timeout to 30s initially
❌ **Event schema mismatch** - Verify Avro schema matches exactly
❌ **Consumer not running** - Ensure Spring Boot app is started before test
❌ **Wrong topic name** - Double-check topic names (case-sensitive)
❌ **Race conditions** - Use proper async assertions, not Thread.sleep()

### Debugging Async Test Failures

**Event not processed:**
1. Check Kafka broker logs: `docker logs kafka-broker`
2. Check app logs for consumer errors
3. Verify topic exists and has the event
4. Check consumer group offset (is it committed?)

**Assertion fails but event processed:**
1. Increase poll interval in Awaitility
2. Add debug logging before assertion
3. Verify you're fetching latest state from DB

**Flaky tests (sometimes pass, sometimes fail):**
1. Classic race condition - event processing timing varies
2. Increase atMost timeout
3. Add pollDelay to give processing time
4. Check for shared state between tests

---

## Expected Deliverables

1. **Code:**
   - `KafkaPickEventTest.kt` (~500-600 lines)
   - `KafkaTestProducer.kt` (~100 lines)
   - `PickEventBuilder.kt` (~100 lines)
   - Avro schema files (if creating new)

2. **Documentation:**
   - `KAFKA-EVENT-PROCESSING.md` with:
     - Event flow diagrams
     - Event schemas (all fields explained)
     - Business rules (event type → action mapping)
     - Async testing patterns guide
     - Troubleshooting common Kafka issues

3. **Pull Request:**
   - Title: "TASK-04: Add Kafka Pick event processing functional tests"
   - Description:
     - Event coverage summary
     - Async testing approach explained
     - Screenshots of tests passing
     - Kafka topics used

---

## Definition of Done

- ✅ All 7 scenarios passing consistently
- ✅ Async testing reliable (no flaky tests)
- ✅ Kafka infrastructure working
- ✅ Event schemas validated
- ✅ Business rules thoroughly tested
- ✅ Documentation comprehensive
- ✅ Pull request approved
- ✅ Tests pass in CI/CD
- ✅ Knowledge shared with team
- ✅ Reusable utilities well-documented

---

## Questions or Blockers?

**Expected Challenges:**
- "Events not being consumed" → Check consumer config, verify app is running
- "Schema deserialization fails" → Verify Avro schema matches exactly
- "Tests are flaky" → Async timing issues, increase timeouts
- "How do I verify event was consumed?" → Use Kafka consumer groups CLI

**Get Help:**
- Pair with backend developer on Kafka consumer setup
- Review existing Kafka integration tests (if any)
- Check application logs during test execution
- Use Kafka CLI tools to debug

---

**Estimated Timeline:**
- Day 1: Kafka infrastructure, KafkaTestProducer, understand event processing
- Day 2: Implement happy path test (scenario 1), debug async issues
- Day 3: Implement remaining scenarios (2-7)
- Day 4: Refine async testing, documentation, review, knowledge share

**This is the most complex task involving event-driven architecture. Successfully completing this demonstrates mastery of async testing and event-driven systems!**
