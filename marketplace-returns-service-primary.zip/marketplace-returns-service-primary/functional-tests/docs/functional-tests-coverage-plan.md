# Marketplace Returns Service - Functional Test Coverage Plan

**Version:** 1.0
**Last Updated:** February 2026
**Purpose:** Phased implementation plan for achieving 90% functional test coverage

---

## Executive Summary

**Current Coverage:** 12% of business scenarios (25 / ~150 scenarios)
**Target Coverage:** 90% (~135 scenarios)
**Estimated Timeline:** 6-8 weeks
**Priority Focus:** Critical revenue-impacting flows and event-driven processing

---

## Table of Contents

1. [Coverage Gap Overview](#1-coverage-gap-overview)
2. [Infrastructure Prerequisites](#2-infrastructure-prerequisites)
3. [Phase 1: Critical Business Flows](#phase-1-critical-business-flows-2-3-weeks)
4. [Phase 2: Event-Driven Flows](#phase-2-event-driven-flows-2-3-weeks)
5. [Phase 3: Edge Cases & Validations](#phase-3-edge-cases--validations-1-2-weeks)
6. [Phase 4: End-to-End & Multi-Tenant](#phase-4-end-to-end--multi-tenant-1-2-weeks)
7. [Implementation Guidelines](#7-implementation-guidelines)
8. [Success Metrics](#8-success-metrics)

---

## 1. Coverage Gap Overview

### 1.1 Summary by Priority

| Priority | Module | Scenarios | Current Coverage | Files Affected |
|----------|--------|-----------|------------------|----------------|
| **CRITICAL** | Carrier Booking API | 10 | 0% | 1 new test file |
| **CRITICAL** | Mirakl API Integration | 8 | 0% | 1 new test file |
| **CRITICAL** | Route Determination | 6 | 33% | 1 enhanced file |
| **CRITICAL** | Kafka Event Processing | 13 | 0% | 1 new test file |
| **HIGH** | Quantity Split Flow | 5 | 0% | 1 new test file |
| **HIGH** | Manual Update Validations | 6 | 0% | 1 new test file |
| **MEDIUM** | DynamoDB Advanced Queries | 5 | 0% | 1 new test file |
| **LOW** | Multi-Tenant & E2E | 10 | 0% | 2 new test files |

**Total New Test Files:** 9
**Total Enhanced Files:** 1
**Total New Scenarios:** ~110

---

## 2. Infrastructure Prerequisites

### 2.1 Existing Infrastructure (Already Available ✅)

The following services are **already running** in `docker-compose-ci.yml`:

- ✅ **WireMock** (port 9090) - External API mocking
- ✅ **DynamoDB Local** (port 8000) - Database
- ✅ **Kafka Broker** (port 9092) - Message streaming
- ✅ **Schema Registry** (port 8081) - Avro schema management
- ✅ **Zookeeper** (port 2181) - Kafka coordination
- ✅ **Returns Service** (port 8080) - Application under test

**Topics Already Configured:**
- `public.bquk.order-management.test.pick`
- `public.in-store-fulfilment.test.pick`

### 2.2 Additional Test Dependencies Required

Add the following to `/functional-tests/build.gradle.kts`:

```kotlin
dependencies {
    // Existing dependencies...

    // Kafka producer client (for sending test events)
    testImplementation("org.apache.kafka:kafka-clients:4.2.0")

    // Confluent Avro serializer (matches schema registry version)
    testImplementation("io.confluent:kafka-avro-serializer:7.8.0")

    // Avro library (for building test messages)
    testImplementation("org.apache.avro:avro:1.11.1")
}
```

**Note:** No Spring dependencies needed - using plain Kafka Java client.

### 2.3 New Test Utilities to Create

**Note:** Container stubs already exist in `/container-setup/__files/` for Product API, Seller API, Carrier Booking API, and Mirakl API. Review existing stubs before creating new ones. See `/WIREMOCK-SETUP-EXPLAINED.md` for details on container vs programmatic stubs.

#### 2.3.1 KafkaTestProducer.kt

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/KafkaTestProducer.kt`

**Purpose:** Utility for producing Avro-serialized test messages to existing Kafka container

```kotlin
package com.kingfisher.utils

import io.confluent.kafka.serializers.KafkaAvroSerializer
import org.apache.avro.generic.GenericRecord
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.StringSerializer
import java.util.*

/**
 * Kafka test producer for sending Avro messages to test topics.
 * Connects to existing Kafka container (localhost:9092).
 */
object KafkaTestProducer {

    private const val KAFKA_BOOTSTRAP_SERVERS = "localhost:9092"
    private const val SCHEMA_REGISTRY_URL = "http://localhost:8081"

    private val producer: KafkaProducer<String, GenericRecord> by lazy {
        val props = Properties().apply {
            put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA_BOOTSTRAP_SERVERS)
            put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer::class.java.name)
            put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer::class.java.name)
            put("schema.registry.url", SCHEMA_REGISTRY_URL)
            put(ProducerConfig.ACKS_CONFIG, "all")
            put(ProducerConfig.RETRIES_CONFIG, 3)
            put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1)
        }
        KafkaProducer(props)
    }

    /**
     * Send an Avro message to a topic and wait for acknowledgment.
     *
     * @param topic Kafka topic name
     * @param key Message key (optional)
     * @param message Avro GenericRecord
     */
    fun sendMessage(topic: String, key: String? = null, message: GenericRecord) {
        val record = ProducerRecord(topic, key, message)
        producer.send(record).get() // Blocking send for test reliability
    }

    /**
     * Close the producer (call in @AfterAll).
     */
    fun close() {
        producer.close()
    }
}
```

#### 2.3.2 PickEventBuilder.kt

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/PickEventBuilder.kt`

**Purpose:** Fluent builder for creating Pick event test messages

```kotlin
package com.kingfisher.utils

import com.kingfisher.orderManagement.avro.Pick
import com.kingfisher.orderManagement.avro.Metadata
import com.kingfisher.orderManagement.avro.Payload
import java.time.Instant

/**
 * Builder for Pick events (order-management topic).
 */
class PickEventBuilder {
    private var eventType: String = "pickDeliveryExpired"
    private var aggregateId: String = "123456789"
    private var logisticalOrderId: String = "MP12345-1"
    private var shippingMethodType: String = "MPCC_DELIVERY"
    private var createdBy: String = "test-system"
    private var createdOn: String = Instant.now().toString()
    private var traceId: String = "test-trace-${System.currentTimeMillis()}"

    fun withEventType(eventType: String) = apply { this.eventType = eventType }
    fun withAggregateId(aggregateId: String) = apply { this.aggregateId = aggregateId }
    fun withLogisticalOrderId(logisticalOrderId: String) = apply { this.logisticalOrderId = logisticalOrderId }
    fun withShippingMethodType(shippingMethodType: String) = apply { this.shippingMethodType = shippingMethodType }

    fun build(): Pick {
        val metadata = Metadata.newBuilder()
            .setCreatedBy(createdBy)
            .setCreatedOn(createdOn)
            .setTraceId(traceId)
            .build()

        val payload = Payload.newBuilder()
            .setAggregateId(aggregateId)
            .setLogisticalOrderId(logisticalOrderId)
            .setShippingMethodType(shippingMethodType)
            // ... set other required fields based on schema
            .build()

        return Pick.newBuilder()
            .setEventType(eventType)
            .setMetadata(metadata)
            .setPayload(payload)
            .build()
    }
}
```

#### 2.3.3 PickInStoreEventBuilder.kt

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/utils/PickInStoreEventBuilder.kt`

**Purpose:** Fluent builder for creating Pick In-Store event test messages

```kotlin
package com.kingfisher.utils

import com.kingfisher.inStoreFulfilment.avro.Pick
import com.kingfisher.inStoreFulfilment.avro.Metadata
import com.kingfisher.inStoreFulfilment.avro.Payload
import java.time.Instant
import java.util.UUID

/**
 * Builder for Pick In-Store events (in-store-fulfilment topic).
 */
class PickInStoreEventBuilder {
    private var eventId: String = UUID.randomUUID().toString()
    private var eventType: String = "pickCollected"
    private var aggregateId: String = "987654321"
    private var createdBy: String = "test-system"
    private var createdOn: String = Instant.now().toString()
    private var traceId: String = "test-trace-${System.currentTimeMillis()}"

    fun withEventType(eventType: String) = apply { this.eventType = eventType }
    fun withAggregateId(aggregateId: String) = apply { this.aggregateId = aggregateId }

    fun build(): Pick {
        val metadata = Metadata.newBuilder()
            .setCreatedBy(createdBy)
            .setCreatedOn(createdOn)
            .setTraceId(traceId)
            .setCommandId("cmd-${System.currentTimeMillis()}")
            .build()

        val payload = Payload.newBuilder()
            .setAggregateId(aggregateId)
            // ... set other required fields based on schema
            .build()

        return Pick.newBuilder()
            .setEventId(eventId)
            .setEventType(eventType)
            .setMetadata(metadata)
            .setPayload(payload)
            .build()
    }
}
```

### 2.4 WireMock Stub Files

**Important:** Many stubs already exist in `/container-setup/__files/` and are automatically loaded by the WireMock container. Check existing stubs before creating new ones:

```bash
# List existing container stubs
ls -la container-setup/__files/

# View mappings
cat container-setup/mappings/request_mappings.json
```

**Existing Container Stubs:**
- Product API: 7 variations (battery, weight, price, TBC, errors)
- Seller API: Success and 404 responses
- Carrier Booking API: Success and error responses  
- Mirakl API: Auth, orders, refunds, notifications

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` and `/TASK-UPDATES.md` for complete details.

#### Create Additional Stubs Only If Needed

**Note:** These stub examples are provided for reference. Check if container stubs in `/container-setup/__files/` already cover your needs before creating new ones.

Create the following stub files in `/functional-tests/src/test/resources/wiremock/`:

#### Mirakl API Stubs

**File:** `mappings/mirakl-create-refund.json`
```json
{
  "request": {
    "method": "POST",
    "urlPattern": "/api/refunds.*"
  },
  "response": {
    "status": 200,
    "headers": {
      "Content-Type": "application/json"
    },
    "bodyFileName": "mirakl-refund-response.json"
  }
}
```

**File:** `__files/mirakl-refund-response.json`
```json
{
  "refund_id": "REFUND-123456",
  "order_id": "MP12345-1",
  "state": "REFUND_CREATED",
  "amount": 20.30
}
```

**Additional Stubs Needed:**
- `mirakl-create-cancellation.json`
- `mirakl-create-thread.json` (seller notification)
- `mirakl-get-order.json`

#### Seller API Stubs

**File:** `mappings/seller-api-get-seller.json`
```json
{
  "request": {
    "method": "GET",
    "urlPattern": "/sellers/\\d+\\?tenant=.*"
  },
  "response": {
    "status": 200,
    "headers": {
      "Content-Type": "application/json"
    },
    "bodyFileName": "seller-response.json"
  }
}
```

**File:** `__files/seller-response.json`
```json
{
  "shopId": "12345",
  "sellerName": "Test Seller Ltd",
  "inStoreReturnDetails": {
    "departmentName": "Returns Department",
    "address": "123 Test Street",
    "city": "London",
    "postcode": "SW1A 1AA",
    "email": "returns@testseller.com",
    "phone": "+44 20 1234 5678"
  }
}
```

#### Carrier Booking API Stubs

**File:** `mappings/carrier-booking-create.json`
```json
{
  "request": {
    "method": "POST",
    "urlPattern": "/v1/bookings.*"
  },
  "response": {
    "status": 200,
    "headers": {
      "Content-Type": "application/json"
    },
    "bodyFileName": "carrier-booking-response.json"
  }
}
```

**File:** `__files/carrier-booking-response.json`
```json
{
  "consignmentCode": "CONS-123456",
  "collectionDate": "2026-02-15",
  "trackingUrl": "https://dpd.co.uk/track/CONS-123456"
}
```

---

## Phase 1: Critical Business Flows (2-3 weeks)

**Goal:** Cover core revenue-impacting flows and integration points

### 1.1 Carrier Booking API Integration (2-3 days)

**Priority:** CRITICAL
**Why:** DPD collections directly impact customer experience

#### New Test File: `CarrierBookingAPITest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/api/CarrierBookingAPITest.kt`

**Extends:** `BaseMockedReturnOrderTest`

#### Test Scenarios (7 total)

##### Test 1: Happy Path - Update Route to DPD with Carrier Booking

```kotlin
@Test
@Tag("integration")
fun `should successfully update route to DPD and book carrier`()
```

**Steps:**
1. Create return order with route = TBC
2. Configure WireMock stubs:
   - Seller API returns valid seller with department name
   - Carrier Booking API returns consignment code + collection date
3. Update route to DPD with parcel tracking info
4. Verify HTTP 200
5. Fetch order and assert:
   - `route = "DPD"`
   - `consignmentCode = "CONS-123456"`
   - `collectionDate = "2026-02-15"`
6. Verify WireMock calls:
   - Seller API called once
   - Carrier Booking API called once

**Assertions:**
- Response status = 200
- Consignment code populated in DynamoDB
- Collection date populated

---

##### Test 2: Seller API Returns Department Name

```kotlin
@Test
@Tag("integration")
fun `should use department name from seller API in carrier booking request`()
```

**Steps:**
1. Configure WireMock: Seller API returns `departmentName = "Returns Department"`
2. Update route to DPD
3. Capture carrier booking request (WireMock verification)
4. Assert request body contains `"recipientName": "Returns Department"`

**Assertions:**
- Carrier booking request uses department name (not seller name)

---

##### Test 3: Seller API Returns Empty Department Name

```kotlin
@Test
@Tag("integration")
fun `should fallback to seller name when department name is empty`()
```

**Steps:**
1. Configure WireMock: Seller API returns `departmentName = null`
2. Update route to DPD
3. Capture carrier booking request
4. Assert request body contains `"recipientName": "Test Seller Ltd"` (seller name)

**Assertions:**
- Fallback to seller name works correctly

---

##### Test 4: Seller Not Found in Seller API

```kotlin
@Test
@Tag("integration")
fun `should throw exception when seller not found in Seller API`()
```

**Steps:**
1. Configure WireMock: Seller API returns HTTP 404
2. Update route to DPD
3. Expect HTTP 500 (internal error) or 400 (bad request)

**Assertions:**
- Error response returned
- Order route not updated

---

##### Test 5: Carrier Booking API Timeout

```kotlin
@Test
@Tag("integration")
fun `should handle carrier booking API timeout gracefully`()
```

**Steps:**
1. Configure WireMock: Carrier Booking API returns HTTP 500
2. Update route to DPD
3. Expect HTTP 500 or specific error message

**Assertions:**
- Error logged
- Route update fails

---

##### Test 6: Consignment Code Extracted Correctly

```kotlin
@Test
@Tag("integration")
fun `should extract consignment code from carrier booking response`()
```

**Steps:**
1. Update route to DPD
2. Fetch order
3. Assert `consignmentCode` matches WireMock response

**Assertions:**
- JSONPath: `consignmentCode = "CONS-123456"`

---

##### Test 7: Collection Date Populated in Return Lines

```kotlin
@Test
@Tag("integration")
fun `should populate collection date in all DPD return lines`()
```

**Steps:**
1. Create multi-line return order (2 lines)
2. Update both lines to DPD
3. Verify both lines have same `collectionDate`

**Assertions:**
- All DPD lines have collection date

---

**WireMock Stubs Required**

- ✅ Container stubs already exist in `/container-setup/__files/__sellers-api/` and `/__carrier-booking/`
- ✅ Seller API: `GET /sellers/{shopId}?tenant={tenant}` - Use existing `seller-successful-response.json`
- ✅ Carrier Booking API: `POST /v1/bookings` - Use existing `carrier-booking-response-successful.json`
- ✅ Product API: `GET /v1/products/{tenant}?filter[ean]={ean}` (existing)

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` for how to use container stubs in tests.

#### Dependencies

```kotlin
// Already available - no new dependencies
```

---

### 1.2 Mirakl API Integration (3-4 days)

**Priority:** CRITICAL
**Why:** Refunds and seller notifications are core business requirements

#### New Test File: `MiraklIntegrationTest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/api/MiraklIntegrationTest.kt`

**Extends:** `BaseMockedReturnOrderTest`

#### Test Scenarios (8 total)

##### Test 1: Create Refund on iForce Route

```kotlin
@Test
@Tag("integration")
fun `should create refund when order routed to iForce`()
```

**Steps:**
1. Create return order with low value (triggers iForce)
2. Configure WireMock: Mirakl refund API returns success
3. Verify refund created
4. Verify WireMock called with correct payload:
   - Amount matches order total
   - Quantity correct
   - Reason code present
   - Currency = GBP

**Assertions:**
- WireMock refund endpoint called once
- Request body contains expected fields

---

##### Test 2: Create Cancellation on Collection Expiry

```kotlin
@Test
@Tag("integration")
fun `should create cancellation when collection expires`()
```

**Steps:**
1. Send Kafka pick event with `eventType = "pickCollectionExpired"`
2. Wait for processing (poll DynamoDB or use delay)
3. Verify WireMock cancellation endpoint called
4. Assert reason code has `CANCEL_` prefix

**Assertions:**
- Cancellation API called
- Reason code format correct

---

##### Test 3: Seller Notification Sent with Correct Template

```kotlin
@Test
@Tag("integration")
fun `should send seller notification with correct parameters`()
```

**Steps:**
1. Create iForce return
2. Verify WireMock notification (create thread) endpoint called
3. Capture request body
4. Assert message contains:
   - Product name
   - EAN
   - Quantity
   - Reason message

**Assertions:**
- Notification body formatted correctly
- Parameters substituted

---

##### Test 4: Currency Fallback (Invalid to Order Currency)

```kotlin
@Test
@Tag("integration")
fun `should fallback to order currency when currency is invalid`()
```

**Steps:**
1. Create order with `currencyIsoCode = "EUR"`
2. Configure refund creation
3. Verify refund request uses GBP (default order currency)

**Assertions:**
- Currency fallback logic works

---

##### Test 5: Refund Failure Updates Metric

```kotlin
@Test
@Tag("integration")
fun `should update REFUND_FAILED_FOR_I_FORCE metric when refund fails`()
```

**Steps:**
1. Configure WireMock: Mirakl refund API returns HTTP 500
2. Create iForce return
3. Verify order still created (refund failure doesn't block)
4. Check logs for error message

**Assertions:**
- Order created despite refund failure
- Error logged

---

##### Test 6: Notification Failure Logged But Process Continues

```kotlin
@Test
@Tag("integration")
fun `should log notification failure but complete order creation`()
```

**Steps:**
1. Configure WireMock: Notification API returns HTTP 500
2. Create iForce return
3. Verify order created
4. Verify refund still created

**Assertions:**
- Notification failure doesn't block process
- Order saved to DynamoDB

---

##### Test 7: Order Line ID Parsed Correctly

```kotlin
@Test
@Tag("integration")
fun `should parse order line ID from logistical order ID`()
```

**Steps:**
1. Create order with `logisticalOrderId = "MP12345-1"`
2. Create refund
3. Verify WireMock refund request contains `orderLineId = "MP12345-1"`

**Assertions:**
- Parsing logic correct

---

##### Test 8: Template Parameter Replacement

```kotlin
@Test
@Tag("integration")
fun `should replace template parameters in notification message`()
```

**Steps:**
1. Create return with specific product details
2. Verify notification message contains:
   - `{{productName}}` → actual product name
   - `{{ean}}` → actual EAN
   - `{{quantity}}` → actual quantity

**Assertions:**
- All placeholders replaced

---

#### WireMock Stubs Required

- ✅ Container stubs already exist in `/container-setup/__files/__mirakl/`
- ✅ Mirakl Refund: `POST /api/refunds` - Use existing `OR28_Successful.json`
- ✅ Mirakl Cancellation: `POST /api/cancellations` - May need to create
- ✅ Mirakl Notification: `POST /api/orders/{orderId}/threads` - Use existing `OR43_Successful.json`
- ✅ Mirakl Order Details: `GET /api/orders?order_ids={orderId}` - Use existing `OR11_Successful.json`

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` and `/TASK-UPDATES.md` for details on existing Mirakl stubs.

---

### 1.3 Enhanced Route Determination Logic (2 days)

**Priority:** CRITICAL
**Why:** Ensures correct routing decisions

#### Enhanced Test File: `WindsorFrameworkTest.kt`

**Action:** Add new test scenarios to existing file

#### New Test Scenarios (5 total)

##### Test 1: Battery Chemistry (Li-ion) Routes to iForce

```kotlin
@Test
@Tag("integration")
fun `should route to iForce when product contains lithium-ion battery`()
```

**Steps:**
1. Configure WireMock: Product API returns `technicalAttributes = { "battery_chemistry": "Li-ion" }`
2. Create return order
3. Verify `route = "iForce"`
4. Verify `reasonForIForce = "Battery"`

**Assertions:**
- Battery detected → iForce route

---

##### Test 2: Product Weight > 29kg Routes to iForce

```kotlin
@Test
@Tag("integration")
fun `should route to iForce when product weight exceeds 29kg`()
```

**Steps:**
1. Configure WireMock: Product API returns `weight = 30.5`
2. Create return order
3. Verify `route = "iForce"`
4. Verify `reasonForIForce = "Weight"`

**Assertions:**
- Heavy product → iForce

---

##### Test 3: Technical Attribute Exceeds Max Threshold

```kotlin
@Test
@Tag("integration")
fun `should route to iForce when dimension exceeds threshold`()
```

**Steps:**
1. Configure WireMock: Product API returns `length = 200` (exceeds max)
2. Create return order
3. Verify `route = "iForce"`
4. Verify `reasonForIForce = "length"` (attribute name)

**Assertions:**
- Oversized dimension → iForce

---

##### Test 4: Multiple Technical Attributes - First Match Wins

```kotlin
@Test
@Tag("integration")
fun `should return first matching iForce reason when multiple attributes exceed`()
```

**Steps:**
1. Configure WireMock: Product API returns:
   - `weight = 30` (exceeds)
   - `length = 200` (exceeds)
2. Create return order
3. Verify `reasonForIForce = "Weight"` (first evaluated)

**Assertions:**
- First matching criterion wins

---

##### Test 5: Windsor Store + High Value Still Routes to iForce

```kotlin
@Test
@Tag("integration")
fun `should route Windsor store to iForce even with high value`()
```

**Steps:**
1. Create order with `storeId = 1211` (Windsor) and `currencyID = 100.00` (high value)
2. Verify `route = "iForce"`
3. Verify `reasonForIForce = "Windsor Framework"`

**Assertions:**
- Store precedence over value

---

#### WireMock Stub Enhancement

**Enhanced File:** `__files/product_response_with_attributes.json`

```json
{
  "data": [
    {
      "id": "1234567890",
      "attributes": {
        "ean": "1234567890",
        "technicalAttributes": {
          "battery_chemistry": "Li-ion",
          "weight": 30.5,
          "length": 200,
          "width": 50,
          "height": 50
        }
      }
    }
  ]
}
```

---

## Phase 2: Event-Driven Flows (2-3 weeks)

**Goal:** Validate Kafka event processing and state transitions

### 2.1 Kafka Pick Event Processing (3-4 days)

**Priority:** HIGH
**Why:** Handles automated status updates and refunds

#### New Test File: `KafkaPickEventTest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/kafka/KafkaPickEventTest.kt`

**Extends:** `BaseMockedReturnOrderTest`

**Additional Setup:**
```kotlin
companion object {
    @JvmStatic
    @AfterAll
    fun closeKafkaProducer() {
        KafkaTestProducer.close()
    }
}
```

#### Test Scenarios (13 total)

##### Test 1: Delivery Expiry Event → LOST_IN_TRANSIT Status

```kotlin
@Test
@Tag("integration")
fun `should mark return as LOST_IN_TRANSIT when pick delivery expires`()
```

**Steps:**
1. Build pick event with `eventType = "pickDeliveryExpired"`
2. Set `shippingMethodType = "MPCC_DELIVERY"` (eligible)
3. Set `aggregateId` and `logisticalOrderId`
4. Send event to topic: `public.bquk.order-management.test.pick`
5. Wait for processing (sleep 2-3 seconds or poll DynamoDB)
6. Fetch return lines by logistical order ID
7. Assert `status = "LOST_IN_TRANSIT"`

**Assertions:**
- Status updated correctly
- Event consumed and processed

**Code Example:**
```kotlin
val pickEvent = PickEventBuilder()
    .withEventType("pickDeliveryExpired")
    .withShippingMethodType("MPCC_DELIVERY")
    .withAggregateId("123456789")
    .withLogisticalOrderId("MP12345-1")
    .build()

KafkaTestProducer.sendMessage(
    topic = "public.bquk.order-management.test.pick",
    key = "MP12345-1",
    message = pickEvent
)

Thread.sleep(3000) // Wait for async processing

val response = When().get("/v1/fetchAllOrders")
assertThat(response.body().jsonPath().getString("status[0]"), equalTo("LOST_IN_TRANSIT"))
```

---

##### Test 2: Collection Expiry + canCancel=true → Create Cancellation

```kotlin
@Test
@Tag("integration")
fun `should create cancellation when collection expires and order can cancel`()
```

**Steps:**
1. Build pick event with `eventType = "pickCollectionExpired"`
2. Set `canCancel = true` in payload
3. Configure WireMock: Mirakl cancellation API returns success
4. Send event
5. Wait for processing
6. Verify WireMock cancellation endpoint called

**Assertions:**
- Cancellation created
- Mirakl API called with CANCEL reason

---

##### Test 3: Collection Expiry + canCancel=false → Create Refund

```kotlin
@Test
@Tag("integration")
fun `should create refund when collection expires and order cannot cancel`()
```

**Steps:**
1. Build pick event with `eventType = "pickCollectionExpired"`
2. Set `canCancel = false`
3. Configure WireMock: Mirakl refund API returns success
4. Send event
5. Verify WireMock refund endpoint called (not cancellation)

**Assertions:**
- Refund created (not cancellation)

---

##### Test 4: Pick Collected Event → CANCELLED Status

```kotlin
@Test
@Tag("integration")
fun `should mark return as CANCELLED when pick is collected`()
```

**Steps:**
1. Build pick in-store event with `eventType = "pickCollected"`
2. Send to topic: `public.in-store-fulfilment.test.pick`
3. Wait for processing
4. Fetch return lines
5. Assert `status = "CANCELLED"`

**Assertions:**
- Status updated to CANCELLED

---

##### Test 5: Ineligible Shipping Method → Skip Processing

```kotlin
@Test
@Tag("integration")
fun `should skip processing when shipping method is ineligible`()
```

**Steps:**
1. Build pick event with `shippingMethodType = "INELIGIBLE_TYPE"`
2. Send event
3. Wait for processing
4. Verify no return lines created
5. Check logs for "skipped" message

**Assertions:**
- Event ignored
- No database changes

---

##### Test 6: Ineligible Event Type → Skip Processing

```kotlin
@Test
@Tag("integration")
fun `should skip processing when event type is ineligible`()
```

**Steps:**
1. Build pick event with `eventType = "someUnknownEvent"`
2. Send event
3. Verify no processing occurred

**Assertions:**
- Unknown event types ignored

---

##### Test 7: Immediate Refund on Expiry Event

```kotlin
@Test
@Tag("integration")
fun `should create immediate refund when event type allows immediate refund`()
```

**Steps:**
1. Send delivery expiry event
2. Verify refund created immediately (not deferred)
3. Check `refundCreated = true` in DynamoDB

**Assertions:**
- Refund created synchronously

---

##### Test 8: Event Type Mapped to Specific Status

```kotlin
@ParameterizedTest
@CsvSource([
    "pickDeliveryExpired, LOST_IN_TRANSIT",
    "pickCollectionExpired, AWAITING_LABEL_PRINTING",
    "pickCollected, CANCELLED"
])
@Tag("integration")
fun `should map event type to correct status`(eventType: String, expectedStatus: String)
```

**Steps:**
1. Send event with specific type
2. Verify status matches expected mapping

**Assertions:**
- All event type → status mappings correct

---

##### Test 9: Order Status Combination Mapping

```kotlin
@Test
@Tag("integration")
fun `should use composite mapping when order status affects routing`()
```

**Steps:**
1. Send event with specific order status
2. Verify composite key used for status determination

**Assertions:**
- Complex mapping logic works

---

##### Test 10: Refund/Cancellation Failure → Log Error But Save Line

```kotlin
@Test
@Tag("integration")
fun `should save return line even when refund fails`()
```

**Steps:**
1. Configure WireMock: Mirakl refund API returns HTTP 500
2. Send pick event
3. Verify return line created in DynamoDB
4. Verify `refundCreated = false`

**Assertions:**
- Process continues despite failure
- Line saved

---

##### Test 11: Missing Product in Product API → Exception Handling

```kotlin
@Test
@Tag("integration")
fun `should handle missing product gracefully during event processing`()
```

**Steps:**
1. Configure WireMock: Product API returns empty response
2. Send pick event
3. Verify error logged
4. Verify no line created

**Assertions:**
- Exception handled gracefully

---

##### Test 12: Multiple Events in Sequence

```kotlin
@Test
@Tag("integration")
fun `should process multiple pick events for same order`()
```

**Steps:**
1. Send delivery expiry event for order X
2. Wait for processing
3. Send collection expiry event for same order
4. Verify both events processed
5. Verify latest status = collection expiry status

**Assertions:**
- Multiple events processed correctly
- State transitions valid

---

##### Test 13: Consumer Group Acknowledgment

```kotlin
@Test
@Tag("integration")
fun `should acknowledge messages after successful processing`()
```

**Steps:**
1. Send event
2. Wait for processing
3. Check Kafka consumer lag (via JMX or logs)
4. Verify offset committed

**Assertions:**
- Messages acknowledged
- No lag in consumer group

---

#### Kafka Topics Used

- ✅ `public.bquk.order-management.test.pick` (already configured in docker-compose)
- ✅ `public.in-store-fulfilment.test.pick` (already configured)

#### Helper Methods

```kotlin
/**
 * Wait for Kafka event to be processed (polls DynamoDB).
 */
fun waitForEventProcessing(maxWaitSeconds: Int = 5) {
    repeat(maxWaitSeconds) {
        Thread.sleep(1000)
        // Could check DynamoDB or logs here
    }
}
```

---

## Phase 3: Edge Cases & Validations (1-2 weeks)

**Goal:** Ensure robustness and error handling

### 3.1 Manual Update Validations (1-2 days)

**Priority:** MEDIUM
**Why:** Prevents invalid state transitions

#### New Test File: `ManualUpdateValidationTest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/api/ManualUpdateValidationTest.kt`

#### Test Scenarios (6 total)

##### Test 1: Cannot Update iForce Route

```kotlin
@Test
@Tag("integration")
fun `should reject update when route is iForce`()
```

**Steps:**
1. Create order with route = iForce (low value)
2. Attempt to update route via manual update endpoint
3. Expect HTTP 400

**Assertions:**
- Error message: "Route must be TBC"

---

##### Test 2: Cannot Update DPD Route

```kotlin
@Test
@Tag("integration")
fun `should reject update when route is DPD`()
```

**Steps:**
1. Create order, update to DPD
2. Attempt manual update
3. Expect HTTP 400

**Assertions:**
- Only TBC routes updatable

---

##### Test 3: Cannot Update CANCELLED Line

```kotlin
@Test
@Tag("integration")
fun `should reject update when line is cancelled`()
```

**Steps:**
1. Create order with TBC route
2. Send pick collected event (sets CANCELLED status)
3. Attempt update
4. Expect HTTP 400

**Assertions:**
- Cancelled lines immutable

---

##### Test 4: Status Progression Backwards Rejected

```kotlin
@Test
@Tag("integration")
fun `should reject status update when progression is backwards`()
```

**Steps:**
1. Create order with status = LABEL_PRINTING_REQUESTED
2. Attempt to update to COLLECTION_BOOKED (earlier in progression)
3. Expect HTTP 400

**Assertions:**
- Status can only move forward

---

##### Test 5: Invalid Status for Route Combination

```kotlin
@Test
@Tag("integration")
fun `should reject invalid status for given route`()
```

**Steps:**
1. Create TBC order
2. Attempt to set status = LABEL_PRINTING_REQUESTED without changing route to iForce
3. Expect HTTP 400

**Assertions:**
- Status must be valid for route

---

##### Test 6: Valid TBC → DPD with COLLECTION_BOOKED

```kotlin
@Test
@Tag("integration")
fun `should allow TBC to DPD update with COLLECTION_BOOKED status`()
```

**Steps:**
1. Create TBC order
2. Update route = DPD, status = COLLECTION_BOOKED
3. Expect HTTP 200

**Assertions:**
- Valid transition succeeds

---

### 3.2 Quantity Split Flow (2 days)

**Priority:** MEDIUM
**Why:** Complex business logic with line creation

#### New Test File: `QuantitySplitTest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/api/QuantitySplitTest.kt`

#### Test Scenarios (5 total)

##### Test 1: Split Single Line into DPD + iForce

```kotlin
@Test
@Tag("integration")
fun `should split TBC line into DPD and iForce with correct quantities`()
```

**Steps:**
1. Create order with TBC route, quantity = 5
2. Update route request with 2 lines:
   - Line 1: route = DPD, quantity = 3
   - Line 2: route = iForce, quantity = 2
3. Verify 2 lines exist in DynamoDB
4. Assert line 1: `route = "DPD"`, `quantity = 3`
5. Assert line 2: `route = "iForce"`, `quantity = 2`

**Assertions:**
- New line created with incremented line number
- Quantities distributed correctly

---

##### Test 2: New Line Number Generated Correctly

```kotlin
@Test
@Tag("integration")
fun `should increment line number for new split line`()
```

**Steps:**
1. Create order with line number = 1
2. Split quantity
3. Verify original line number = 1
4. Verify new line number = 2

**Assertions:**
- Line number sequential

---

##### Test 3: Max Line Number Tracking

```kotlin
@Test
@Tag("integration")
fun `should track max line number correctly when splitting multiple lines`()
```

**Steps:**
1. Create order with 2 lines (line 1, line 2)
2. Split line 1 → creates line 3
3. Split line 2 → creates line 4 (not line 3)
4. Verify line numbers: 1, 2, 3, 4

**Assertions:**
- No line number collisions

---

##### Test 4: Multiple Splits in Single Request

```kotlin
@Test
@Tag("integration")
fun `should handle multiple splits in single update request`()
```

**Steps:**
1. Create order with 2 TBC lines
2. Send update request splitting both lines
3. Verify 4 lines created total

**Assertions:**
- Batch splitting works

---

##### Test 5: Both Lines Saved to DynamoDB

```kotlin
@Test
@Tag("integration")
fun `should persist both original and new line to DynamoDB`()
```

**Steps:**
1. Split line
2. Fetch all orders
3. Verify both lines returned

**Assertions:**
- Database consistency

---

### 3.3 DynamoDB Advanced Queries (1-2 days)

**Priority:** MEDIUM
**Why:** Validates GSI performance and filtering

#### New Test File: `DynamoDBQueryTest.kt`

**Location:** `/functional-tests/src/test/kotlin/com/kingfisher/repository/DynamoDBQueryTest.kt`

#### Test Scenarios (5 total)

##### Test 1: Query by Store ID + Date Range

```kotlin
@Test
@Tag("integration")
fun `should fetch returns by store ID and date range using GSI`()
```

**Steps:**
1. Create 3 orders for storeId = 1017 with different dates
2. Query endpoint: `/v1/fetchReturnLines/BQUK/1017?dateFrom={yesterday}&dateTo={tomorrow}`
3. Verify all 3 orders returned

**Assertions:**
- GSI query works
- Date filtering correct

---

##### Test 2: Tenant Filtering

```kotlin
@Test
@Tag("integration")
fun `should filter by tenant and return only BQUK orders`()
```

**Steps:**
1. Create orders for multiple tenants (if possible)
2. Query with tenant = BQUK
3. Verify only BQUK returns shown

**Assertions:**
- Tenant isolation works

---

##### Test 3: Status Filtering (Multiple Statuses)

```kotlin
@Test
@Tag("integration")
fun `should filter by multiple statuses`()
```

**Steps:**
1. Create orders with different statuses
2. Query should return only specific statuses
3. Verify filter expression works

**Assertions:**
- Status filtering correct

---

##### Test 4: Retention Period Filtering

```kotlin
@Test
@Tag("integration")
fun `should apply different retention periods for confirmed vs non-confirmed lines`()
```

**Steps:**
1. Create old confirmed line (> 11 days old)
2. Create old non-confirmed line (> 30 days old)
3. Query recent returns
4. Verify only recent ones returned

**Assertions:**
- Retention logic applied

---

##### Test 5: Pagination Handling

```kotlin
@Test
@Tag("integration")
fun `should handle pagination for large result sets`()
```

**Steps:**
1. Create 50 orders for same store
2. Query with pagination
3. Verify all pages returned

**Assertions:**
- Pagination works

---

## Phase 4: End-to-End & Multi-Tenant (1-2 weeks)

**Goal:** Full journey testing and tenant isolation

### 4.1 Multi-Tenant Scenarios (2 days)

#### New Test File: `MultiTenantTest.kt`

#### Test Scenarios (5 total)

1. BQUK tenant → correct Kafka topics, Product API tenant param
2. TPUK tenant → isolated data
3. Invalid tenant → 400 Bad Request
4. Tenant-specific notification templates
5. Tenant-specific currency handling

---

### 4.2 End-to-End Happy Paths (2-3 days)

#### New Test File: `EndToEndFlowTest.kt`

#### Test Scenarios (5 total)

##### E2E 1: iForce Flow

```
MQ → Route iForce → Refund → Notify → Confirm
```

##### E2E 2: DPD Flow

```
MQ → Route TBC → Update to DPD → Carrier Booking → Confirm
```

##### E2E 3: Expiry Flow

```
Kafka Event → Route → Immediate Refund → Status Update
```

##### E2E 4: Split Flow

```
Create → Route TBC → Split (DPD + iForce) → Both paths complete
```

##### E2E 5: Multi-line Multi-route

```
Create 3-line order → Route 1 iForce, Route 2 TBC, Route 3 DPD
```

---

## 7. Implementation Guidelines

### 7.1 Development Workflow

**For Each Test File:**

1. **Create Test Class**
   - Extend `BaseMockedReturnOrderTest`
   - Add `@Tag("integration")` to all tests
   - Use descriptive test names (backtick syntax)

2. **Configure WireMock Stubs**
   - Add stub files to `/functional-tests/src/test/resources/wiremock/`
   - Configure in `@BeforeEach` if dynamic

3. **Write Test Scenario**
   - Follow Arrange-Act-Assert pattern
   - Use fluent builders for test data
   - Add cleanup to `ordersToCleanup` list

4. **Run Locally**
   ```bash
   ./gradlew runFunctionalIntegrationTests --tests "TestClassName"
   ```

5. **Verify in CI**
   - Push branch
   - Run pipeline
   - Check artifacts for reports

### 7.2 Best Practices

#### Test Isolation
- Each test creates unique order IDs
- Cleanup in `@AfterEach` ensures no data leakage
- Use `orderIdGenerator.incrementAndGet()` for uniqueness

#### Async Event Handling
- Use `Thread.sleep()` or polling for Kafka events
- Recommended wait: 2-3 seconds for event processing
- Consider retry logic for flaky timing

#### WireMock Verification
```kotlin
wireMockServer.verify(
    postRequestedFor(urlMatching("/api/refunds.*"))
        .withRequestBody(matchingJsonPath("$.amount", equalTo("20.30")))
)
```

#### Kafka Message Production
```kotlin
val event = PickEventBuilder()
    .withEventType("pickDeliveryExpired")
    .withLogisticalOrderId("MP12345-1")
    .build()

KafkaTestProducer.sendMessage(
    topic = "public.bquk.order-management.test.pick",
    key = "MP12345-1",
    message = event
)

Thread.sleep(3000) // Wait for processing
```

### 7.3 Common Pitfalls to Avoid

❌ **Don't:**
- Use hardcoded order IDs (causes flaky tests)
- Skip cleanup (causes subsequent test failures)
- Use Spring Kafka Test (not compatible with current setup)
- Mock services already running in docker-compose

✅ **Do:**
- Use generated unique IDs
- Always cleanup in `@AfterEach`
- Use plain Kafka client to send to existing container
- Use WireMock for external APIs

---

## 8. Success Metrics

### 8.1 Coverage Targets

| Metric | Current | Phase 1 Target | Final Target |
|--------|---------|---------------|--------------|
| **Business Scenario Coverage** | 12% | 40% | 90% |
| **Integration Point Coverage** | 25% | 60% | 100% |
| **Critical Flow Coverage** | 20% | 80% | 100% |

### 8.2 Quality Gates

**Before Merging New Tests:**

1. ✅ All tests pass in CI/CD (3 consecutive runs)
2. ✅ No flaky tests (run 10 times, 100% pass rate)
3. ✅ WireMock stubs verified against API contracts
4. ✅ Test execution time < 5 minutes per phase
5. ✅ Logs reviewed for warnings/errors
6. ✅ Code review by 2 team members

### 8.3 Monitoring & Maintenance

**Weekly:**
- Review failed tests in CI
- Update WireMock stubs if APIs change
- Check test execution time trends

**Monthly:**
- Update this plan with lessons learned
- Review coverage metrics
- Identify new gap areas

---

## Appendix A: Quick Reference Commands

### Run Specific Phase Tests

```bash
# Phase 1: Critical flows
./gradlew runFunctionalIntegrationTests --tests "CarrierBookingAPITest"
./gradlew runFunctionalIntegrationTests --tests "MiraklIntegrationTest"

# Phase 2: Event-driven
./gradlew runFunctionalIntegrationTests --tests "KafkaPickEventTest"

# Phase 3: Edge cases
./gradlew runFunctionalIntegrationTests --tests "ManualUpdateValidationTest"
./gradlew runFunctionalIntegrationTests --tests "QuantitySplitTest"

# Phase 4: E2E
./gradlew runFunctionalIntegrationTests --tests "EndToEndFlowTest"
```

### Debug Kafka Events

```bash
# Check Kafka topics
docker exec -it kafka-broker kafka-topics --list --bootstrap-server localhost:9092

# Consume messages from test topic
docker exec -it kafka-broker kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --topic public.bquk.order-management.test.pick \
  --from-beginning

# Check consumer group lag
docker exec -it kafka-broker kafka-consumer-groups \
  --bootstrap-server localhost:9092 \
  --describe \
  --group marketplace-return-test-pick-event-group
```

### WireMock Admin API

```bash
# List all requests received
curl http://localhost:9090/__admin/requests

# Verify specific endpoint called
curl http://localhost:9090/__admin/requests/count?url=/api/refunds
```

---

## Appendix B: File Structure After Implementation

```
/functional-tests/
├── build.gradle.kts                          # Updated with Kafka dependencies
├── src/
│   └── test/
│       ├── kotlin/com/kingfisher/
│       │   ├── api/
│       │   │   ├── CreateReturnOrderTest.kt           # Existing
│       │   │   ├── ConfirmReturnOrderTest.kt          # Existing
│       │   │   ├── DeleteReturnOrderTest.kt           # Existing
│       │   │   ├── UpdateRouteTest.kt                 # Existing
│       │   │   ├── ExceptionHandlingTest.kt           # Existing
│       │   │   ├── WindsorFrameworkTest.kt            # Enhanced
│       │   │   ├── CarrierBookingAPITest.kt           # NEW - Phase 1
│       │   │   ├── MiraklIntegrationTest.kt           # NEW - Phase 1
│       │   │   ├── ManualUpdateValidationTest.kt      # NEW - Phase 3
│       │   │   ├── QuantitySplitTest.kt               # NEW - Phase 3
│       │   │   └── MultiTenantTest.kt                 # NEW - Phase 4
│       │   ├── kafka/
│       │   │   └── KafkaPickEventTest.kt              # NEW - Phase 2
│       │   ├── repository/
│       │   │   └── DynamoDBQueryTest.kt               # NEW - Phase 3
│       │   ├── e2e/
│       │   │   └── EndToEndFlowTest.kt                # NEW - Phase 4
│       │   ├── core/
│       │   │   ├── BaseReturnsServiceTest.kt          # Existing
│       │   │   └── BaseMockedReturnOrderTest.kt       # Existing
│       │   ├── config/
│       │   │   ├── ConfigurationManager.kt            # Existing
│       │   │   └── SpecLoggingFilter.kt               # Existing
│       │   ├── utils/
│       │   │   ├── PSO.kt                             # Existing
│       │   │   ├── ReturnOrderBuilder.kt              # Existing
│       │   │   ├── ConfirmReturnRequestBuilder.kt     # Existing
│       │   │   ├── UpdateRouteBuilder.kt              # Existing
│       │   │   ├── KafkaTestProducer.kt               # NEW - Phase 2
│       │   │   ├── PickEventBuilder.kt                # NEW - Phase 2
│       │   │   └── PickInStoreEventBuilder.kt         # NEW - Phase 2
│       │   └── model/
│       │       ├── ParcelTrackingInfo.kt              # Existing
│       │       ├── ConfirmReturnRequest.kt            # Existing
│       │       └── UpdateRouteRequest.kt              # Existing
│       └── resources/
│           ├── local.properties                       # Existing
│           ├── logback-test.xml                       # Existing
│           ├── data/
│           │   ├── request/
│           │   │   ├── SingleLineReturnPSO.xml        # Existing
│           │   │   └── MultiLineReturnPSO.xml         # NEW - Phase 2
│           │   └── response/
│           │       ├── product_response.json          # Existing
│           │       └── product_response_with_attributes.json  # NEW - Phase 1
│           └── wiremock/
│               ├── mappings/
│               │   ├── mirakl-create-refund.json      # NEW - Phase 1
│               │   ├── mirakl-create-cancellation.json # NEW - Phase 1
│               │   ├── mirakl-create-thread.json      # NEW - Phase 1
│               │   ├── mirakl-get-order.json          # NEW - Phase 1
│               │   ├── seller-api-get-seller.json     # NEW - Phase 1
│               │   └── carrier-booking-create.json    # NEW - Phase 1
│               └── __files/
│                   ├── mirakl-refund-response.json    # NEW - Phase 1
│                   ├── mirakl-cancellation-response.json  # NEW - Phase 1
│                   ├── mirakl-order-response.json     # NEW - Phase 1
│                   ├── seller-response.json           # NEW - Phase 1
│                   └── carrier-booking-response.json  # NEW - Phase 1
```

---

## Document Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Feb 2026 | SDiT Team | Initial coverage plan with Kafka client approach |

---

**End of Document**
