# TASK-01: Route Determination Logic Enhancement

**Complexity:** ⭐ Simple
**Estimated Effort:** 1.5-2 days
**Can Run in Parallel:** ✅ Yes (independent of other tasks)
**Priority:** CRITICAL

---

## Important: Existing Container Stubs

🎉 **Good news!** The project already has WireMock stubs pre-configured in `/container-setup/__files/__product/` that cover all routing scenarios needed for this task.

**Available Product Stubs:**
- `2222222222222_iForce_battery_chemistry.json` - Li-ion battery product
- `3333333333333_iForce_product_weight.json` - Heavy product (>29kg)
- `1111111111111_iForce_order_amount.json` - Low price product
- `4444444444444_5555555555555_route_TBC.json` - Normal product → TBC
- `6666666666666_product_not_found_error.json` - 404 error
- `7777777777777_mixed_basket.json` - Multiple products

**These stubs are automatically loaded** when containers start - no test setup code needed!

**Implementation Approach:** Use existing container stubs directly in tests (no stub creation required). This saves ~1 day of work.

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` for detailed explanation of how container stubs work.

---

## Why This is Needed

### Business Problem

The marketplace returns service automatically routes returns to different fulfillment paths based on product characteristics:
- **iForce** - Third-party logistics for bulky/hazardous items
- **TBC** - To Be Confirmed by store (default route)
- **DPD** - Direct courier pickup

**Current Gap:** Only ~20% of routing logic is tested. The existing `WindsorFrameworkTest` only covers price-based routing for specific stores. Missing coverage includes:
- Battery chemistry routing (safety-critical - Li-ion batteries must go to iForce)
- Weight-based routing (items >29kg must go to iForce due to handling constraints)
- Technical attribute routing (dimensions, special handling requirements)

**Business Impact:**
- Incorrect routing causes operational issues (stores receiving items they can't handle)
- Safety risk if hazardous items (batteries) routed incorrectly
- Customer experience degraded if wrong collection method assigned

### What You'll Learn

- How to work with existing functional test patterns
- Product API integration via WireMock mocking
- Business logic testing with multiple test scenarios
- Parameterized testing in JUnit 5
- How routing decisions affect customer returns experience

---

## What Needs to Be Done

### Objectives

1. **Extend existing test coverage** for route determination logic in `IForceRouteValidator.validate()`
2. **Add 5 new test scenarios** to `WindsorFrameworkTest.kt` using existing container stubs
3. **Use pre-configured WireMock stubs** from `/container-setup/__files/__product/`
4. **Document the routing rules** and EAN-to-scenario mappings for future QA reference

**Key Change from Original Plan:** No need to create new WireMock stub files - reuse existing container stubs!

### Scope

**Files to Modify:**
- `/functional-tests/src/test/kotlin/com/kingfisher/api/WindsorFrameworkTest.kt` (enhance existing)

**Files to Reference:**
- `/container-setup/__files/__product/` (existing product stubs)
- `/container-setup/mappings/request_mappings.json` (URL patterns)
- `/WIREMOCK-SETUP-EXPLAINED.md` (how container stubs work)

**Files to Create:**
- `/functional-tests/docs/ROUTING-LOGIC.md` (documentation with EAN mappings)

**Business Logic Under Test:**
Located in `/src/main/kotlin/com/kingfisher/marketplace/service/IForceRouteValidator.kt`

The validator checks product attributes in this order:
1. Store in default iForce list → iForce (highest priority)
2. Price < threshold → iForce with "amount threshold" reason
3. Battery chemistry = Li-ion → iForce with "Battery" reason
4. Product weight > 29kg → iForce with "Weight" reason
5. Technical attributes exceed limits → iForce with attribute name reason
6. All checks pass → TBC (default)

---

## High-Level Technical Approach

### Step 1: Understand Existing Tests

**Action:** Study `WindsorFrameworkTest.kt` to understand the pattern

**Key Concepts:**
```kotlin
@ParameterizedTest
@MethodSource("provideStoreIds")
fun `should check route when order meets conditions for iForce`(storeId: Int) {
    // 1. Create return order with specific price/product
    // 2. Verify route assigned = iForce or TBC
    // 3. Verify status = expected value
}
```

**Learning Points:**
- How `BaseMockedReturnOrderTest` sets up WireMock stubs
- How `ReturnOrderBuilder` creates test data
- How to verify route and status in response

### Step 2: Understand Existing Container Stubs

**Action:** Review pre-configured WireMock stubs before creating new ones

**Container Stubs Already Available:**

The project has extensive WireMock stubs pre-loaded in `/container-setup/__files/__product/`:

- `2222222222222_iForce_battery_chemistry.json` - Li-ion battery product
- `3333333333333_iForce_product_weight.json` - Heavy product (>29kg)
- `1111111111111_iForce_order_amount.json` - Low price product
- `4444444444444_5555555555555_route_TBC.json` - Normal product → TBC
- `6666666666666_product_not_found_error.json` - 404 error
- `7777777777777_mixed_basket.json` - Multiple products

**These stubs are automatically loaded** when containers start - no test setup code needed!

**Read First:** `/WIREMOCK-SETUP-EXPLAINED.md` - Explains how container stubs work and how to use them in tests.

**Key Learning:** You can use these EANs directly in tests:
```kotlin
// Use existing container stub - no setup needed!
val response = createReturnOrder(ean = "2222222222222")
// Automatically returns Li-ion battery product
```

**Example Product Response Structure (from container stub):**
```json
// container-setup/__files/__product/2222222222222_iForce_battery_chemistry.json
{
  "data": [{
    "attributes": {
      "ean": "2222222222222",
      "technicalAttributes": {
        "technical": [{
          "groupName": "Battery_chemistry",
          "value": "Li-ion"
        }]
      }
    }
  }]
}
```

**How Container Stubs Work:**

Container stubs are mounted into WireMock on startup via `docker-compose-ci.yml`:
```yaml
wiremock:
  volumes:
    - "./container-setup/__files:/home/wiremock/__files"
    - "./container-setup/mappings:/home/wiremock/mappings"
```

URL patterns are defined in `/container-setup/mappings/request_mappings.json`. When you create an order with EAN `2222222222222`, WireMock automatically returns the battery product response - no test setup needed!

### Step 3: Implement Test Scenarios

**Recommended Approach:** Use existing container stubs for faster implementation

**5 Required Scenarios:**

| Scenario | Container EAN | Expected Route | Expected Status |
|----------|---------------|----------------|-----------------|
| 1. Heavy item | `3333333333333` | iForce | AWAITING_STORE_CONFIRMATION |
| 2. Battery item | `2222222222222` | iForce | AWAITING_STORE_CONFIRMATION |
| 3. Low price item | `1111111111111` | iForce | AWAITING_STORE_CONFIRMATION |
| 4. Normal product | `4444444444444` | TBC | AWAITING_LABEL_PRINTING |
| 5. Windsor store | Any EAN + storeId 1211 | iForce | AWAITING_STORE_CONFIRMATION |

**Test Structure Example (Using Container Stub):**
```kotlin
@Test
fun `should route to iForce when product weight exceeds 29kg`() {
    // Given: Use container stub for heavy product
    val ean = "3333333333333"  // Container stub exists!
    val storeId = 1017  // B&Q store

    // When: Create return order
    val response = createReturnOrder(storeId, ean)

    // Then: Verify route is iForce with Weight reason
    response.then()
        .statusCode(200)
        .body("route", equalTo("iForce"))
        .body("routeReason", equalTo("Weight"))
        .body("status", equalTo("AWAITING_STORE_CONFIRMATION"))
}
```

**Alternative:** Create programmatic stubs if you need custom variations not covered by container stubs.

### Step 4: Document Routing Rules

**Action:** Create `ROUTING-LOGIC.md` explaining:
- Decision tree for routing
- Each attribute checked and threshold
- Examples of each routing scenario
- How to add new routing tests

---

## Success Metrics

### Success Metrics

### Test Coverage Metrics

- ✅ **5 new test scenarios** added to WindsorFrameworkTest using container stubs
- ✅ **Route determination coverage**: 20% → 75% (from functional tests perspective)
- ✅ **All tests pass** in CI/CD pipeline
- ✅ **Test execution time**: Additional scenarios add <10 seconds total
- ✅ **EAN-to-scenario mapping documented** in ROUTING-LOGIC.md

### Quality Metrics

- ✅ **Test clarity**: Each test has clear Given/When/Then structure
- ✅ **Test isolation**: Tests can run independently and in any order
- ✅ **Container stubs reused**: No duplicate stub creation
- ✅ **Code review approval**: At least one senior QA/developer reviews

### Documentation Metrics

- ✅ **ROUTING-LOGIC.md created** with all routing rules and EAN mappings documented
- ✅ **WindsorFrameworkTest.kt commented** explaining what each scenario tests
- ✅ **Peer review**: Another QA can understand and extend tests

---

## Acceptance Criteria

**Before Considering Task Complete:**

- [ ] All 5 test scenarios implemented and passing
- [ ] Tests run successfully via `./gradlew runFunctionalIntegrationTests --tests "WindsorFrameworkTest"`
- [ ] Tests fail appropriately when assertions are inverted (proves tests work)
- [ ] Container stubs verified working (EANs return expected product attributes)
- [ ] ROUTING-LOGIC.md document created with routing decision tree and EAN mappings
- [ ] Code committed to feature branch with descriptive commit messages
- [ ] Pull request created with clear description of changes
- [ ] Tests pass in CI/CD pipeline
- [ ] Documentation reviewed by at least one other team member
- [ ] No new warnings or errors in test execution logs

---

## Dependencies & Parallelization

**Can Start Immediately:** ✅ Yes
**Blocked By:** None
**Blocks:** None (other tasks independent)

**Parallel Execution:**
- Can work in parallel with TASK-02, TASK-03, TASK-04
- No merge conflicts expected (different test files)

**Required Services:**
- Docker containers (WireMock, DynamoDB, Kafka) - already configured in `docker-compose-ci.yml`
- Must start containers before running tests: `docker-compose -f docker-compose-ci.yml up -d`

---

## Getting Started Guide

### 1. Environment Setup (30 minutes)

```bash
# Navigate to project
cd /Users/LUBAWM01/projects/marketplace-returns-service

# Start Docker containers
docker-compose -f docker-compose-ci.yml up -d

# Verify containers running
docker-compose -f docker-compose-ci.yml ps

# Run existing tests to verify setup
./gradlew runFunctionalIntegrationTests --tests "WindsorFrameworkTest"
```

### 2. Study Existing Code (1 hour)

**Read these files to understand patterns:**
1. `/functional-tests/src/test/kotlin/com/kingfisher/api/WindsorFrameworkTest.kt`
2. `/functional-tests/src/test/kotlin/com/kingfisher/api/BaseMockedReturnOrderTest.kt`
3. `/functional-tests/src/test/kotlin/com/kingfisher/utils/ReturnOrderBuilder.kt`
4. **NEW:** `/WIREMOCK-SETUP-EXPLAINED.md` - How container stubs work
5. **NEW:** `/TASK-UPDATES.md` - Discovery of existing stubs

**Key Questions to Answer:**
- How are test orders created?
- How is WireMock configured?
- What's the structure of a test method?
- How are assertions made on the response?
- **Which container stubs already exist?**

### 3. Read Business Logic (30 minutes)

**Read:**
- `/src/main/kotlin/com/kingfisher/marketplace/service/IForceRouteValidator.kt`

**Understand:**
- What attributes are checked?
- What are the threshold values? (29kg, battery types, etc.)
- What reasons are returned for each routing decision?

### 4. Implement First Scenario (1-2 hours)

**Start simple:**
- Implement "Heavy item" scenario using container stub `3333333333333`
- No WireMock setup needed - stub already exists!
- Write test, run it, make it pass
- Refine and clean up

### 5. Implement Remaining Scenarios (2-3 hours)

- Battery chemistry scenario (use `2222222222222`)
- Low price scenario (use `1111111111111`)
- TBC default scenario (use `4444444444444`)
- Windsor store scenario

### 6. Document and Review (1.5 hours)

- Create ROUTING-LOGIC.md with EAN-to-scenario mappings
- Document which container stubs are used for each test
- Add code comments
- Self-review checklist
- Create pull request

---

## Resources

### Container Stubs

- **Location**: `/container-setup/__files/__product/`
- **Mappings**: `/container-setup/mappings/request_mappings.json`
- **Documentation**: `/WIREMOCK-SETUP-EXPLAINED.md`

### Existing Test Examples

- **Similar test pattern**: `WindsorFrameworkTest.kt` lines 25-60
- **WireMock stub examples**: `BaseMockedReturnOrderTest.kt` lines 40-70
- **Test data builders**: `/functional-tests/src/test/kotlin/com/kingfisher/utils/`

### Documentation References

- **Functional test docs**: `/functional-tests-docs.md`
- **Coverage plan**: `/functional-tests-coverage-plan.md` (Section 1.3)
- **Business logic**: `/src/main/kotlin/com/kingfisher/marketplace/service/IForceRouteValidator.kt`

### WireMock Documentation

- [WireMock Request Matching](http://wiremock.org/docs/request-matching/)
- [WireMock Response Templating](http://wiremock.org/docs/response-templating/)

---

## Tips for Success

### For Junior QAs

1. **Start by running existing tests** - understand what "passing" looks like
2. **Review container stubs** - Check `/container-setup/__files/__product/` to see what EANs are available
3. **Use existing EANs** - No need to create new stubs, just use `2222222222222`, `3333333333333`, etc.
4. **Test one thing at a time** - Don't try to implement all scenarios at once
5. **Ask questions early** - If stuck >30 minutes, ask for help
6. **Document as you go** - Write down EAN mappings while fresh in your mind

### Common Pitfalls to Avoid

❌ **Don't hardcode values** - Use constants or test data builders
❌ **Don't create new stubs** - Reuse existing container stubs (saves time!)
❌ **Don't skip cleanup** - Make sure test orders are deleted in @AfterEach
❌ **Don't assume order** - Tests should work in any execution order
❌ **Don't ignore flaky tests** - If test passes sometimes, investigate why

### Verification Checklist

After each scenario:
- [ ] Test passes when run alone
- [ ] Test passes when run with all other tests
- [ ] Test fails when assertion is inverted
- [ ] Test name clearly describes what it tests
- [ ] WireMock stub is specific to this scenario

---

## Expected Deliverables

1. **Code Changes:**
   - Enhanced `WindsorFrameworkTest.kt` with 5 new scenarios using container stubs
   - No new WireMock stub files needed (reusing existing)

2. **Documentation:**
   - `ROUTING-LOGIC.md` explaining routing decision tree
   - EAN-to-scenario mapping table (which EAN tests which routing rule)
   - Reference to container stubs used

3. **Pull Request:**
   - Clear title: "TASK-01: Add route determination test coverage using container stubs"
   - Description explaining what was added and why
   - EAN mapping table in description
   - Screenshots of test execution (passing tests)

---

## Definition of Done

Task is complete when:
- ✅ All 5 test scenarios implemented and passing
- ✅ Test coverage improved (verified by running all tests)
- ✅ Documentation created and reviewed
- ✅ Pull request approved by reviewer
- ✅ Tests pass in CI/CD pipeline
- ✅ Knowledge shared with team (demo or walkthrough)

---

## Questions or Blockers?

If you encounter issues:
1. Check `/functional-tests-docs.md` for setup instructions
2. Ask in team chat with specific error messages
3. Schedule pairing session with senior QA if stuck >1 day

---

**Estimated Timeline:**
- Day 1: Setup, study existing code and container stubs, implement 2-3 scenarios
- Day 2: Complete remaining scenarios, debug
- Day 3: Documentation, code review, refinement

**Time Saved:** Using existing container stubs saves ~1 day compared to creating all stubs from scratch!

**Good luck! This task will give you solid foundation in functional testing patterns used throughout the project.**
