# TASK-02: Carrier Booking API Integration Testing

**Complexity:** ⭐⭐ Simple to Medium
**Estimated Effort:** 1.5-2 days
**Can Run in Parallel:** ✅ Yes independent of other tasks
**Priority:** CRITICAL

---

## Important: Existing Container Stubs

🎉 **Good news!** The project already has WireMock stubs pre-configured in `/container-setup/__files/` for Seller API and Carrier Booking API.

**Available Stubs:**
- `__sellers-api/seller-successful-response.json` - Seller with address details
- `__sellers-api/seller-not-found-error-response.json` - 404 seller not found
- `__carrier-booking/carrier-booking-response-successful.json` - Successful DPD booking
- `__carrier-booking/carrier-booking-processing-error-response.json` - Booking failure

**These stubs are automatically loaded** when containers start - no test setup code needed for happy paths!

**Implementation Approach:** Use existing container stubs for main scenarios, create programmatic overrides only for test-specific variations. This saves ~1 day of work.

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` for detailed explanation of how container stubs work.

---

## Why This is Needed

### Business Problem

When a customer return is routed to **DPD** (courier pickup), the system must:
1. Book a collection slot with the carrier (DPD)
2. Retrieve seller's address from Seller API
3. Generate consignment tracking code
4. Update return order with collection date and tracking info

**Current Gap:** Zero functional test coverage for this critical customer-facing flow. The existing tests don't verify:
- Carrier Booking API integration
- Seller API integration
- Consignment code extraction and storage
- Error handling when booking fails

**Business Impact:**
- If carrier booking fails silently, customer won't get pickup
- Incorrect seller address means failed collection
- Missing tracking codes prevent shipment monitoring
- Customer experience degraded (no collection, no visibility)

**Revenue Impact:**
- Failed collections lead to customer complaints
- Manual intervention costs time and resources
- Poor customer experience affects retention

### What You'll Learn

- Creating new functional test files from scratch
- Testing API integration workflows with multiple external services
- WireMock advanced features (multiple stubs, response chaining)
- Error scenario testing (what happens when APIs fail?)
- How DPD collection booking works in the returns process

---

## What Needs to Be Done

### Objectives

1. **Create comprehensive test coverage** for Carrier Booking API integration
2. **Implement 7 test scenarios** covering happy path and error cases
3. **Use existing WireMock container stubs** for Seller API and Carrier Booking API
4. **Create programmatic stub overrides** only when needed for test-specific scenarios
5. **Verify end-to-end flow** from route update to DPD booking confirmation
6. **Document the booking flow** for future reference

**Key Change from Original Plan:** Reuse existing container stubs - only create programmatic overrides for variations not covered!

### Scope

**New Files to Create:**
- `/functional-tests/src/test/kotlin/com/kingfisher/api/CarrierBookingAPITest.kt` (new test class)
- `/functional-tests/docs/CARRIER-BOOKING-FLOW.md` (documentation)

**Existing Files to Reference:**
- `/container-setup/__files/__sellers-api/` (existing seller stubs)
- `/container-setup/__files/__carrier-booking/` (existing carrier booking stubs)
- `/container-setup/mappings/request_mappings.json` (URL patterns)
- `/WIREMOCK-SETUP-EXPLAINED.md` (how container stubs work)

**Optional Files (only if container stubs insufficient):**
- `/functional-tests/src/test/resources/data/response/seller_response.json` (programmatic override)
- `/functional-tests/src/test/resources/data/response/carrier_booking_response.json` (programmatic override)

**Business Logic Under Test:**
Located in `/src/main/kotlin/com/kingfisher/marketplace/service/CarrierBookingAPIService.kt`

The service performs this workflow:
1. Fetch seller details from Seller API (address, contact info)
2. Call Carrier Booking API with seller address + return details
3. Parse response to extract consignment code and collection date
4. Update return order with tracking information
5. Handle errors gracefully (API timeouts, invalid responses)

---

## High-Level Technical Approach

### Step 1: Understand the Carrier Booking Flow

**Study these files:**
1. `/src/main/kotlin/com/kingfisher/marketplace/service/CarrierBookingAPIService.kt` - Main booking logic
2. `/src/main/kotlin/com/kingfisher/marketplace/service/UpdateRouteBusinessServiceImpl.kt` - When booking is triggered
3. Existing test: `/functional-tests/src/test/kotlin/com/kingfisher/api/UpdateRouteTest.kt` - Route update pattern

**Flow Diagram:**
```
User updates route to DPD
    ↓
UpdateRouteBusinessServiceImpl.processUpdateRoute()
    ↓
CarrierBookingAPIService.invokeCarrierBookingAPI()
    ├─→ Fetch seller from Seller API
    ├─→ Build booking request
    ├─→ Call Carrier Booking API
    └─→ Extract consignment code & collection date
    ↓
Update return order in DynamoDB
    ↓
Return success response with tracking info
```

### Step 2: Create Test File Structure

**Pattern:** Follow existing test structure from `UpdateRouteTest.kt`

```kotlin
package com.kingfisher.api

import com.kingfisher.core.BaseReturnsServiceTest
import io.restassured.RestAssured.given
import org.hamcrest.Matchers.*
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class CarrierBookingAPITest : BaseMockedReturnOrderTest() {

    private val tenant = "BQUK"
    private val shopId = "12345"

    @BeforeEach
    fun setup() {
        // Setup WireMock stubs
        setupProductStub()
        setupSellerStub()
        setupCarrierBookingStub()
    }

    @AfterEach
    fun cleanup() {
        // Delete test orders
    }

    @Test
    fun `should successfully book DPD collection and update return order`() {
        // Test implementation
    }
}
```

### Step 3: Create WireMock Stubs

**Important Discovery:** Container stubs already exist for Seller API and Carrier Booking API!

**Existing Container Stubs:**

**Location:** `/container-setup/__files/`

- `__sellers-api/seller-successful-response.json` - Seller with address
- `__sellers-api/seller-not-found-error-response.json` - 404 error
- `__carrier-booking/carrier-booking-response-successful.json` - Successful booking
- `__carrier-booking/carrier-booking-processing-error-response.json` - Booking failure

**Read First:** `/WIREMOCK-SETUP-EXPLAINED.md` and `/TASK-UPDATES.md`

**Recommended Approach:** Use existing container stubs and only create programmatic overrides if you need test-specific variations.

**Stub 1: Seller API Response (Container Stub Exists)**

**Location:** `/container-setup/__files/__sellers-api/seller-successful-response.json`

```json
// Already exists in container!
{
  "shopId": "12345",
  "shopName": "Test Seller Ltd",
  "departmentName": "Returns Department",
  "address": {
    "street": "123 Business Park",
    "city": "London",
    "zipCode": "SW1A 1AA",
    "country": "GB"
  },
  "contact": {
    "email": "returns@testseller.com",
    "phone": "+44 20 1234 5678"
  }
}
```

**Stub 2: Carrier Booking API Response (Container Stub Exists)**

**Location:** `/container-setup/__files/__carrier-booking/carrier-booking-response-successful.json`

```json
// Already exists in container!
{
  "bookingReference": "DPD-202401-123456",
  "consignmentCode": "15501234567890123456",
  "collectionDate": "2024-01-20",
  "collectionTimeWindow": "09:00-17:00",
  "status": "CONFIRMED"
}
```

**WireMock Setup in Test (Optional - Container stubs may be sufficient):**
```kotlin
private fun setupSellerStub() {
    // Container stub already exists!
    // Only override if you need test-specific variations
    wireMockServer.stubFor(
        get(urlPathMatching("/sellers/$shopId"))
            .withQueryParam("tenant", equalTo(tenant))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("seller_response.json")
            )
    )
}

private fun setupCarrierBookingStub() {
    // Container stub already exists!
    // Only override if you need test-specific variations
    wireMockServer.stubFor(
        post(urlPathEqualTo("/v1/bookings"))
            .withRequestBody(matchingJsonPath("$.sellerAddress"))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("carrier_booking_response.json")
            )
    )
}
```

**Note:** Check if container stubs work for your tests before creating programmatic overrides.

### Step 4: Implement Test Scenarios

**7 Required Test Scenarios:**

| # | Scenario | Verifies | Complexity |
|---|----------|----------|------------|
| 1 | Happy path - successful booking | Full flow, consignment code saved | ⭐ Simple |
| 2 | Seller has department name | Department used in address | ⭐ Simple |
| 3 | Seller missing department | Seller name fallback | ⭐⭐ Medium |
| 4 | Seller API returns 404 | CarrierBookingException thrown | ⭐⭐ Medium |
| 5 | Carrier Booking API timeout | Timeout handled gracefully | ⭐⭐⭐ Complex |
| 6 | Consignment code extraction | Correct format (15 digits) | ⭐ Simple |
| 7 | Collection date populated | Date saved in return order | ⭐ Simple |

**Example Test Implementation (Scenario 1):**

```kotlin
@Test
fun `should successfully book DPD collection and update return order`() {
    // GIVEN: Return order exists with TBC route
    val orderId = createReturnOrderWithTBCRoute(
        storeId = 1017,
        ean = "1234567890123",
        shopId = shopId
    )

    setupSellerStub(shopId, hasDepartmentName = true)
    setupCarrierBookingStub(success = true)

    // WHEN: Route updated to DPD
    val updateRouteRequest = UpdateRouteBuilder()
        .withRoute("DPD")
        .withEan("1234567890123")
        .withReason("Customer requested courier pickup")
        .build()

    given()
        .contentType("application/json")
        .body(updateRouteRequest)
        .pathParam("tenant", tenant)
        .pathParam("orderId", orderId)
    .`when`()
        .post("/v1/returns/{tenant}/{orderId}/route")
    .then()
        .statusCode(200)
        .body("route", equalTo("DPD"))
        .body("consignmentCode", matchesPattern("\\d{20}")) // 20-digit code
        .body("collectionDate", notNullValue())
        .body("status", equalTo("COLLECTION_BOOKED"))

    // THEN: Verify Seller API was called
    wireMockServer.verify(
        getRequestedFor(urlPathMatching("/sellers/$shopId"))
            .withQueryParam("tenant", equalTo(tenant))
    )

    // AND: Verify Carrier Booking API was called with correct address
    wireMockServer.verify(
        postRequestedFor(urlPathEqualTo("/v1/bookings"))
            .withRequestBody(matchingJsonPath("$.sellerAddress.zipCode", equalTo("SW1A 1AA")))
            .withRequestBody(matchingJsonPath("$.sellerAddress.contactName", containing("Returns Department")))
    )

    // AND: Verify return order updated in database
    val fetchedOrder = fetchReturnOrder(orderId)
    assertThat(fetchedOrder.consignmentCode, startsWith("DPD-"))
    assertThat(fetchedOrder.collectionDate, notNullValue())
}
```

**Example Test Implementation (Scenario 4 - Error Case):**

```kotlin
@Test
fun `should throw CarrierBookingException when seller not found`() {
    // GIVEN: Seller API returns 404
    wireMockServer.stubFor(
        get(urlPathMatching("/sellers/$shopId"))
            .willReturn(aResponse().withStatus(404))
    )

    val orderId = createReturnOrderWithTBCRoute(shopId = shopId)

    // WHEN: Route updated to DPD
    val updateRouteRequest = UpdateRouteBuilder()
        .withRoute("DPD")
        .build()

    given()
        .contentType("application/json")
        .body(updateRouteRequest)
        .pathParam("orderId", orderId)
    .`when`()
        .post("/v1/returns/{tenant}/{orderId}/route")
    .then()
        .statusCode(500) // Or 400 depending on error handling
        .body("error", containsString("Seller not found"))

    // THEN: Verify no booking was attempted
    wireMockServer.verify(0, postRequestedFor(urlPathEqualTo("/v1/bookings")))
}
```

### Step 5: Document the Flow

**Create:** `/functional-tests/docs/CARRIER-BOOKING-FLOW.md`

**Content should include:**
- Sequence diagram of the booking flow
- Seller API contract (endpoint, params, response)
- Carrier Booking API contract
- Error scenarios and handling
- How to add new carrier integration tests

---

## Success Metrics

### Test Coverage Metrics

- ✅ **7 test scenarios** implemented and passing
- ✅ **Carrier Booking API coverage**: 0% → 100% (functional tests)
- ✅ **All tests pass** independently and together
- ✅ **Test execution time**: <30 seconds for all scenarios

### Quality Metrics

- ✅ **Error scenarios covered**: API failures don't crash the system
- ✅ **WireMock verification**: API calls are made with correct payloads
- ✅ **Database verification**: Orders updated correctly after booking
- ✅ **Code review approval**: Senior QA/developer approves

### Documentation Metrics

- ✅ **CARRIER-BOOKING-FLOW.md created** with flow diagrams
- ✅ **Test class well-commented** explaining each scenario
- ✅ **WireMock stubs documented** with example requests/responses

---

## Acceptance Criteria

**Before Considering Task Complete:**

- [ ] All 7 test scenarios implemented and passing
- [ ] Tests run successfully via `./gradlew runFunctionalIntegrationTests --tests "CarrierBookingAPITest"`
- [ ] WireMock stubs created for Seller API and Carrier Booking API
- [ ] Error scenarios tested (seller not found, booking timeout)
- [ ] Consignment code format verified (15-20 digits)
- [ ] Collection date saved and verified in DynamoDB
- [ ] CARRIER-BOOKING-FLOW.md documentation created
- [ ] Code committed to feature branch with clear commits
- [ ] Pull request created with description and test results
- [ ] Tests pass in CI/CD pipeline
- [ ] Peer review completed
- [ ] No flaky tests (run 5 times, 100% pass rate)

---

## Dependencies & Parallelization

**Can Start Immediately:** ✅ Yes
**Blocked By:** None
**Blocks:** None

**Parallel Execution:**
- Can work in parallel with TASK-01, TASK-03, TASK-04
- Different test file, no merge conflicts expected

**Required Services:**
- Docker containers must be running
- WireMock (port 9090)
- DynamoDB (port 8000)

**Integration Points to Mock:**
- Seller API (WireMock stub)
- Carrier Booking API (WireMock stub)
- Product API (reuse existing stub)

---

## Getting Started Guide

### 1. Environment Setup (30 minutes)

```bash
# Navigate to project
cd /Users/LUBAWM01/projects/marketplace-returns-service

# Start Docker containers
docker-compose -f docker-compose-ci.yml up -d

# Verify WireMock is accessible
curl http://localhost:9090/__admin/mappings

# Run existing route update tests to understand pattern
./gradlew runFunctionalIntegrationTests --tests "UpdateRouteTest"
```

### 2. Study Existing Code (1-2 hours)

**Read these files:**
1. `/functional-tests/src/test/kotlin/com/kingfisher/api/UpdateRouteTest.kt` - Similar pattern
2. `/src/main/kotlin/com/kingfisher/marketplace/service/CarrierBookingAPIService.kt` - Business logic
3. `/functional-tests/src/test/kotlin/com/kingfisher/utils/UpdateRouteBuilder.kt` - Test data builder
4. **NEW:** `/WIREMOCK-SETUP-EXPLAINED.md` - How container stubs work
5. **NEW:** `/TASK-UPDATES.md` - Existing Seller/Carrier stubs
6. **NEW:** `/container-setup/__files/__sellers-api/` - Review existing stubs
7. **NEW:** `/container-setup/__files/__carrier-booking/` - Review existing stubs

**Key Questions:**
- How does UpdateRouteTest create orders?
- How are WireMock stubs configured?
- What does a successful route update look like?
- How are errors handled?
- **Which container stubs already exist and can be reused?**

### 3. Create Test File Skeleton (1 hour)

**Steps:**
1. Copy `UpdateRouteTest.kt` as template
2. Rename to `CarrierBookingAPITest.kt`
3. Remove existing test methods
4. Add setup methods for new WireMock stubs
5. Verify it compiles and runs (empty test class)

### 4. Implement Happy Path First (2-3 hours)

**Focus on Scenario 1:**
- Check if container stubs work for your test (they likely do!)
- If container stubs sufficient, no stub setup needed
- Write test for successful booking
- Run test, debug, make it pass
- Add assertions for all important fields

### 5. Add Error Scenarios (3-4 hours)

- Implement scenarios 4 and 5 (error cases)
- May need programmatic stub overrides for specific errors
- Verify error handling works correctly
- Check logs for appropriate error messages

### 6. Complete Remaining Scenarios (2-3 hours)

- Implement scenarios 2, 3, 6, 7
- Ensure good test coverage
- Refactor common code into helper methods

### 7. Documentation and Review (2 hours)

- Create CARRIER-BOOKING-FLOW.md
- Add comments to test code
- Create pull request
- Address review feedback

---

## Resources

### Code References

- **Similar test**: `/functional-tests/src/test/kotlin/com/kingfisher/api/UpdateRouteTest.kt`
- **Business logic**: `/src/main/kotlin/com/kingfisher/marketplace/service/CarrierBookingAPIService.kt`
- **Test builders**: `/functional-tests/src/test/kotlin/com/kingfisher/utils/UpdateRouteBuilder.kt`

### Documentation

- **Functional tests overview**: `/functional-tests-docs.md`
- **Coverage plan**: `/functional-tests-coverage-plan.md` (Section 1.1)

### WireMock Examples

- Existing product stub: Look in `BaseMockedReturnOrderTest.kt`
- Request matching: [WireMock Docs](http://wiremock.org/docs/request-matching/)
- Verify API calls: [WireMock Verification](http://wiremock.org/docs/verifying/)

---

## Tips for Success

### For Junior/Mid-Level QAs

1. **Start with happy path** - Get one test working end-to-end first
2. **Use WireMock admin UI** - Browse to http://localhost:9090/__admin to debug stubs
3. **Check application logs** - If test fails, look at app logs for API call details
4. **Verify WireMock was called** - Use `.verify()` to ensure stubs were hit
5. **Test error cases last** - They're trickier, do them after happy path works

### Common Pitfalls to Avoid

❌ **Forgetting to setup WireMock stub** - Test will fail with "connection refused"
❌ **Wrong stub URL path** - Double-check endpoints match actual API calls
❌ **Not verifying API calls** - Use `verify()` to ensure integration happened
❌ **Hardcoding test data** - Use builders for flexibility
❌ **Not testing error scenarios** - These are critical for production reliability

### Debugging Tips

**Test fails with "Connection refused":**
```bash
# Check WireMock is running
curl http://localhost:9090/__admin/mappings

# Check stub was registered
curl http://localhost:9090/__admin/requests/unmatched
```

**Test fails with "Stub not found":**
- Check URL path matches exactly (case-sensitive)
- Verify query parameters match
- Look at WireMock logs in docker-compose output

**Test passes but verification fails:**
- Check request body format (JSON structure)
- Use `matchingJsonPath()` for flexible matching
- Print actual request body in WireMock admin UI

---

## Expected Deliverables

1. **Code:**
   - `CarrierBookingAPITest.kt` with 7 test scenarios
   - Helper methods for WireMock stub setup
   - Test data in `/functional-tests/src/test/resources/data/response/`

2. **Documentation:**
   - `CARRIER-BOOKING-FLOW.md` with flow diagrams and API contracts

3. **Pull Request:**
   - Title: "TASK-02: Add Carrier Booking API integration tests"
   - Description with test coverage summary
   - Screenshots of passing tests

---

## Definition of Done

- ✅ All 7 scenarios implemented and passing
- ✅ Error handling tested thoroughly
- ✅ WireMock stubs for both APIs created
- ✅ Documentation complete and reviewed
- ✅ Pull request approved
- ✅ Tests pass in CI/CD
- ✅ Knowledge shared with team

---

## Questions or Blockers?

**Common Questions:**
- "What should seller API endpoint look like?" → Check CarrierBookingAPIService.kt for actual endpoint
- "What format is consignment code?" → Check existing orders in DynamoDB or service code
- "How do I test timeouts?" → Use WireMock's `.withFixedDelay()` method

**Get Help:**
- Check existing UpdateRouteTest for similar patterns
- Ask in team chat with specific error messages
- Pair with senior QA if stuck >2 hours on one issue

---

**Estimated Timeline:**
- Day 1: Setup, study code and container stubs, skeleton test file, happy path
- Day 2: Implement remaining scenarios, debug
- Day 3: Error scenarios, documentation, review

**Time Saved:** Using existing container stubs saves ~1 day compared to creating all stubs from scratch!

**This task builds on TASK-01 concepts and adds API integration complexity. Perfect for leveling up your testing skills!**
