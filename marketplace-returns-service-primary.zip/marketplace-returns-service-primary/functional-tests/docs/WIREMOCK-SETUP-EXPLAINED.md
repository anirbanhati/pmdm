# WireMock Setup Explained

**Created:** 2026-02-16
**Purpose:** Clarify how WireMock stubs work in this project (container-mounted vs programmatic)

---

## TL;DR - Two Stub Mechanisms

Your functional tests use **TWO different approaches** for WireMock stubbing:

1. **Container-Mounted Stubs** (Static, Pre-configured)
   - 📁 Location: `/container-setup/__files` + `/container-setup/mappings`
   - 🐳 Mounted into WireMock container on startup
   - 🎯 Always available, baseline stubs for all tests

2. **Programmatic Stubs** (Dynamic, Test-Defined)
   - 💻 Created in test code: `WireMock.stubFor(...)`
   - 📁 Responses from: `/functional-tests/src/test/resources/data/response/`
   - 🎯 Test-specific, can override container stubs

Both work together! Container stubs provide defaults, tests can override/extend them.

---

## Container-Mounted Stubs (Static)

### How It Works

**1. Files are mounted into WireMock container:**

```yaml
# docker-compose-ci.yml
wiremock:
  volumes:
    - "./container-setup/__files:/home/wiremock/__files"
    - "./container-setup/mappings:/home/wiremock/mappings"
```

**2. Mappings define URL patterns → Response files:**

```json
// container-setup/mappings/request_mappings.json
{
  "mappings": [
    {
      "request": {
        "method": "GET",
        "urlPattern": "^(/api/orders).*"
      },
      "response": {
        "status": 200,
        "bodyFileName": "__mirakl/OR11_Successful.json"
      }
    }
  ]
}
```

**3. WireMock serves these automatically when container starts**

### What Exists Already

**Product API Stubs:**
```
container-setup/__files/__product/
├── 1111111111111_iForce_order_amount.json        # Low price → iForce
├── 2222222222222_iForce_battery_chemistry.json   # Li-ion battery → iForce
├── 3333333333333_iForce_product_weight.json      # Heavy (>29kg) → iForce
├── 4444444444444_5555555555555_route_TBC.json    # Normal product → TBC
├── 6666666666666_product_not_found_error.json    # 404 error
└── 7777777777777_mixed_basket.json               # Multiple products
```

**Carrier Booking API Stubs:**
```
container-setup/__files/__carrier-booking/
├── carrier-booking-response-successful.json      # Successful DPD booking
└── carrier-booking-processing-error-response.json # Booking failure
```

**Seller API Stubs:**
```
container-setup/__files/__sellers-api/
├── seller-successful-response.json               # Seller found
└── seller-not-found-error-response.json          # 404 seller not found
```

**Mirakl API Stubs:**
```
container-setup/__files/__mirakl/
├── Authentication_Successful.json                # OAuth2 token
├── OR11_Successful.json                          # Get orders
├── OR28_Successful.json                          # Refund success
├── OR28_Error.json                               # Refund error
├── OR43_Successful.json                          # Seller notification success
├── OR43_Error.json                               # Notification error
└── OF22_*.json                                   # Offer endpoints
```

### When Container Stubs Are Used

✅ **When container starts**, these stubs are immediately available
✅ **All tests** can use them without any setup code
✅ **Default behavior** for API endpoints

### Example: Product API Battery Stub

**File:** `container-setup/__files/__product/2222222222222_iForce_battery_chemistry.json`

```json
{
  "data": [{
    "attributes": {
      "ean": "2222222222222",
      "technicalAttributes": {
        "technical": [
          {
            "groupName": "Battery_chemistry",
            "value": "Li-ion"
          }
        ]
      }
    }
  }]
}
```

**Mapping:** `container-setup/mappings/request_mappings.json`

```json
{
  "request": {
    "method": "GET",
    "urlPattern": "/v1/products/BQUK\\?filter\\[ean\\]=2222222222222"
  },
  "response": {
    "status": 200,
    "bodyFileName": "__product/2222222222222_iForce_battery_chemistry.json"
  }
}
```

**Usage in Test:**

```kotlin
// No stub setup needed! Just use the EAN
val response = createReturnOrder(ean = "2222222222222")
// Product API automatically returns Li-ion battery response
// Route will be iForce automatically
```

---

## Programmatic Stubs (Dynamic)

### How It Works

**1. Tests create stubs in code:**

```kotlin
// BaseMockedReturnOrderTest.kt
protected fun stubProductEndpoint() {
    WireMock.stubFor(
        WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN))
            .atPriority(1)  // Override container stubs
            .willReturn(
                WireMock.aResponse()
                    .withStatus(200)
                    .withBody(FileUtils.readDataFile("response/product_response.json"))
            )
    )
}
```

**2. Response body comes from test resources:**

**File:** `functional-tests/src/test/resources/data/response/product_response.json`

```json
{
  "data": [{
    "attributes": {
      "ean": "9898989898097",
      "technicalAttributes": {
        "technical": [
          {
            "groupName": "Product_weight",
            "value": "190"  // 190g - lightweight
          }
        ]
      }
    }
  }]
}
```

**3. Stub is registered when test runs:**

```kotlin
@BeforeEach
fun baseSetup() {
    WireMock.configureFor(WIREMOCK_HOST, WIREMOCK_PORT)
    stubProductEndpoint()  // Registers stub dynamically
}
```

### When Programmatic Stubs Are Used

✅ **When you need test-specific responses**
✅ **When you want to override container defaults**
✅ **When testing multiple variations** of same endpoint

### Priority System

```kotlin
// Priority 1 = Highest (overrides container stubs)
WireMock.stubFor(
    WireMock.get("/api/orders")
        .atPriority(1)  // This wins over container mapping
        .willReturn(...)
)

// Container stubs have default priority (5)
// Lower number = higher priority
```

---

## How They Work Together

### Scenario 1: Using Container Stub (No Override)

```kotlin
@Test
fun `test with container stub`() {
    // Create order with EAN that has container stub
    val response = createReturnOrder(ean = "2222222222222")

    // WireMock uses container stub:
    // container-setup/__files/__product/2222222222222_iForce_battery_chemistry.json

    assertThat(response.route).isEqualTo("iForce")
}
```

**Flow:**
1. Test creates order with EAN `2222222222222`
2. App calls Product API: `GET /v1/products/BQUK?filter[ean]=2222222222222`
3. WireMock checks mappings, finds container stub
4. Returns battery product response
5. Route determination logic sees Li-ion → iForce

---

### Scenario 2: Overriding Container Stub

```kotlin
@Test
fun `test with custom stub`() {
    // Override with custom response
    WireMock.stubFor(
        WireMock.get(WireMock.urlPathEqualTo("/v1/products/BQUK"))
            .withQueryParam("filter[ean]", WireMock.equalTo("2222222222222"))
            .atPriority(1)  // Higher priority than container
            .willReturn(
                WireMock.aResponse()
                    .withStatus(200)
                    .withBody("""{"data":[{"attributes":{"ean":"2222222222222","technicalAttributes":{"technical":[{"groupName":"Product_weight","value":"50"}]}}}]}""")
            )
    )

    // Now same EAN returns custom response (50kg weight)
    val response = createReturnOrder(ean = "2222222222222")

    assertThat(response.route).isEqualTo("iForce")  // Heavy weight
}
```

**Flow:**
1. Test creates custom stub with priority 1
2. App calls Product API
3. WireMock checks stubs by priority: Custom (1) beats container (5)
4. Returns custom response with 50kg weight
5. Route determination sees weight > 29kg → iForce

---

### Scenario 3: Generic Catch-All (Current Pattern)

```kotlin
// BaseMockedReturnOrderTest.kt
protected fun stubProductEndpoint() {
    WireMock.stubFor(
        WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN))  // Matches ANY EAN
            .atPriority(1)
            .willReturn(
                WireMock.aResponse()
                    .withBody(FileUtils.readDataFile("response/product_response.json"))
            )
    )
}
```

**Problem:** This generic stub **overrides ALL container product stubs**!

**Why:** Priority 1 + broad URL pattern = catches everything

**Impact:**
- EAN `2222222222222` no longer returns battery product
- All product requests return same `product_response.json`
- Container stubs are effectively disabled

---

## Best Practices for Tasks

### TASK-01: Route Determination Enhancement

**Option A: Use Existing Container Stubs (Recommended)**

```kotlin
@Test
fun `should route to iForce when product has Li-ion battery`() {
    // Use existing container stub - no setup needed!
    val response = createReturnOrder(ean = "2222222222222")

    assertThat(response.route).isEqualTo("iForce")
    assertThat(response.routeReason).isEqualTo("Battery")
}

@Test
fun `should route to iForce when product weight over 29kg`() {
    // Use existing container stub
    val response = createReturnOrder(ean = "3333333333333")

    assertThat(response.route).isEqualTo("iForce")
    assertThat(response.routeReason).isEqualTo("Weight")
}
```

**Pros:**
- ✅ No new files to create
- ✅ Stubs already exist and work
- ✅ Fast implementation

**Cons:**
- ⚠️ Need to **remove or adjust** generic `stubProductEndpoint()` in base test
- ⚠️ EANs are hardcoded (2222222222222, 3333333333333)

---

**Option B: Create Test-Specific Stubs**

```kotlin
@Test
fun `should route to iForce when product has Li-ion battery`() {
    // Create custom stub for this test
    stubProductWithBattery(ean = "TEST-BATTERY-001", chemistry = "Li-ion")

    val response = createReturnOrder(ean = "TEST-BATTERY-001")

    assertThat(response.route).isEqualTo("iForce")
}

private fun stubProductWithBattery(ean: String, chemistry: String) {
    WireMock.stubFor(
        WireMock.get(WireMock.urlPathEqualTo("/v1/products/BQUK"))
            .withQueryParam("filter[ean]", WireMock.equalTo(ean))
            .atPriority(1)
            .willReturn(
                WireMock.aResponse()
                    .withStatus(200)
                    .withBody(buildProductResponseWithBattery(ean, chemistry))
            )
    )
}
```

**Pros:**
- ✅ Flexible - any EAN, any attribute
- ✅ Self-documenting (clear what product has)
- ✅ Follows existing pattern

**Cons:**
- ⚠️ More code to write
- ⚠️ Duplicates existing container stubs

---

### TASK-02: Carrier Booking Integration

**Use Container Stubs:**

```kotlin
@Test
fun `should successfully book DPD collection`() {
    // Seller stub exists in container!
    // Carrier booking stub exists in container!
    // No stub setup needed

    val response = updateRouteToDPD(orderId)

    assertThat(response.consignmentCode).isNotNull()
}
```

**Check:** Verify container mappings have correct URLs for your use case.

---

### TASK-03: Mirakl Integration

**Container has these Mirakl stubs:**
- Authentication (OAuth2)
- OR11 (Get orders)
- OR28 (Refunds)
- OR43 (Notifications)

**You can:**
1. Use existing stubs for happy paths
2. Override for error scenarios
3. Add new stubs for specific test cases

```kotlin
@Test
fun `should create refund in Mirakl`() {
    // Container has refund stub already!
    // Check container-setup/mappings/request_mappings.json

    val response = confirmReturn(orderId)

    // Verify Mirakl API was called
    WireMock.verify(WireMock.postRequestedFor(WireMock.urlPathEqualTo("/api/orders/refund")))
}
```

---

## Recommendations for Task Implementation

### 1. Understand What Exists First

**Before creating new stubs:**

```bash
# Check what container stubs exist
ls -la container-setup/__files/

# Read the mappings file
cat container-setup/mappings/request_mappings.json

# Test them - start containers and call WireMock admin
curl http://localhost:9090/__admin/mappings | jq
```

### 2. Decide: Reuse vs Create

**Reuse container stubs when:**
- ✅ Stub already exists for your scenario
- ✅ You're okay with predefined EANs/IDs
- ✅ You want fast implementation

**Create programmatic stubs when:**
- ✅ Need test-specific variations
- ✅ Want dynamic test data
- ✅ Testing error scenarios not in container

### 3. Fix the Base Test Generic Stub Issue

**Problem:** `BaseMockedReturnOrderTest.stubProductEndpoint()` overrides ALL product stubs.

**Solution:** Make it more specific or remove priority:

```kotlin
// Option A: Remove priority (let container stubs win)
protected fun stubProductEndpoint() {
    WireMock.stubFor(
        WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN))
            // .atPriority(1)  // REMOVE THIS
            .willReturn(...)
    )
}

// Option B: Make it a fallback for unknown EANs
protected fun stubProductEndpoint() {
    WireMock.stubFor(
        WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN))
            .atPriority(10)  // Lower priority than container (5)
            .willReturn(...)
    )
}

// Option C: Only stub specific EAN
protected fun stubProductEndpoint(ean: String = "9898989898097") {
    WireMock.stubFor(
        WireMock.get(WireMock.urlPathEqualTo("/v1/products/BQUK"))
            .withQueryParam("filter[ean]", WireMock.equalTo(ean))
            .willReturn(...)
    )
}
```

### 4. Update Task Documentation

**TASK-01 should mention:**
- Container stubs exist for battery (2222222222222), weight (3333333333333)
- Can use these directly OR create new ones
- Need to adjust base test stub priority

**TASK-02 should mention:**
- Carrier booking stub exists: `carrier-booking-response-successful.json`
- Seller stub exists: `seller-successful-response.json`
- Check mappings to understand URL patterns

**TASK-03 should mention:**
- Mirakl stubs exist for main operations
- Can be used as-is for happy paths
- Override for error scenarios

---

## Debugging WireMock Stubs

### Check what stubs are active

```bash
# All mappings
curl http://localhost:9090/__admin/mappings | jq

# Specific mapping by URL pattern
curl http://localhost:9090/__admin/mappings | jq '.mappings[] | select(.request.urlPattern | contains("products"))'
```

### See all requests WireMock received

```bash
# All requests
curl http://localhost:9090/__admin/requests | jq

# Unmatched requests (no stub found)
curl http://localhost:9090/__admin/requests/unmatched | jq
```

### Reset to container stubs

```bash
# Remove all programmatic stubs
curl -X DELETE http://localhost:9090/__admin/mappings

# Reload container stubs
curl -X POST http://localhost:9090/__admin/mappings/reset
```

---

## Summary

### What You Have

1. **Container Stubs** - Pre-configured, always available
   - Product API (battery, weight, price variations)
   - Carrier Booking API (success, error)
   - Seller API (found, not found)
   - Mirakl API (auth, orders, refunds, notifications)

2. **Programmatic Stubs** - Test-specific, dynamic
   - Created in `BaseMockedReturnOrderTest.stubProductEndpoint()`
   - Currently **overrides container stubs** (priority 1)
   - Can be adjusted to work alongside container stubs

### What Tasks Should Do

**TASK-01:** Use container product stubs (battery, weight) - fastest path

**TASK-02:** Use container carrier/seller stubs - already exist

**TASK-03:** Mix container Mirakl stubs + custom overrides for errors

**All Tasks:** Consider adjusting base test generic stub to avoid conflicts

---

## Files Reference

### Container Stubs
```
container-setup/
├── __files/
│   ├── __product/          # 7 product variations
│   ├── __carrier-booking/  # 2 responses
│   ├── __sellers-api/      # 2 responses
│   └── __mirakl/           # 9+ responses
└── mappings/
    └── request_mappings.json  # URL patterns → response files
```

### Test Stubs
```
functional-tests/src/test/resources/data/response/
├── product_response.json   # Generic product (used by base test)
└── actuator-response.json  # Health check
```

### Test Code
```
functional-tests/src/test/kotlin/com/kingfisher/api/
└── BaseMockedReturnOrderTest.kt  # stubProductEndpoint() - generic stub
```

---

**Key Takeaway:** You have extensive container stubs already! Tasks can use them directly instead of creating everything from scratch. This will speed up implementation significantly.
