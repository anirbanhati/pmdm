# TASK-03: Mirakl API Integration Testing

**Complexity:** ⭐⭐⭐ Complex
**Estimated Effort:** 2.5-3 days
**Can Run in Parallel:** ✅ Yes (independent of other tasks)
**Priority:** CRITICAL

---

## Important: Existing Container Stubs

🎉 **Good news!** The project already has extensive Mirakl API stubs pre-configured in `/container-setup/__files/__mirakl/`.

**Available Mirakl Stubs:**
- `Authentication_Successful.json` - OAuth2 token
- `OR11_Successful.json` - Get orders
- `OR28_Successful.json` - Refund success
- `OR28_Error.json` - Refund error
- `OR43_Successful.json` - Seller notification success
- `OR43_Error.json` - Notification error
- `OF22_*.json` - Offer endpoints

**These stubs are automatically loaded** when containers start - no test setup code needed for main scenarios!

**Implementation Approach:** Use existing container stubs for happy paths, create programmatic overrides for test-specific error scenarios. This saves ~1 day of work.

**See:** `/WIREMOCK-SETUP-EXPLAINED.md` for detailed explanation of how container stubs work.

---

## Why This is Needed

### Business Problem

Mirakl is the marketplace platform managing seller orders and refunds. The returns service integrates with Mirakl to:
1. **Create refunds** when items are returned via iForce route
2. **Create cancellations** when pick collection expires (different from refunds)
3. **Notify sellers** about return status updates
4. **Fetch order details** to validate returns

**Current Gap:** Zero functional test coverage for Mirakl integration. The integration tests mock `MiraklAPIService`, which means actual API calls, JSON payload structure, error handling, and currency fallback logic are **never verified end-to-end**.

**Business Impact:**
- Refund failures leave customers waiting for money
- Seller notifications failing means sellers don't know about returns
- Incorrect cancellation reasons cause disputes
- Currency conversion bugs affect international orders
- Failed refunds require manual intervention (costly)

**Financial Impact:**
- Each failed refund requires customer service escalation (~£15 cost)
- Delayed refunds increase chargeback risk
- Seller disputes cost time and damage relationships

### What You'll Learn

- Complex multi-API integration testing
- WireMock advanced scenarios (conditional responses, request verification)
- Testing financial operations (refunds, currency handling)
- Error resilience patterns (retry, fallback logic)
- Business process testing (refund vs cancellation workflows)
- How marketplace refund operations work

---

## What Needs to Be Done

### Objectives

1. **Create comprehensive functional tests** for all Mirakl API integrations
2. **Implement 8 core test scenarios** covering refunds, cancellations, notifications
3. **Use existing WireMock container stubs** for main Mirakl endpoints
4. **Create programmatic stub overrides** for test-specific variations and error scenarios
5. **Verify complex business logic**: currency fallback, order line ID parsing, template parameters
6. **Test error handling**: API failures, metrics updates, graceful degradation
7. **Document Mirakl integration patterns** for future test development

**Key Change from Original Plan:** Reuse existing container stubs for OR11, OR28, OR43 endpoints - only create overrides for specific test variations!

### Scope

**New Files to Create:**
- `/functional-tests/src/test/kotlin/com/kingfisher/api/MiraklIntegrationTest.kt` (main test class)
- `/functional-tests/docs/MIRAKL-INTEGRATION.md` (comprehensive documentation)

**Existing Files to Reference:**
- `/container-setup/__files/__mirakl/` (existing Mirakl stubs)
- `/container-setup/mappings/request_mappings.json` (URL patterns)
- `/WIREMOCK-SETUP-EXPLAINED.md` (how container stubs work)

**Optional Files (only if container stubs insufficient):**
- `/functional-tests/src/test/resources/data/response/mirakl_order_response.json` (programmatic override)
- `/functional-tests/src/test/resources/data/request/expected_refund_request.json` (verification template)
- `/functional-tests/src/test/resources/data/request/expected_notification_request.json` (verification template)

**Business Logic Under Test:**
Located in `/src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt`

**Complex Scenarios:**
- **Currency fallback logic** - If invalid currency in refund, use order's original currency
- **Order line ID parsing** - Extract from `logisticalOrderId` (format: `ORDER-123-LINE-456`)
- **Cancellation vs Refund** - Different API calls, different reason prefixes
- **Template parameters** - Seller notifications use product details as variables
- **Metrics on failure** - Counter `REFUND_FAILED_FOR_I_FORCE` incremented
- **Graceful failure** - Notification failures logged but don't block process

---

## High-Level Technical Approach

### Step 1: Understand Mirakl Integration Architecture

**Study these files (critical):**
1. `/src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt` - Core integration
2. `/src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt` - When Mirakl is called
3. Look for usage of: `createRefund()`, `createCancellation()`, `notifySeller()`

**Integration Points:**

```
Return Flow → Mirakl API Calls
├── iForce route → createRefund() → POST /api/refunds
├── Pick expiry → createCancellation() → POST /api/cancellations
├── Status update → notifySeller() → POST /api/orders/{id}/threads
└── Order validation → fetchOrder() → GET /api/orders?order_ids={id}
```

**Key Business Rules to Test:**
1. **Refund creation:**
   - Amount = item price + tax
   - Currency = order currency (with fallback if invalid)
   - Order line ID parsed from logisticalOrderId

2. **Cancellation creation:**
   - Reason must start with "CANCEL:" prefix
   - Only for collection expiry scenarios
   - Different endpoint than refunds

3. **Seller notification:**
   - Template ID depends on event type
   - Parameters include: product name, EAN, quantity, reason
   - Failure should not block main process

### Step 2: Review Existing Container Stubs

**Before creating new stubs, check what exists:**

```bash
# List existing Mirakl stubs
ls -la container-setup/__files/__mirakl/

# View mappings
cat container-setup/mappings/request_mappings.json | grep mirakl
```

**Available Container Stubs:**
- `OR11_Successful.json` - GET /api/orders (fetch order details)
- `OR28_Successful.json` - POST /api/refunds (create refund)
- `OR28_Error.json` - POST /api/refunds (refund error)
- `OR43_Successful.json` - POST /api/orders/{id}/threads (seller notification)
- `OR43_Error.json` - POST /api/orders/{id}/threads (notification error)
- `Authentication_Successful.json` - OAuth2 token

**These stubs work automatically** - no setup code needed for happy paths!

**When to Create Programmatic Overrides:**
- Test-specific variations (different amounts, currencies)
- Complex error scenarios not covered by container stubs
- Request body verification (need to capture specific payloads)

### Step 3: Set Up WireMock Stubs for 4 Mirakl Endpoints

**Endpoint 1: GET /api/orders (Container Stub Exists)**

**Location:** `/container-setup/__files/__mirakl/OR11_Successful.json`

```json
// Already exists in container!
{
  "orders": [{
    "id": "ORDER-123-A",
    "currency_iso_code": "GBP",
    "customer": {
      "firstname": "John",
      "lastname": "Smith"
    },
    "order_lines": [{
      "id": "LINE-001",
      "order_line_id": "ORDER-123-A-LINE-001",
      "product_title": "Test Product",
      "product_sku": "SKU-12345",
      "quantity": 2,
      "price": 50.00,
      "currency_iso_code": "GBP"
    }]
  }]
}
```

**Endpoint 2: POST /api/refunds (Container Stub Exists)**

**Location:** `/container-setup/__files/__mirakl/OR28_Successful.json`

**For happy path, container stub works automatically. Override only if needed:**
```kotlin
// Only create programmatic stub if you need test-specific variations
wireMockServer.stubFor(
    post(urlPathEqualTo("/api/refunds"))
        .withRequestBody(matchingJsonPath("$.order_id", equalTo("ORDER-123-A")))
        .atPriority(1)  // Override container stub
        .willReturn(
            aResponse()
                .withStatus(201)
                .withHeader("Content-Type", "application/json")
                .withBody("""{"refund_id": "REFUND-456"}""")
        )
)
```

**Endpoint 3: POST /api/cancellations (May Need to Create)**

**Note:** Check if container stub exists. If not, create programmatic stub:
```kotlin
wireMockServer.stubFor(
    post(urlPathEqualTo("/api/cancellations"))
        .withRequestBody(matchingJsonPath("$.reason", matching("^CANCEL:.*")))
        .willReturn(aResponse().withStatus(201))
)
```

**Endpoint 4: POST /api/orders/{orderId}/threads (Container Stub Exists)**

**Location:** `/container-setup/__files/__mirakl/OR43_Successful.json`

**For happy path, container stub works automatically. Override only if needed:**
```kotlin
// Only create programmatic stub if you need test-specific variations
wireMockServer.stubFor(
    post(urlPathMatching("/api/orders/.*/threads"))
        .withRequestBody(matchingJsonPath("$.message.body", containing("Test Product")))
        .atPriority(1)  // Override container stub
        .willReturn(aResponse().withStatus(201))
)
```

### Step 3: Implement 8 Core Test Scenarios

**Test Suite Structure:**

| # | Scenario | API Tested | Complexity | Verification |
|---|----------|------------|------------|--------------|
| 1 | Create refund on iForce route | POST /refunds | ⭐⭐ | Refund ID returned, payload correct |
| 2 | Create cancellation on expiry | POST /cancellations | ⭐⭐ | Reason has CANCEL: prefix |
| 3 | Seller notification sent | POST /threads | ⭐⭐⭐ | Template params populated |
| 4 | Currency fallback logic | POST /refunds | ⭐⭐⭐ | Invalid EUR → GBP from order |
| 5 | Refund failure metrics | POST /refunds (500) | ⭐⭐⭐ | Counter incremented |
| 6 | Notification failure logged | POST /threads (500) | ⭐⭐ | Process continues |
| 7 | Order line ID parsing | POST /refunds | ⭐⭐⭐ | Extracted from logisticalOrderId |
| 8 | Template parameter replacement | POST /threads | ⭐⭐⭐ | Product name, EAN, qty in message |

### Step 4: Example Test Implementation

**Scenario 1: Create Refund on iForce Route**

```kotlin
@Test
fun `should create refund in Mirakl when route is iForce`() {
    // GIVEN: Return order routed to iForce
    val orderId = "ORDER-123-A"
    val lineId = "LINE-001"
    val logisticalOrderId = "$orderId-$lineId"

    setupMiraklOrderStub(orderId)
    setupMiraklRefundStub(expectSuccess = true)

    val returnOrder = createReturnOrder(
        orderId = orderId,
        route = "iForce",
        status = "AWAITING_STORE_CONFIRMATION"
    )

    // WHEN: Confirm return (triggers refund)
    confirmReturn(returnOrder.id)

    // THEN: Verify Mirakl refund API was called
    wireMockServer.verify(
        postRequestedFor(urlPathEqualTo("/api/refunds"))
            .withRequestBody(matchingJsonPath("$.order_id", equalTo(orderId)))
            .withRequestBody(matchingJsonPath("$.order_line_id", equalTo(lineId)))
            .withRequestBody(matchingJsonPath("$.amount", equalTo("50.00")))
            .withRequestBody(matchingJsonPath("$.currency", equalTo("GBP")))
            .withRequestBody(matchingJsonPath("$.reason_code", notNullValue()))
    )

    // AND: Return order updated with refund ID
    val updatedOrder = fetchReturnOrder(returnOrder.id)
    assertThat(updatedOrder.refundId).isEqualTo("REFUND-456")
    assertThat(updatedOrder.status).isEqualTo("REFUND_CREATED")
}
```

**Scenario 4: Currency Fallback Logic (Complex)**

```kotlin
@Test
fun `should fallback to order currency when refund currency is invalid`() {
    // GIVEN: Refund request with invalid currency EUR
    // BUT: Original order has GBP currency

    val orderId = "ORDER-123-A"
    setupMiraklOrderStub(orderId, currencyCode = "GBP")

    val returnOrder = createReturnOrder(
        orderId = orderId,
        route = "iForce"
    )

    // Create refund with EUR (invalid for this order)
    val refundRequest = RefundRequest(
        amount = 50.0,
        currency = "EUR"  // Invalid - order is in GBP
    )

    // WHEN: Process refund
    miraklAPIService.createRefund(orderId, refundRequest)

    // THEN: Verify API called with GBP (fallback from order)
    wireMockServer.verify(
        postRequestedFor(urlPathEqualTo("/api/refunds"))
            .withRequestBody(matchingJsonPath("$.currency", equalTo("GBP"))) // Fallback!
            .withRequestBody(matchingJsonPath("$.amount", equalTo("50.00")))
    )

    // AND: Log warning about currency fallback
    // (Check application logs for warning message)
}
```

**Scenario 5: Refund Failure Metrics (Error Handling)**

```kotlin
@Test
fun `should increment failure metric when Mirakl refund fails`() {
    // GIVEN: Mirakl refund API will fail with 500
    wireMockServer.stubFor(
        post(urlPathEqualTo("/api/refunds"))
            .willReturn(aResponse().withStatus(500).withBody("Internal Server Error"))
    )

    val orderId = "ORDER-123-A"
    val returnOrder = createReturnOrder(orderId = orderId, route = "iForce")

    // WHEN: Attempt to create refund
    val result = try {
        confirmReturn(returnOrder.id)
        false
    } catch (e: Exception) {
        true // Exception expected
    }

    // THEN: Verify failure was handled
    assertThat(result).isTrue()

    // AND: Verify Mirakl API was attempted
    wireMockServer.verify(postRequestedFor(urlPathEqualTo("/api/refunds")))

    // AND: Verify metrics updated (if metrics exposed via actuator)
    // Check /actuator/metrics/mirakl.refund.failed counter
    val metrics = given()
        .`when`().get("/actuator/metrics/mirakl.refund.failed")
        .then().extract().path<Double>("measurements[0].value")

    assertThat(metrics).isGreaterThan(0.0)
}
```

**Scenario 8: Template Parameter Replacement (Seller Notification)**

```kotlin
@Test
fun `should populate seller notification template with product details`() {
    // GIVEN: Return order with product details
    val orderId = "ORDER-123-A"
    val productName = "Wireless Drill 18V"
    val ean = "1234567890123"
    val quantity = 2

    setupMiraklOrderStub(orderId, productName = productName, ean = ean)

    wireMockServer.stubFor(
        post(urlPathMatching("/api/orders/.*/threads"))
            .willReturn(aResponse().withStatus(201))
    )

    val returnOrder = createReturnOrder(
        orderId = orderId,
        ean = ean,
        quantity = quantity
    )

    // WHEN: Notify seller about return
    notifySeller(returnOrder.id, "Return received")

    // THEN: Verify notification message includes product details
    wireMockServer.verify(
        postRequestedFor(urlPathMatching("/api/orders/.*/threads"))
            .withRequestBody(matchingJsonPath("$.message.subject", containing("Return")))
            .withRequestBody(matchingJsonPath("$.message.body", containing(productName)))
            .withRequestBody(matchingJsonPath("$.message.body", containing(ean)))
            .withRequestBody(matchingJsonPath("$.message.body", containing(quantity.toString())))
    )
}
```

### Step 5: Complex Verification Patterns

**Request Body Verification:**
```kotlin
// Verify complex nested JSON structure
wireMockServer.verify(
    postRequestedFor(urlPathEqualTo("/api/refunds"))
        .withRequestBody(matchingJsonPath("$.refunds[0].refund_lines[0].refund_line_id"))
        .withRequestBody(matchingJsonPath("$.refunds[0].amount", equalToJson("50.00")))
)
```

**Verify API NOT Called (Important for error paths):**
```kotlin
// When notification fails, should NOT retry
wireMockServer.verify(
    exactly(1), // Only one attempt
    postRequestedFor(urlPathMatching("/api/orders/.*/threads"))
)
```

**Conditional Stubbing (Different responses based on request):**
```kotlin
// Success for GBP, failure for EUR
wireMockServer.stubFor(
    post(urlPathEqualTo("/api/refunds"))
        .withRequestBody(matchingJsonPath("$.currency", equalTo("GBP")))
        .willReturn(aResponse().withStatus(201))
)

wireMockServer.stubFor(
    post(urlPathEqualTo("/api/refunds"))
        .withRequestBody(matchingJsonPath("$.currency", equalTo("EUR")))
        .willReturn(aResponse().withStatus(400).withBody("Invalid currency"))
)
```

---

## Success Metrics

### Test Coverage Metrics

- ✅ **8 test scenarios** implemented covering refunds, cancellations, notifications
- ✅ **Mirakl integration coverage**: 0% → 100% (all API endpoints)
- ✅ **All tests pass** in isolation and suite
- ✅ **Request verification**: Payload structure validated for all API calls
- ✅ **Error scenarios**: API failures handled gracefully

### Quality Metrics

- ✅ **Business logic verified**: Currency fallback, order line ID parsing, template substitution
- ✅ **Metrics integration**: Failure counters tested
- ✅ **WireMock mastery**: Complex request matching, conditional responses
- ✅ **Production-ready**: Tests catch real integration bugs
- ✅ **Code review**: Senior developer approves approach

### Documentation Metrics

- ✅ **MIRAKL-INTEGRATION.md**: Complete API contract documentation
- ✅ **Test scenarios documented**: Each test explains business context
- ✅ **WireMock patterns**: Reusable stub examples for future tests

---

## Acceptance Criteria

**Before Considering Task Complete:**

- [ ] All 8 test scenarios implemented and passing
- [ ] WireMock stubs for 4 Mirakl endpoints (GET orders, POST refunds, POST cancellations, POST threads)
- [ ] Request body verification for all API calls (structure, values, JSON paths)
- [ ] Currency fallback logic tested and documented
- [ ] Order line ID parsing verified (logisticalOrderId → order_line_id)
- [ ] Error handling tested (API 500, timeout scenarios)
- [ ] Metrics verification (REFUND_FAILED_FOR_I_FORCE counter)
- [ ] Seller notification template parameters tested
- [ ] MIRAKL-INTEGRATION.md comprehensive documentation created
- [ ] Tests pass in CI/CD pipeline
- [ ] No flaky tests (run 10 times, 100% pass rate)
- [ ] Code review approved by senior developer/architect
- [ ] Performance acceptable (<1 minute for all 8 tests)

---

## Dependencies & Parallelization

**Can Start Immediately:** ✅ Yes
**Blocked By:** None
**Blocks:** None

**Parallel Execution:**
- Can work in parallel with TASK-01, TASK-02, TASK-04
- Completely independent test file
- Uses same WireMock instance but different endpoints

**Required Services:**
- Docker containers running
- WireMock on port 9090 (shared with other tests)
- DynamoDB on port 8000
- Application metrics endpoint (/actuator/metrics) enabled

**Integration Complexity:**
- Multiple API endpoints to mock
- Complex JSON payload structures
- Request/response correlation
- Error scenarios with different status codes

---

## Getting Started Guide

### 1. Deep Dive into Business Logic (2-3 hours)

**Critical files to understand:**

```bash
# Core Mirakl integration
src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt

# When Mirakl is called
src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt

# Search for method calls
grep -r "createRefund\|createCancellation\|notifySeller" src/main/kotlin/

# Review existing container stubs
ls -la container-setup/__files/__mirakl/
cat container-setup/mappings/request_mappings.json | grep mirakl
```

**Key questions to answer:**
- When is `createRefund()` called vs `createCancellation()`?
- What data is required for each API call?
- How are template parameters populated for notifications?
- What happens when Mirakl API fails?
- Where is currency fallback logic implemented?

### 2. Analyze Mirakl API Contracts (2 hours)

**If available, review:**
- Mirakl API documentation
- Existing API call logs from production
- Example request/response payloads

**Document:**
- Required fields for each endpoint
- Optional vs mandatory parameters
- Error response formats
- Authentication headers

### 3. Set Up Test Infrastructure (1-2 hours)

```bash
# Create test file
mkdir -p functional-tests/src/test/kotlin/com/kingfisher/api
touch functional-tests/src/test/kotlin/com/kingfisher/api/MiraklIntegrationTest.kt

# Review existing container stubs (may not need to create new ones!)
ls -la container-setup/__files/__mirakl/

# Start containers
docker compose -f docker-compose-ci.yml up -d

# Verify Mirakl stubs are loaded
curl http://localhost:9090/__admin/mappings | grep mirakl
```

### 4. Implement Happy Path Tests First (1 day)

**Order of implementation:**
1. Scenario 1: Create refund (simplest integration)
2. Scenario 2: Create cancellation (similar to refund)
3. Scenario 3: Seller notification (new endpoint)

**Verify each works before moving to next**

### 5. Implement Complex Scenarios (1 day)

**Order of implementation:**
4. Scenario 7: Order line ID parsing (requires understanding format)
5. Scenario 4: Currency fallback (conditional logic)
6. Scenario 8: Template parameters (complex verification)

### 6. Implement Error Scenarios (1 day)

**Order of implementation:**
7. Scenario 5: Refund failure metrics (error handling)
8. Scenario 6: Notification failure logged (graceful degradation)

### 7. Documentation and Polish (0.5 day)

- Create comprehensive MIRAKL-INTEGRATION.md
- Add detailed comments to complex tests
- Refactor common WireMock setup into helper methods
- Create pull request with thorough description

---

## Resources

### Code References

- **Mirakl service**: `/src/main/kotlin/com/kingfisher/marketplace/service/MiraklAPIService.kt`
- **Business service**: `/src/main/kotlin/com/kingfisher/marketplace/service/ReturnBusinessService.kt`
- **Test utilities**: `/functional-tests/src/test/kotlin/com/kingfisher/utils/`

### Documentation

- **Coverage plan**: `/functional-tests-coverage-plan.md` (Section 1.2)
- **Functional test docs**: `/functional-tests-docs.md`

### WireMock Advanced Patterns

- [Request Matching](http://wiremock.org/docs/request-matching/)
- [JSON Path Matching](http://wiremock.org/docs/request-matching/#json-path)
- [Verifying](http://wiremock.org/docs/verifying/)
- [Stubbing](http://wiremock.org/docs/stubbing/)

---

## Tips for Success

### For Senior QAs

1. **Map the business flow first** - Understand when each API is called before writing tests
2. **Start with API contracts** - Know exactly what request/response looks like
3. **Use WireMock request journal** - Debug with http://localhost:9090/__admin/requests
4. **Test error paths thoroughly** - These expose the most bugs in production
5. **Think about edge cases** - What if currency is null? Empty string? Invalid format?

### Advanced Testing Techniques

**Scenario-based stubbing:**
```kotlin
// Different responses for different request content
wireMockServer.stubFor(
    post(urlPathEqualTo("/api/refunds"))
        .inScenario("RefundRetry")
        .whenScenarioStateIs(STARTED)
        .willReturn(aResponse().withStatus(500))
        .willSetStateTo("RetryAttempted")
)

wireMockServer.stubFor(
    post(urlPathEqualTo("/api/refunds"))
        .inScenario("RefundRetry")
        .whenScenarioStateIs("RetryAttempted")
        .willReturn(aResponse().withStatus(201))
)
```

**Request correlation:**
```kotlin
// Capture request details for verification
val requests = wireMockServer.findAll(postRequestedFor(urlPathEqualTo("/api/refunds")))
assertThat(requests).hasSize(1)
val refundRequest = requests[0].bodyAsString
assertThat(refundRequest).contains("ORDER-123")
```

### Common Pitfalls to Avoid

❌ **Not verifying request payloads** - Always use `.withRequestBody()` verification
❌ **Ignoring error scenarios** - These catch the most production bugs
❌ **Hardcoding API responses** - Use realistic data from actual API docs
❌ **Not testing currency fallback** - This has caused production issues before
❌ **Forgetting to verify metrics** - Failure counters are critical for alerting

### Debugging Complex Issues

**Request not matching stub:**
```bash
# Check WireMock unmatched requests
curl http://localhost:9090/__admin/requests/unmatched | jq

# Compare expected vs actual request body
# Use JSONPath tester: https://jsonpath.com/
```

**Verification failing:**
```bash
# See all requests received
curl http://localhost:9090/__admin/requests | jq

# Check specific endpoint
curl "http://localhost:9090/__admin/requests?url=/api/refunds" | jq
```

---

## Expected Deliverables

1. **Code (Primary):**
   - `MiraklIntegrationTest.kt` (~400-500 lines)
   - Helper methods for Mirakl stub setup (~100 lines)
   - Test data JSON files (4-5 files)

2. **Documentation (Critical):**
   - `MIRAKL-INTEGRATION.md` with:
     - API endpoint contracts (request/response schemas)
     - Business flow diagrams (when each API is called)
     - Error handling patterns
     - Currency fallback logic explanation
     - Template parameter examples

3. **Pull Request:**
   - Title: "TASK-03: Add comprehensive Mirakl API integration tests"
   - Description with:
     - Coverage summary (8 scenarios, 4 endpoints)
     - Complex scenarios explained (currency fallback, order line parsing)
     - Screenshots of passing tests
     - WireMock stub examples

---

## Definition of Done

- ✅ All 8 scenarios passing reliably
- ✅ Complex business logic verified (currency, parsing, templates)
- ✅ Error handling comprehensive
- ✅ Request/response validation thorough
- ✅ Documentation complete and peer-reviewed
- ✅ Pull request approved
- ✅ Tests pass in CI/CD
- ✅ Knowledge sharing session delivered to team

---

## Questions or Blockers?

**Expected Challenges:**
- "How do I know what the Mirakl API request looks like?" → Check MiraklAPIService.kt, look for REST client calls
- "Test fails but WireMock shows no requests" → Application might not be calling Mirakl; check logs
- "Currency fallback not working" → Debug the actual service code to understand the logic flow

**Get Help:**
- Pair with backend developer to understand Mirakl integration
- Review Mirakl SDK documentation if using Mirakl Java client
- Check production logs for example API calls

---

**Estimated Timeline:**
- Day 1: Deep code study, review container stubs, understand all business flows, set up infrastructure
- Day 2: Implement happy path tests using container stubs (scenarios 1-3)
- Day 3: Implement complex scenarios with programmatic overrides (4, 7, 8), error scenarios (5-6)
- Day 4: Documentation, review, refinement (reduced from original estimate)

**Time Saved:** Using existing container stubs saves ~1 day compared to creating all stubs from scratch!

**This is a complex task - perfect for senior QAs to demonstrate advanced testing skills. The patterns learned here will be valuable for all future API integration testing!**
