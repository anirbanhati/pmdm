plugins {
    kotlin("jvm")
    id("com.github.davidmc24.gradle.plugin.avro") version "1.9.1"
}


group = "com.kingfisher.marketplace"
version = "0.0.1-SNAPSHOT"

repositories {
    mavenCentral()
    maven {
        url = uri("https://packages.confluent.io/maven/")
    }
}

// replace non compatible transient swagger-annotations dep from kafka-avro-serializer:8.2.0
configurations.all {
    resolutionStrategy.dependencySubstitution {
        substitute(module("io.swagger.core.v3:swagger-annotations"))
            .using(module("io.swagger.core.v3:swagger-annotations-jakarta:2.2.47"))
    }
}

dependencies {
    testImplementation("io.rest-assured:rest-assured:4.5.0")
    testImplementation("org.assertj:assertj-core:3.27.7")
    testImplementation("org.hamcrest:hamcrest:2.2")
    testImplementation("io.cucumber:cucumber-java:7.2.3")
    testImplementation("net.javacrumbs.json-unit:json-unit-assertj:3.2.2")
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.11.1")
    testImplementation("org.junit-pioneer:junit-pioneer:2.3.0")
    // Override wiremock transitive Dep - jetty and jackson
    testImplementation("org.wiremock:wiremock-jetty12:3.13.2")
    testImplementation(platform("org.eclipse.jetty:jetty-bom:12.0.36"))
    // Jackson security alignment
    testImplementation("com.fasterxml.jackson.core:jackson-core:2.21.5")
    testImplementation("org.junit.jupiter:junit-jupiter-engine:5.11.1")
    testImplementation("org.springframework.boot:spring-boot-starter-test:3.5.16")
    testImplementation("commons-io:commons-io:2.17.0")
    // Dependency security alignment
    testImplementation("org.apache.logging.log4j:log4j-api:2.25.5")
    testImplementation("at.yawk.lz4:lz4-java:1.11.1")
    testImplementation("com.github.jknack:handlebars:4.5.2")
    testImplementation("org.apache.httpcomponents.client5:httpclient5:5.6.3")
    // Kafka event testing dependencies
    testImplementation("org.apache.kafka:kafka-clients:4.2.0")
    testImplementation("io.confluent:kafka-avro-serializer:8.2.0")
    testImplementation("org.awaitility:awaitility:4.2.0")

    kotlin {
        jvmToolchain(17)
    }


    val test by testing.suites.existing(JvmTestSuite::class)
    tasks.register<Test>("runFunctionalIntegrationTests") {
        testClassesDirs = files(test.map { it.sources.output.classesDirs })
        classpath = files(test.map { it.sources.runtimeClasspath })
        useJUnitPlatform {
            val categories = System.getProperty("test.categories", "integration")
            includeTags(*categories.split(",").toTypedArray())
            
            // Exclude mock-dependent tests in deployed environments
            if (System.getProperty("envName", "local") != "local") {
                excludeTags("requires-mocks")
            }
        }
        
        // Pass system properties to test JVM
        systemProperty("envName", System.getProperty("envName", "local"))

        testLogging {
            events("passed", "skipped", "failed")
            showStandardStreams = project.hasProperty("showstreams")
            showExceptions = true
            showCauses = true
            showStackTraces = project.hasProperty("stacktrace")    // Set to true only for debugging
        }
        reports {
            html.required.set(true)
            html.outputLocation = file("build/reports/integrationTests")
            junitXml
            junitXml.required.set(true)
        }
    }

}



