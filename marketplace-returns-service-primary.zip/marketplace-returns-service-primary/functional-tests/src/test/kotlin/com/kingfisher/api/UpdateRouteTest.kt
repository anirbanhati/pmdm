package com.kingfisher.api

import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import com.kingfisher.model.*
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.equalTo
import org.junit.jupiter.api.*

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class UpdateRouteTest : BaseMockedReturnOrderTest() {

    companion object {
        private const val LINE_NUMBER = 1L
        private const val DPD_TRACKING_NUMBER = "DPD123456"
        private val tenant = Tenant.BQUK
    }

    private val updateRoutePath = ConfigurationManager.getProperty("updateRoutePath")

    @Test
    @Tag("integration")
    fun `should successfully update route for return order`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        val request = UpdateRouteRequest(
            data = UpdateRouteData(
                type = "updateRoute",
                attributes = UpdateRouteAttributes(
                    userId = "USER123",
                    lines = listOf(
                        ReturnLine(
                            lineNumber = LINE_NUMBER,
                            ean = "1234567890123",
                            route = "DPD",
                            quantity = 1,
                            reason = "Change of mind",
                            parcelTrackingInfo = listOf(
                                ParcelTrackingInfo(
                                    quantity = 1,
                                    externalParcelIdentifier = "EXT-123",
                                    trackingNumber = DPD_TRACKING_NUMBER
                                )
                            )
                        )
                    )
                )
            )
        )

        val response = When()
            .body(request)
            .put("$updateRoutePath/{tenant}/{returnOrderNumber}", tenant.name, orderId)

        assertThat(response.statusCode, equalTo(HttpStatus.SC_OK))
    }

    @Test
    @Tag("integration")
    fun `should throw bad request when required fields are missing`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        val request = UpdateRouteRequest(
            data = UpdateRouteData(
                type = "updateRoute",
                attributes = UpdateRouteAttributes(
                    userId = "USER123",
                    lines = listOf(
                        ReturnLine(
                            lineNumber = LINE_NUMBER,
                            ean = "",
                            route = "DPD",
                            quantity = 1,
                            reason = "",
                            parcelTrackingInfo = emptyList()
                        )
                    )
                )
            )
        )

        val response = When()
            .body(request)
            .put("$updateRoutePath/{tenant}/{returnOrderNumber}", tenant.name, orderId)

        assertThat(response.statusCode, equalTo(HttpStatus.SC_BAD_REQUEST))
    }

    @Test
    @Tag("integration")
    fun `should throw bad request when invalid tenant provided`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        val request = UpdateRouteRequest(
            data = UpdateRouteData(
                type = "updateRoute",
                attributes = UpdateRouteAttributes(
                    userId = "USER123",
                    lines = listOf(
                        ReturnLine(
                            lineNumber = LINE_NUMBER,
                            ean = "1234567890123",
                            route = "DPD",
                            quantity = 1,
                            reason = "Change of mind",
                            parcelTrackingInfo = emptyList()
                        )
                    )
                )
            )
        )

        val response = When()
            .body(request)
            .put("$updateRoutePath/INVALID_TENANT/{returnOrderNumber}", orderId)

        assertThat(response.statusCode, equalTo(HttpStatus.SC_BAD_REQUEST))
    }
}
