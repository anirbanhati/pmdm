package com.kingfisher.kafka

import com.kingfisher.api.BaseMockedReturnOrderTest
import com.kingfisher.config.ConfigurationManager
import com.kingfisher.model.DeliveryNotificationItem
import com.kingfisher.utils.CAPLKafkaTestProducer

import com.kingfisher.core.Tenant
import com.github.tomakehurst.wiremock.client.WireMock
import com.github.tomakehurst.wiremock.client.WireMock.exactly
import com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor
import com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching
import com.github.tomakehurst.wiremock.stubbing.StubMapping
import com.kingfisher.model.DeliveryNotification
import org.awaitility.Awaitility.await
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.*
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance
import org.springframework.context.annotation.Description
import java.util.concurrent.TimeUnit

/**
 * Functional tests for Kafka Delivery Notification event processing for CAPL tenant.
 *
 * Processing Flow:
 * 1. CAPL return order created via PSO/JMS → DynamoDB ReturnLine with status CARRIER_BOOKING_FAILED
 * 2. DeliveryNotification Kafka event sent with matching orderNumber + lineRef
 * 3. Service updates ReturnLine → BOOKING_CONFIRMED or BOOKING_NOTIFICATION_FAILED
 * 4. Seller notified via Mirakl POST /api/orders/{logisticalOrderId}/threads
 *
 * WireMock mappings used:
 * - POST /api/orders/{id}-{letter}/threads → 201 (seller notification success)
 * - POST /stage/v2/cmsapi/1[0-8].* → Success:false (CARRIER_BOOKING_FAILED for our order IDs)
 */

@Tag("integration")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class KafkaDeliveryNotificationTest : BaseMockedReturnOrderTest() {

    private val fetchReturnOrderPath = ConfigurationManager.getProperty("fetchReturnOrderPath")

    companion object {
        private const val MIRAKL_THREADS_PATH = "^(/api/orders/)([0-9]+)-([A-Z])(/threads).*"
        private const val CMS_API_PATH = "^(/stage/v2/cmsapi/.*)"
        private const val DELIVERY_NOTIFICATION_TOPIC = "public.capl.in-store-fulfilment.test.pick"

    }

    @BeforeEach
    override fun baseSetup() {
        super.baseSetup()
        WireMock.stubFor(
            WireMock.post(urlPathMatching(MIRAKL_THREADS_PATH))
                .atPriority(5)
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""{"message": "Thread created"}""")
                )
        )
    }


    private fun createReturnOrder(): String {
        val orderDetails = generateUniqueOrderDetails()
        createReturnOrder(orderDetails, Tenant.CAPL)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                When()
                    .get(fetchReturnOrderPath, orderDetails.orderId)
                    .then()
                    .statusCode(200)
                    .body("data.attributes.lines.returnOrderNumber", hasItem(orderDetails.orderId.toLong()))
                    .body("data.attributes.lines.status", hasItem("CARRIER_BOOKING_FAILED"))
            }

        return orderDetails.orderId
    }


    @Test
    @Description("Verifies that a CAPL return line status is updated to BOOKING_CONFIRMED when a matching delivery notification is received")
    fun `should update return line to BOOKING_CONFIRMED when delivery notification received`() {
        val orderId = createReturnOrder()
        val notification = DeliveryNotification(orderNumber = orderId, items = listOf(DeliveryNotificationItem(lineRef = "1", partNumber = "1234567890123", quantity = 1)))

        CAPLKafkaTestProducer.sendMessage(DELIVERY_NOTIFICATION_TOPIC, orderId, notification)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                When()
                    .get(fetchReturnOrderPath, orderId)
                    .then()
                    .statusCode(200)
                    .body("data.attributes.lines.status", hasItem("BOOKING_CONFIRMED"))
            }

        WireMock.verify(exactly(1), postRequestedFor(urlPathMatching(MIRAKL_THREADS_PATH)))
        WireMock.verify(exactly(1), postRequestedFor(urlPathMatching(CMS_API_PATH)))
    }

    @Test
    @Description("Verifies that a CAPL return line status is updated to BOOKING_NOTIFICATION_FAILED when seller notification fails")
    fun `should set status to BOOKING_NOTIFICATION_FAILED when seller notification fails`() {
        var overrideStub: StubMapping? = null
        try {
            overrideStub = WireMock.stubFor(
                WireMock.post(urlPathMatching(MIRAKL_THREADS_PATH))
                    .atPriority(1)
                    .willReturn(
                        WireMock.aResponse()
                            .withStatus(502)
                            .withHeader("Content-Type", "application/json")
                            .withBody("""{"message": "Order not found"}""")
                    )
            )


            val orderId = createReturnOrder()

            val notification = DeliveryNotification(orderNumber = orderId)

            CAPLKafkaTestProducer.sendMessage(DELIVERY_NOTIFICATION_TOPIC, orderId, notification)

            await()
                .atMost(5, TimeUnit.SECONDS)
                .pollInterval(100, TimeUnit.MILLISECONDS)
                .untilAsserted {
                    When()
                        .get(fetchReturnOrderPath, orderId)
                        .then()
                        .statusCode(200)
                        .body("data.attributes.lines.status", hasItem("BOOKING_NOTIFICATION_FAILED"))
                }

            WireMock.verify(exactly(1), postRequestedFor(urlPathMatching(MIRAKL_THREADS_PATH)))
        } finally {
            overrideStub?.let { WireMock.removeStub(it) }
        }
    }

    @Test
    @Description("Verifies that the service handles non-existent orders gracefully")
    fun `should handle missing order gracefully when delivery notification received`() {
        val nonExistentOrderId = "0000000000"

        val beforeCount = getCarrierBookedCount()

        val notification = DeliveryNotification(orderNumber = nonExistentOrderId)

        CAPLKafkaTestProducer.sendMessage(DELIVERY_NOTIFICATION_TOPIC, nonExistentOrderId, notification)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                val afterCount =getCarrierBookedCount()
                assertThat(afterCount, equalTo(beforeCount + 1.0))
            }

        When()
            .get(fetchReturnOrderPath, nonExistentOrderId)
            .then()
            .statusCode(404)
        WireMock.verify(exactly(0), postRequestedFor(urlPathMatching(MIRAKL_THREADS_PATH)))
    }

    @Test
    @Description("Verifies that the service does not update any lines when notification line refs do not match stored lines")
    fun `should not update any lines when notification line refs do not match`() {
        val orderId = createReturnOrder()

        val notification = DeliveryNotification(orderNumber = orderId,items = listOf(DeliveryNotificationItem(lineRef = "999", partNumber = "1234567890123", quantity = 1)))

        CAPLKafkaTestProducer.sendMessage(DELIVERY_NOTIFICATION_TOPIC, orderId, notification)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                When()
                    .get(fetchReturnOrderPath, orderId)
                    .then()
                    .statusCode(200)
                    .body("data.attributes.lines.status", hasItem("CARRIER_BOOKING_FAILED"))
                    .body("data.attributes.lines.status", not(hasItem("BOOKING_CONFIRMED")))
                    .body("data.attributes.lines.status", not(hasItem("BOOKING_NOTIFICATION_FAILED")))
            }

        WireMock.verify(exactly(0), postRequestedFor(urlPathMatching(MIRAKL_THREADS_PATH)))
    }

    private fun getCarrierBookedCount():Double =
        When()
            .get("actuator/metrics/return.capl.carrier.booked")
            .then()
            .statusCode(200)
            .extract()
            .jsonPath()
            .getDouble("measurements[0].value")

}
