package com.kingfisher.api

import com.kingfisher.core.BaseReturnsServiceTest
import com.kingfisher.core.Tenant
import io.restassured.response.Response
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.equalTo
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class ExceptionHandlingTest : BaseReturnsServiceTest() {
    private val dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME
    private val validDateTo = LocalDateTime.now().format(dateFormatter)
    private val validDateFrom = LocalDateTime.now().minusDays(1).format(dateFormatter)
    private val tenant = Tenant.BQUK



    private fun getResponse(
        dateFrom: String,
        dateTo: String,
        storeId: String = tenant.storeId
    ): Response {
        return When()
            .get(
                "/v1/fetchReturnLines/{tenant}/{storeId}?dateFrom={dateFrom}&dateTo={dateTo}",
                tenant.name,
                storeId,
                dateFrom,
                dateTo,
            )
            .then()
            .extract()
            .response()
    }

    private fun assertBadRequest(response: Response) {
        assertThat(response.statusCode, equalTo(HttpStatus.SC_BAD_REQUEST))
    }

    @Test
    @Tag("integration")
    fun `test incorrect date format - missing time`() {
        assertBadRequest(getResponse("2024-08-29", validDateTo))
    }

    @Test
    @Tag("integration")
    fun `test incorrect date format - missing date`() {
        assertBadRequest(getResponse("08:31:06", validDateTo))
    }

    @Test
    @Tag("integration")
    fun `test empty date_from`() {
        assertBadRequest(getResponse( "", validDateTo))
    }

    @Test
    @Tag("integration")
    fun `test store_id not a number`() {
        assertBadRequest(getResponse(validDateFrom, validDateTo, storeId = "abcd"))
    }

    @Test
    @Tag("integration")
    fun `test dateFrom is bigger than dateTo`() {
        assertBadRequest(getResponse(validDateTo, validDateFrom))
    }

    @Test
    @Tag("integration")
    fun `test valid request`() {
        assertThat(
            getResponse(validDateFrom, validDateTo).statusCode,
            equalTo(HttpStatus.SC_OK)
        )
    }
}
