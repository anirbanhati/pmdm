package com.kingfisher.utils

import com.kingfisher.core.BaseReturnsServiceTest
import com.kingfisher.core.Tenant
import io.restassured.response.Response

class PSO : BaseReturnsServiceTest() {

    companion object {
        private const val BASE_PATH = "/v1"
        private const val IMPORT_ENDPOINT = "/import"
        private const val CONTENT_TYPE_HEADER = "Content-Type"
        private const val XML_CONTENT_TYPE = "application/xml"
    }

    fun createReturnOrder(orderDetails: ReturnOrderDetails, tenant: Tenant, storeId: String = tenant.storeId): Response {
        val psoXmlFile = when (tenant) {
            Tenant.BQUK -> "request/SingleLineReturnPSO.xml"
            Tenant.CAPL -> "request/SingleLineReturnPSO_PL.xml"
        }

        val psoBody = FileUtils.readDataFile(psoXmlFile)
            ?.replace("AMOUNT_PLACEHOLDER", orderDetails.amount)
            ?.replace("STORE_ID_PLACEHOLDER", storeId)
            ?.replace("ORDER_ID_PLACEHOLDER", orderDetails.orderId)
            ?.replace("ALTERNATE_ID_PLACEHOLDER", orderDetails.alternateId)
            ?.replace("ORIGINAL_ORDER_ID_PLACEHOLDER", orderDetails.originalOrderId)
            ?.replace("CUSTOMER_EMAIL_PLACEHOLDER", orderDetails.customerEmail)
            ?.replace("CUSTOMER_FIRST_NAME_PLACEHOLDER", orderDetails.customerFirstName)
            ?.replace("CUSTOMER_LAST_NAME_PLACEHOLDER", orderDetails.customerLastName)
            ?: throw IllegalStateException("Failed to read PSO template file")

        val response = When()
            .basePath(BASE_PATH)
            .header(CONTENT_TYPE_HEADER, XML_CONTENT_TYPE)
            .body(psoBody)
            .post(IMPORT_ENDPOINT)

        return response
    }


    data class ReturnOrderDetails(
        val amount: String,
        val orderId: String,
        val alternateId: String,
        val originalOrderId: String,
        val customerEmail: String,
        val customerFirstName: String,
        val customerLastName: String,
        val phoneNumber: String
    )

    fun getReturnOrderId(response: Response): String {
        return response.then().extract().path("returnOrderId")
    }
}
