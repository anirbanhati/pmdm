package com.kingfisher.api

import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import org.hamcrest.Matchers
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.TestInstance
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.MethodSource
import java.util.stream.Stream

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class WindsorFrameworkTest : BaseMockedReturnOrderTest() {
    private val fetchAllOrderPath = ConfigurationManager.getProperty("fetchAllOrderPath")

    private companion object {
        private const val HIGH_VALUE_AMOUNT = "20.3"
        private const val LOW_VALUE_AMOUNT = "-0.3"
        private val WINDSOR_STORE_IDS = listOf("1211", "1355", "1353", "1209", "1318")
        private val BQ_STORE_IDS = listOf("1017", "1052")
        private val tenant = Tenant.BQUK

        @JvmStatic
        fun getWindsorStoreIds(): Stream<String> = WINDSOR_STORE_IDS.stream()

        @JvmStatic
        fun getBQStoreIds(): Stream<String> = BQ_STORE_IDS.stream()
    }

    @ParameterizedTest
    @MethodSource("getWindsorStoreIds")
    @Tag("integration")
    fun `should check route and reasonForIForce when order meets conditions for TBC`(storeId: String) {
        val orderDetails = generateUniqueOrderDetails(amount = HIGH_VALUE_AMOUNT)
        val orderId = orderDetails.orderId

        createReturnOrder(orderDetails, tenant, storeId)
        verifyOrderCreatedWindsor(orderId)
    }

    @ParameterizedTest
    @MethodSource("getWindsorStoreIds")
    @Tag("integration")
    fun `should check route and reasonForIForce when order meets conditions for iForce`(storeId: String) {
        val orderDetails = generateUniqueOrderDetails(amount = LOW_VALUE_AMOUNT)
        val orderId = orderDetails.orderId

        createReturnOrder(orderDetails, tenant, storeId)
        verifyOrderCreatedWindsor(orderId)
    }

    @ParameterizedTest
    @MethodSource("getBQStoreIds")
    @Tag("integration")
    fun `should check the field values in the return order when order meets conditions for TBC`(storeId: String) {
        val orderDetails = generateUniqueOrderDetails(amount = HIGH_VALUE_AMOUNT)
        val orderId = orderDetails.orderId

        createReturnOrder(orderDetails, tenant, storeId)
        verifyOrderCreatedTBC(orderId)
    }

    @ParameterizedTest
    @MethodSource("getBQStoreIds")
    @Tag("integration")
    fun `should check the field values in the return order when order meets conditions for iForce`(storeId: String) {
        val orderDetails = generateUniqueOrderDetails(amount = LOW_VALUE_AMOUNT)
        val orderId = orderDetails.orderId

        createReturnOrder(orderDetails, tenant, storeId)
        verifyOrderCreatedIForce(orderId)
    }

    private fun verifyOrderCreatedWindsor(orderId: String) {
        When()
            .get(fetchAllOrderPath)
            .then()
            .statusCode(200)
            .body("returnOrderNumber", Matchers.hasItem(orderId.toLong()))
            .body("status", Matchers.hasItem("AWAITING_LABEL_PRINTING"))
            .body("route", Matchers.hasItem("iForce"))
            .body("reasonForIForce", Matchers.hasItem("Windsor Framework"))
    }

    private fun verifyOrderCreatedTBC(orderId: String) {
        When()
            .get(fetchAllOrderPath)
            .then()
            .statusCode(200)
            .body("returnOrderNumber", Matchers.hasItem(orderId.toLong()))
            .body("status", Matchers.hasItem("AWAITING_STORE_CONFIRMATION"))
            .body("route", Matchers.hasItem("TBC"))
            .body("reasonForIForce", Matchers.hasItem(""))
    }

    private fun verifyOrderCreatedIForce(orderId: String) {
        When()
            .get(fetchAllOrderPath)
            .then()
            .statusCode(200)
            .body("returnOrderNumber", Matchers.hasItem(orderId.toLong()))
            .body("status", Matchers.hasItem("AWAITING_LABEL_PRINTING"))
            .body("route", Matchers.hasItem("iForce"))
            .body("reasonForIForce", Matchers.hasItem("Product-amount"))
    }
}
