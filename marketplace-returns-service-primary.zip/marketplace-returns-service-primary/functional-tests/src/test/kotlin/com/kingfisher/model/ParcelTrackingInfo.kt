package com.kingfisher.model

data class ParcelTrackingInfo(
    val quantity: Int,
    val externalParcelIdentifier: String,
    val trackingNumber: String
)
