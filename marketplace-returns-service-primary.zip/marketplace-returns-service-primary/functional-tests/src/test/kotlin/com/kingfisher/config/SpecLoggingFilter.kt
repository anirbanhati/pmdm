package com.kingfisher.config

import io.restassured.filter.Filter
import io.restassured.filter.FilterContext
import io.restassured.filter.log.LogDetail
import io.restassured.filter.log.RequestLoggingFilter
import io.restassured.filter.log.ResponseLoggingFilter
import io.restassured.response.Response
import io.restassured.specification.FilterableRequestSpecification
import io.restassured.specification.FilterableResponseSpecification
import org.hamcrest.Matchers.greaterThanOrEqualTo
import java.io.PrintStream

class SpecLoggingFilter private constructor(
    private val delegated: Filter,
    private val stream: PrintStream,
    private val logType: String,
    private val endLine: Boolean,
    private val logLevel: LogLevel = LogLevel.INFO
) : Filter {
    enum class LogLevel {
        INFO, DEBUG, ERROR
    }
    private fun log(message: String) {
        when (logLevel) {
            LogLevel.DEBUG -> if (isDebugEnabled()) stream.println(message)
            LogLevel.INFO -> stream.println(message)
            LogLevel.ERROR -> System.err.println(message)
        }
    }
    private fun isDebugEnabled(): Boolean {
        return System.getProperty("debug.enabled")?.toBoolean() ?: false
    }

    private val startSeparator = buildString {
        append("\n--------------------------")
        append(" $logType for method: ")
    }
    private val endSeparator = "-----------------------------------------------"

    override fun filter(
        requestSpec: FilterableRequestSpecification,
        responseSpec: FilterableResponseSpecification,
        ctx: FilterContext,
    ): Response = try {
        val methodName = getTestMethodName()
        // Replace direct stream.println calls with log function
        log("$startSeparator$methodName -------------------")

        delegated.filter(requestSpec, responseSpec, ctx).also {
            if (endLine) log(endSeparator)
        }
    } catch (e: Exception) {
        log("Error during filtering: ${e.message}")
        throw e
    }


    private fun getTestMethodName(): String =
        Thread.currentThread().stackTrace.asSequence()
            .find { it.className.contains("Test") }
            ?.methodName ?: "unknown method"

    companion object {
        // Changed from const to regular val since LogDetail is not a primitive
        private val DEFAULT_LOG_DETAIL = LogDetail.ALL
        private const val PRINT_MULTILINE = true

        @JvmStatic
        fun requestLog(stream: PrintStream): Filter = createFilter(
            delegated = RequestLoggingFilter(DEFAULT_LOG_DETAIL, PRINT_MULTILINE, stream),
            stream = System.out,
            logType = "Request",
            endLine = true
        )

        @JvmStatic
        fun responseLog(
            stream: PrintStream,
            minStatus: Int
        ): Filter = createFilter(
            delegated = ResponseLoggingFilter(
                DEFAULT_LOG_DETAIL,
                PRINT_MULTILINE,
                stream,
                greaterThanOrEqualTo(minStatus)
            ),
            stream = System.out,
            logType = "Response",
            endLine = false

        )

        private fun createFilter(
            delegated: Filter,
            stream: PrintStream,
            logType: String,
            endLine: Boolean
        ): Filter = SpecLoggingFilter(delegated, stream, logType, endLine)
    }
}
