package com.kingfisher.core

enum class Tenant(val storeId: String) {
    BQUK(storeId = "1017"),
    CAPL(storeId = "1566")
}