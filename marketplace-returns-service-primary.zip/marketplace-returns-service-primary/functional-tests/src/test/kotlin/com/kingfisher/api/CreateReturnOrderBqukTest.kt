package com.kingfisher.api

import com.github.tomakehurst.wiremock.client.WireMock
import com.kingfisher.api.ConfirmReturnOrderTest.Companion
import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import org.apache.http.HttpStatus
import org.awaitility.Awaitility.await
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers
import org.hamcrest.Matchers.hasItem
import org.hamcrest.Matchers.not
import org.junit.jupiter.api.*
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.ValueSource
import org.springframework.context.annotation.Description
import java.util.concurrent.TimeUnit

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CreateReturnOrderBqukTest : BaseMockedReturnOrderTest() {
    private val fetchReturnOrderPath = ConfigurationManager.getProperty("fetchReturnOrderPath")
    private val tenant = Tenant.BQUK

    @Test
    @Tag("integration")
    fun `should create return order successfully`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId
        verifyOrderCreated(orderId)
    }

    @ParameterizedTest
    @ValueSource(strings = ["Obżęściąski", "田中さんにあげて下さい", "表ポあA鷗ŒéＢ逍Üßªąñ丂㐀\uD840\uDC00"])
    @Tag("integration")
    fun `should handle special characters in customer details`(lastName: String) {
        val specialCharsOrderDetails = generateUniqueOrderDetails(
            customerFirstName = "Michał",
            customerLastName = lastName
        )
        createReturnOrder(specialCharsOrderDetails, tenant)
        verifyOrderCreated(specialCharsOrderDetails.orderId)
    }

    @Test
    @Tag("integration")
    fun `should handle duplicate orders`() {
        val orderDetails = generateUniqueOrderDetails()

        // Given
        val response = createReturnOrder(orderDetails, tenant)
        assertThat(response.statusCode(), Matchers.equalTo(HttpStatus.SC_OK))
        verifyOrderCreated(orderDetails.orderId)

        // When
        val duplicateResponse = createReturnOrder(orderDetails, tenant)

        // Then
        assertThat(duplicateResponse.statusCode(), Matchers.equalTo(HttpStatus.SC_OK))
        verifyOrderCreated(orderDetails.orderId)
    }

    @Test
    @Tag("integration")
    @Description("Verifies that an invalid PSO message results in an error and no DynamoDB entry is created")
    fun `should not create entry when PSO message is invalid`() {
        val invalidOrderId = "0000000001"

        val response = When()
            .basePath("/v1")
            .header("Content-Type", "application/xml")
            .body("<invalid>xml</invalid>")
            .post("/import")

        assertThat(response.statusCode(), not(HttpStatus.SC_OK))

        val orderNumbers = When()
                    .get(fetchReturnOrderPath, invalidOrderId)
                    .then()
                    .extract()
                    .jsonPath()
                    .getList<Long>("data.attributes.lines.returnOrderNumber")

        assertThat(
            "No return line should exist for invalid PSO order $invalidOrderId",
                    orderNumbers, not(hasItem(invalidOrderId.toLong()))
                )

    }

    @Test
    @Tag("integration")
    @Description("Verifies that when Mirakl returns an error, the entry exists in DynamoDB but refundCreated is false")
    fun `should have refundCreated false when Mirakl returns error`() {
        val miraklErrorStub = WireMock.stubFor(
            WireMock.put(WireMock.urlMatching("^(/api/orders/refund).*"))
                .atPriority(1)
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(400)
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("__mirakl/OR28_Error.json")
                )
        )

        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId


        When()
            .get(fetchReturnOrderPath, orderId)
            .then()
            .statusCode(200)
            .body("data.attributes.lines.returnOrderNumber", hasItem(orderId.toLong()))
            .body("data.attributes.lines.refundCreated", hasItem(false))

        WireMock.removeStub(miraklErrorStub)
    }

    private fun verifyOrderCreated(orderId: String) {
        When()
            .get(fetchReturnOrderPath, orderId)
            .then()
            .statusCode(200)
            .body("data.attributes.lines.returnOrderNumber", hasItem(orderId.toLong()))
            .body("data.attributes.lines.status", hasItem("AWAITING_STORE_CONFIRMATION"))
    }
}
