package com.kingfisher.utils

import com.kingfisher.orderManagement.avro.*
import java.time.Instant

class PickEventBuilder {

    private var eventType: String = "public.orderManagement.pickDeliveryExpired"
    private var aggregateId: String = "123456789"
    private var logisticalOrderNumber: String? = "MP12345-1"
    private var shippingMethodType: ShippingMethodType = ShippingMethodType.ClickCollect
    private var state: State = State.None
    private var orderId: String = "1012408436"
    private var orderCreatedDateTime: String = Instant.now().toString()
    private var promisedDateTime: String = Instant.now().toString()
    private var createdBy: String = "test-system"
    private var createdOn: String = Instant.now().toString()
    private var traceId: String = "test-trace-${System.currentTimeMillis()}"
    private var ean: String = "2222222222222"  // Battery chemistry stub
    private var amount: Double = 10.0

    fun withEventType(eventType: String) = apply { this.eventType = eventType }
    fun withAggregateId(aggregateId: String) = apply { this.aggregateId = aggregateId }
    fun withLogisticalOrderId(logisticalOrderId: String) = apply { this.logisticalOrderNumber = logisticalOrderId }
    fun withShippingMethodType(shippingMethodType: ShippingMethodType) = apply { this.shippingMethodType = shippingMethodType }
    fun withState(state: State) = apply { this.state = state }
    fun withTraceId(traceId: String) = apply { this.traceId = traceId }

    fun deliveryExpiry() = apply { 
        eventType = "public.orderManagement.pickDeliveryExpired"
        state = State.None
    }
    
    fun collectionExpiry() = apply { 
        eventType = "public.orderManagement.pickCollectionExpired"
        state = State.None
    }
    
    fun ineligibleShippingMethod() = apply { 
        shippingMethodType = ShippingMethodType.StoreDelivery
    }

    fun build(): Pick {
        val metadata = Metadata.newBuilder()
            .setCreatedBy(createdBy)
            .setCreatedOn(createdOn)
            .setTraceId(traceId)
            .build()

        val orderTotal = MonetaryAmount.newBuilder()
            .setAmount(amount)
            .setCurrencyCode("GBP")
            .build()

        val orderTotalTax = MonetaryAmount.newBuilder()
            .setAmount(0.0)
            .setCurrencyCode("GBP")
            .build()

        val payment = Payment.newBuilder()
            .setTradeUkCard(false)
            .setPaymentType("CARD")
            .setOrderPaymentStatus(OrderPaymentStatus.settled)
            .setMaskedPaymentCard("****1234")
            .build()

        val customer = Customer.newBuilder()
            .setCustomerId("123")
            .setCustomerName("Test Customer")
            .setCustomerContactNumber("1234567890")
            .build()

        val channel = Channel.newBuilder()
            .setSource(Source.ContactCentre)
            .setAmendment(Amendment.None)
            .build()

        val pickLine = PickLine.newBuilder()
            .setLineItemId("1")
            .setBespokeType(BespokeType.None)
            .setBomType(BomType.None)
            .setSpecificationValue("NA")
            .setEan(ean)
            .setArticleNumber(ean)
            .setUnitOfMeasure("EA")
            .setDescription("Test Product")
            .setLineQty(2L)
            .setPickedQty(2L)
            .setLineNumber(1L)
            .setPickLineType(PickLineType.Standard)
            .setParentLine("NA")
            .setChildLines(emptyList())
            .setItemTotal(orderTotal)
            .setItemTotalTax(orderTotalTax)
            .build()

        val payload = Payload.newBuilder()
            .setAggregateId(aggregateId)
            .setLogisticalOrderNumber(logisticalOrderNumber)
            .setState(state)
            .setFulfilmentType(FulfilmentType.None)
            .setPromisedDateTime(promisedDateTime)
            .setShippingMethodType(shippingMethodType)
            .setOrderCreatedDateTime(orderCreatedDateTime)
            .setOrderId(orderId)
            .setAgeRestricted(false)
            .setRefundAmount(0.0)
            .setOrderTotal(orderTotal)
            .setOrderTotalTax(orderTotalTax)
            .setChannel(channel)
            .setCustomer(customer)
            .setPayment(payment)
            .setSite(Site.newBuilder().setNumber("1017").setTenant(Tenant.BQUK).build())
            .setPickLine(listOf(pickLine))
            .build()

        return Pick.newBuilder()
            .setEventType(eventType)
            .setMetadata(metadata)
            .setPayload(payload)
            .build()
    }
}
