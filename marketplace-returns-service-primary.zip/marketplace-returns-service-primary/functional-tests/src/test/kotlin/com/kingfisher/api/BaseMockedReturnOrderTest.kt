package com.kingfisher.api

import com.github.tomakehurst.wiremock.client.WireMock
import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.BaseReturnsServiceTest
import com.kingfisher.core.Tenant
import com.kingfisher.model.CreateOrderResponse
import com.kingfisher.utils.FileUtils
import com.kingfisher.utils.PSO
import io.restassured.response.Response
import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.TestInstance
import java.util.concurrent.atomic.AtomicLong

/**
 * Extends BaseRestAssuredTest with external service mocking capabilities.
 * Used as a foundation for all tests requiring mocked responses.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
abstract class BaseMockedReturnOrderTest : BaseReturnsServiceTest() {
    protected lateinit var testOrderDetails: PSO.ReturnOrderDetails
    private val ordersToCleanup = mutableListOf<String>()
    private val deleteOrderPath = ConfigurationManager.getProperty("deleteOrderPath")


    companion object {

        const val RETURN_ORDER_ID = 4001876521

        @JvmStatic
        protected val PRODUCT_URL_PATTERN = """/v1/products/BQUK\?filter%5Bean%5D=\d+(,\d+)?""".toRegex().toString()

        @JvmStatic
        protected val WIREMOCK_HOST = ConfigurationManager.cachedWiremockHost

        @JvmStatic
        protected val WIREMOCK_PORT = ConfigurationManager.cachedWiremockPort

        @JvmStatic
        protected val orderIdGenerator = AtomicLong(RETURN_ORDER_ID)
    }

    protected fun stubProductEndpoint() {
        WireMock.stubFor(
            WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN))
                .atPriority(1)
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(FileUtils.readDataFile("response/product_response.json"))
                )
        )
    }

    protected fun generateUniqueOrderDetails(
        alternateId: String = "ret16650152",
        originalOrderId: String = "1930157522",
        customerEmail: String = "test@example.com",
        customerFirstName: String = "John",
        customerLastName: String = "Doe",
        phoneNumber: String = "1234567890",
        amount: String = "20.3"
    ): PSO.ReturnOrderDetails {
        return PSO.ReturnOrderDetails(
            orderId = orderIdGenerator.incrementAndGet().toString(),
            alternateId = alternateId,
            originalOrderId = originalOrderId,
            customerEmail = customerEmail,
            customerFirstName = customerFirstName,
            customerLastName = customerLastName,
            phoneNumber = phoneNumber,
            amount = amount
        )
    }

    protected fun createReturnOrder(tenant: Tenant): CreateOrderResponse {
            testOrderDetails = generateUniqueOrderDetails()
            val response = PSO().createReturnOrder(testOrderDetails, tenant)
            ordersToCleanup.add(testOrderDetails.orderId)
            return CreateOrderResponse(testOrderDetails.orderId, response)
        }

    protected fun createReturnOrder(details: PSO.ReturnOrderDetails, tenant: Tenant): Response {
        val response = PSO().createReturnOrder(details, tenant)
        ordersToCleanup.add(details.orderId)
        return response
    }

    protected fun createReturnOrder(details: PSO.ReturnOrderDetails, tenant: Tenant, storeId: String): Response {
        val response = PSO().createReturnOrder(details, tenant, storeId)
        ordersToCleanup.add(details.orderId)
        return response
    }





    @BeforeEach
    open fun baseSetup() {
        runCatching {
            WireMock.configureFor(WIREMOCK_HOST, WIREMOCK_PORT)
            WireMock.resetAllRequests()
            WireMock.resetAllScenarios()
            stubProductEndpoint()
        }.onFailure { e ->
            println("Failed to configure WireMock: ${e.message}")
            throw e
        }
    }

    @AfterEach
    fun cleanup() {
        WireMock.resetAllRequests()
        ordersToCleanup.forEach { orderId ->
            try {
                When()
                    .delete("$deleteOrderPath/{RETURN_ORDER_ID}", orderId)
            } catch (e: Exception) {
                println("Warning: Cleanup failed for order $orderId: ${e.message}")
            }
        }
        ordersToCleanup.clear()
    }

    @AfterAll
    fun baseTearDown() {
        WireMock.removeStub(WireMock.get(WireMock.urlMatching(PRODUCT_URL_PATTERN)))
    }
}