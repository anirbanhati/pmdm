package com.kingfisher.utils

import com.kingfisher.inStoreFulfilment.avro.Pick
import com.kingfisher.inStoreFulfilment.avro.Metadata
import com.kingfisher.inStoreFulfilment.avro.Payload
import com.kingfisher.inStoreFulfilment.avro.Site
import com.kingfisher.inStoreFulfilment.avro.Channel
import com.kingfisher.inStoreFulfilment.avro.Customer
import com.kingfisher.inStoreFulfilment.avro.Payment
import com.kingfisher.inStoreFulfilment.avro.Allocation
import com.kingfisher.inStoreFulfilment.avro.Collection
import java.time.Instant
import java.util.*

/**
 * Builder for Pick In-Store events (in-store-fulfilment topic).
 * Used for pickCollected event type.
 */
class PickInStoreEventBuilder {

    private var eventId: String = UUID.randomUUID().toString()
    private var eventType: String = "pickCollected"
    private var aggregateId: String = "987654321"
    private var logisticalOrderNumber: String? = "MP12345-1"
    private var orderId: String = "101240843689"
    private var createdBy: String = "test-system"
    private var createdOn: String = Instant.now().toString()
    private var traceId: String = "test-trace-${System.currentTimeMillis()}"
    private var commandId: String = "cmd-${System.currentTimeMillis()}"

    fun withEventId(eventId: String) = apply { this.eventId = eventId }
    fun withEventType(eventType: String) = apply { this.eventType = eventType }
    fun withAggregateId(aggregateId: String) = apply { this.aggregateId = aggregateId }
    fun withLogisticalOrderNumber(logisticalOrderNumber: String) = apply { this.logisticalOrderNumber = logisticalOrderNumber }
    fun withTraceId(traceId: String) = apply { this.traceId = traceId }


    fun collected() = apply { eventType = "public.inStoreFulfilment.pickCollected" }

    /**
     * Build Avro Pick event for in-store-fulfilment topic.
     */
    fun build(): Pick {
        val metadata = Metadata.newBuilder()
            .setCreatedBy(createdBy)
            .setCreatedOn(createdOn)
            .setTraceId(traceId)
            .setCommandId(commandId)
            .build()

        val site = Site.newBuilder()
            .setNumber("1017")
            .setTenant("BQUK")
            .build()

        val channel = Channel.newBuilder()
            .setSource("STORE")
            .setAmendment("NONE")
            .build()

        val customer = Customer.newBuilder()
            .setCustomerID("123")
            .setCustomerName("Test Customer")
            .setCustomerContactNumber("1234567890")
            .build()

        val payment = Payment.newBuilder()
            .setPaymentType("CARD")
            .setOrderPaymentStatus("NOT_SETTLED")
            .setMaskedPaymentCard("****1234")
            .build()

        val allocation = Allocation.newBuilder()
            .setStatus("ALLOCATED")
            .build()

        val collection = Collection.newBuilder()
            .setCollectorName("null")
            .setIdentityProof("null")
            .setIsAgeVerified(false)
            .build()

        val payload = Payload.newBuilder()
            .setAggregateId(aggregateId)
            .setLogisticalOrderNumber(logisticalOrderNumber)
            .setStatus("collected")
            .setOrderId(orderId)
            .setPromisedDateTime(Instant.now().toString())
            .setOrderCreatedDateTime(createdOn)
            .setAgeRestricted(false)
            .setDcManualOrder(false)
            .setSite(site)
            .setChannel(channel)
            .setCustomer(customer)
            .setPayment(payment)
            .setAllocation(allocation)
            .setCollection(collection)
            .setPicklines(emptyList())
            .build()

        return Pick.newBuilder()
            .setEventId(eventId)
            .setEventType(eventType)
            .setMetadata(metadata)
            .setPayload(payload)
            .build()
    }
}
