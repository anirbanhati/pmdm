package com.kingfisher.api

import com.github.tomakehurst.wiremock.client.WireMock
import com.github.tomakehurst.wiremock.http.Fault
import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import org.hamcrest.Matchers.hasItem
import org.junit.jupiter.api.*
import org.springframework.context.annotation.Description

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CreateReturnOrderCaplTest : BaseMockedReturnOrderTest() {
    private val fetchReturnOrderPath = ConfigurationManager.getProperty("fetchReturnOrderPath")

    companion object {
        private const val CMS_URL_PATTERN = "/stage/v2/cmsapi/.*"
        private val tenant = Tenant.CAPL
    }

    @Test
    @Tag("integration")
    fun `should create return order successfully`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId
        verifyOrderCreated(orderId)
    }

    @Test
    @Tag("integration")
    @Description("Verifies that when CMS returns a failed response, status is CARRIER_BOOKING_FAILED and refundCreated is true")
    fun `should set CARRIER_BOOKING_FAILED when CMS returns failed response`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId
        verifyOrderLineStatus(orderId, "CARRIER_BOOKING_FAILED")
    }

    @Test
    @Tag("integration")
    @Description("Verifies that when CMS throws a network exception, status is CARRIER_BOOKING_FAILED and refundCreated is true")
    fun `should set CARRIER_BOOKING_FAILED when CMS throws network exception`() {
        val cmsExceptionStub = WireMock.stubFor(
            WireMock.post(WireMock.urlPathMatching(CMS_URL_PATTERN))
                .atPriority(1)
                .willReturn(
                    WireMock.aResponse()
                        .withFixedDelay(2000)
                        .withFault(Fault.CONNECTION_RESET_BY_PEER)
                )
        )

        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        verifyOrderLineStatus(orderId, "CARRIER_BOOKING_FAILED")
        WireMock.removeStub(cmsExceptionStub)
    }

    @Test
    @Tag("integration")
    @Description("Verifies that when both Mirakl and CMS respond successfully, status is CARRIER_BOOKED")
    fun `should set CARRIER_BOOKED when Mirakl and CMS both succeed`() {
        val cmsSuccessStub = WireMock.stubFor(
            WireMock.post(WireMock.urlPathMatching(CMS_URL_PATTERN))
                .atPriority(1)
                .willReturn(
                    WireMock.aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("__cms/cms-response-successful.json")
                )
        )

        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId
        verifyOrderLineStatus(orderId, "CARRIER_BOOKED")

        WireMock.removeStub(cmsSuccessStub)
    }

    private fun verifyOrderCreated(orderId: String) {
        When()
            .get(fetchReturnOrderPath, orderId)
            .then()
            .statusCode(200)
            .body("data.attributes.lines.returnOrderNumber", hasItem(orderId.toLong()))
    }

    private fun verifyOrderLineStatus(orderId: String, expectedLineStatus: String) {
        When()
            .get(fetchReturnOrderPath, orderId)
            .then()
            .statusCode(200)
            .body("data.attributes.lines.returnOrderNumber", hasItem(orderId.toLong()))
            .body("data.attributes.lines.refundCreated", hasItem(true))
            .body("data.attributes.lines.status", hasItem(expectedLineStatus))
    }
}
