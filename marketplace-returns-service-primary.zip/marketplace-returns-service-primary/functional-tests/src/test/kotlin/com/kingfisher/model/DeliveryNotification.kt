package com.kingfisher.model

import com.fasterxml.jackson.annotation.JsonProperty

data class DeliveryNotification(
    val carrier: String = "DPD",
    @param:JsonProperty("order_number")
    val orderNumber: String = "",
    @param:JsonProperty("tracking_number")
    val trackingNumber: String = "DPD123456",
    @param:JsonProperty("tracking_url")
    val trackingUrl: String = "https://tracking.dpd.co.uk/DPD123456",
    val items: List<DeliveryNotificationItem> = listOf(DeliveryNotificationItem())
)

data class DeliveryNotificationItem(
    @param:JsonProperty("line_ref")
    val lineRef: String = "1",
    @param:JsonProperty("part_number")
    val partNumber: String = "1234567890123",
    val quantity: Long = 1
)
