package com.kingfisher.utils

import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths

class FileUtils {

    companion object {
        const val DATA_FILES_RESOURCE_LOCATION = "./src/test/resources/data"

        @Throws(IOException::class)
        fun readDataFile(fileName: String?): String? {
            return Files.readString(Paths.get(DATA_FILES_RESOURCE_LOCATION, fileName))
        }
    }
}