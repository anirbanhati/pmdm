package com.kingfisher.utils

import com.kingfisher.model.ParcelTrackingInfo
import com.kingfisher.model.ReturnLine
import com.kingfisher.model.UpdateRouteAttributes
import com.kingfisher.model.UpdateRouteData
import com.kingfisher.model.UpdateRouteRequest

class UpdateRouteBuilder {
    private var userId: String = "TEST_USER"
    private var lines: MutableList<ReturnLine> = mutableListOf()

    fun withUserId(userId: String) = apply {
        this.userId = userId
    }

    // Method without parcelTrackingInfo
    fun addUpdateRouteAttributes(
        lineNumber: Long,
        ean: String,
        route: String,
        quantity: Int,
        reason: String
    ) = apply {
        lines.add(
            ReturnLine(
                lineNumber = lineNumber,
                ean = ean,
                route = route,
                quantity = quantity,
                reason = reason,
                parcelTrackingInfo = emptyList()
            )
        )
    }

    fun addUpdateRouteAttributesWithTracking(
        lineNumber: Long,
        ean: String,
        route: String,
        quantity: Int,
        reason: String,
        trackingQuantity: Int,
        externalParcelIdentifier: String,
        trackingNumber: String
    ) = apply {
        val parcelTracking = ParcelTrackingInfo(
            quantity = trackingQuantity,
            externalParcelIdentifier = externalParcelIdentifier,
            trackingNumber = trackingNumber
        )

        lines.add(
            ReturnLine(
                lineNumber = lineNumber,
                ean = ean,
                route = route,
                quantity = quantity,
                reason = reason,
                parcelTrackingInfo = listOf(parcelTracking)
            )
        )
    }

    fun build() = UpdateRouteRequest(
        data = UpdateRouteData(
            type = "updateRoute",
            attributes = UpdateRouteAttributes(
                userId = userId,
                lines = lines
            )
        )
    )
}