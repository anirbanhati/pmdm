package com.kingfisher.core

import com.kingfisher.config.ConfigurationManager
import com.kingfisher.config.SpecLoggingFilter.Companion.requestLog
import com.kingfisher.config.SpecLoggingFilter.Companion.responseLog
import io.restassured.RestAssured
import io.restassured.RestAssured.given
import io.restassured.config.FailureConfig
import io.restassured.config.LogConfig
import io.restassured.config.RedirectConfig
import io.restassured.config.RestAssuredConfig
import io.restassured.filter.Filter
import io.restassured.filter.log.LogDetail
import io.restassured.listener.ResponseValidationFailureListener
import io.restassured.specification.RequestSpecification
import org.apache.http.HttpHeaders
import org.slf4j.LoggerFactory
import java.util.*

/**
 * Base configuration class for all API tests.
 * Provides core Rest Assured setup and common helper methods.
 */

open class BaseReturnsServiceTest {
    companion object {
        private const val USER_AGENT = "mktp-returns-ta"
        private const val CONTENT_TYPE = "application/json"
        private const val MAX_REDIRECTS = 1

        private val logger = LoggerFactory.getLogger(BaseReturnsServiceTest::class.java)
        
        fun isDeployedEnvironment(): Boolean {
            return System.getProperty("envName", "local") != "local"
        }
        
        fun requiresMocks(): Boolean {
            return !isDeployedEnvironment()
        }

        private val LOG_REQUEST: Filter by lazy {
            requestLog(System.out).also { logger.debug("Initialized request logging filter") }
        }

        private val LOG_RESPONSE: Filter by lazy {
            responseLog(System.out, 200).also { logger.debug("Initialized response logging filter") }
        }

        private val failureListener = ResponseValidationFailureListener { _, _, response ->
            logger.error(
                "Request validation failed - Status code: {}, Response body: {}",
                response.statusCode,
                response.body.asPrettyString()
            )
        }

        private val defaultConfig: RestAssuredConfig by lazy {
            logger.debug("Initializing RestAssured default configuration")
            RestAssured.config()
                .logConfig(
                    LogConfig.logConfig()
                        .enableLoggingOfRequestAndResponseIfValidationFails(LogDetail.ALL)
                )
                .failureConfig(
                    FailureConfig.failureConfig()
                        .failureListeners(failureListener)
                )
                .redirect(
                    RedirectConfig.redirectConfig()
                        .maxRedirects(MAX_REDIRECTS)
                )
        }

        init {
            try {
                configureLogging()
                configureRestAssured()
                logger.info("ReturnsServiceTest initialization completed successfully")
            } catch (e: Exception) {
                logger.error("Failed to initialize ReturnsServiceTest", e)
                throw e
            }
        }

        private fun configureLogging() {
            try {
                val rootLogger = LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME)
                if (rootLogger is ch.qos.logback.classic.Logger) {
                    rootLogger.level = ch.qos.logback.classic.Level.INFO
                    logger.info("Logging configured with INFO level")
                }
            } catch (e: Exception) {
                logger.error("Failed to configure logging", e)
                throw e
            }
        }

        private fun configureRestAssured() {
            try {
                RestAssured.config = defaultConfig
                RestAssured.enableLoggingOfRequestAndResponseIfValidationFails()
                logger.info("RestAssured configured successfully")
            } catch (e: Exception) {
                logger.error("Failed to configure RestAssured", e)
                throw e
            }
        }
    }

    protected fun When(): RequestSpecification = try {
        logger.debug("Creating new request specification")
        given()
            .headers(getDefaultHeaders())
            .contentType(CONTENT_TYPE)
            .accept(CONTENT_TYPE)
            .baseUri(ConfigurationManager.cachedBaseUrl)
            .noFilters()
            .filters(LOG_REQUEST, LOG_RESPONSE)
            .also { logger.debug("Request specification created successfully") }
    } catch (e: Exception) {
        logger.error("Failed to create request specification", e)
        throw e
    }

    private fun getDefaultHeaders(): Map<String, String> =
        mapOf(
            HttpHeaders.USER_AGENT to USER_AGENT,
            "X-Request-ID" to UUID.randomUUID().toString()
        ).also {
            logger.debug("Generated new headers with Request-ID: {}", it["X-Request-ID"])
        }

    protected fun logRequestDetails(specification: RequestSpecification) {
        if (logger.isDebugEnabled) {
            logger.debug("Request details: {}", specification.log().all())
        }
    }
}
