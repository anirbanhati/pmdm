package com.kingfisher.kafka

import com.kingfisher.api.BaseMockedReturnOrderTest
import com.kingfisher.utils.BQKafkaTestProducer
import com.kingfisher.utils.PickEventBuilder
import com.kingfisher.utils.PickInStoreEventBuilder
import com.kingfisher.orderManagement.avro.ShippingMethodType
import org.awaitility.Awaitility.await
import com.github.tomakehurst.wiremock.client.WireMock
import com.github.tomakehurst.wiremock.client.WireMock.exactly
import com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor
import com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo
import com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.equalTo
import org.hamcrest.Matchers.hasItem
import org.hamcrest.Matchers.not
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * Functional tests for Kafka Pick event processing in the marketplace returns service.
 *
 * Tests the end-to-end flow of consuming Avro-serialized Pick events from Kafka topics,
 * processing them through the service, and verifying the resulting state in DynamoDB
 * and external API calls to Mirakl.
 *
 * **Event Sources:**
 * - Order Management topic: Pick delivery/collection expiry events
 * - In-Store Fulfilment topic: Pick collected events
 *
 * **Processing Flow:**
 * 1. Kafka event consumed by service
 * 2. Event validated (shipping method, event type)
 * 3. Return line created/updated in DynamoDB
 * 4. External APIs called (Mirakl refund/notification) if applicable
 *
 * **Test Coverage:**
 * - Collection expiry: Creates return line, no external API calls
 * - Delivery expiry: Creates return line, triggers refund and seller notification
 * - Pick collected: No return line created (order fulfilled)
 * - Invalid shipping methods: Events ignored
 * - Unknown event types: Events ignored
 * - Missing Mirakl orders: Handled gracefully
 */
@Tag("integration")
class KafkaPickEventTest : BaseMockedReturnOrderTest() {

    private val ordersToCleanup = mutableListOf<String>()

    companion object {
        private const val ORDER_MANAGEMENT_TOPIC = "public.bquk.order-management.test.pick"
        private const val IN_STORE_FULFILMENT_TOPIC = "public.bquk.in-store-fulfilment.test.pick"
    }

    @BeforeEach
    override fun baseSetup() {
        WireMock.configureFor(WIREMOCK_HOST, WIREMOCK_PORT)
        WireMock.resetAllRequests()
    }

    @Test
    fun `should create return line when collection expiry event received`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-B"
        ordersToCleanup.add(orderLineId)

        val event = PickEventBuilder()
            .withLogisticalOrderId(orderLineId)
            .collectionExpiry()
            .withShippingMethodType(ShippingMethodType.ClickCollectMP)
            .build()

        BQKafkaTestProducer.sendMessage(ORDER_MANAGEMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .body("logisticalOrderId", hasItem(orderLineId))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.status", equalTo("AWAITING_LABEL_PRINTING"))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.returnType", equalTo("COLLECTION_EXPIRED"))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.refundCreated", equalTo(false))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.cancellationCreated", equalTo(false))
            }

        WireMock.verify(exactly(0), putRequestedFor(urlPathMatching("/api/orders/.*")))
    }

    @Test
    fun `should create refund when delivery expiry event with canCancel false`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-C"
        ordersToCleanup.add(orderLineId)

        val event = PickEventBuilder()
            .withLogisticalOrderId(orderLineId)
            .deliveryExpiry()
            .withShippingMethodType(ShippingMethodType.ClickCollectMP)
            .build()

        BQKafkaTestProducer.sendMessage(ORDER_MANAGEMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .body("logisticalOrderId", hasItem(orderLineId))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.status", equalTo("DELIVERY_EXPIRED"))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.returnType", equalTo("DELIVERY_EXPIRED"))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.route", equalTo("LOST_IN_TRANSIT"))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.refundCreated", equalTo(true))
                    .body("find { it.logisticalOrderId == '$orderLineId' }.cancellationCreated", equalTo(false))
            }

        WireMock.verify(putRequestedFor(urlPathEqualTo("/api/orders/refund")))
        WireMock.verify(exactly(0), putRequestedFor(urlPathEqualTo("/api/orders/cancel")))
    }

    @Test
    fun `should mark return as CANCELLED when pick is collected`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-D"
        ordersToCleanup.add(orderLineId)

        val event = PickInStoreEventBuilder()
            .withLogisticalOrderNumber(orderLineId)
            .collected()
            .build()

        BQKafkaTestProducer.sendMessage(IN_STORE_FULFILMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                val logisticalOrderIds = When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .extract()
                    .jsonPath()
                    .getList<String>("logisticalOrderId")

                assertThat(
                    "Order $orderLineId should not be created for collected pick",
                    logisticalOrderIds, not(hasItem(orderLineId))
                )
            }

        WireMock.verify(exactly(0), putRequestedFor(urlPathMatching("/api/.*")))
    }

    @Test
    fun `should skip processing when shipping method is ineligible`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-E"
        ordersToCleanup.add(orderLineId)

        val event = PickEventBuilder()
            .withLogisticalOrderId(orderLineId)
            .deliveryExpiry()
            .withShippingMethodType(ShippingMethodType.StoreDelivery)
            .build()

        BQKafkaTestProducer.sendMessage(ORDER_MANAGEMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                val logisticalOrderIds = When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .extract()
                    .jsonPath()
                    .getList<String>("logisticalOrderId")

                assertThat(
                    "Order $orderLineId should not be created for ineligible shipping method StoreDelivery",
                    logisticalOrderIds, not(hasItem(orderLineId))
                )
            }

        WireMock.verify(exactly(0), putRequestedFor(urlPathMatching("/api/.*")))
    }

    @Test
    fun `should skip processing when event type is ineligible`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-F"
        ordersToCleanup.add(orderLineId)

        val event = PickEventBuilder()
            .withLogisticalOrderId(orderLineId)
            .withEventType("unknownEventType")
            .withShippingMethodType(ShippingMethodType.ClickCollect)
            .build()

        BQKafkaTestProducer.sendMessage(ORDER_MANAGEMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                val logisticalOrderIds = When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .extract()
                    .jsonPath()
                    .getList<String>("logisticalOrderId")

                assertThat(
                    "Order $orderLineId should not be created for unknown event type",
                    logisticalOrderIds, not(hasItem(orderLineId))
                )
            }

        WireMock.verify(exactly(0), putRequestedFor(urlPathMatching("/api/.*")))
    }

    @Test
    fun `should handle missing order gracefully`() {
        val orderLineId = "MP-${Random.nextInt(10000, 99999)}-NONEXISTENT"
        ordersToCleanup.add(orderLineId)

        val event = PickEventBuilder()
            .withLogisticalOrderId(orderLineId)
            .deliveryExpiry()
            .withShippingMethodType(ShippingMethodType.ClickCollect)
            .build()

        BQKafkaTestProducer.sendMessage(ORDER_MANAGEMENT_TOPIC, orderLineId, event)

        await()
            .atMost(5, TimeUnit.SECONDS)
            .pollInterval(100, TimeUnit.MILLISECONDS)
            .untilAsserted {
                val logisticalOrderIds = When().get("/v1/fetchAllOrders")
                    .then()
                    .statusCode(200)
                    .extract()
                    .jsonPath()
                    .getList<String>("logisticalOrderId")

                assertThat(
                    "Order $orderLineId should not be created when Mirakl order is missing",
                    logisticalOrderIds, not(hasItem(orderLineId))
                )
            }

        WireMock.verify(exactly(0), putRequestedFor(urlPathMatching("/api/.*")))
    }
}
