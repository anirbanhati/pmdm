package com.kingfisher.config

import java.util.*

object ConfigurationManager {
    private val properties: Properties by lazy {
        Properties().apply {
            loadProperties()
        }
    }

    private val envName: String by lazy {
        System.getProperty("envName", "local")
    }

    private val logger by lazy {
        org.slf4j.LoggerFactory.getLogger(ConfigurationManager::class.java)
    }

    private fun Properties.loadProperties() {
        val configEnvFileName = "$envName.properties"
        logger.debug("Loading configuration from: $configEnvFileName")
        ConfigurationManager::class.java.classLoader.getResourceAsStream(configEnvFileName)?.use { stream ->
            load(stream)
        } ?: throw RuntimeException("Configuration file $configEnvFileName not found")
    }

    // Cache commonly accessed values
    val cachedBaseUrl by lazy {
        System.getenv("BASE_URL") ?: properties.getProperty("base.url")
    }

    val cachedWiremockHost: String? by lazy {
        System.getenv("WIREMOCK_HOST") ?: properties.getProperty("wiremock.host")
    }

    val cachedWiremockPort by lazy {
        val defaultPort = 9091
        try {
            (System.getenv("WIREMOCK_PORT") ?: properties.getProperty("wiremock.port"))?.toInt() ?: defaultPort
        } catch (e: NumberFormatException) {
            defaultPort
        }
    }

    fun getProperty(key: String): String {
        return properties.getProperty(key)?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("Property '$key' not found or is blank")
    }
}
