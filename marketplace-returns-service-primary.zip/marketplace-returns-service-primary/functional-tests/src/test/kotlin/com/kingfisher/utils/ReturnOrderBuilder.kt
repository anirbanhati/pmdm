package com.kingfisher.utils

class ReturnOrderBuilder {
    private var orderId: String = "4001876521"
    private var alternateId: String = "ret16650152"
    private var originalOrderId: String = "1930157522"
    private var email: String = "test@example.com"
    private var firstName: String = "John"
    private var lastName: String = "Doe"
    private var phone: String = "1234567890"
    private var storeId: String = "1017"
    private var amount: String = "20.3"

    fun withOrderId(id: String) = apply { orderId = id }
    fun withCustomerDetails(firstName: String, lastName: String) = apply {
        this.firstName = firstName
        this.lastName = lastName
    }

    fun build() = PSO.ReturnOrderDetails(
        orderId = orderId,
        alternateId = alternateId,
        originalOrderId = originalOrderId,
        customerEmail = email,
        customerFirstName = firstName,
        customerLastName = lastName,
        phoneNumber = phone,
        amount = amount
    )
}