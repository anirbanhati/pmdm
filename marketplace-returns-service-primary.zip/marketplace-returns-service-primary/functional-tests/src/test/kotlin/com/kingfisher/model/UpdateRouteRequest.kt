package com.kingfisher.model

data class UpdateRouteRequest(
    val data: UpdateRouteData
)

data class UpdateRouteData(
    val type: String, val attributes: UpdateRouteAttributes
)

data class UpdateRouteAttributes(
    val userId: String, val lines: List<ReturnLine>
)

data class ReturnLine(
    val lineNumber: Long,
    val ean: String,
    val route: String,
    val quantity: Int,
    val reason: String,
    val parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList()
)

