package com.kingfisher.utils
import java.net.URL

object UrlUtils {

    fun build(base: String, endpoint: String): URL {
        val baseWithoutTrailingSlash = base.replace("/$".toRegex(), "")
        val endPointWithoutLeadingSlash = endpoint.replace("^/".toRegex(), "")
        return URL("$baseWithoutTrailingSlash/$endPointWithoutLeadingSlash")
    }

}
