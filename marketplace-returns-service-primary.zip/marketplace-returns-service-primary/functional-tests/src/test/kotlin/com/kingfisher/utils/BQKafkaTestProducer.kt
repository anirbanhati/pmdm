package com.kingfisher.utils

import com.kingfisher.config.ConfigurationManager
import io.confluent.kafka.serializers.KafkaAvroSerializer
import org.apache.avro.specific.SpecificRecord
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.StringSerializer
import java.util.*

/**
 * Kafka test producer for sending messages to test topics.
 * Connects to local Kafka (localhost:9092).
 */
object BQKafkaTestProducer {

    private val KAFKA_BOOTSTRAP_SERVERS = ConfigurationManager.getProperty("kafka.bootstrap.servers")
    private val SCHEMA_REGISTRY_URL = ConfigurationManager.getProperty("schema.registry.url")

    private val Producer: KafkaProducer<String, SpecificRecord> by lazy {
        val props = Properties().apply {
            put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA_BOOTSTRAP_SERVERS)
            put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer::class.java.name)
            put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer::class.java.name)
            put("schema.registry.url", SCHEMA_REGISTRY_URL)
            put(ProducerConfig.ACKS_CONFIG, "all")
            put(ProducerConfig.RETRIES_CONFIG, 3)
            put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1)
        }
        KafkaProducer(props)
    }


    /**
     * Sends a BQUK Avro message to a Kafka topic and waits for acknowledgment.
     *
     * @param topic Kafka topic name
     * @param key Message key (optional, defaults to null)
     * @param message Avro SpecificRecord (generated from schema)
     */
    fun sendMessage(topic: String, key: String? = null, message: SpecificRecord) {
        val record = ProducerRecord(topic, key, message)
        Producer.send(record).get()
    }

    init {
        Runtime.getRuntime().addShutdownHook(Thread {
            Producer.close()
        })
    }

}
