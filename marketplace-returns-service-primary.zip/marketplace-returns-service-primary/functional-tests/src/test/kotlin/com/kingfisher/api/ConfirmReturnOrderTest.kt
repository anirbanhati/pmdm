package com.kingfisher.api

import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import com.kingfisher.model.*
import com.kingfisher.utils.ConfirmReturnRequestBuilder
import io.restassured.response.Response
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers
import org.hamcrest.Matchers.not
import org.junit.jupiter.api.*
import org.junitpioneer.jupiter.ExpectedToFail

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ConfirmReturnOrderTest : BaseMockedReturnOrderTest() {

    companion object {
        private const val LINE_NUMBER = 1L
        private const val DPD_TRACKING_NUMBER = "DPD123456"
        private const val DEFAULT_USER_ID = "USER123"
        private const val DEFAULT_PARCEL_ID = "EXT-123"
        private val tenant = Tenant.BQUK
    }

    private val confirmPath = ConfigurationManager.getProperty("confirmPath")
    private val updateRoutePath = ConfigurationManager.getProperty("updateRoutePath")


    @Test
    @Tag("integration")
    fun `should confirm return line with parcel tracking info`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        val request = ConfirmReturnRequestBuilder()
            .withUserId(DEFAULT_USER_ID)
            .withTrackingNumber(DPD_TRACKING_NUMBER)
            .withParcelId(DEFAULT_PARCEL_ID).buildDpdRequest()

        val response = confirmReturn(request, tenant.name, orderId, LINE_NUMBER)

        assertThat(response.statusCode(), Matchers.equalTo(HttpStatus.SC_OK))
        verifyConfirmationResponse(response, orderId.toLong(), request)
    }

    @Test
    @ExpectedToFail("Empty parcel tracking info should cause bad request exception but it does not.")
    @Tag("integration")
    fun `should throw bad request when parcel tracking info missing for DPD confirm line request`() {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        val request = ConfirmReturnRequest(
            data = ConfirmData(
                type = "confirmReturn", attributes = ConfirmReturnRequestAttributes(
                    userId = "USER123"
                )
            )
        )
        When()
            .body(
                UpdateRouteRequest(
                    data = UpdateRouteData(
                        type = "updateRoute", attributes = UpdateRouteAttributes(
                            userId = "USER123", lines = listOf(
                                ReturnLine(
                                    lineNumber = LINE_NUMBER,
                                    ean = "1234567890123",
                                    route = "DPD",
                                    quantity = 1,
                                    reason = "Change of mind",
                                    parcelTrackingInfo = listOf(
                                        ParcelTrackingInfo(
                                            quantity = 1,
                                            externalParcelIdentifier = "EXT-123",
                                            trackingNumber = "DPD123456"
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            .put("$updateRoutePath/{tenant}/{returnOrderNumber}", tenant.name, orderId)

        val response = When()
            .body(request)
            .put("$confirmPath/{tenant}/{returnOrderNumber}/{lineNumber}", tenant.name, orderId, LINE_NUMBER)

        assertThat(response.statusCode, Matchers.equalTo(HttpStatus.SC_BAD_REQUEST))
    }

    private fun confirmReturn(request: ConfirmReturnRequest, tenant: String, orderId: String, lineNumber: Long) =
        When()
            .body(request)
            .put("$confirmPath/{tenant}/{returnOrderNumber}/{lineNumber}", tenant, orderId, lineNumber)

    private fun verifyConfirmationResponse(
        response: Response, expectedOrderId: Long, request: ConfirmReturnRequest
    ) {
        val jsonPath = response.jsonPath()
        with(jsonPath) {
            assertThat(
                getLong("data.attributes.line.returnOrderNumber"), Matchers.equalTo(expectedOrderId)
            )
            val trackingInfo = getList<Map<String, Any>>("data.attributes.line.parcelTrackingInfo")
            assertThat(trackingInfo, not(emptyList()))
            assertThat(
                getInt("data.attributes.line.parcelTrackingInfo[0].quantity"),
                Matchers.equalTo(request.data.attributes.parcelTrackingInfo[0].quantity)
            )
            assertThat(
                getString("data.attributes.line.parcelTrackingInfo[0].trackingNumber"),
                Matchers.equalTo(DPD_TRACKING_NUMBER)
            )
            assertThat(
                getString("data.attributes.line.labelPrintingRequestedBy"),
                Matchers.equalTo(request.data.attributes.userId)
            )
        }
    }

}
