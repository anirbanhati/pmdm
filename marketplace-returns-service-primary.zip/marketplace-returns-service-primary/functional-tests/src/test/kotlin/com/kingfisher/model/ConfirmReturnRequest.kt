package com.kingfisher.model


data class ConfirmReturnRequest(
    val data: ConfirmData
)

data class ConfirmData(
    val type: String,
    val attributes: ConfirmReturnRequestAttributes,
)

data class ConfirmReturnRequestAttributes(
    val userId: String,
    val parcelTrackingInfo: List<ParcelTrackingInfo> = emptyList()
)


