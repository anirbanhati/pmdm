package com.kingfisher.api

import com.kingfisher.config.ConfigurationManager
import com.kingfisher.core.Tenant
import org.hamcrest.Matchers
import org.junit.jupiter.api.*
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.EnumSource

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DeleteReturnOrderTest : BaseMockedReturnOrderTest() {

    private val deleteOrderPath = ConfigurationManager.getProperty("deleteOrderPath")
    private val fetchAllOrderPath = ConfigurationManager.getProperty("fetchAllOrderPath")

    @ParameterizedTest
    @EnumSource(Tenant::class)
    @Tag("integration")
    fun `test should delete return order`(tenant: Tenant) {
        val orderInfo = createReturnOrder(tenant)
        val orderId = orderInfo.orderId

        When()
            .get(fetchAllOrderPath)
            .then()
            .statusCode(200)
            .body("returnOrderNumber", Matchers.hasItem(orderId.toLong()))

        When()
            .delete("$deleteOrderPath/${orderId}")
            .then()
            .statusCode(204)

        When()
            .get(fetchAllOrderPath)
            .then()
            .statusCode(200)
            .body(Matchers.not(Matchers.containsString(orderId)))
    }
}
