package com.kingfisher.model

import io.restassured.response.Response

data class CreateOrderResponse(
    val orderId: String,
    val response: Response
)
