package com.kingfisher.utils

import com.kingfisher.model.ConfirmData
import com.kingfisher.model.ConfirmReturnRequest
import com.kingfisher.model.ConfirmReturnRequestAttributes
import com.kingfisher.model.ParcelTrackingInfo

class ConfirmReturnRequestBuilder {
    private var userId: String = "USER123"
    private var trackingNumber: String = "DPD123456"
    private var parcelId: String = "EXT-123"
    private var quantity: Int = 1

    fun withUserId(userId: String) = apply { this.userId = userId }
    fun withTrackingNumber(number: String) = apply { this.trackingNumber = number }
    fun withParcelId(id: String) = apply { this.parcelId = id }
    fun withQuantity(qty: Int) = apply { this.quantity = qty }

    fun buildDpdRequest() = ConfirmReturnRequest(
        data = ConfirmData(
            type = "confirmReturn",
            attributes = ConfirmReturnRequestAttributes(
                userId = userId,
                parcelTrackingInfo = listOf(
                    ParcelTrackingInfo(
                        quantity = quantity,
                        externalParcelIdentifier = parcelId,
                        trackingNumber = trackingNumber
                    )
                )
            )
        )
    )

    fun buildNonDpdRequest() = ConfirmReturnRequest(
        data = ConfirmData(
            type = "confirmReturn",
            attributes = ConfirmReturnRequestAttributes(
                userId = userId
            )
        )
    )
}