CHANGELOG
=========

1782141525
---
2026-06-22
* MKTP-2059: Fix comparing enum values
* MKTP-2059: Add BQUK/CAPL variables fetching from vault
* Increase concurrency on JMSListener
* [MKTP-2059] Trigger refund for CAPL Instore Return
* [MKTP-2058] Adjust code to use notification templates for BQUK and CAPL
* [MKTP-2050] In Store return service script for Poland
* [MKTP-2050] Consume PSO xml for CAPL

1779460506
---
2026-05-25
* [MKTP-1974] Remove functionality of fetching orders in AWAITING_STORE_CONFIRMATION state

1779085436
---
2026-05-18
* [MKTP-1974] Log error during @JMSListner failure
* [MKTP-1974] Extend JMS metric, change Mirakl aspect definition
* [MKTP-1974] Fix JMS and Kafka metrics, move FetchReturnsAwaitingForBooking scheduler functionality to rest endpoint
* [MKTP-1933]: Handle dynamoDB paging to not return duplicate values. Split ReturnBusinessService to smaller classes

1778166089
---
2026-05-07
* [MKTP-1835] Fixed scheduled deploys
* [MKTP-1974] Refactor datadog metrics

1777544845
---
2026-04-30
* Upgrade mirakl SDK version
* MKTP-1970 test: add Kafka integration test with Avro schema support
* Add comprehensive test documentation and coverage plan

1767852855
---
2026-01-08
* Revert "[MKTP-1907]: Fix swagger url"
* Reapply "feat: [MKTP-1907] Migrating Mirakl integration from API_KEY to OAuth2"
* [MKTP-1907]: handle swagger https to http conversion
* [MKTP-1907]: Fix swagger url
* Revert "feat: [MKTP-1907] Migrating Mirakl integration from API_KEY to OAuth2"

1767347193
---
2026-01-02
* fix: [MKTP-1907] Updating manifest to pass the validation
* feat: [MKTP-1907] Migrating Mirakl integration from API_KEY to OAuth2

1762784156
---
2025-11-10
* chore:[MKTP-1890] Updating base docker image to fix build

1760948643
---
2025-10-22
* [MKTP-1829]: Adjust manifest tags
* Resolve MKTP-1829 "Add manifest fields"

1759755338
---
2025-10-08
* docs: [MKTP-1599] Updating swagger documentation for Marketplace Returns Service
* fix: upgrade Docker version to 24.0.6 to resolve cgroup mounting issues

1759154626
---
2025-09-30
* [MKTP-1829]: Enable datadog in manifest
* [MKTP-1781] Changing the auto iForce routing logic: items below £10 are no longer defaulted to iForce
* fix: [MKTP-1655]Fix for IForce and Collection Expiry Refund and Notification flow
* feat: [MKTP-1655] Process Refunds Immediately For All Returns (Except Collection Expiry)

1753432917
---
2025-07-29
* [MKTP-1771] Fixing the logistical Order ID attribute name in carrier booking request.
* Revert "[MKTP-1771] Fixing the logistical Order ID attribute name in request."
* [MKTP-1771] Fixing the logistical Order ID attribute name in request.

1752833769
---
2025-07-21
* # CI Configuration and Docker Setup Improvements
* Revert "Remove Metrics from Kafka configuration" Mistake in commiting to primary
* Remove Metrics from Kafka configuration
* chore: [MKTP-1627]: Add changelog generation
* Revert "Revert "[MKTP-1749] Adding logistical order id in carrier booking request""
* Revert "[MKTP-1749] Adding logistical order id in carrier booking request"
* fix: [MKTP-1752] Changing seller notification message for IForce and added missing signature in few notification templates
* [MKTP-1749] Adding logistical order id in carrier booking request
* feat [MKTP-1743]: Make Functional Test run on CI

30062025
---
2025-06-30
* [MKTP-1734] Correcting bootstrap server url

1750930957
---
2025-06-27
* [MKTP-1734] In store topic name changed for Prod.
* [MKTP-1737] Fix for refund and cancellation api call with null currency iso code for old records
* [MKTP-1737] Cancel Order For Delivery Expiry on Orders Not in a "Shipped" Status
* [MKTP-1696] Address vulnerabilities in Marketplace-Returns-Service
* fix:[MKTP-1738] Fix for seller notification template for route and type combination
* [MKTP-1696] Address vulnerabilities in Marketplace-Returns-Service and Manual trigger for Test job
* Revert "[MKTp-1696]Address vulnerabilities in Marketplace-Returns-Service"
* [MKTp-1696]Address vulnerabilities in Marketplace-Returns-Service
* [MKTP-1728] Mapping UPCID as EAN while processing return PSO
* [MKTP-1735] Fix for seller notification template for collection expired iForce line
* [MKTP-1733] Fix to process pick collected events successfully
* Revert "Revert "[MKTP-1722] Changes to generate unique returnOrderNumber for each logistical Group.""
* Revert "[MKTP-1722] Changes to generate unique returnOrderNumber for each logistical Group."
* [MKTP-1722] Changes to generate unique returnOrderNumber for each logistical Group.
* [MKTP-1714] Enabling PSO processing for Marketplace click & collect delivery group
* Merge branch 'dev_platfrom_MKTP-1688-V2' into 'primary'
* [MKTP-1622] Change in unit price for collection order.
* [MKTP-1622] Collection date formatter from Zoned to ISO
* [MKTP-1622] Changed return date format from collection journey
* Merge branch 'primary' of https://gitlab.kfplc.com/dcom-mktp/marketplace-returns-service into primary
* chore:Removing extra image
* MKTP-1685 chore:
* chore:[MKTP-1685] Fix for dependency check failure
* [MKTP-1631] Fix for return order id exceeding in length
* Merge remote-tracking branch 'origin/primary_MKTP-1684' into primary
* [MKTP-1631] Adding new topic name and schema for pick collected events
* [MKTP-1677] Automation script for MKTP-1660 (functional-tests)
* fix: [MKTP-1678] Removing extra gradle task
* Merge remote-tracking branch 'origin/primary_MKTP-1678' into primary
* feat:[MKTP-1660] Windsor Framework Return Filtering -  Set route to IForce for Northern Ireland store returns
* [MKTP-1672] Change attribute name from logisticalOrderId to logisticalOrderNumber in pick outbound message
* [MKTP-1631] Updating C&C Return Line's Status As CANCELLED If Customer Collects Order Before it is Processed
* [MKTP-1622] Handling Collection Expiry In Returns
* [MKTP-1667] Replacing owasp dependency check job with GitLab dependency scanning job
* Merge branch 'chore-docker-auth' into 'primary'
* Chore: Only run functional test if previous jobs succeded
* [MKTP-1577] Fix for calculation of total price set in database
* [MKTP-1577] Automating refund created for delivery expiry pick events and storing route and status for the same in Returns Service
* [MKTP-1582]Storing Expired Collections and Deliveries in the Returns Service
* feat:[MKTP-1606] Handling deserialization error while consuming events and logging it
* [MKTP-1582] Storing Expired Collections and Deliveries in the Returns Service
* Merge branch 'chore_improve_loggigng_level' into 'primary'
* Chore: Improve logging level
* [MKTP-1595] Adding Kafka security protocol
* [MKTP-1595] Kafka consumer to consume PickEvents in Marketplace Returns Service

CHG0163676
---
2025-04-22
* feat:[MKTP-1660] Windsor Framework Return Filtering -  Set route to IForce for Northern Ireland store returns

CHG0163216
---
2025-04-02
* [MKTP-1684] CHG0163216 - Use default country code in recipient address in Carrier booking api request

CHG0161546_FIXES_0.2
---
2025-03-25
* fix: [MKTP-1678] Calling OR11 to get shop id while booking carrier if not stored already

CHG0161546_FIXES_0.1
---
2025-03-05
* [MKTP-1667] Replacing owasp dependency check job with GitLab dependency scanning job

CHG0161546
---
2025-01-31
* feat: [MKTP-1639] Storing shop id while saving the return lines
* Merge branch 'MKTP-1604' into 'primary'
* MKTP-1604 Test for creating a return order and deleting a return order

CHG0158872
---
2025-01-03
* Merge branch 'primary' of https://gitlab.kfplc.com/dcom-mktp/marketplace-returns-service into primary
* [MKTP-1576] Fixing wiremock changes for local
* fix:[MKTP-1590] Updating metric initialization logic to fix pod restart failure issue
* feat:[MKTP-1594] Introducing new endpoint for updating status & route manually
* [MKTP-1576] Fixing sonar issue
* Revert "[MKTP-1576] Fixing build issue"
* [MKTP-1576] Fixing detekt build issue
* [MKTP-1576] Fixing build issue
* [MKTP-1576] Change Returns Service to call OR11 for Shop ID

1733941519
---
2024-12-12
* chore: [MKTP-1579] Updating dt_servicenow_owner

1733918970
---
2024-12-11
* [MKTP-1579] Mapping the return reason instead of reason code in seller notification message for DPD

1733913877
---
2024-12-11
* fix:[MKTP-1580] Updating code to process mixed basket return PSO

CHG0158126_v1
---
2024-12-10
* [MKTP-1583] Increasing cpu
* [MKTP-1583] Increasing memory

CHG0158126
---
2024-12-10
* [MKTP-1583] Increasing cpu and memory for production

1733329930
---
2024-12-04
* [MKTP-1572] Logging carrier booking exception

1733309920
---
2024-12-04
* [MKTP-1572] Updating seller notification message for both DPD & iForce

1733232538
---
2024-12-03
* [MKTP-1559] Updating return tracking link URL

1732190785
---
2024-11-21
* feat:[MKTP-1561] Exposing GET endpoint to fetch return line details for a given return order number
* [MKTP-1558] chore: resolve CVEs
* Merge branch 'chore_add_.DS_Store_to_ignore' into 'primary'
* Chore add .ds store to ignore
* Merge branch 'MKTP-1550' into primary
* [MKTP-1543] Fixing intendation create table script
* [MKTP-1543] Updating folder name containing container setup files
* Merge branch 'primary_wiremock_POC' into 'primary'
* [MKTP-1543] POC for using wiremock instead of hitting actual endpoints for local machines
* [MKTP-1515] Adding another status while filtering returns
* [MKTP-1515] Fixing GSI issue for dynamoDB
* [MKTP-1515] Fixing syntax error for db deploy fail
* [MKTP-1515] Adding dependency failures
* [MKTP-1515] Correcting a syntax error in manifest template
* [MKTP-1515] Filtering out returns based on given conditions
* [MKTP-1501] Handled Carrier booking exception also modified Update route Journey.
* [MKTP-1502] Updating initial query logic to custom metric to track refund failed for DPD lines
* [MKTP-1502] Creating schedular and manual endpoint to generate refund and notify seller after storing return iForce line
* Merge tag '1726138401_v9' into primary
* Revert "[MKTP-1501] Initial Draft."
* [MKTP-1501] Initial Draft.
* [MKTP-1514] Updating example API Response in swagger to make in sink with actual response
* [MKTP-1514] Including details for API responses in delete endpoints
* [MKTP-1517] Returns Service Can't Support Carrier Bookings to Multiple Logistical Order Numbers
* [MKTP-1514] Fixing delete endpoint to delete return line and exposing endpoint to delete all lines of a given return order
* [MKTP-1479] Updaing logging statement if no return order is waiting for booking more than configured time
* [MKTP-1479] Introducing scheduler to log return orders awaiting for booking  more than 48hours
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1501] Handle exception at the time of carrier booking api call
* [MKTP-1479] Updating custom metrics logics based on current reason values
* Merge branch 'mktp-1444_Fix' into 'primary'
* Mktp-1444: Actuator fucntional script fix
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1490] Updating log level to reduce log
* [MKTP-1485] Changing the HFT functional test rule
* [MKTP-1485] Fixing build issue.
* [MKTP-1485] Decommissioning Marketplace Return services deployed in SIT
* Merge branch 'mktp-1444' into 'primary'
* Mktp-1444: Return microservice automation script MR
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v11
---
2024-11-11
* [MKTP-1550] Adding return order number to logger for carrier booking response

1726138401_v10
---
2024-11-08
* [MKTP-1550] Fix for dependency check failures in latest tag deployed in prod
* [MKTP-1550] Enabling hub stores in returns service

1730720072
---
2024-11-04
* [MKTP-1543] Fixing intendation create table script
* [MKTP-1543] Updating folder name containing container setup files

1730714940
---
2024-11-04
* Merge branch 'primary_wiremock_POC' into 'primary'
* [MKTP-1543] POC for using wiremock instead of hitting actual endpoints for local machines
* [MKTP-1515] Adding another status while filtering returns
* [MKTP-1515] Fixing GSI issue for dynamoDB
* [MKTP-1515] Fixing syntax error for db deploy fail
* [MKTP-1515] Adding dependency failures
* [MKTP-1515] Correcting a syntax error in manifest template
* [MKTP-1515] Filtering out returns based on given conditions
* [MKTP-1501] Handled Carrier booking exception also modified Update route Journey.
* [MKTP-1502] Updating initial query logic to custom metric to track refund failed for DPD lines
* [MKTP-1502] Creating schedular and manual endpoint to generate refund and notify seller after storing return iForce line
* Merge tag '1726138401_v9' into primary
* Revert "[MKTP-1501] Initial Draft."
* [MKTP-1501] Initial Draft.
* [MKTP-1514] Updating example API Response in swagger to make in sink with actual response
* [MKTP-1514] Including details for API responses in delete endpoints
* [MKTP-1517] Returns Service Can't Support Carrier Bookings to Multiple Logistical Order Numbers
* [MKTP-1514] Fixing delete endpoint to delete return line and exposing endpoint to delete all lines of a given return order
* [MKTP-1479] Updaing logging statement if no return order is waiting for booking more than configured time
* [MKTP-1479] Introducing scheduler to log return orders awaiting for booking  more than 48hours
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1501] Handle exception at the time of carrier booking api call
* [MKTP-1479] Updating custom metrics logics based on current reason values
* Merge branch 'mktp-1444_Fix' into 'primary'
* Mktp-1444: Actuator fucntional script fix
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1490] Updating log level to reduce log
* [MKTP-1485] Changing the HFT functional test rule
* [MKTP-1485] Fixing build issue.
* [MKTP-1485] Decommissioning Marketplace Return services deployed in SIT
* Merge branch 'mktp-1444' into 'primary'
* Mktp-1444: Return microservice automation script MR
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v9
---
2024-10-22
* [MKTP-1526] Fix for dependency check failure

1726138401_v8
---
2024-10-21
* [MKTP-1526] Enable Next Batch of Stores in Returns Service (Remaining Pilot Stores)
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1517] Resolving Carrier Bookings issue to support Multiple Logistical Order Numbers
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1504] changing mirakl client for notify seller

1728912796
---
2024-10-14
* [MKTP-1517] Returns Service Can't Support Carrier Bookings to Multiple Logistical Order Numbers
* [MKTP-1514] Fixing delete endpoint to delete return line and exposing endpoint to delete all lines of a given return order
* [MKTP-1479] Updaing logging statement if no return order is waiting for booking more than configured time
* [MKTP-1479] Introducing scheduler to log return orders awaiting for booking  more than 48hours
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1501] Handle exception at the time of carrier booking api call
* [MKTP-1479] Updating custom metrics logics based on current reason values
* Merge branch 'mktp-1444_Fix' into 'primary'
* Mktp-1444: Actuator fucntional script fix
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1490] Updating log level to reduce log
* [MKTP-1485] Changing the HFT functional test rule
* [MKTP-1485] Fixing build issue.
* [MKTP-1485] Decommissioning Marketplace Return services deployed in SIT
* Merge branch 'mktp-1444' into 'primary'
* Mktp-1444: Return microservice automation script MR
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v7
---
2024-10-10
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1517] Resolving Carrier Bookings issue to support Multiple Logistical Order Numbers
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1504] changing mirakl client for notify seller

1728544134
---
2024-10-10
* [MKTP-1479] Updaing logging statement if no return order is waiting for booking more than configured time
* [MKTP-1479] Introducing scheduler to log return orders awaiting for booking  more than 48hours
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1501] Handle exception at the time of carrier booking api call
* [MKTP-1479] Updating custom metrics logics based on current reason values
* Merge branch 'mktp-1444_Fix' into 'primary'
* Mktp-1444: Actuator fucntional script fix
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1490] Updating log level to reduce log
* [MKTP-1485] Changing the HFT functional test rule
* [MKTP-1485] Fixing build issue.
* [MKTP-1485] Decommissioning Marketplace Return services deployed in SIT
* Merge branch 'mktp-1444' into 'primary'
* Mktp-1444: Return microservice automation script MR
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v6
---
2024-10-09
* [MKTP-1517] Resolving Carrier Bookings issue to support Multiple Logistical Order Numbers
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1504] changing mirakl client for notify seller

1728386079
---
2024-10-08
* [MKTP-1479] Introducing scheduler to log return orders awaiting for booking  more than 48hours

1728033419
---
2024-10-04
* [MKTP-1512] Adding hedge end store ID in returns microservice
* [MKTP-1501] Handle exception at the time of carrier booking api call

1727883729
---
2024-10-02
* [MKTP-1479] Updating custom metrics logics based on current reason values
* Merge branch 'mktp-1444_Fix' into 'primary'
* Mktp-1444: Actuator fucntional script fix
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1490] Updating log level to reduce log
* [MKTP-1485] Changing the HFT functional test rule
* [MKTP-1485] Fixing build issue.
* [MKTP-1485] Decommissioning Marketplace Return services deployed in SIT
* Merge branch 'mktp-1444' into 'primary'
* Mktp-1444: Return microservice automation script MR
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v5
---
2024-09-26
* [MKTP-1507] Populate Return Address Attributes if They Are Missing
* [MKTP-1504] changing mirakl client for notify seller

1727104845
---
2024-09-24
* [MKTP-1500] Updating update route business logic to handle few split quantity scenarios

1727075545
---
2024-09-23
* [MKTP-1457] Exception handling for date format
* [MKTP-1457] Fixing date range validation for fetchReturnLine api endpoint
* [MKTP-1504] changing mirakl client for notify seller
* Merge branch 'MKTP-1499-V1' into primary
* Merge branch 'MKTP-1499' into primary
* Reapply "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401_v4
---
2024-09-19
* [MKTP-1504] changing mirakl client for notify seller

1726138401_v3
---
2024-09-17
* [MKTP-1499] Corrected the Reason code.

1726138401_v2
---
2024-09-16
* [MKTP-1499] Adding dependency

1726138401_v1
---
2024-09-16
* [MKTP-1499] Changing Pilot store ID

1726206852
---
2024-09-13
* [MKTP-1493] Correcting V tier mirakl url
* Revert "Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice""
* Reapply "[MKTP-1457] Exception handling for Marketplace Returns Microservice"

1726138401
---
2024-09-12
* [MKTP-1350] Dynamically configuring the channel name for MQ

1726134314
---
2024-09-12
* [MKTP-1350] Adding logger to obtain return order IDs
* [MKTP-1350] Deploy to Prod

1726058243
---
2024-09-11
* [MKTP-1424] Adding few changes in iForceTemplate text file

1725976814
---
2024-09-10
* Merge remote-tracking branch 'origin/MKTP-1427' into primary
* [MKTP-1427] Updating logic to fetch seller name if department name is empty

1725967435
---
2024-09-10
* Revert "[MKTP-1457] Exception handling for Marketplace Returns Microservice"
* [MKTP-1427] Using seller instore return address for carrier collection

1725897905
---
2024-09-09
* [MKTP-1493] Deploy Marketplace Returns Mircroservice in V Tier
* [MKTP-1457] Exception handling for Marketplace Returns Microservice

1725622885
---
2024-09-06
* [MKTP-1424] Populating iForce Message to Seller based on Reason for iForce

1725536086
---
2024-09-05
* [MKTP-1427] Fixing CarrierBooking URL path

1725461727
---
2024-09-04
* [MKTP-1427] Code cleanup changes for Carrier Booking API

1725293642
---
2024-09-03
* Revert "[MKTP-XXXX] Workaround for Dependency check failure."

1725290707
---
2024-09-02
* [MKTP-XXXX] Workaround for Dependency check failure.
* [MKTP-1425] Storing Reason For iForce When Automatically Assigning Product To iForce

1724859957
---
2024-08-29
* [MKTP-1483] Fixing SONAR issue
* [MKTP-1483] Capturing and storing two more attributes namely Display name and Primary Image from Product API Response

1724856515
---
2024-08-28
* [MKTP-1427] Fixing the logic to get the returnLineItems to be processed for carrier booking api

1724777249
---
2024-08-27
* [MKTP-1484] Supressing detekt errors
* [MKTP-1484] Adding log statement for updateRoute component

1724419801
---
2024-08-26
* [MKTP-1427] Adding vault  configuration
* [MKTP-1427] Book carrier collection for DPD lines

1724401255
---
2024-08-23
* [MKTP-1473] Adding the reason instead of reason code in Mirakl Notification template

1724313020
---
2024-08-22
* [MKTP-1348] Fixing configuration file by adding bean annotation
* [MKTP-1348] Introducing custom metrics to track data in Dashboard

1724259373
---
2024-08-21
* [MKTP-1484] Configuring piloted stores

1724254819
---
2024-08-21
* [MKTP-1439] Fixing changes for DPD file for notify seller email

1724243037
---
2024-08-21
* [MKTP-1470] Dynamically mapping logistical order ID from return PSO

1724156929
---
2024-08-21
* [MKTP-1473] Fixing the spelling of Parcel Tracking in both Update and Confirm route flow

1724152921
---
2024-08-20
* [MKTP-1439] Updating logic to fetch resource files
* [MKTP-1439] Updating dependency check plugin version
* [MKTP-1439] Fixing notification template path

1724059805
---
2024-08-19
* [MKTP-1439] Dynamically configuring JMS Listener in Return Service

1724057245
---
2024-08-19
* [MKTP-1473] Store the parcel tracking information as a List in DB

1723805009
---
2024-08-16
* [MKTP-1348] Exposing metrics endpoint to check the available metrics

1723478705
---
2024-08-13
* [MKTP-1443] Improving code coverage by adding unit test cases
* [MKTP-1439] Some more change regarding README file
* [MKTP-1439] Changes in README file for this service
* [MKTP-1439] Automate Message to Seller on DPD Returns
* [MKTP-1443] Fixing issues found after sonar analysis
* [MKTP-1443] Integrating sonar

1722597508
---
2024-08-02
* [MKTP-1347]- Fixing gitlab ci issue
* [MKTP-1347] Initial draft.
* [MKTP-1423] Checking if the list to save orders is not empty
* [MKTP-1460] Store Tracking Link(or ID) coming from DCA in ReturnLine
* [MKTP-1336] Fixing Mirakl refund creation issue
* [MKTP-1336] Fixing logistical order ID issue
* [MKTP-1336] Changes in marketplace-return-services README file done as a part of MKTP-1336
* [MKTP-1336] Store 3p return order attributes into DB from Queue
* [MKTP-1423] Applying spotless
* [MKTP-1423] Adding FakeUnleash configuration for Local
* [MKTP-1423] Adding store to inclusion list
* [MKTP-1342] Expose API endpoint to store label printing requested
* [MKTP-1423] Adding logic for Store ID Exclusion List For Rollout
* [MKTP-1340] Updating price for iForce line and reason for DPD line
* [MKTP-1417] Applying Enum constructor changes for Route type.
* [MKTP-1417] Updating undeploy db job
* [MKTP-1417] Upgrading jar version & data type of partition key
* [MKTP-1417] Storing few more attributes in DB and refactored Product API call
* [MKTP-1419] Add open api documentation for API endpoint and dependency vulnerability check for Marketplace Returns Service

1720073982
---
2024-07-04
* [MKTP-1340] Fixing partial DPD refund status updation

1720026879
---
2024-07-04
* [MKTP-1340] Exposing API endpoint to update route and handle iForce route update
* [MKTP-1013] RestTemplate bean fix
* [MKTP-1013] Implement business logic to determine iForce line
* [MKTP-1337] Call refund and notifySeller for Iforce
* [MKTP-1338] Mapping store id from db to api response
* [MKTP-1338] Changed Storeid mapping logic.
* [MKTP-1335] Mapping additional attributes for fetch return line api endpoint
* [MKTP-1339] Exposing API endpoint to fetch return line details filtered with tenant and store id for a specific date range
* [MKTP-1338] Store 3p return attributes in Dynamo DB
* [MKTP-1335] Updating table name config in env variable
* [MKTP-1335] Updating dynamodb table name config
* Revert "[MKTP-1335] added table name in envvariable file"
* [MKTP-1335] added table name in envvariable file
* [MKTP-1335] Provisioning DynamoDB in F tier
* Initial commit
* [MKTP-1000] Building API endpoint to accept list of EANs and total price combination to check whether lines need to be disposed or not
* [MKTP-873] Provisioning postgres db for service

