#!/bin/bash
set -e

TABLE_NAME="marketPlaceReturnService"
ENDPOINT_URL="http://localhost:8000"

# Check if the table exists
if aws dynamodb describe-table --table-name $TABLE_NAME --endpoint-url $ENDPOINT_URL >/dev/null 2>&1; then
    echo "Table $TABLE_NAME already exists. Skipping creation."
else
    echo "Table $TABLE_NAME does not exist. Creating..."

    aws dynamodb create-table \
        --table-name $TABLE_NAME \
        --attribute-definitions \
            AttributeName=return_order_number,AttributeType=N \
            AttributeName=line_number,AttributeType=N \
            AttributeName=store_id,AttributeType=S \
            AttributeName=returned_date_in_ms,AttributeType=N \
        --key-schema \
            AttributeName=return_order_number,KeyType=HASH \
            AttributeName=line_number,KeyType=RANGE \
        --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
        --global-secondary-indexes '[
            {
                "IndexName": "store_id_returned_date_in_ms_index",
                "KeySchema": [
                    {"AttributeName": "store_id", "KeyType": "HASH"},
                    {"AttributeName": "returned_date_in_ms", "KeyType": "RANGE"}
                ],
                "Projection": {
                    "ProjectionType": "ALL"
                },
                "ProvisionedThroughput": {
                    "ReadCapacityUnits": 5,
                    "WriteCapacityUnits": 5
                }
            }
        ]' \
        --endpoint-url $ENDPOINT_URL

    echo "Table $TABLE_NAME created successfully."
fi
