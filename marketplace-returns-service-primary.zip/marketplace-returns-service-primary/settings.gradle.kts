pluginManagement {
    repositories {
        mavenLocal()
        mavenCentral()
        maven {
            url = uri("https://nexus-internal-gts-prod.k8s.ap.digikfplc.com/repository/public-repo")
        }
        maven {
            url = uri("https://nexus.k8s.an.digikfplc.com/repository/maven-public")
        }
        maven {
            url = uri("https://packages.confluent.io/maven")
        }
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.5.0"
}
rootProject.name = "marketplace-returns-service"
include("functional-tests")
