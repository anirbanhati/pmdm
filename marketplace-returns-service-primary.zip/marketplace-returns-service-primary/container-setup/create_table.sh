#!/bin/bash
# Wait until DynamoDB Local is available
TIMEOUT=120  # 2 minutes timeout
COUNTER=0

until aws dynamodb list-tables --endpoint-url http://dynamodb:8000 --region eu-west-1 2>/dev/null; do
  echo "Waiting for DynamoDB Local to be ready... (${COUNTER}s/${TIMEOUT}s)"
  sleep 2
  COUNTER=$((COUNTER + 2))

  if [ $COUNTER -ge $TIMEOUT ]; then
    echo "Timeout waiting for DynamoDB Local to be ready!"
    exit 1
  fi
done

echo "DynamoDB Local is ready!"


# Check if the table already exists
if aws dynamodb list-tables --endpoint-url http://dynamodb:8000 --region eu-west-1 | grep -q "marketPlaceReturnService"; then
  echo "Table 'marketPlaceReturnService' already exists."
else
  aws dynamodb create-table \
    --table-name marketPlaceReturnService \
    --attribute-definitions AttributeName=return_order_number,AttributeType=N \
    AttributeName=line_number,AttributeType=N \
    AttributeName=store_id,AttributeType=S \
    AttributeName=returned_date_in_ms,AttributeType=N \
    --key-schema AttributeName=return_order_number,KeyType=HASH AttributeName=line_number,KeyType=RANGE \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --global-secondary-indexes 'IndexName=store_id_returned_date_in_ms_index,KeySchema=[{AttributeName=store_id,KeyType=HASH},{AttributeName=returned_date_in_ms,KeyType=RANGE}],Projection={ProjectionType=ALL},ProvisionedThroughput={ReadCapacityUnits=5,WriteCapacityUnits=5}' \
    --endpoint-url http://dynamodb:8000 \
    --region eu-west-1
    echo "Table 'marketPlaceReturnService' created successfully!"
fi